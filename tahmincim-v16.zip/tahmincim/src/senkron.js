// 🔄 Otomatik fikstür + canlı skor + robot tahmini (API-Football, ücretsiz paket)
// Sunucu olmadığı için bu işi admin telefonu yapar; sonuçlar Firestore'a yazılır, herkes görür.
import AsyncStorage from '@react-native-async-storage/async-storage';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';
import { getApiKey } from './veriApi';
import { evalMarket, normName } from './tema';
import { findTeam, saveTeam } from './topluluk';

const BASE = 'https://v3.football.api-sports.io';
const STATE_KEY = 'tahmincim_senkron';
const DAILY_BUDGET = 88;           // 100 hakkın 12'si teste ve yedeğe kalsın
const LIVE_EVERY = 6 * 60 * 1000;  // canlı güncelleme aralığı
const IMPORT_EVERY = 6 * 3600e3;   // fikstür yenileme aralığı

export const LIGLER = [
  [203, 'Süper Lig'], [204, '1. Lig'], [206, 'Türkiye Kupası'], [2, 'Şampiyonlar Ligi'], [3, 'Avrupa Ligi'], [848, 'Konferans Ligi'],
  [39, 'Premier Lig'], [140, 'La Liga'], [135, 'Serie A'], [78, 'Bundesliga'], [61, 'Ligue 1'],
];
const LIG_AD = Object.fromEntries(LIGLER);

let st = null;
let running = false;
const subs = new Set();
const utcDay = () => new Date().toISOString().slice(0, 10);

async function loadSt() {
  if (!st) { try { st = JSON.parse((await AsyncStorage.getItem(STATE_KEY)) || 'null'); } catch (e) { st = null; } }
  if (!st || st.day !== utcDay()) st = { day: utcDay(), calls: 0, lastImport: st?.lastImport || 0, lastLive: 0, pred: st?.pred || {}, log: [] };
  return st;
}
async function saveSt() {
  try { await AsyncStorage.setItem(STATE_KEY, JSON.stringify(st)); } catch (e) {}
  subs.forEach((f) => f({ ...st }));
}
export function senkronDinle(f) { subs.add(f); loadSt().then((s) => f({ ...s })); return () => subs.delete(f); }
function log(t) { st.log = [`${new Date().toTimeString().slice(0, 5)} ${t}`, ...(st.log || [])].slice(0, 8); }

async function api(path, key) {
  if (st.calls >= DAILY_BUDGET) throw new Error('Günlük sorgu hakkı doldu');
  st.calls++;
  const res = await fetch(BASE + path, { headers: { 'x-apisports-key': key } });
  const j = await res.json().catch(() => ({}));
  const errs = j && j.errors && (Array.isArray(j.errors) ? j.errors : Object.values(j.errors));
  if (errs && errs.length) throw new Error(errs.map(String).join(' · '));
  return j.response || [];
}

const ymdTR = (offsetDays = 0) => {
  const d = new Date(Date.now() + offsetDays * 864e5 + 3 * 3600e3); // Türkiye saati
  return d.toISOString().slice(0, 10);
};
function statusOf(short) {
  if (['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE', 'INT', 'SUSP'].includes(short)) return 'live';
  if (['FT', 'AET', 'PEN', 'AWD', 'WO'].includes(short)) return 'finished';
  return 'upcoming'; // NS, TBD, PST, CANC, ABD
}
const formTR = (f) => String(f || '').replace(/W/g, 'G').replace(/D/g, 'B').replace(/L/g, 'M').replace(/[^GBM]/g, '').slice(-5);
const pct = (x) => parseInt(String(x || '0').replace('%', ''), 10) || 0;

/* API tahmininden bizim tahmin alanlarımızı üret */
export function robotdan(p) {
  const pr = p.predictions || {};
  const ph = pct(pr.percent?.home); const pd = pct(pr.percent?.draw); const pa = pct(pr.percent?.away);
  const uo = String(pr.under_over || '');
  const uoN = parseFloat(uo.replace(/[^\d.]/g, '')) || 0;
  let market = '';
  if (ph >= 50) market = 'MS 1';
  else if (pa >= 50) market = 'MS 2';
  else if (uo.startsWith('+') && uoN >= 2.5) market = '2.5 Üst';
  else if (uo.startsWith('-') && uoN <= 2.5 && uoN > 0) market = '2.5 Alt';
  else if (ph + pd >= 70) market = '1X';
  else if (pa + pd >= 70) market = 'X2';
  else if (ph || pa) market = ph >= pa ? '1X' : 'X2';
  const top = Math.max(ph, pa, ph + pd > 75 || pa + pd > 75 ? 55 : 0);
  const conf = top >= 55 ? 3 : top >= 45 ? 2 : 1;
  const cmp = p.comparison || {};
  const satir = (l, k) => (cmp[k] ? `${l}: ev ${cmp[k].home} · dep ${cmp[k].away}` : null);
  const reasons = [satir('Form', 'form'), satir('Hücum', 'att'), satir('Savunma', 'def'), satir('Aralarındaki maçlar', 'h2h')].filter(Boolean).join('\n');
  const h2h = (p.h2h || []).slice(0, 5).map((f) => `${f.teams?.home?.name} ${f.goals?.home ?? '-'}-${f.goals?.away ?? '-'} ${f.teams?.away?.name}`).join('\n');
  return {
    market, conf, reasons, h2h,
    p1: ph ? String(ph) : '', px: pd ? String(pd) : '', p2: pa ? String(pa) : '',
    homeForm: formTR(p.teams?.home?.league?.form), awayForm: formTR(p.teams?.away?.league?.form),
    text: market ? `🤖 Robot analizi: ev %${ph} · beraberlik %${pd} · deplasman %${pa}${uo ? ` · gol beklentisi ${uo.startsWith('+') ? 'üst' : 'alt'} ${uoN}` : ''}` : '',
    robot: true,
  };
}

export function canliAlanlar(f, m) {
  const short = f.fixture?.status?.short || 'NS';
  const status = statusOf(short);
  const out = { status, afStatus: short, updatedAt: Date.now() };
  if (status !== 'upcoming') out.score = `${f.goals?.home ?? 0}-${f.goals?.away ?? 0}`;
  if (status === 'live') {
    const el = f.fixture?.status?.elapsed;
    out.minute = short !== 'HT' && el ? String(el) : '';
    out.minuteAt = out.minute ? Date.now() : 0;
  } else { out.minute = ''; out.minuteAt = 0; }
  if (status === 'finished' && m && m.market && !m.result) {
    const r = evalMarket(m.market, { status: 'finished', score: out.score });
    if (r) out.result = r;
  }
  return out;
}

/* Fikstürü içeri al (bugün + yarın) */
async function fiksturAl(key, cfg, list, teams) {
  const lig = (cfg.auto?.leagues || [203]).map(Number);
  const byId = {}; list.forEach((m) => { byId[m.id] = m; });
  let yeni = 0; let guncel = 0;
  for (const off of [0, 1]) {
    const day = ymdTR(off);
    const fx = await api(`/fixtures?date=${day}&timezone=Europe/Istanbul`, key);
    for (const f of fx) {
      if (!lig.includes(f.league?.id)) continue;
      const id = 'af_' + f.fixture.id;
      const old = byId[id];
      const iso = String(f.fixture?.date || '');
      const date = iso.slice(0, 10); const time = iso.slice(11, 16);
      if (old) {
        const c = canliAlanlar(f, old);
        await updateDoc(doc(db, 'matches', id), { ...c, date, time }).catch(() => {});
        guncel++;
        continue;
      }
      const hn = f.teams?.home?.name || ''; const an = f.teams?.away?.name || '';
      const ht = findTeam(teams, hn); const at = findTeam(teams, an);
      const homeLogo = ht?.logo || f.teams?.home?.logo || '';
      const awayLogo = at?.logo || f.teams?.away?.logo || '';
      if (!ht && homeLogo) saveTeam(hn, homeLogo).catch(() => {});
      if (!at && awayLogo) saveTeam(an, awayLogo).catch(() => {});
      let rob = {};
      if (!st.pred[f.fixture.id] && st.calls < DAILY_BUDGET - 12) {
        try { const p = await api(`/predictions?fixture=${f.fixture.id}`, key); if (p[0]) rob = robotdan(p[0]); st.pred[f.fixture.id] = 1; }
        catch (e) { st.pred[f.fixture.id] = 1; if (!st.predErr) { st.predErr = e.message; log('Robot tahmini alınamadı: ' + e.message); } }
      }
      const draft = cfg.auto?.publish === 'draft' || !rob.market;
      const m = {
        id, afId: f.fixture.id, auto: true, draft,
        home: ht ? ht.name : hn, away: at ? at.name : an, homeLogo, awayLogo,
        league: LIG_AD[f.league?.id] || f.league?.name || '', date, time,
        market: rob.market || '', marketOther: '', text: rob.text || '', conf: rob.conf || 2, reasons: rob.reasons || '',
        access: cfg.auto?.access || 'open', cost: (cfg.auto?.access || 'open') === 'open' ? 1 : 2, banko: false,
        score: '', minute: '', minuteAt: 0, liveText: '', result: '', odd: '',
        p1: rob.p1 || '', px: rob.px || '', p2: rob.p2 || '', homeForm: rob.homeForm || '', awayForm: rob.awayForm || '', h2h: rob.h2h || '', robot: !!rob.robot,
        status: 'upcoming', updatedAt: Date.now(),
        ...canliAlanlar(f, { market: rob.market }),
      };
      const { id: _i, ...rest } = m;
      await setDoc(doc(db, 'matches', id), rest).catch(() => {});
      yeni++;
    }
  }
  st.lastImport = Date.now();
  log(`Fikstür: ${yeni} yeni, ${guncel} güncellendi`);
  return { yeni, guncel };
}

/* Canlı skorları güncelle */
async function canliGuncelle(key, list) {
  const now = Date.now();
  const izle = list.filter((m) => m.afId && m.status !== 'finished' && !['PST', 'CANC', 'ABD'].includes(m.afStatus)).filter((m) => {
    const [y, mo, d] = String(m.date).split('-').map(Number); const [h, mi] = String(m.time).split(':').map(Number);
    const ks = new Date(y, mo - 1, d, h || 0, mi || 0).getTime();
    return m.status === 'live' || (now >= ks - 5 * 60000 && now <= ks + 150 * 60000);
  });
  if (!izle.length) return 0;
  const byAf = {}; izle.forEach((m) => { byAf[m.afId] = m; });
  const ids = izle.map((m) => m.afId).slice(0, 20).join('-');
  let fx;
  try { fx = await api(`/fixtures?ids=${ids}&timezone=Europe/Istanbul`, key); }
  catch (e) { fx = await api('/fixtures?live=all&timezone=Europe/Istanbul', key); }
  let n = 0;
  for (const f of fx) {
    const m = byAf[f.fixture?.id];
    if (!m) continue;
    const c = canliAlanlar(f, m);
    if (c.status !== m.status || c.score !== m.score || c.afStatus !== m.afStatus || c.minute !== m.minute || c.result) {
      await updateDoc(doc(db, 'matches', m.id), c).catch(() => {});
      n++;
    }
  }
  st.lastLive = Date.now();
  if (n) log(`Canlı: ${n} maç güncellendi`);
  return n;
}

/* Ana döngü: App her dakika çağırır */
export async function senkronTick({ cfg, list, teams, force }) {
  if (running || !cfg?.auto?.on) return;
  running = true;
  try {
    await loadSt();
    const key = await getApiKey();
    if (!key) { running = false; return; }
    if (force || !st.lastImport || Date.now() - st.lastImport > IMPORT_EVERY || new Date(st.lastImport).toDateString() !== new Date().toDateString()) {
      await fiksturAl(key, cfg, list, teams);
    } else if (Date.now() - (st.lastLive || 0) >= LIVE_EVERY) {
      await canliGuncelle(key, list);
    }
  } catch (e) {
    log('Hata: ' + (e.message || 'bağlantı'));
  }
  await saveSt();
  running = false;
}
export { normName };
