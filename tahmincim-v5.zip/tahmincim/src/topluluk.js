// Topluluk: takımlar, beğeni, yorum, Tribün kuponları, şikayetler
import { useEffect, useState } from 'react';
import { collection, doc, onSnapshot, setDoc, deleteDoc, addDoc, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { db, configured } from './firebase';
import { normName, teamId } from './tema';

function useQuery(build, deps, enabled = true) {
  const [state, setState] = useState({ list: [], loading: true });
  useEffect(() => {
    if (!configured || !enabled) return;
    let q;
    try { q = build(); } catch (e) { setState({ list: [], loading: false }); return; }
    return onSnapshot(q, (snap) => setState({ list: snap.docs.map((d) => ({ id: d.id, ...d.data() })), loading: false }),
      () => setState((x) => ({ ...x, loading: false, error: true })));
  }, deps); // eslint-disable-line
  return state;
}

/* ---------- Takım kütüphanesi ---------- */
export const useTeams = () => useQuery(() => collection(db, 'teams'), []);
export const saveTeam = (name, logo) =>
  setDoc(doc(db, 'teams', teamId(name)), { name: String(name).trim(), logo: logo || '', key: normName(name), updatedAt: Date.now() });
export const removeTeam = (id) => deleteDoc(doc(db, 'teams', id));
export function findTeam(teams, name) {
  const k = normName(name);
  return (teams || []).find((t) => t.key === k || normName(t.name) === k) || null;
}
export function suggestTeams(teams, text) {
  const k = normName(text);
  if (k.length < 2) return [];
  return (teams || []).filter((t) => (t.key || normName(t.name)).includes(k) && (t.key || normName(t.name)) !== k).slice(0, 5);
}
// Maçlardaki logoları kütüphaneye aktarır (bir kerelik)
export async function importTeamsFromMatches(matches, teams) {
  let n = 0;
  for (const m of matches) {
    for (const [name, logo] of [[m.home, m.homeLogo], [m.away, m.awayLogo]]) {
      if (!name || !logo) continue;
      const t = findTeam(teams, name);
      if (t && t.logo) continue;
      try { await saveTeam(name, logo); n++; teams = [...teams, { name, logo, key: normName(name) }]; } catch (e) {}
    }
  }
  return n;
}

/* ---------- Beğeni (👍 / 👎) ---------- */
export function useVotes(target) {
  const st = useQuery(() => query(collection(db, 'votes'), where('target', '==', target)), [target], !!target);
  return st.list;
}
export async function castVote(target, uid, v, current) {
  const ref = doc(db, 'votes', `${target}__${uid}`);
  if (current === v) return deleteDoc(ref);
  return setDoc(ref, { target, uid, v, at: Date.now() });
}

/* ---------- Yorumlar ---------- */
const KOTU = ['amk', 'aq', 'orospu', 'piç', 'pic', 'siktir', 'sik', 'yarrak', 'göt', 'got', 'ibne', 'pezevenk', 'kahpe', 'oç', 'amına', 'amina', 'sikerim', 'gavat'];
export function cleanText(t) {
  let out = String(t || '');
  KOTU.forEach((w) => {
    const re = new RegExp(`(^|[^a-zçğıöşü])(${w})(?=$|[^a-zçğıöşü])`, 'gi');
    out = out.replace(re, (m0, p1, p2) => p1 + '*'.repeat(p2.length));
  });
  return out;
}
export function useComments(target) {
  const st = useQuery(() => query(collection(db, 'comments'), where('target', '==', target)), [target], !!target);
  return { ...st, list: [...st.list].sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)) };
}
export const addComment = (target, uid, name, text, admin) =>
  addDoc(collection(db, 'comments'), { target, uid, name: String(name || 'Üye').slice(0, 40), text: cleanText(text).slice(0, 500), createdAt: Date.now(), admin: !!admin });
export const deleteComment = (id) => deleteDoc(doc(db, 'comments', id));
export const useRecentComments = (enabled) =>
  useQuery(() => query(collection(db, 'comments'), orderBy('createdAt', 'desc'), limit(100)), [], enabled);

/* ---------- Tribün ---------- */
export const useTribune = () =>
  useQuery(() => query(collection(db, 'tribune'), orderBy('createdAt', 'desc'), limit(300)), []);
export const addTribune = (uid, name, picks, admin) =>
  addDoc(collection(db, 'tribune'), { uid, name: String(name || 'Üye').slice(0, 40), picks, createdAt: Date.now(), admin: !!admin });
export const deleteTribune = (id) => deleteDoc(doc(db, 'tribune', id));

/* ---------- Şikayetler ---------- */
export const addReport = (kind, refId, text, reporter) =>
  addDoc(collection(db, 'reports'), { kind, refId, text: String(text || '').slice(0, 300), reporter, createdAt: Date.now() });
export const useReports = (enabled) =>
  useQuery(() => query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(100)), [], enabled);
export const deleteReport = (id) => deleteDoc(doc(db, 'reports', id));
export async function deleteReportsFor(refId) {
  const snap = await getDocs(query(collection(db, 'reports'), where('refId', '==', refId)));
  for (const d of snap.docs) { try { await deleteDoc(d.ref); } catch (e) {} }
}
