import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Alert } from 'react-native';
import { C } from '../tema';
import { Icon, s, useTheme, useToast, Sheet, Btn, Tik } from '../parcalar';
import { useVotes, castVote, useComments, addComment, deleteComment, addReport } from '../topluluk';

export function onceLabel(ms) {
  const d = Math.max(0, Date.now() - (ms || 0)) / 1000;
  if (d < 60) return 'az önce';
  if (d < 3600) return `${Math.floor(d / 60)} dk önce`;
  if (d < 86400) return `${Math.floor(d / 3600)} sa önce`;
  return `${Math.floor(d / 86400)} gün önce`;
}

/* 👍 / 👎 katılıyorum çubuğu */
export function VoteBar({ target, me, onNeedAuth, compact }) {
  const t = useTheme();
  const toast = useToast();
  const votes = useVotes(target);
  const up = votes.filter((v) => v.v === 1).length;
  const down = votes.filter((v) => v.v === -1).length;
  const mine = me && !me.guest ? (votes.find((v) => v.uid === me.id) || {}).v : undefined;
  const total = up + down;
  const pct = total ? Math.round((up / total) * 100) : 0;
  const vote = async (v) => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    try { await castVote(target, me.id, v, mine); } catch (e) { toast('Oy verilemedi'); }
  };
  const B = ({ v, icon, label, n }) => {
    const on = mine === v;
    return (
      <Pressable onPress={() => vote(v)} accessibilityRole="button" accessibilityState={{ selected: on }}
        style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 44, borderRadius: 14, borderWidth: on ? 2 : 1.5, borderColor: on ? (v === 1 ? t.acc : C.red) : C.border, backgroundColor: on ? (v === 1 ? C.okBg : C.redBg) : C.card }}>
        <Icon name={icon} size={18} color={on ? (v === 1 ? C.okTx : C.red) : C.mut} />
        <Text style={{ fontWeight: '700', color: on ? (v === 1 ? C.okTx : C.red) : C.ink }}>{label}{compact ? '' : ` · ${n}`}</Text>
      </Pressable>
    );
  };
  return (
    <View style={{ marginTop: 12 }}>
      {total ? (
        <View style={{ marginBottom: 8 }}>
          <View style={{ flexDirection: 'row', height: 8, borderRadius: 6, overflow: 'hidden', backgroundColor: C.redBg }}>
            <View style={{ width: `${pct}%`, backgroundColor: t.acc }} />
          </View>
          <Text style={{ color: C.mut, fontSize: 13, marginTop: 4 }}>Kullanıcıların %{pct}'i bu tahmine katılıyor ({total} oy)</Text>
        </View>
      ) : null}
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <B v={1} icon="thumbs-up" label="Katılıyorum" n={up} />
        <B v={-1} icon="thumbs-down" label="Katılmıyorum" n={down} />
      </View>
    </View>
  );
}

/* Yorumlar */
export function Yorumlar({ target, me, isAdmin, onNeedAuth }) {
  const t = useTheme();
  const toast = useToast();
  const { list } = useComments(target);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    const v = text.trim();
    if (v.length < 2) return;
    setBusy(true);
    try { await addComment(target, me.id, isAdmin ? (me.adminName || me.name || 'Admin') : (me.name || 'Üye'), v, isAdmin); setText(''); } catch (e) { toast('Gönderilemedi'); }
    setBusy(false);
  };
  const more = (c) => {
    const own = me && c.uid === me.id;
    const btns = [{ text: 'Vazgeç', style: 'cancel' }];
    if (own || isAdmin) btns.push({ text: 'Sil', style: 'destructive', onPress: () => deleteComment(c.id).then(() => toast('Yorum silindi')).catch(() => toast('Silinemedi')) });
    if (!own && me && !me.guest) btns.push({ text: 'Şikayet et', onPress: () => addReport('comment', c.id, c.text, me.id).then(() => toast('Teşekkürler, inceleyeceğiz')).catch(() => toast('Gönderilemedi')) });
    Alert.alert('Yorum', c.text.slice(0, 80), btns);
  };
  return (
    <View style={{ marginTop: 16 }}>
      <Text style={[s.h3, { marginBottom: 8 }]}>💬 Yorumlar {list.length ? `(${list.length})` : ''}</Text>
      {!list.length ? <Text style={[s.sub, { marginBottom: 8 }]}>İlk yorumu sen yaz!</Text> : list.map((c) => (
        <Pressable key={c.id} onLongPress={() => more(c)} onPress={() => more(c)} style={{ backgroundColor: C.bg, borderRadius: 14, padding: 12, marginBottom: 8 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, flexShrink: 1 }}>
              <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink, flexShrink: 1 }}>{c.name || 'Üye'}{me && c.uid === me.id ? ' (sen)' : ''}</Text>
              {c.admin ? <Tik size={15} label="Admin" /> : null}
            </View>
            <Text style={{ color: C.mut, fontSize: 12 }}>{onceLabel(c.createdAt)} ⋯</Text>
          </View>
          <Text style={{ color: C.ink, lineHeight: 20 }}>{c.text}</Text>
        </Pressable>
      ))}
      {me && !me.guest ? (
        <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', marginTop: 4 }}>
          <TextInput value={text} onChangeText={setText} placeholder="Yorumunu yaz…" placeholderTextColor={C.mut} multiline maxLength={500} accessibilityLabel="Yorum"
            style={[s.input, { flex: 1, minHeight: 46, maxHeight: 120 }]} />
          <Pressable onPress={send} disabled={busy} accessibilityLabel="Gönder" style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', opacity: busy ? 0.5 : 1 }}>
            <Icon name="send" size={20} color={t.onAcc} />
          </Pressable>
        </View>
      ) : (
        <Btn small kind="out" title="Yorum yazmak için giriş yap" onPress={onNeedAuth} />
      )}
      <Text style={[s.note, { marginTop: 8 }]}>Bir yoruma dokunarak silebilir ya da şikayet edebilirsin.</Text>
    </View>
  );
}

/* Kupon için beğeni + yorum penceresi */
export function EtkilesimPenceresi({ target, title, me, isAdmin, onNeedAuth, onClose }) {
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>{title}</Text>
      <VoteBar target={target} me={me} onNeedAuth={onNeedAuth} />
      <Yorumlar target={target} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} />
    </Sheet>
  );
}
