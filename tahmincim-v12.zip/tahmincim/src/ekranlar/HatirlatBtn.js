import React, { useState } from 'react';
import { Pressable, Text } from 'react-native';
import { C, canPredictScore } from '../tema';
import { Icon, useToast } from '../parcalar';
import { useReminders, addReminder, removeReminder } from '../hatirlat';

// Maçtan 15 dk önce hatırlat butonu
export default function HatirlatBtn({ m, compact }) {
  const map = useReminders();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!m || !canPredictScore(m)) return null;
  const on = !!map[m.id] && !map[m.id].off;
  const press = async () => {
    if (busy) return;
    setBusy(true);
    if (on) { await removeReminder(m.id); toast('Hatırlatıcı kapatıldı'); }
    else {
      const r = await addReminder(m);
      toast(r === 'ok' ? '🔔 Maçtan 15 dk önce hatırlatacağız' : r === 'perm' ? 'Bildirim izni vermen gerekiyor' : r === 'past' ? 'Maç başlamak üzere' : 'Hatırlatıcı kurulamadı');
    }
    setBusy(false);
  };
  if (compact) {
    return (
      <Pressable onPress={press} accessibilityRole="button" accessibilityLabel={on ? 'Hatırlatıcıyı kapat' : 'Maçı hatırlat'} hitSlop={6}
        style={{ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.lockBg : 'transparent' }}>
        <Icon name={on ? 'notifications' : 'notifications-outline'} size={20} color={on ? C.lockTx : C.mut} />
      </Pressable>
    );
  }
  return (
    <Pressable onPress={press} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, minHeight: 46, borderRadius: 14, marginTop: 12, backgroundColor: on ? C.lockBg : C.bg, borderWidth: 1, borderColor: on ? C.lockBg : C.border }}>
      <Icon name={on ? 'notifications' : 'notifications-outline'} size={20} color={on ? C.lockTx : C.ink} />
      <Text style={{ fontWeight: '700', color: on ? C.lockTx : C.ink }}>{on ? 'Hatırlatıcı açık · kapat' : 'Maçtan 15 dk önce hatırlat'}</Text>
    </Pressable>
  );
}
