import React, { useState } from 'react';
import { View, Text, Pressable, Modal, ScrollView, Image, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import { C, MARKETS, marketText, today, dayOff, newId, isImg, predText, oddOf, couponPicks, couponTotal, couponStatus, dayLabel, successStats } from '../tema';
import { Btn, Card, Crest, Field, Icon, Seg, Toggle, s, useToast, useKeyboardHeight } from '../parcalar';
import { saveMatch, removeMatch, saveConfig, clearBanko, logout, useUsers, updateUser, saveCoupon, removeCoupon, grantRole, useRoles, modLog, useModLog } from '../veri';
import { sendPushAll, countDevices, notifHistory } from '../bildirim';
import { useTeams, saveTeam, removeTeam, findTeam, suggestTeams, importTeamsFromMatches, useRecentComments, deleteComment, useReports, deleteReport, deleteReportsFor, useTribune, deleteTribune, countCollection, useViewCounts, useFeedback, deleteFeedback } from '../topluluk';
import { onceLabel } from './Etkilesim';

/* Görseli küçültüp veritabanına sığacak hale getirir */
async function pickImage(maxSide, jpeg) {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('perm');
  const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 1, allowsEditing: !jpeg, aspect: [1, 1] });
  if (res.canceled || !res.assets?.length) return null;
  const a = res.assets[0];
  if (typeof ImageManipulator.manipulateAsync !== 'function') {
    // Yedek yol: küçültme aracı yoksa düşük kalitede yeniden seç
    const r2 = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.2, base64: true, allowsEditing: true, aspect: jpeg ? [3, 1] : [1, 1] });
    if (r2.canceled || !r2.assets?.[0]?.base64) return null;
    const u = `data:image/jpeg;base64,${r2.assets[0].base64}`;
    if (u.length > 300000) throw new Error('big');
    return u;
  }
  const scale = Math.min(1, maxSide / Math.max(a.width || maxSide, a.height || maxSide));
  const out = await ImageManipulator.manipulateAsync(
    a.uri,
    scale < 1 ? [{ resize: { width: Math.round((a.width || maxSide) * scale) } }] : [],
    { compress: jpeg ? 0.8 : 1, format: jpeg ? ImageManipulator.SaveFormat.JPEG : ImageManipulator.SaveFormat.PNG, base64: true }
  );
  const url = `data:image/${jpeg ? 'jpeg' : 'png'};base64,${out.base64}`;
  if (url.length > 300000) throw new Error('big');
  return url;
}

function Header({ title, onBack, right }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 }}>
      <Pressable onPress={onBack} accessibilityLabel="Geri" style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="chevron-back" />
      </Pressable>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 12, fontWeight: '700', letterSpacing: 1, color: C.mut }}>YÖNETİM PANELİ</Text>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{title}</Text>
      </View>
      {right}
    </View>
  );
}

const ACCESS = { open: 'Açık', locked: 'Kilitli', vip: 'VIP' };

export default function Admin({ visible, onClose, matches, coupons, cfg, startWith, me, perm = {} }) {
  const ins = useSafeAreaInsets();
  const kb = useKeyboardHeight();
  const [page, setPage] = useState('list');
  const [m, setM] = useState(null);
  const [c, setC] = useState(null);
  const [uid, setUid] = useState(null);
  const [co, setCo] = useState(null);
  const [listTab, setListTab] = useState('matches');
  const users = useUsers(visible && (page === 'users' || page === 'user'));
  const teams = useTeams();
  const roles = useRoles(visible && (page === 'users' || page === 'user'));
  const home = perm.admin ? 'list' : 'community';
  const goHome = () => setPage(home);

  React.useEffect(() => {
    if (visible && startWith === 'new' && perm.admin) { setM(blank()); setPage('match'); }
    else if (visible) setPage(home);
  }, [visible, startWith, home]);

  const blankCoupon = () => ({ id: newId(), title: 'Günün Kuponu', date: today(), access: 'locked', cost: 5, picks: [], isNew: true });
  const blank = () => ({ id: newId(), odd: '', home: '', away: '', homeLogo: '', awayLogo: '', league: '', date: today(), time: '20:00', market: 'MS 1', marketOther: '', text: '', conf: 3, reasons: '', access: 'open', cost: 1, banko: false, status: 'upcoming', score: '', minute: '', liveText: '', result: '', p1: '', px: '', p2: '', isNew: true });

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={() => (page === home ? onClose() : page === 'user' ? setPage('users') : goHome())} statusBarTranslucent>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.adminBg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 16, paddingTop: ins.top + 16, paddingBottom: ins.bottom + 40 + kb }} keyboardShouldPersistTaps="handled">
          {page === 'list' ? (
            <List matches={matches} coupons={coupons} tab={listTab} setTab={setListTab} onClose={onClose}
              onNewCoupon={() => { setCo(blankCoupon()); setPage('coupon'); }}
              onEditCoupon={(x) => { setCo(JSON.parse(JSON.stringify({ ...x, picks: x.picks || [] }))); setPage('coupon'); }}
              onNew={() => { setM(blank()); setPage('match'); }}
              onEdit={(x) => { setM({ ...x }); setPage('match'); }}
              onCfg={() => { setC(JSON.parse(JSON.stringify(cfg))); setPage('cfg'); }}
              onUsers={() => setPage('users')} onPush={() => setPage('push')} onTeams={() => setPage('teams')} onCommunity={() => setPage('community')} onStats={() => setPage('stats')} perm={perm} />
          ) : page === 'match' && m ? (
            <MatchForm m={m} setM={setM} all={matches.list} teams={teams.list} cfg={cfg} onBack={() => setPage('list')} />
          ) : page === 'cfg' && c && perm.owner ? (
            <CfgForm c={c} setC={setC} onBack={() => setPage('list')} />
          ) : page === 'coupon' && co ? (
            <CouponForm co={co} setCo={setCo} matches={matches} cfg={cfg} onBack={() => setPage('list')} />
          ) : page === 'stats' ? (
            <Istatistik matches={matches} coupons={coupons} onBack={() => setPage('list')} />
          ) : page === 'teams' ? (
            <Takimlar teams={teams} matches={matches} onBack={() => setPage('list')} />
          ) : page === 'community' ? (
            <Topluluk matches={matches} me={me} perm={perm} onBack={perm.admin ? goHome : onClose} onUsers={() => setPage('users')} />
          ) : page === 'push' ? (
            <Bildirim cfg={cfg} onBack={() => setPage('list')} />
          ) : page === 'users' ? (
            <Users users={users} roles={roles} onBack={goHome} onOpen={(id) => { setUid(id); setPage('user'); }} />
          ) : page === 'user' ? (
            <UserDetail u={users.list.find((x) => x.id === uid)} role={(roles.find((r) => r.id === uid) || {}).role || ''} me={me} perm={perm} onBack={() => setPage('users')} />
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

/* ---------------- Maç listesi ---------------- */
function List({ matches, coupons, tab, setTab, onClose, onNew, onEdit, onCfg, onUsers, onPush, onTeams, onCommunity, onStats, onNewCoupon, onEditCoupon, perm = {} }) {
  const ms = [...matches.list].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time));
  const cs = [...(coupons?.list || [])].sort((a, b) => String(b.date).localeCompare(a.date));
  const views = useViewCounts(tab === 'coupons' ? cs.slice(0, 30).map((x) => 'c_' + x.id) : ms.slice(0, 40).map((x) => 'm_' + x.id));
  const Goz = ({ k }) => (views[k] != null ? (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
      <Icon name="eye-outline" size={15} color={C.mut} />
      <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13 }}>{views[k]}</Text>
    </View>
  ) : null);
  return (
    <View>
      <Header title="Maçlar" onBack={onClose}
        right={<Pressable onPress={() => logout().then(onClose)} accessibilityLabel="Çıkış yap" style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}><Icon name="log-out-outline" /></Pressable>} />
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
        <Btn small kind="ink" title="+ Yeni maç" onPress={onNew} style={{ flex: 1 }} />
        <Btn small kind="ink" title="+ Yeni kupon" onPress={onNewCoupon} style={{ flex: 1 }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
        <Btn small kind="out" title="Kullanıcılar" icon="people-outline" onPress={onUsers} style={{ flex: 1 }} />
        {perm.owner ? <Btn small kind="out" title="Ayarlar" icon="settings-outline" onPress={onCfg} style={{ flex: 1 }} /> : null}
      </View>
      <View style={{ flexDirection: 'row', gap: 8, marginTop: -8, marginBottom: 8 }}>
        <Btn small kind="out" title="Takımlar" icon="shield-outline" onPress={onTeams} style={{ flex: 1 }} />
        <Btn small kind="out" title="Topluluk" icon="chatbubbles-outline" onPress={onCommunity} style={{ flex: 1 }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
        <Btn small kind="out" title="Bildirim gönder" icon="notifications-outline" onPress={onPush} style={{ flex: 1 }} />
        <Btn small kind="out" title="İstatistik" icon="stats-chart-outline" onPress={onStats} style={{ flex: 1 }} />
      </View>
      <Seg value={tab} onChange={setTab} options={[['matches', `Maçlar (${matches.list.length})`], ['coupons', `Kuponlar (${(coupons?.list || []).length})`]]} />
      <Text style={[s.sub, { fontSize: 13, marginTop: -4, marginBottom: 8 }]}>👁 = tahmini kaç farklı kişi gördü</Text>
      {tab === 'coupons' ? (
        cs.length ? cs.map((x) => {
          const pk = couponPicks(x, matches.list);
          const st = couponStatus(pk);
          const tot = couponTotal(pk);
          return (
            <Pressable key={x.id} onPress={() => onEditCoupon(x)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
              <Icon name="receipt-outline" size={26} />
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.title || 'Kupon'} · {pk.length} maç</Text>
                <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>
                  {x.date} · Oran {tot ? tot.toFixed(2) : '—'} · {ACCESS[x.access] || ''} · {st === 'won' ? 'Kazandı' : st === 'lost' ? 'Kaybetti' : 'Bekliyor'}
                </Text>
              </View>
              <Goz k={'c_' + x.id} />
              <Icon name="chevron-forward" color={C.mut} size={18} />
            </Pressable>
          );
        }) : <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Henüz kupon yok</Text><Text style={s.sub}>"+ Yeni kupon" ile oluştur.</Text></View>
      ) : ms.length ? ms.map((x) => (
        <Pressable key={x.id} onPress={() => onEdit(x)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
          <Crest name={x.home} logo={x.homeLogo} size={34} />
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.home} – {x.away}</Text>
            <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>
              {x.date} {x.time} · {x.market} · {ACCESS[x.access] || ''}{x.banko ? ' · Banko' : ''}{x.hidden ? ' · Sadece kupon' : ''}{x.status === 'live' ? ' · CANLI' : x.status === 'finished' ? ' · Bitti' : ''}
            </Text>
          </View>
          <Goz k={'m_' + x.id} />
          <Icon name="chevron-forward" color={C.mut} size={18} />
        </Pressable>
      )) : (
        <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Henüz maç yok</Text><Text style={s.sub}>"+ Yeni maç" ile ilk tahminini ekle.</Text></View>
      )}
    </View>
  );
}

/* ---------------- Maç ekle / düzenle ---------------- */
function MatchForm({ m, setM, all, teams, cfg, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const F = (k, v) => setM((x) => ({ ...x, [k]: v }));
  const autoText = marketText(m.market, m.home, m.away);

  const pickLogo = async (k) => {
    try { const u = await pickImage(128, false); if (u) F(k, u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const pickMarket = (k) => setM((x) => ({ ...x, market: k, text: !x.text || x.text === marketText(x.market, x.home, x.away) ? '' : x.text }));

  const publish = async () => {
    if (!m.home.trim() || !m.away.trim()) return toast('İki takımın adını da yaz');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(m.date)) return toast('Tarihi 2026-11-21 biçiminde yaz');
    const out = { ...m };
    delete out.isNew;
    if (out.market === 'Diğer' && out.marketOther) out.market = out.marketOther.trim();
    out.home = out.home.trim();
    out.away = out.away.trim();
    if (!out.text) out.text = marketText(out.market, out.home, out.away) || out.market;
    out.cost = Math.max(1, +out.cost || 1);
    out.conf = +out.conf || 3;
    out.updatedAt = Date.now();
    setBusy(true);
    try {
      if (out.banko) await clearBanko(all, out.date, out.id);
      await saveMatch(out);
      // Logoları takım kütüphanesine kaydet (bir dahakine otomatik gelsin)
      for (const [n, l] of [[out.home, out.homeLogo], [out.away, out.awayLogo]]) {
        const tm = findTeam(teams, n);
        if (l && (!tm || tm.logo !== l)) saveTeam(n, l).catch(() => {});
      }
      toast(m.isNew ? 'Maç yayınlandı' : 'Kaydedildi');
      onBack();
      const before = (all || []).find((x) => x.id === out.id);
      if (!m.isNew && out.result === 'won' && (!before || before.result !== 'won')) {
        askNotify(cfg, '✅ Tahminimiz tuttu!', `${out.home} – ${out.away}${out.score ? ` · ${out.score}` : ''} · ${predText(out)}`, toast);
      }
      if (m.isNew && !out.hidden) askNotify(cfg, out.banko ? '🔥 Günün bankosu yayında!' : '⚽ Yeni tahmin yayında', `${out.home} – ${out.away} · ${out.time}`, toast);
    } catch (e) {
      toast('Kaydedilemedi. Admin e-postanı kontrol et.');
    }
    setBusy(false);
  };

  const del = () =>
    Alert.alert('Maç silinsin mi?', `${m.home} – ${m.away} herkesten kaldırılacak.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: async () => { try { await removeMatch(m.id); toast('Maç silindi'); onBack(); } catch (e) { toast('Silinemedi'); } } },
    ]);

  // Takım adı yazılınca kütüphanede varsa logo kendiliğinden gelir
  const setTeamName = (side, v) => setM((x) => {
    const tm = findTeam(teams, v);
    const lk = side + 'Logo';
    return { ...x, [side]: v, [lk]: tm && tm.logo ? tm.logo : (findTeam(teams, x[side]) ? '' : x[lk]) };
  });
  const pickTeam = (side, tm) => setM((x) => ({ ...x, [side]: tm.name, [side + 'Logo']: tm.logo || x[side + 'Logo'] }));
  const Oneriler = ({ text, onPick }) => {
    const sug = suggestTeams(teams, text);
    if (!sug.length) return null;
    return (
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: -6, marginBottom: 12, marginLeft: 62 }}>
        {sug.map((tm) => (
          <Pressable key={tm.id} onPress={() => onPick(tm)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, minHeight: 36, borderRadius: 18, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border }}>
            <Crest name={tm.name} logo={tm.logo} size={20} />
            <Text style={{ color: C.ink, fontWeight: '600' }}>{tm.name}</Text>
          </Pressable>
        ))}
      </View>
    );
  };

  const LogoBtn = ({ k, label }) => (
    <Pressable onPress={() => pickLogo(k)} accessibilityLabel={label} style={{ width: 52, height: 52, borderRadius: 14, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 12 }}>
      {isImg(m[k]) ? <Image source={{ uri: m[k] }} style={{ width: 52, height: 52 }} resizeMode="contain" /> : <Icon name="add" color={C.mut} />}
    </Pressable>
  );

  return (
    <View>
      <Header title={m.isNew ? 'Yeni maç ekle' : 'Maçı düzenle'} onBack={onBack} />
      <Card>
        <Text style={s.h3}>Takımlar</Text>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <LogoBtn k="homeLogo" label="Ev sahibi logosu" />
          <Field style={{ flex: 1 }} label="Ev sahibi" value={m.home} onChangeText={(v) => setTeamName('home', v)} placeholder="Örn. Galatasaray" />
        </View>
        <Oneriler text={m.home} onPick={(tm) => pickTeam('home', tm)} />
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <LogoBtn k="awayLogo" label="Deplasman logosu" />
          <Field style={{ flex: 1 }} label="Deplasman" value={m.away} onChangeText={(v) => setTeamName('away', v)} placeholder="Örn. Fenerbahçe" />
        </View>
        <Oneriler text={m.away} onPick={(tm) => pickTeam('away', tm)} />
        <Field label="Lig" value={m.league} onChangeText={(v) => F('league', v)} placeholder="Örn. Süper Lig" />
        <Text style={s.label}>Tarih</Text>
        <Seg value={m.date} onChange={(v) => F('date', v)} options={[[today(), 'Bugün'], [dayOff(1), 'Yarın'], [dayOff(2), 'Öbür gün']]} />
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Tarih (yıl-ay-gün)" value={m.date} onChangeText={(v) => F('date', v)} placeholder="2026-11-21" />
          <Field style={{ flex: 1 }} label="Saat" value={m.time} onChangeText={(v) => F('time', v)} placeholder="20:00" keyboardType="numbers-and-punctuation" />
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Tahmin</Text>
        <Seg value={m.market} onChange={pickMarket} options={MARKETS.map(([k]) => [k, k])} />
        {m.market === 'Diğer' ? <Field label="Bahis adı (isteğe bağlı)" value={m.marketOther} onChangeText={(v) => F('marketOther', v)} placeholder="Örn. Korner 9.5 Üst" /> : null}
        <Field label="Oran (isteğe bağlı, kuponlarda kullanılır)" value={String(m.odd || '')} onChangeText={(v) => F('odd', v.replace(',', '.'))} placeholder="Örn. 1.85" keyboardType="decimal-pad" />
        <Field label="Kullanıcının göreceği yazı" value={m.text || autoText} onChangeText={(v) => F('text', v)} placeholder="Örn. Maçta 3 veya daha fazla gol olur" />
        <Text style={s.label}>Güven</Text>
        <Seg value={m.conf} onChange={(v) => F('conf', v)} options={[[1, 'Zayıf'], [2, 'Orta'], [3, 'Güçlü']]} />
        <Field multiline label="Neden? (her satır bir madde, isteğe bağlı)" value={m.reasons} onChangeText={(v) => F('reasons', v)} placeholder="İki takım da son maçlarında bol gol attı" />
        <Text style={s.label}>Kazanma ihtimali % (isteğe bağlı)</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} value={String(m.p1)} onChangeText={(v) => F('p1', v)} placeholder="Ev" keyboardType="number-pad" />
          <Field style={{ flex: 1 }} value={String(m.px)} onChangeText={(v) => F('px', v)} placeholder="Ber." keyboardType="number-pad" />
          <Field style={{ flex: 1 }} value={String(m.p2)} onChangeText={(v) => F('p2', v)} placeholder="Dep." keyboardType="number-pad" />
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Kim görebilsin?</Text>
        <Seg tall value={m.access} onChange={(v) => F('access', v)} options={[['open', 'Açık', 'lock-open-outline'], ['locked', 'Kilitli', 'lock-closed-outline'], ['vip', 'VIP', 'diamond-outline']]} />
        {m.access !== 'open' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48, marginBottom: 8 }}>
            <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>Açmak için anahtar</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Btn small kind="out" title="−" onPress={() => F('cost', Math.max(1, (+m.cost || 1) - 1))} style={{ width: 48 }} />
              <Text style={{ fontSize: 20, fontWeight: '800', minWidth: 22, textAlign: 'center', color: C.ink }}>{+m.cost || 1}</Text>
              <Btn small kind="out" title="+" onPress={() => F('cost', Math.min(20, (+m.cost || 1) + 1))} style={{ width: 48 }} />
            </View>
          </View>
        ) : null}
        <Toggle label="Günün bankosu yap" sub="O günün en üstünde büyük kart olarak çıkar" value={m.banko} onChange={(v) => setM((x) => ({ ...x, banko: v, cost: v && (+x.cost || 1) < 3 ? 3 : x.cost }))} />
        <Toggle label="Ana sayfada göster" sub="Kapalıysa maç sadece kuponlarda görünür" value={!m.hidden} onChange={(v) => F('hidden', !v)} />
      </Card>

      <Card>
        <Text style={s.h3}>Maç durumu</Text>
        <Seg value={m.status} onChange={(v) => F('status', v)} options={[['upcoming', 'Başlamadı'], ['live', 'Canlı'], ['finished', 'Bitti']]} />
        {m.status !== 'upcoming' ? (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label="Skor" value={m.score} onChangeText={(v) => F('score', v)} placeholder="1-0" keyboardType="numbers-and-punctuation" />
            {m.status === 'live' ? <Field style={{ flex: 1 }} label="Dakika" value={String(m.minute)} onChangeText={(v) => F('minute', v)} placeholder="67" keyboardType="number-pad" /> : <View style={{ flex: 1 }} />}
          </View>
        ) : null}
        {m.status === 'live' ? <Field label="Canlı tahmin yazısı" value={m.liveText} onChangeText={(v) => F('liveText', v)} placeholder="Bir gol daha gelir" /> : null}
        {m.status === 'finished' ? (
          <>
            <Text style={s.label}>Tahmin sonucu</Text>
            <Seg value={m.result} onChange={(v) => F('result', v)} options={[['won', 'Tuttu'], ['lost', 'Tutmadı'], ['', 'Belirsiz']]} />
          </>
        ) : null}
      </Card>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
        {m.isNew ? <Btn kind="out" title="Vazgeç" onPress={onBack} style={{ flex: 1 }} /> : <Btn kind="out" title="Sil" onPress={del} style={{ flex: 1 }} />}
        <Btn kind="ink" title={m.isNew ? 'Yayınla' : 'Kaydet'} onPress={publish} loading={busy} style={{ flex: 2 }} />
      </View>
      {!m.isNew ? (
        <Btn kind="out" icon="copy-outline" title="Bu maçı kopyala (yeni maç olarak)" style={{ marginTop: 8 }} onPress={() => {
          setM((x) => ({ ...x, id: newId(), isNew: true, banko: false, status: 'upcoming', score: '', minute: '', liveText: '', result: '', updatedAt: undefined }));
          toast('Kopyalandı · takımları ve saati değiştirip yayınla');
        }} />
      ) : null}
    </View>
  );
}

/* ---------------- Uygulama ayarları ---------------- */
const COLORS = ['#00D26A', '#2F7BFF', '#FF8A1F', '#8B5CFF', '#E5484D', '#12B5B0', '#F2C200'];

function CfgForm({ c, setC, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const set = (path, v) => setC((o) => {
    const n = JSON.parse(JSON.stringify(o));
    const p = path.split('.');
    let x = n;
    while (p.length > 1) x = x[p.shift()];
    x[p[0]] = v;
    return n;
  });
  const pick = async (path, max, jpeg) => {
    try { const u = await pickImage(max, jpeg); if (u) set(path, u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const save = async () => {
    setBusy(true);
    try {
      await saveConfig({ ...c, name: (c.name || '').trim() || 'Tahmincim' });
      toast('Ayarlar kaydedildi');
      onBack();
    } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  const M = c.message;
  const A = c.ads;
  return (
    <View>
      <Header title="Uygulama ayarları" onBack={onBack} />
      <Card>
        <Text style={s.h3}>Görünüm</Text>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 12 }}>
          <View style={{ width: 64, height: 64, borderRadius: 18, backgroundColor: c.color, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
            {isImg(c.logo) ? <Image source={{ uri: c.logo }} style={{ width: 64, height: 64 }} /> : <Text style={{ fontWeight: '700', fontSize: 12 }}>Logo</Text>}
          </View>
          <Btn small kind="out" title="Logo yükle" onPress={() => pick('logo', 256, false)} style={{ flex: 1 }} />
          {c.logo ? <Btn small kind="out" title="Kaldır" onPress={() => set('logo', '')} /> : null}
        </View>
        <Field label="Uygulama adı" value={c.name} onChangeText={(v) => set('name', v)} />
        <Text style={s.label}>Ana renk</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
          {COLORS.map((x) => (
            <Pressable key={x} onPress={() => set('color', x)} accessibilityLabel={`Renk ${x}`} accessibilityState={{ selected: c.color === x }}
              style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: x, borderWidth: c.color === x ? 3 : 0, borderColor: C.ink }} />
          ))}
        </View>
        <Field label="Yeni kullanıcıya hediye anahtar" value={String(c.startKeys)} onChangeText={(v) => set('startKeys', +v || 0)} keyboardType="number-pad" />
      </Card>

      <Card>
        <Toggle label="Sistem mesajı" sub="Ana sayfanın üstünde görünür" value={M.on} onChange={(v) => set('message.on', v)} />
        <Field multiline label="Mesaj" value={M.text} onChangeText={(v) => set('message.text', v)} placeholder="Derbi tahmini 19:00'da yayında!" />
        <Text style={s.label}>Tür</Text>
        <Seg value={M.type} onChange={(v) => set('message.type', v)} options={[['info', 'Bilgi'], ['warn', 'Uyarı'], ['camp', 'Kampanya']]} />
      </Card>

      <Card>
        <Toggle label="Reklamlar" sub="Reklamla anahtar kazanma" value={A.on} onChange={(v) => set('ads.on', v)} />
        <Field label="Ödüllü reklam birim kimliği (AdMob)" value={A.unitId} onChangeText={(v) => set('ads.unitId', v.trim())} placeholder="ca-app-pub-xxxx/yyyy (boşsa test reklamı)" autoCapitalize="none" />
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Ödül (anahtar)" value={String(A.reward)} onChangeText={(v) => set('ads.reward', +v || 1)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="24 saatte en fazla (max 3)" value={String(Math.min(3, +A.limit || 3))} onChangeText={(v) => set('ads.limit', Math.min(3, +v || 0))} keyboardType="number-pad" />
        </View>
        <Text style={s.label}>Kendi reklam görselin (ana sayfanın altında)</Text>
        {isImg(A.bannerImg) ? <Image source={{ uri: A.bannerImg }} style={{ width: '100%', aspectRatio: 3, borderRadius: 14, marginBottom: 8 }} resizeMode="cover" /> : null}
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
          <Btn small kind="out" title={A.bannerImg ? 'Değiştir' : 'Görsel yükle'} onPress={() => pick('ads.bannerImg', 900, true)} style={{ flex: 1 }} />
          {A.bannerImg ? <Btn small kind="out" title="Kaldır" onPress={() => set('ads.bannerImg', '')} style={{ flex: 1 }} /> : null}
        </View>
        <Field label="Reklam bağlantısı (isteğe bağlı)" value={A.bannerLink} onChangeText={(v) => set('ads.bannerLink', v.trim())} placeholder="https://…" autoCapitalize="none" keyboardType="url" />
      </Card>

      <Card>
        <Toggle label="Anahtar mağazası" sub="Paketler ve fiyatlar (ödeme Google Play'e çıkınca açılır)" value={!!c.store?.on} onChange={(v) => set('store.on', v)} />
        {(c.store?.packs || []).map((p, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label={`Paket ${i + 1}: anahtar`} value={String(p.keys || '')} onChangeText={(v) => set(`store.packs.${i}.keys`, +v || 0)} keyboardType="number-pad" />
            <Field style={{ flex: 1 }} label="Fiyat" value={String(p.price || '')} onChangeText={(v) => set(`store.packs.${i}.price`, v)} placeholder="₺19,99" />
          </View>
        ))}
      </Card>

      <Card>
        <Text style={s.h3}>Ödüller ve bildirim</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Günlük giriş bonusu" value={String(c.rewards?.daily ?? 1)} onChangeText={(v) => set('rewards.daily', +v || 0)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="7. gün ekstra" value={String(c.rewards?.week ?? 3)} onChangeText={(v) => set('rewards.week', +v || 0)} keyboardType="number-pad" />
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Günlük açma sınırı (0=sınırsız)" value={String(c.keys?.dailyUnlock ?? 5)} onChangeText={(v) => set('keys.dailyUnlock', +v || 0)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="Anahtar ömrü gün (0=kapalı)" value={String(c.keys?.expireDays ?? 0)} onChangeText={(v) => set('keys.expireDays', +v || 0)} keyboardType="number-pad" />
        </View>
        <Text style={[s.sub, { fontSize: 13, marginTop: -4, marginBottom: 10 }]}>Açma sınırı VIP'lere uygulanmaz. Anahtar ömrü: o kadar gün hiç anahtar harcamayan/kazanmayanın anahtarı sıfırlanır.</Text>
        <Field label="Arkadaşına öner (paylaş) ödülü – anahtar (0 = kapalı)" value={String(c.rewards?.share ?? 2)} onChangeText={(v) => set('rewards.share', +v || 0)} keyboardType="number-pad" />
        <Field label="Expo proje kimliği (bildirimler için, kurulumda verilecek)" value={c.push?.projectId || ''} onChangeText={(v) => set('push.projectId', v.trim())} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autoCapitalize="none" />
      </Card>

      <Card>
        <Text style={s.h3}>Bağlantılar</Text>
        <Field label="Destek / iletişim (WhatsApp, Telegram, Instagram linki)" value={c.links?.support || ''} onChangeText={(v) => set('links.support', v.trim())} placeholder="https://wa.me/90..." autoCapitalize="none" keyboardType="url" />
        <Field label="Gizlilik politikası linki" value={c.links?.privacy || ''} onChangeText={(v) => set('links.privacy', v.trim())} placeholder="https://..." autoCapitalize="none" keyboardType="url" />
      </Card>

      <Card>
        <Text style={s.h3}>Sosyal medya</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Doldurduğun hesaplar Ben sekmesinde "Bizi takip et" olarak görünür.</Text>
        {[['instagram', 'Instagram', 'https://instagram.com/...'], ['telegram', 'Telegram', 'https://t.me/...'], ['whatsapp', 'WhatsApp (kanal/grup)', 'https://whatsapp.com/channel/...'], ['x', 'X (Twitter)', 'https://x.com/...'], ['youtube', 'YouTube', 'https://youtube.com/@...'], ['tiktok', 'TikTok', 'https://tiktok.com/@...']].map(([k, l, ph]) => (
          <Field key={k} label={l} value={c.links?.[k] || ''} onChangeText={(v) => set('links.' + k, v.trim())} placeholder={ph} autoCapitalize="none" keyboardType="url" />
        ))}
      </Card>

      <Btn kind="ink" title="Kaydet" onPress={save} loading={busy} />
    </View>
  );
}

/* ---------------- Kullanıcılar ---------------- */
const isVipU = (u) => Number(u?.vipUntil || 0) > Date.now();
const fmtDate = (ms) => {
  if (!ms) return '—';
  const d = new Date(ms);
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
};

function Users({ users, roles = [], onBack, onOpen }) {
  const roleOf = (id) => (roles.find((r) => r.id === id) || {}).role;
  const [q, setQ] = useState('');
  const [f, setF] = useState('all');
  const L = users.list;
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const stats = [
    ['Toplam', L.length],
    ['Bugün', L.filter((u) => (u.createdAt || 0) >= dayStart.getTime()).length],
    ['VIP', L.filter(isVipU).length],
    ['Engelli', L.filter((u) => u.banned).length],
  ];
  const staff = roles.length;
  const ql = q.trim().toLowerCase();
  const shown = L.filter((u) =>
    (f === 'all' || (f === 'vip' && isVipU(u)) || (f === 'ban' && u.banned) || (f === 'staff' && roleOf(u.id))) &&
    (!ql || String(u.name || '').toLowerCase().includes(ql) || String(u.email || '').includes(ql)));
  return (
    <View>
      <Header title="Kullanıcılar" onBack={onBack} />
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
        {stats.map(([l, v]) => (
          <View key={l} style={{ flex: 1, backgroundColor: C.card, borderRadius: 14, padding: 10, alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>{v}</Text>
            <Text style={{ fontSize: 12, color: C.mut }}>{l}</Text>
          </View>
        ))}
      </View>
      <Field value={q} onChangeText={setQ} placeholder="İsim veya e-posta ara" autoCapitalize="none" />
      <Seg value={f} onChange={setF} options={[['all', 'Tümü'], ['vip', 'VIP'], ['ban', 'Engelli'], ['staff', `Yetkili (${staff})`]]} />
      {users.loading ? (
        <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View>
      ) : users.error ? (
        <View style={s.empty}><Text style={[s.sub, { textAlign: 'center' }]}>Kullanıcılar okunamadı. Firebase kurallarını güncelledin mi?</Text></View>
      ) : !shown.length ? (
        <View style={s.empty}><Text style={s.sub}>Kullanıcı yok</Text></View>
      ) : shown.map((u) => (
        <Pressable key={u.id} onPress={() => onOpen(u.id)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
          <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: u.banned ? C.red : C.hero, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontWeight: '800' }}>{String(u.name || u.email || '?').slice(0, 1).toUpperCase()}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{u.name || '(isimsiz)'}{roleOf(u.id) === 'admin' ? '  🛠️' : roleOf(u.id) === 'mod' ? '  🛡️' : ''}{isVipU(u) ? '  👑' : ''}{u.banned ? '  ⛔' : ''}{Number(u.mutedUntil || 0) > Date.now() ? '  🔇' : ''}</Text>
            <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{u.email} · {fmtDate(u.createdAt)}</Text>
          </View>
          <Text style={{ fontWeight: '800', color: C.lockTx }}>🔑 {Number(u.keys) || 0}</Text>
        </Pressable>
      ))}
    </View>
  );
}

function UserDetail({ u, onBack, role, me, perm = {} }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!u) return <View><Header title="Kullanıcı" onBack={onBack} /><Text style={s.sub}>Kullanıcı bulunamadı.</Text></View>;
  const save = async (patch, msg) => {
    setBusy(true);
    try { await updateUser(u.id, patch); toast(msg); } catch (e) { toast('Kaydedilemedi. Firebase kurallarını kontrol et.'); }
    setBusy(false);
  };
  const keys = Number(u.keys) || 0;
  const vip = isVipU(u);
  const muted = Number(u.mutedUntil || 0) > Date.now();
  const mute = (h) => {
    save({ mutedUntil: h ? Date.now() + h * 3600e3 : 0 }, h ? `${h >= 24 ? h / 24 + ' gün' : h + ' saat'} susturuldu` : 'Susturma kaldırıldı');
    modLog(me, h ? `Susturdu (${h >= 24 ? h / 24 + ' gün' : h + ' saat'})` : 'Susturmayı kaldırdı', u.name || u.email);
  };
  const setYetki = (r) => {
    if (u.email === 'blackman0233@gmail.com') return toast('Sahibin yetkisi değiştirilemez');
    Alert.alert(r ? `${u.name || u.email} ${r === 'admin' ? 'Admin' : 'Moderatör'} yapılsın mı?` : 'Yetki kaldırılsın mı?',
      r === 'admin' ? 'Maç, kupon, sonuç girer ve bildirim gönderir. Ayarlara, anahtar ve VIP vermeye dokunamaz.' : r === 'mod' ? 'Yorum ve Tribün kuponlarını siler, şikayetlere bakar, kullanıcı susturur.' : 'Normal kullanıcı olur.',
      [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Evet', onPress: async () => {
        try { await grantRole(u.id, r, { email: u.email, name: u.name }); toast(r ? 'Yetki verildi' : 'Yetki kaldırıldı'); modLog(me, r ? `Yetki verdi: ${r}` : 'Yetki aldı', u.name || u.email); }
        catch (e) { toast('Yapılamadı. Kuralları güncelledin mi?'); }
      } }]);
  };
  const addVip = (days) => {
    const base = Math.max(Date.now(), Number(u.vipUntil) || 0);
    save({ vipUntil: base + days * 864e5 }, `${days} gün VIP verildi`);
  };
  return (
    <View>
      <Header title={u.name || 'Kullanıcı'} onBack={onBack} />
      <Card>
        <Text style={s.label}>E-posta</Text>
        <Text style={{ fontSize: 16, fontWeight: '600', color: C.ink, marginBottom: 10 }}>{u.email}</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <View style={{ flex: 1 }}><Text style={s.label}>Katılma</Text><Text style={{ fontWeight: '600', color: C.ink }}>{fmtDate(u.createdAt)}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.label}>Son giriş</Text><Text style={{ fontWeight: '600', color: C.ink }}>{fmtDate(u.lastSeen)}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.label}>Açtığı maç</Text><Text style={{ fontWeight: '600', color: C.ink }}>{(u.unlocked || []).length}</Text></View>
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Susturma</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>{muted ? `${fmtDate(u.mutedUntil)} tarihine kadar yorum ve paylaşım yapamaz.` : 'Susturulan kullanıcı belirli süre yorum yazamaz, Tribün ve Skor Ligi\'nde paylaşım yapamaz.'}</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: muted ? 8 : 0 }}>
          {[[1, '1 saat'], [24, '1 gün'], [168, '7 gün']].map(([h, l]) => (
            <Btn key={h} small kind="out" title={l} disabled={busy} onPress={() => mute(h)} style={{ flex: 1 }} />
          ))}
        </View>
        {muted ? <Btn small kind="out" title="Susturmayı kaldır" disabled={busy} onPress={() => mute(0)} /> : null}
      </Card>

      {perm.owner ? (
      <Card>
        <Text style={s.h3}>Yetki</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Şu an: {role === 'admin' ? '🛠️ Admin' : role === 'mod' ? '🛡️ Moderatör' : 'Normal kullanıcı'}</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Btn small kind={role === 'mod' ? 'ink' : 'out'} title="Moderatör" disabled={busy || role === 'mod'} onPress={() => setYetki('mod')} style={{ flex: 1 }} />
          <Btn small kind={role === 'admin' ? 'ink' : 'out'} title="Admin" disabled={busy || role === 'admin'} onPress={() => setYetki('admin')} style={{ flex: 1 }} />
        </View>
        {role ? <Btn small kind="out" title="Yetkiyi kaldır" onPress={() => setYetki('')} style={{ marginTop: 8 }} /> : null}
      </Card>
      ) : null}

      {perm.owner ? (<>
      <Card>
        <Text style={s.h3}>Anahtar</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 16, marginBottom: 12 }}>
          <Btn small kind="out" title="−1" disabled={busy || keys <= 0} onPress={() => save({ keys: Math.max(0, keys - 1) }, 'Anahtar azaltıldı')} style={{ width: 64 }} />
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.ink, minWidth: 50, textAlign: 'center' }}>{keys}</Text>
          <Btn small kind="out" title="+1" disabled={busy} onPress={() => save({ keys: keys + 1 }, '+1 anahtar verildi')} style={{ width: 64 }} />
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[5, 10, 25].map((n) => (
            <Btn key={n} small kind="out" title={`+${n}`} disabled={busy} onPress={() => save({ keys: keys + n }, `+${n} anahtar verildi`)} style={{ flex: 1 }} />
          ))}
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>VIP üyelik</Text>
        <Text style={[s.sub, { marginBottom: 12 }]}>
          {vip ? `VIP, ${fmtDate(u.vipUntil)} tarihine kadar (${Math.ceil((u.vipUntil - Date.now()) / 864e5)} gün). Tüm kilitli ve VIP tahminleri görür.` : 'VIP değil.'}
        </Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: vip ? 8 : 0 }}>
          {[7, 30, 90].map((d) => (
            <Btn key={d} small kind="out" title={`+${d} gün`} disabled={busy} onPress={() => addVip(d)} style={{ flex: 1 }} />
          ))}
        </View>
        {vip ? <Btn small kind="out" title="VIP'i kaldır" disabled={busy} onPress={() => save({ vipUntil: 0 }, 'VIP kaldırıldı')} /> : null}
      </Card>

      <Card>
        <Toggle label="Hesabı engelle" sub="Engellenen kullanıcı kilitli tahmin açamaz, anahtar kazanamaz" value={!!u.banned}
          onChange={(v) => save({ banned: v }, v ? 'Kullanıcı engellendi' : 'Engel kaldırıldı')} />
      </Card>
      </>) : null}
    </View>
  );
}

/* ---------------- Kupon oluştur / düzenle ---------------- */
function CouponForm({ co, setCo, matches, cfg, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const F = (k, v) => setCo((x) => ({ ...x, [k]: v }));
  const picked = (id) => co.picks.find((p) => p.matchId === id);
  const toggle = (m) => setCo((x) => ({
    ...x,
    picks: x.picks.find((p) => p.matchId === m.id) ? x.picks.filter((p) => p.matchId !== m.id) : [...x.picks, { matchId: m.id, odd: m.odd ? String(m.odd) : '' }],
  }));
  const setOdd = (id, v) => setCo((x) => ({ ...x, picks: x.picks.map((p) => (p.matchId === id ? { ...p, odd: v.replace(',', '.') } : p)) }));
  const cands = matches.list
    .filter((m) => (m.date >= dayOff(-1) && m.status !== 'finished') || picked(m.id))
    .sort((a, b) => String(a.date + a.time).localeCompare(b.date + b.time));
  const [quick, setQuick] = useState(null);
  const [qBusy, setQBusy] = useState(false);
  const openQuick = () => setQuick({ home: '', away: '', time: '20:00', market: 'MS 1', odd: '', show: false });
  const Q = (k, v) => setQuick((x) => ({ ...x, [k]: v }));
  const saveQuick = async () => {
    if (!quick.home.trim() || !quick.away.trim()) return toast('İki takımı da yaz');
    const m = {
      id: newId(), home: quick.home.trim(), away: quick.away.trim(), homeLogo: '', awayLogo: '', league: '',
      date: co.date, time: quick.time, market: quick.market, marketOther: '',
      text: marketText(quick.market, quick.home.trim(), quick.away.trim()) || quick.market,
      conf: 3, reasons: '', access: 'open', cost: 1, banko: false, status: 'upcoming', score: '', minute: '', liveText: '',
      result: '', p1: '', px: '', p2: '', odd: quick.odd.replace(',', '.'), hidden: !quick.show, updatedAt: Date.now(),
    };
    setQBusy(true);
    try {
      await saveMatch(m);
      setCo((x) => ({ ...x, picks: [...x.picks, { matchId: m.id, odd: m.odd }] }));
      setQuick(null);
      toast('Maç eklendi ve kupona seçildi');
    } catch (e) { toast('Kaydedilemedi'); }
    setQBusy(false);
  };
  const pk = couponPicks(co, matches.list);
  const total = couponTotal(pk);

  const save = async () => {
    if (!co.picks.length) return toast('En az bir maç seç');
    const out = { ...co, cost: Math.max(1, +co.cost || 1), updatedAt: Date.now() };
    delete out.isNew;
    setBusy(true);
    try {
      await saveCoupon(out);
      toast(co.isNew ? 'Kupon yayınlandı' : 'Kupon kaydedildi');
      onBack();
      if (co.isNew) askNotify(cfg, `🔥 ${out.title || 'Günün Kuponu'} yayında!`, `${out.picks.length} maçlık kupon${total ? ` · Toplam oran ${total.toFixed(2)}` : ''}`, toast);
    }
    catch (e) { toast('Kaydedilemedi. Firebase kurallarını kontrol et.'); }
    setBusy(false);
  };
  const del = () => Alert.alert('Kupon silinsin mi?', co.title || 'Kupon', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Sil', style: 'destructive', onPress: async () => { try { await removeCoupon(co.id); toast('Kupon silindi'); onBack(); } catch (e) { toast('Silinemedi'); } } },
  ]);

  return (
    <View>
      <Header title={co.isNew ? 'Yeni kupon' : 'Kuponu düzenle'} onBack={onBack} />
      <Card>
        <Field label="Kupon adı" value={co.title} onChangeText={(v) => F('title', v)} placeholder="Günün Kuponu" />
        <Text style={s.label}>Tarih</Text>
        <Seg value={co.date} onChange={(v) => F('date', v)} options={[[dayOff(-1), 'Dün'], [today(), 'Bugün'], [dayOff(1), 'Yarın']]} />
        <Field label="Tarih (yıl-ay-gün)" value={co.date} onChangeText={(v) => F('date', v)} placeholder="2026-11-21" />
      </Card>

      <Card>
        <Text style={s.h3}>Maçları seç</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Dünden itibaren tüm yaklaşan maçlar listelenir. Dokunarak seç, oranını gir.</Text>
        {!cands.length ? <Text style={s.sub}>Yaklaşan maç yok. Aşağıdan kupona yeni maç ekleyebilirsin.</Text> : cands.map((m, idx) => {
          const p = picked(m.id);
          const head = idx === 0 || cands[idx - 1].date !== m.date;
          return (
            <View key={m.id}>
            {head ? <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13, marginTop: idx ? 10 : 0, marginBottom: 6 }}>📅 {dayLabel(m.date)}</Text> : null}
            <View style={{ borderWidth: p ? 2 : 1.5, borderColor: p ? C.ink : C.border, borderRadius: 16, padding: 12, marginBottom: 8, backgroundColor: p ? C.selBg : C.card }}>
              <Pressable onPress={() => toggle(m)} accessibilityRole="checkbox" accessibilityState={{ checked: !!p }} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Icon name={p ? 'checkbox' : 'square-outline'} size={24} color={p ? C.okTx : C.mut} />
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{m.home} – {m.away}</Text>
                  <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{m.time} · {m.market} · {predText(m)}</Text>
                </View>
              </Pressable>
              {p ? <Field style={{ marginTop: 10, marginBottom: 0 }} label="Oran" value={String(p.odd || '')} onChangeText={(v) => setOdd(m.id, v)} placeholder="1.85" keyboardType="decimal-pad" /> : null}
            </View>
            </View>
          );
        })}
        {quick ? (
          <View style={{ borderWidth: 2, borderColor: C.ink, borderRadius: 16, padding: 12, marginTop: 8, backgroundColor: C.card }}>
            <Text style={[s.h3, { marginBottom: 8 }]}>Kupona yeni maç ({dayLabel(co.date, false)})</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Field style={{ flex: 1 }} label="Ev sahibi" value={quick.home} onChangeText={(v) => Q('home', v)} placeholder="Ev sahibi" />
              <Field style={{ flex: 1 }} label="Deplasman" value={quick.away} onChangeText={(v) => Q('away', v)} placeholder="Deplasman" />
            </View>
            <Seg value={quick.market} onChange={(v) => Q('market', v)} options={MARKETS.filter(([k]) => k !== 'Diğer').map(([k]) => [k, k])} />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Field style={{ flex: 1 }} label="Saat" value={quick.time} onChangeText={(v) => Q('time', v)} placeholder="20:00" keyboardType="numbers-and-punctuation" />
              <Field style={{ flex: 1 }} label="Oran" value={quick.odd} onChangeText={(v) => Q('odd', v)} placeholder="1.85" keyboardType="decimal-pad" />
            </View>
            <Toggle label="Ana sayfada da göster" sub="Kapalıysa maç sadece bu kuponda görünür" value={quick.show} onChange={(v) => Q('show', v)} />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Btn small kind="out" title="Vazgeç" onPress={() => setQuick(null)} style={{ flex: 1 }} />
              <Btn small kind="ink" title="Ekle" onPress={saveQuick} loading={qBusy} style={{ flex: 2 }} />
            </View>
          </View>
        ) : (
          <Btn small kind="out" icon="add" title="Kupona yeni maç ekle" onPress={openQuick} style={{ marginTop: 8 }} />
        )}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
          <Text style={{ fontWeight: '600', color: C.mut }}>{co.picks.length} maç · Toplam oran</Text>
          <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{total ? total.toFixed(2) : '—'}</Text>
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Kim görebilsin?</Text>
        <Seg tall value={co.access} onChange={(v) => F('access', v)} options={[['open', 'Açık', 'lock-open-outline'], ['locked', 'Kilitli', 'lock-closed-outline'], ['vip', 'VIP', 'diamond-outline']]} />
        {co.access !== 'open' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48 }}>
            <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>Açmak için anahtar</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Btn small kind="out" title="−" onPress={() => F('cost', Math.max(1, (+co.cost || 1) - 1))} style={{ width: 48 }} />
              <Text style={{ fontSize: 20, fontWeight: '800', minWidth: 22, textAlign: 'center', color: C.ink }}>{+co.cost || 1}</Text>
              <Btn small kind="out" title="+" onPress={() => F('cost', Math.min(50, (+co.cost || 1) + 1))} style={{ width: 48 }} />
            </View>
          </View>
        ) : null}
        <Text style={[s.sub, { marginTop: 8 }]}>Sonuç otomatik: tüm maçlar "Tuttu" olunca kupon Kazandı, biri "Tutmadı" olunca Kaybetti olur.</Text>
      </Card>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
        {co.isNew ? <Btn kind="out" title="Vazgeç" onPress={onBack} style={{ flex: 1 }} /> : <Btn kind="out" title="Sil" onPress={del} style={{ flex: 1 }} />}
        <Btn kind="ink" title={co.isNew ? 'Yayınla' : 'Kaydet'} onPress={save} loading={busy} style={{ flex: 2 }} />
      </View>
    </View>
  );
}

/* ---------------- Bildirim gönder ---------------- */
const SABLONLAR = [
  ['🔥 Günün banko kuponu yüklendi!', 'Hemen aç, kaçırma!'],
  ['⚽ Yeni tahminler yayında', 'Bugünün maçları için tahminler hazır.'],
  ['🏆 Kuponumuz kazandı!', 'Kazanan kuponu görmek için uygulamaya gir.'],
  ['🔴 Maç başlıyor', 'Canlı tahminimizi kaçırma.'],
];
function Bildirim({ cfg, onBack }) {
  const toast = useToast();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [devices, setDevices] = useState(null);
  const [hist, setHist] = useState([]);
  const load = () => {
    countDevices().then(setDevices).catch(() => setDevices(-1));
    notifHistory().then(setHist).catch(() => {});
  };
  React.useEffect(load, []);
  const ready = !!cfg.push?.projectId;
  const send = () => {
    if (!title.trim()) return toast('Başlık yaz');
    Alert.alert('Bildirim gönderilsin mi?', `${title}\n${body}\n\n${devices > 0 ? devices + ' telefona' : 'Kayıtlı tüm telefonlara'} gidecek.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Gönder', onPress: async () => {
        setBusy(true);
        try {
          const r = await sendPushAll(title.trim(), body.trim());
          toast(`${r.ok} / ${r.total} telefona gönderildi`);
          setTitle(''); setBody(''); load();
        } catch (e) { toast('Gönderilemedi, internet bağlantını kontrol et'); }
        setBusy(false);
      } },
    ]);
  };
  return (
    <View>
      <Header title="Bildirim gönder" onBack={onBack} />
      {!ready ? (
        <Card style={{ backgroundColor: C.lockBg }}>
          <Text style={{ color: C.lockTx, fontWeight: '700' }}>Bildirim kurulumu henüz tamamlanmadı.</Text>
          <Text style={{ color: C.lockTx, marginTop: 4 }}>Ayarlar → "Expo proje kimliği" alanı doldurulunca telefonlar kaydolmaya başlar.</Text>
        </Card>
      ) : null}
      <Card>
        <Text style={s.sub}>Kayıtlı telefon: <Text style={{ fontWeight: '800', color: C.ink }}>{devices == null ? '…' : devices < 0 ? '?' : devices}</Text></Text>
        <Text style={[s.label, { marginTop: 12 }]}>Hazır şablonlar</Text>
        <View style={{ gap: 8, marginBottom: 12 }}>
          {SABLONLAR.map(([t, b]) => (
            <Pressable key={t} onPress={() => { setTitle(t); setBody(b); }} accessibilityRole="button" style={{ borderWidth: 1.5, borderColor: C.border, borderRadius: 12, padding: 12, backgroundColor: C.card }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{t}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>{b}</Text>
            </Pressable>
          ))}
        </View>
        <Field label="Başlık" value={title} onChangeText={setTitle} placeholder="🔥 Günün banko kuponu yüklendi!" maxLength={65} />
        <Field multiline label="Mesaj" value={body} onChangeText={setBody} placeholder="Hemen aç, kaçırma!" maxLength={180} />
        <Btn kind="ink" icon="send-outline" title="Gönder" onPress={send} loading={busy} disabled={!ready} />
      </Card>
      {hist.length ? (
        <Card>
          <Text style={s.h3}>Son gönderilenler</Text>
          {hist.map((h) => (
            <View key={h.id} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.line }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{h.title}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>{fmtDate(h.sentAt)} · {h.count}/{h.total} telefon</Text>
            </View>
          ))}
        </Card>
      ) : null}
    </View>
  );
}

/* Yeni maç/kupon sonrası tek dokunuşla bildirim */
function askNotify(cfg, title, body, toast) {
  if (!cfg?.push?.projectId) return;
  setTimeout(() => {
    Alert.alert('Kullanıcılara bildirim gönderilsin mi?', `${title}\n${body}`, [
      { text: 'Hayır', style: 'cancel' },
      { text: 'Gönder 🔔', onPress: () => sendPushAll(title, body).then((r) => toast(`${r.ok} telefona bildirim gitti`)).catch(() => toast('Bildirim gönderilemedi')) },
    ]);
  }, 600);
}

/* ---------------- Takım kütüphanesi ---------------- */
function Takimlar({ teams, matches, onBack }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [logo, setLogo] = useState('');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const pick = async (setter) => {
    try { const u = await pickImage(128, false); if (u) setter(u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const add = async () => {
    if (!name.trim()) return toast('Takım adını yaz');
    setBusy(true);
    try { await saveTeam(name, logo); toast('Takım kaydedildi'); setName(''); setLogo(''); } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  const importAll = async () => {
    setBusy(true);
    const n = await importTeamsFromMatches(matches.list, teams.list).catch(() => 0);
    toast(n ? `${n} takım logosu aktarıldı` : 'Aktarılacak yeni logo yok');
    setBusy(false);
  };
  const ql = q.trim().toLocaleLowerCase('tr');
  const list = [...teams.list].filter((t) => !ql || String(t.name).toLocaleLowerCase('tr').includes(ql)).sort((a, b) => String(a.name).localeCompare(String(b.name), 'tr'));
  return (
    <View>
      <Header title="Takımlar" onBack={onBack} />
      <Card>
        <Text style={s.h3}>Yeni takım</Text>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <Pressable onPress={() => pick(setLogo)} accessibilityLabel="Logo seç" style={{ width: 52, height: 52, borderRadius: 14, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 12 }}>
            {isImg(logo) ? <Image source={{ uri: logo }} style={{ width: 52, height: 52 }} resizeMode="contain" /> : <Icon name="add" color={C.mut} />}
          </Pressable>
          <Field style={{ flex: 1 }} label="Takım adı" value={name} onChangeText={setName} placeholder="Örn. Galatasaray" />
        </View>
        <Btn small kind="ink" title="Kaydet" onPress={add} loading={busy} />
        <Btn small kind="out" title="Maçlardaki logoları içe aktar" icon="download-outline" onPress={importAll} style={{ marginTop: 8 }} />
        <Text style={[s.note, { marginTop: 8 }]}>Maç eklerken takım adını yazınca logo kendiliğinden gelir.</Text>
      </Card>
      <Field value={q} onChangeText={setQ} placeholder={`Takım ara (${teams.list.length})`} />
      {list.map((tm) => (
        <View key={tm.id} style={[s.row, { minHeight: 60 }]}>
          <Pressable onPress={() => pick((u) => saveTeam(tm.name, u).then(() => toast('Logo güncellendi')).catch(() => toast('Kaydedilemedi')))} accessibilityLabel="Logoyu değiştir">
            <Crest name={tm.name} logo={tm.logo} size={40} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '700', color: C.ink }}>{tm.name}</Text>
            <Text style={{ color: C.mut, fontSize: 12.5 }}>{tm.logo ? 'Logoya dokunup değiştirebilirsin' : 'Logo yok · dokunup ekle'}</Text>
          </View>
          <Pressable onPress={() => Alert.alert('Takım silinsin mi?', tm.name, [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Sil', style: 'destructive', onPress: () => removeTeam(tm.id).catch(() => toast('Silinemedi')) }])}
            accessibilityLabel="Sil" style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="trash-outline" color={C.red} />
          </Pressable>
        </View>
      ))}
    </View>
  );
}

/* ---------------- Topluluk yönetimi ---------------- */
function Topluluk({ matches, onBack, me, perm = {}, onUsers }) {
  const toast = useToast();
  const [tab, setTab] = useState('feedback');
  const comments = useRecentComments(tab === 'comments');
  const fbs = useFeedback(true);
  const reports = useReports(true);
  const tribune = useTribune();
  const logs = useModLog(perm.owner && tab === 'log');
  const del = (title, fn) => Alert.alert(title, 'Bu işlem geri alınamaz.', [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Sil', style: 'destructive', onPress: fn }]);
  return (
    <View>
      <Header title="Topluluk" onBack={onBack} />
      <Seg value={tab} onChange={setTab} options={[['feedback', `Mesajlar (${fbs.list.length})`], ['reports', `Bildirilen (${reports.list.length})`], ['comments', 'Yorumlar'], ['tribune', 'Tribün'], ...(perm.owner ? [['log', '📋 Kayıt']] : [])]} />
      {!perm.admin ? <Btn small kind="out" icon="people-outline" title="Kullanıcılar (susturma)" onPress={onUsers} style={{ marginBottom: 12 }} /> : null}
      {tab === 'log' ? (
        !logs.length ? <View style={s.empty}><Text style={s.sub}>Henüz kayıt yok</Text></View> : logs.map((l) => (
          <View key={l.id} style={[s.row, { alignItems: 'flex-start', minHeight: 0 }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{l.byName || 'Yetkili'} <Text style={{ color: C.mut, fontWeight: '400', fontSize: 12 }}>· {l.role === 'mod' ? 'Moderatör' : l.role === 'admin' ? 'Admin' : 'Sahip'} · {onceLabel(l.at)}</Text></Text>
              <Text style={{ color: C.ink, marginTop: 2 }}>{l.action}</Text>
              {l.detail ? <Text numberOfLines={2} style={{ color: C.mut, fontSize: 13, marginTop: 2 }}>{l.detail}</Text> : null}
            </View>
          </View>
        ))
      ) : null}
      {tab === 'log' ? null : tab === 'feedback' ? (
        !fbs.list.length ? <View style={s.empty}><Text style={s.sub}>Henüz öneri veya şikayet yok</Text></View> : fbs.list.map((f) => (
          <Card key={f.id}>
            <Text style={{ color: C.mut, fontSize: 12.5 }}>{f.kind === 'oneri' ? '💡 Öneri' : f.kind === 'hata' ? '🐞 Hata' : '⚠️ Şikayet'} · {f.name || 'Misafir'} · {onceLabel(f.createdAt)}</Text>
            <Text style={{ color: C.ink, marginVertical: 8, lineHeight: 20 }}>{f.text}</Text>
            {f.contact ? <Text selectable style={{ color: C.mut, fontSize: 13, marginBottom: 8 }}>📧 {f.contact}</Text> : null}
            <Btn small kind="out" title="Okundu, sil" onPress={() => deleteFeedback(f.id).catch(() => toast('Silinemedi'))} />
          </Card>
        ))
      ) : tab === 'reports' ? (
        !reports.list.length ? <View style={s.empty}><Text style={s.sub}>Şikayet yok 👍</Text></View> : reports.list.map((r) => (
          <Card key={r.id}>
            <Text style={{ color: C.mut, fontSize: 12.5 }}>{r.kind === 'comment' ? 'Yorum' : 'Tribün kuponu'} · {onceLabel(r.createdAt)}</Text>
            <Text style={{ color: C.ink, marginVertical: 8 }}>{r.text}</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Btn small kind="out" title="Yoksay" onPress={() => deleteReport(r.id).catch(() => {})} style={{ flex: 1 }} />
              <Btn small kind="red" title="İçeriği sil" style={{ flex: 1 }} onPress={() => del('İçerik silinsin mi?', async () => {
                try { await (r.kind === 'comment' ? deleteComment(r.refId) : deleteTribune(r.refId)); await deleteReportsFor(r.refId); toast('Silindi'); modLog(me, r.kind === 'comment' ? 'Şikayet edilen yorumu sildi' : 'Şikayet edilen kuponu sildi', r.text); } catch (e) { toast('Silinemedi'); }
              })} />
            </View>
          </Card>
        ))
      ) : tab === 'comments' ? (
        !comments.list.length ? <View style={s.empty}><Text style={s.sub}>Yorum yok</Text></View> : comments.list.map((c) => (
          <View key={c.id} style={[s.row, { alignItems: 'flex-start' }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{c.name} <Text style={{ color: C.mut, fontWeight: '400', fontSize: 12 }}>· {onceLabel(c.createdAt)}</Text></Text>
              <Text style={{ color: C.ink, marginTop: 2 }}>{c.text}</Text>
            </View>
            <Pressable onPress={() => del('Yorum silinsin mi?', () => deleteComment(c.id).then(() => { toast('Silindi'); modLog(me, 'Yorum sildi', `${c.name}: ${c.text}`); }).catch(() => toast('Silinemedi')))} accessibilityLabel="Sil" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="trash-outline" color={C.red} />
            </Pressable>
          </View>
        ))
      ) : (
        !tribune.list.length ? <View style={s.empty}><Text style={s.sub}>Tribün boş</Text></View> : tribune.list.slice(0, 100).map((x) => (
          <View key={x.id} style={s.row}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{x.name}</Text>
              <Text style={{ color: C.mut, fontSize: 12.5 }}>{(x.picks || []).length} maç · {onceLabel(x.createdAt)}</Text>
            </View>
            <Pressable onPress={() => del('Kupon silinsin mi?', () => deleteTribune(x.id).then(() => { toast('Silindi'); modLog(me, 'Tribün kuponu sildi', x.name); }).catch(() => toast('Silinemedi')))} accessibilityLabel="Sil" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="trash-outline" color={C.red} />
            </Pressable>
          </View>
        ))
      )}
    </View>
  );
}

/* ---------------- İstatistik paneli ---------------- */
function Istatistik({ matches, coupons, onBack }) {
  const users = useUsers(true);
  const [n, setN] = useState({});
  React.useEffect(() => {
    let on = true;
    (async () => {
      const [dev, com, tri, sco, vw] = await Promise.all([countDevices().catch(() => null), countCollection('comments'), countCollection('tribune'), countCollection('scores'), countCollection('views')]);
      if (on) setN({ dev, com, tri, sco, vw });
    })();
    return () => { on = false; };
  }, []);
  const U = users.list || [];
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const day = d0.getTime();
  const week = Date.now() - 7 * 864e5;
  const now = Date.now();
  const activeToday = U.filter((u) => (u.lastSeen || 0) >= day).length;
  const active7 = U.filter((u) => (u.lastSeen || 0) >= week).length;
  const new7 = U.filter((u) => (u.createdAt || 0) >= week).length;
  const vip = U.filter((u) => Number(u.vipUntil || 0) > now).length;
  const keys = U.reduce((t, u) => t + (Number(u.keys) || 0), 0);
  const cnt = {};
  U.forEach((u) => (u.unlocked || []).forEach((id) => { cnt[id] = (cnt[id] || 0) + 1; }));
  const byId = {};
  matches.list.forEach((m) => { byId[m.id] = `${m.home} – ${m.away}`; });
  (coupons?.list || []).forEach((c) => { byId['c_' + c.id] = c.title || 'Kupon'; byId[c.id] = c.title || 'Kupon'; });
  const top = Object.entries(cnt).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const st = successStats(matches.list, 30);
  const recent = [...matches.list].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 20);
  const vc = useViewCounts(recent.map((m) => 'm_' + m.id));
  const topV = recent.map((m) => [m, vc['m_' + m.id] || 0]).filter((x) => x[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const Kutu = ({ v, l }) => (
    <View style={{ flexBasis: '47%', flexGrow: 1, backgroundColor: C.card, borderRadius: 18, padding: 14 }}>
      <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{v == null ? '–' : v}</Text>
      <Text style={{ color: C.mut, fontSize: 13 }}>{l}</Text>
    </View>
  );
  return (
    <View>
      <Header title="İstatistik" onBack={onBack} />
      {users.loading ? <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
        <Kutu v={U.length} l="Toplam üye" />
        <Kutu v={activeToday} l="Bugün giren" />
        <Kutu v={active7} l="Son 7 gün aktif" />
        <Kutu v={new7} l="Son 7 gün yeni üye" />
        <Kutu v={n.dev} l="Bildirim açık cihaz" />
        <Kutu v={vip} l="VIP üye" />
        <Kutu v={keys} l="Kullanıcılardaki anahtar" />
        <Kutu v={st.total ? `%${st.pct}` : '–'} l={`30 gün başarı (${st.won}/${st.total})`} />
        <Kutu v={n.com} l="Yorum" />
        <Kutu v={n.tri} l="Tribün kuponu" />
        <Kutu v={n.sco} l="Skor tahmini" />
        <Kutu v={matches.list.length} l="Toplam maç" />
        <Kutu v={n.vw} l="Toplam görüntülenme" />
      </View>
      <Card>
        <Text style={s.h3}>👁 En çok görüntülenen (son 20 maç)</Text>
        {!topV.length ? <Text style={s.sub}>Henüz görüntülenme yok.</Text> : topV.map(([m, c], i) => (
          <View key={m.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderTopWidth: i ? 1 : 0, borderColor: C.line }}>
            <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{m.home} – {m.away}</Text>
            <Text style={{ color: C.okTx, fontWeight: '800' }}>{c} kişi</Text>
          </View>
        ))}
      </Card>
      <Card>
        <Text style={s.h3}>En çok açılanlar</Text>
        {!top.length ? <Text style={s.sub}>Henüz açılan kilitli içerik yok.</Text> : top.map(([id, c], i) => (
          <View key={id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderTopWidth: i ? 1 : 0, borderColor: C.line }}>
            <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{byId[id] || 'Silinmiş içerik'}</Text>
            <Text style={{ color: C.lockTx, fontWeight: '800' }}>{c} kişi</Text>
          </View>
        ))}
      </Card>
    </View>
  );
}
