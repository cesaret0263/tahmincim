// Anlık bildirimler (Expo Push). Kurulum tamamlanmadıysa sessizce hiçbir şey yapmaz.
import { Platform } from 'react-native';
import { collection, doc, setDoc, getDocs, deleteDoc, addDoc } from 'firebase/firestore';
import { db } from './firebase';

let N = null;
try {
  N = require('expo-notifications');
} catch (e) {
  N = null;
}

export function setupNotifications() {
  if (!N) return;
  try {
    N.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldShowBanner: true,
        shouldShowList: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      }),
    });
  } catch (e) {}
}

const tokenId = (t) => String(t).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 150);

// Telefonu bildirim listesine kaydeder. projectId admin panelinden gelir.
export async function registerPush(projectId, uid) {
  if (!N || !projectId) return null;
  try {
    if (Platform.OS === 'android') {
      await N.setNotificationChannelAsync('default', { name: 'Genel', importance: N.AndroidImportance.MAX });
    }
    let { status } = await N.getPermissionsAsync();
    if (status !== 'granted') ({ status } = await N.requestPermissionsAsync());
    if (status !== 'granted') return null;
    const t = (await N.getExpoPushTokenAsync({ projectId })).data;
    if (!t) return null;
    await setDoc(doc(db, 'tokens', tokenId(t)), { token: t, uid: uid || null, updatedAt: Date.now() });
    return t;
  } catch (e) {
    return null;
  }
}

export async function countDevices() {
  const snap = await getDocs(collection(db, 'tokens'));
  return snap.size;
}

// Admin: kayıtlı tüm telefonlara bildirim gönderir.
export async function sendPushAll(title, body) {
  const snap = await getDocs(collection(db, 'tokens'));
  const toks = snap.docs.map((d) => ({ id: d.id, t: d.data().token })).filter((x) => x.t);
  let ok = 0;
  const bad = [];
  for (let i = 0; i < toks.length; i += 100) {
    const chunk = toks.slice(i, i + 100);
    const res = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(chunk.map((x) => ({ to: x.t, title, body, sound: 'default', channelId: 'default', priority: 'high' }))),
    });
    const j = await res.json().catch(() => ({}));
    (j.data || []).forEach((r, k) => {
      if (r.status === 'ok') ok++;
      else if (r.details && r.details.error === 'DeviceNotRegistered') bad.push(chunk[k].id);
    });
  }
  for (const id of bad) {
    try { await deleteDoc(doc(db, 'tokens', id)); } catch (e) {}
  }
  try { await addDoc(collection(db, 'notifications'), { title, body, sentAt: Date.now(), count: ok, total: toks.length }); } catch (e) {}
  return { ok, total: toks.length };
}

export async function notifHistory() {
  const snap = await getDocs(collection(db, 'notifications'));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => (b.sentAt || 0) - (a.sentAt || 0)).slice(0, 20);
}
