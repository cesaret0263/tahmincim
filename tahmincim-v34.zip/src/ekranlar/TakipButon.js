// 👥 Takip et / Takiptesin butonu + 🔔 kupon bildirimi zili (Tribün kartları ve profil)
import React, { useState } from 'react';
import { View, Text, Pressable, Alert, ActivityIndicator } from 'react-native';
import { C } from '../tema';
import { Icon, useToast, useTheme } from '../parcalar';
import { useTakiplerim, takipEt, takibiBirak, takipBildir } from '../topluluk';
import { engelliMi } from '../sosyal';

export function useTakipDurum(me, uid) {
  const benimId = me && me.id && !me.guest ? me.id : null;
  const liste = useTakiplerim(benimId);
  const kayit = liste ? liste[uid] : null;
  return { hazir: !benimId || !!liste, takipte: !!kayit, bildir: kayit ? kayit.bildir !== false : false };
}

export function useTakipIslem(me, p, onNeedAuth) {
  const toast = useToast();
  const [mesgul, setMesgul] = useState(false);
  const d = useTakipDurum(me, p.uid);
  const ad = p.name || 'Üye';
  const takip = async () => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    if (d.takipte) {
      return Alert.alert('Takibi bırak', `${ad} adlı kişiyi takip etmeyi bırakmak istiyor musun?`, [
        { text: 'Vazgeç', style: 'cancel' },
        { text: 'Takibi bırak', style: 'destructive', onPress: async () => {
          setMesgul(true);
          try { await takibiBirak(me.id, p.uid); toast('Takibi bıraktın'); } catch (e) { toast('Olmadı, tekrar dene'); }
          setMesgul(false);
        } },
      ], { cancelable: true });
    }
    setMesgul(true);
    try { await takipEt(me, { uid: p.uid, name: ad, avatar: p.avatar || '' }); toast(`${ad} takip ediliyor 👥 Kupon paylaşınca haber vereceğiz`); } catch (e) { toast('Olmadı. Bu kullanıcı seni engellemiş olabilir.'); }
    setMesgul(false);
  };
  const zil = async () => {
    if (!d.takipte) return;
    const yeni = !d.bildir;
    try {
      await takipBildir(me.id, p.uid, yeni);
      toast(yeni ? `🔔 ${ad} kupon paylaşınca bildirim gelecek` : `🔕 ${ad} için kupon bildirimi kapandı`);
    } catch (e) { toast('Kaydedilemedi. Uygulamayı güncelledin mi?'); }
  };
  return { ...d, mesgul, takip, zil };
}

// Kartlarda kullanılan küçük hâli: [Takip et] ya da [✓ Takiptesin] [🔔]
export function TakipMini({ me, p, onNeedAuth }) {
  const t = useTakipIslem(me, p, onNeedAuth);
  const th = useTheme();
  if ((me && me.id === p.uid) || engelliMi(me, p.uid) || !t.hazir) return null;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <Pressable onPress={t.takip} disabled={t.mesgul} hitSlop={6} accessibilityLabel={t.takipte ? 'Takibi bırak' : 'Takip et'}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 3, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3,
          backgroundColor: t.takipte ? C.bg : th.acc, borderWidth: t.takipte ? 1 : 0, borderColor: C.line }}>
        {t.mesgul ? <ActivityIndicator size="small" color={t.takipte ? C.mut : th.onAcc} /> : (
          <>
            <Icon name={t.takipte ? 'checkmark' : 'person-add-outline'} size={12} color={t.takipte ? C.mut : th.onAcc} />
            <Text style={{ fontSize: 11.5, fontWeight: '800', color: t.takipte ? C.mut : th.onAcc }}>{t.takipte ? 'Takiptesin' : 'Takip et'}</Text>
          </>
        )}
      </Pressable>
      {t.takipte ? (
        <Pressable onPress={t.zil} hitSlop={8} accessibilityLabel={t.bildir ? 'Kupon bildirimini kapat' : 'Kupon bildirimini aç'}
          style={{ width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: t.bildir ? C.okBg : C.bg }}>
          <Icon name={t.bildir ? 'notifications' : 'notifications-off-outline'} size={14} color={t.bildir ? C.okTx : C.mut} />
        </Pressable>
      ) : null}
    </View>
  );
}
