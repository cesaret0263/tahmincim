import React, { useState, useEffect } from 'react';
import { markView, useCommentCounts } from '../topluluk';
import { iyelik } from '../sosyal';
import { Gir, Iskelet } from '../efekt';
import PaylasKart from './PaylasKart';
import { useSaved, toggleSaved, isSaved } from '../kayit';
import { View, Text, Pressable } from 'react-native';
import { C, today, predText, couponPicks, couponTotal, couponStatus, oddOf, dayLabel, marketText, canliDakika, satirPazar, satirSonuc, tribuneStatus, isVerified } from '../tema';
import { Crest, Icon, s, useTheme, Tik } from '../parcalar';
import { paylas } from './Pencereler';
import Tribun, { TribunKart } from './Tribun';
import { EtkilesimPenceresi } from './Etkilesim';
import { isVip } from './MacKart';

export const couponKey = (c) => 'c_' + c.id;
export function isCouponOpen(c, status, me) {
  return c.access === 'open' || status !== 'pending' || isVip(me) || (!me?.banned && (me?.unlocked || []).includes(couponKey(c)));
}

function fmtDay(d) {
  if (!d) return '';
  const [y, m, g] = d.split('-');
  return `${g}.${m}.${y}`;
}

// Satırın kendi tahmini varsa onun açıklaması, yoksa maçın tahmin yazısı
const satirMetni = (p) => (p.market && p.m && p.market !== p.m.market ? (marketText(p.market, p.m.home, p.m.away) || p.market) : predText(p.m));

const STATUS = {
  pending: { t: 'Bekliyor', get bg() { return C.track; }, get fg() { return C.mut; } },
  won: { t: 'Tuttu ✓', get bg() { return C.okBg; }, get fg() { return C.okTx; } },
  lost: { t: 'Tutmadı ✕', get bg() { return C.redBg; }, get fg() { return C.red; } },
};

function kuponMetni(c, picks, total, st, appName) {
  const lines = picks.filter((p) => p.m).map((p) => {
    const odd = oddOf(p.odd || p.m.odd);
    const sr = satirSonuc(p);
    const r = sr === 'won' ? ' ✅' : sr === 'lost' ? ' ❌' : '';
    return `⚽ ${p.m.home} – ${p.m.away}${p.m.time ? ` (${p.m.time})` : ''}\n   🎯 ${satirMetni(p)}${odd ? ` · ${odd.toFixed(2)}` : ''}${r}`;
  });
  const head = st === 'won' ? '✅ TUTTU! ' : '';
  return `${head}🧾 ${c.title || 'Günün Kuponu'}\n📅 ${dayLabel(c.date, false)}\n\n${lines.join('\n')}\n\n💰 Toplam oran: ${total ? total.toFixed(2) : '—'}\n\n${appName || 'Tahmincim'} uygulamasında 📲\n18+ · Tahminler garanti değildir.`;
}

export function KuponKart({ c, matchList, me, onLocked, appName, onComments, onShareCard, onMatch, onAdmin }) {
  const t = useTheme();
  const picks = couponPicks(c, matchList);
  const total = couponTotal(picks);
  const st = couponStatus(picks);
  const open = isCouponOpen(c, st, me);
  const S = STATUS[st];
  const saved = useSaved();
  const sv = isSaved(saved, 'c', c.id);
  useEffect(() => { if (open && !(me && me.admin)) markView('c_' + c.id, me && !me.guest ? me.id : null); }, [open, c.id]); // eslint-disable-line
  const won = st === 'won';
  return (
    <Pressable onPress={open ? undefined : () => onLocked(c)} disabled={open} accessibilityRole={open ? undefined : 'button'}
      style={{ backgroundColor: won ? '#0F2A1B' : C.hero, borderRadius: 26, padding: 18, marginBottom: 14 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ color: t.acc, fontWeight: '800', fontSize: 12, letterSpacing: 1 }}>{(c.title || 'Günün Kuponu').toUpperCase()}</Text>
          <Text style={{ color: '#C5CCD6', fontSize: 13, marginTop: 2 }}>📅 {dayLabel(c.date)} · {picks.length} maç</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 }}>
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13 }}>{appName || 'Tahmincim'}</Text>
            <Tik size={15} />
          </View>
        </View>
        <View style={{ alignItems: 'flex-end', gap: 8 }}>
          <View style={{ backgroundColor: S.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
            <Text style={{ color: S.fg, fontWeight: '800', fontSize: 12 }}>{S.t}</Text>
          </View>
          <Pressable onPress={() => toggleSaved({ k: 'c', id: c.id })} accessibilityLabel="Kaydet" hitSlop={8}>
            <Icon name={sv ? 'bookmark' : 'bookmark-outline'} size={20} color={sv ? '#FFB46B' : '#C5CCD6'} />
          </Pressable>
        </View>
      </View>

      <View style={{ marginTop: 14, gap: 8 }}>
        {open ? picks.map((p, i) => {
          const m = p.m;
          const r = satirSonuc(p);
          const k = satirPazar(p);
          const odd = oddOf(p.odd || (m && m.odd));
          return (
            <Pressable key={i} disabled={!m || (!onMatch && !onAdmin)} onPress={() => m && onMatch && onMatch(m)} onLongPress={onAdmin ? () => onAdmin(c) : undefined} delayLongPress={400} accessibilityRole="button"
              style={({ pressed }) => ({ backgroundColor: pressed ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.06)', borderRadius: 14, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 })}>
              {m ? <Crest name={m.home} logo={m.homeLogo} size={26} /> : null}
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={{ color: '#fff', fontWeight: '600', fontSize: 14 }}>{m ? `${m.home} – ${m.away}` : 'Silinmiş maç'}</Text>
                {m ? (
                  <Text numberOfLines={1} style={{ fontSize: 14 }}>
                    <Text style={{ color: t.acc, fontWeight: '800' }}>{k || predText(m)}</Text>
                    <Text style={{ color: '#AEB6C0' }}>{k && marketText(k, m.home, m.away) ? ` · ${marketText(k, m.home, m.away)}` : ''}</Text>
                  </Text>
                ) : null}
                {m && m.status === 'live' ? <Text style={{ color: '#FF8A8E', fontWeight: '800', fontSize: 12.5 }}>● Canlı {m.score || ''} {canliDakika(m)}{r === 'won' ? '  ·  tuttu, maç bitmeden kesinleşti' : r === 'lost' ? '  ·  tutmadı' : ''}</Text>
                  : m && m.status === 'finished' && m.score ? <Text style={{ color: '#AEB6C0', fontSize: 12.5 }}>Maç sonu {m.score}</Text>
                  : m ? <Text style={{ color: '#8C96A3', fontSize: 12.5 }}>{m.time}{m.league ? ` · ${m.league}` : ''}</Text> : null}
              </View>
              {odd ? <Text style={{ color: '#fff', fontWeight: '800', fontSize: 15 }}>{odd.toFixed(2)}</Text> : null}
              {r ? <Icon name={r === 'won' ? 'checkmark-circle' : 'close-circle'} size={22} color={r === 'won' ? '#2EE59D' : '#FF6B7D'} /> : m && onMatch ? <Icon name="chevron-forward" size={18} color="#8C96A3" /> : null}
            </Pressable>
          );
        }) : (
          <View style={{ backgroundColor: C.dark2, borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Icon name={c.access === 'vip' ? 'diamond-outline' : 'lock-closed'} color="#fff" size={20} />
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15, flex: 1 }}>
              {c.access === 'vip' ? 'VIP kupon' : 'Kilitli kupon'} · görmek için dokun
            </Text>
            <Text style={{ color: '#FFB46B', fontWeight: '800' }}>🔑 {Math.max(1, Number(c.cost) || 1)}</Text>
          </View>
        )}
      </View>

      {total ? (
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 }}>
          <Text style={{ color: '#C5CCD6' }}>Toplam oran</Text>
          <Text style={{ color: won ? '#2EE59D' : t.acc, fontSize: 26, fontWeight: '800' }}>{total.toFixed(2)}</Text>
        </View>
      ) : open && onMatch ? <Text style={{ color: '#8C96A3', fontSize: 12.5, marginTop: 10 }}>Maça dokun: analiz, form ve canlı istatistikleri gör</Text> : null}
      {open && onAdmin ? <Text style={{ color: '#8C96A3', fontSize: 12, marginTop: 6 }}>Yönetici: maça basılı tut → tahmini değiştir / maçı bitir</Text> : null}
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
        <Pressable onPress={() => onComments && onComments(c)} accessibilityRole="button"
          style={{ flex: 1, minHeight: 44, borderRadius: 14, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.25)', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <Icon name="chatbubble-ellipses-outline" size={18} color="#fff" />
          <Text style={{ color: '#fff', fontWeight: '700' }}>Yorum & oy</Text>
        </Pressable>
        {open ? (
          <Pressable onPress={() => (onShareCard ? onShareCard({
            title: c.title || 'Günün Kuponu', sub: dayLabel(c.date, false), status: st, total: total ? total.toFixed(2) : '',
            lines: picks.filter((p) => p.m).map((p) => ({ t: `${p.m.home} – ${p.m.away}`, p: satirMetni(p), o: oddOf(p.odd || p.m.odd) ? oddOf(p.odd || p.m.odd).toFixed(2) : '', r: satirSonuc(p) })),
            text: kuponMetni(c, picks, total, st, appName),
          }) : paylas(kuponMetni(c, picks, total, st, appName)))} accessibilityRole="button"
            style={{ flex: 1, minHeight: 44, borderRadius: 14, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.25)', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <Icon name="share-social-outline" size={18} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: '700' }}>{won ? 'Tuttu, paylaş' : 'Paylaş'}</Text>
          </Pressable>
        ) : null}
      </View>
    </Pressable>
  );
}

/* 👥 Üyelerin tutan kuponları: son 7 gün, herkese açık, doğrulanmış (elle maç yok), en az 2 maç.
   Bizim başarı yüzdemize karışmaz, ayrı bölümde durur. */
function UyeTutanlar({ tribune, matches, me, isAdmin, onNeedAuth, onShareCard }) {
  const bas = Date.now() - 7 * 864e5;
  const L = (tribune?.list || [])
    .filter((x) => x.gorunur !== 'takipci' && !x.admin && (x.createdAt || 0) >= bas && (x.picks || []).length >= 2 && isVerified(x))
    .filter((x) => tribuneStatus(x, matches.list) === 'won')
    .slice(0, 30);
  const yorumSay = useCommentCounts(L.map((x) => 't_' + x.id));
  if (!L.length) return null;
  return (
    <View style={{ marginTop: 18 }}>
      <Text style={[s.h2, { marginBottom: 2 }]}>👥 Üyelerin tutan kuponları</Text>
      <Text style={[s.sub, { marginBottom: 10 }]}>Son 7 günde Tribün'de paylaşılıp tutan, en az 2 maçlık ve bültenden seçilmiş kuponlar. Bizim başarı oranımıza dahil değildir.</Text>
      {L.map((x, i) => (
        <Gir key={x.id} i={i}>
          <TribunKart tc={x} matchList={matches.list} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} onShareCard={onShareCard} yorumSay={yorumSay['t_' + x.id] || 0} baslik={`🎉 ${iyelik(x.name)} kuponu tuttu!`} />
        </Gir>
      ))}
    </View>
  );
}

const dayOffK = (n) => { const d = new Date(Date.now() + n * 864e5); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

export default function Kuponlar({ coupons, matches, me, onLocked, appName, logo, tribune, isAdmin, onNeedAuth, jump, shareTick, onMatch, onAdminCoupon }) {
  const [tab, setTab] = useState(jump === 'score' || jump === 'rank' || jump === 'feed' || jump === 'share' ? 'tribun' : jump === 'won' ? 'won' : jump === 'robot' ? 'robot' : 'today');
  useEffect(() => { if (jump === 'robot') setTab('robot'); else if (['score', 'rank', 'feed', 'share'].includes(jump)) setTab('tribun'); }, [jump]);
  useEffect(() => { if (shareTick) setTab('tribun'); }, [shareTick]);
  const [talk, setTalk] = useState(null);
  const [card, setCard] = useState(null);
  const td = today();
  const withSt = coupons.list.map((c) => ({ c, st: couponStatus(couponPicks(c, matches.list)) }));
  const yeniUst = (a, b) => (a.st === 'pending' ? 0 : 1) - (b.st === 'pending' ? 0 : 1) || String(b.c.date).localeCompare(a.c.date);
  const list = tab === 'today'
    ? withSt.filter((x) => !x.c.robot && (x.c.date >= td || x.st === 'pending')).sort(yeniUst)
    : tab === 'robot'
      ? withSt.filter((x) => x.c.robot && x.c.date >= dayOffK(-3)).sort(yeniUst)
      : withSt.filter((x) => x.st === 'won').sort((a, b) => String(b.c.date).localeCompare(a.c.date)).slice(0, 50);
  const wonCount = withSt.filter((x) => x.st === 'won').length;
  const done = withSt.filter((x) => x.st !== 'pending').length;
  const rDone = withSt.filter((x) => x.c.robot && x.st !== 'pending');
  const rWon = rDone.filter((x) => x.st === 'won').length;

  return (
    <View>
      <Text style={[s.h1, { marginBottom: 14 }]}>Kuponlar</Text>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 14 }}>
        {[['today', 'Kuponlar'], ['robot', '🤖 Robot'], ['won', `Tutanlar${wonCount ? ` (${wonCount})` : ''}`], ['tribun', 'Tribün']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }}
            style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: tab === k ? C.card : 'transparent' }}>
            <Text numberOfLines={1} style={{ fontWeight: tab === k ? '700' : '600', color: tab === k ? C.ink : C.mut, fontSize: 13.5 }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {tab === 'robot' && rDone.length ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.card, borderRadius: 14, padding: 12, marginBottom: 12 }}>
          <Text style={{ fontSize: 20 }}>🤖</Text>
          <Text style={{ flex: 1, color: C.ink, fontWeight: '600' }}>Robotun kuponları: {rDone.length} kuponun {rWon} tanesi tuttu (%{Math.round((rWon / rDone.length) * 100)})</Text>
        </View>
      ) : null}
      {tab === 'won' && done ? (
        <Text style={[s.sub, { marginBottom: 12 }]}>Sonuçlanan {done} kuponun {wonCount} tanesi tuttu (%{Math.round((wonCount / done) * 100)}).</Text>
      ) : null}
      {tab === 'tribun' ? (
        <Tribun tribune={tribune} matches={matches} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} start={jump === 'score' || jump === 'rank' || jump === 'feed' ? jump : null} shareTick={jump === 'share' ? shareTick : 0} onShareCard={setCard} />
      ) : coupons.loading ? (
        <Iskelet n={2} h={160} />
      ) : !list.length ? (
        <View style={s.empty}>
          <Text style={[s.h3, { marginBottom: 0 }]}>{tab === 'today' ? 'Henüz kupon yok' : tab === 'robot' ? 'Robot henüz kupon yapmadı' : 'Henüz tutan kupon yok'}</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>{tab === 'today' ? 'Günün kuponu eklenince burada görünecek.' : tab === 'robot' ? 'Robot her gün öğleden sonra kendi kuponunu paylaşır.' : 'Tutan kuponlar burada listelenecek.'}</Text>
        </View>
      ) : list.map(({ c }, i) => <Gir key={c.id} i={i}><KuponKart c={c} matchList={matches.list} me={me} onLocked={onLocked} appName={appName} onComments={setTalk} onShareCard={setCard} onMatch={onMatch} onAdmin={isAdmin ? onAdminCoupon : undefined} /></Gir>)}
      {tab === 'won' ? <UyeTutanlar tribune={tribune} matches={matches} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} onShareCard={setCard} /> : null}
      {card ? <PaylasKart data={card} appName={appName} logo={logo} onClose={() => setCard(null)} /> : null}
      {talk ? <EtkilesimPenceresi target={'c_' + talk.id} title={talk.title || 'Günün Kuponu'} me={me} isAdmin={isAdmin} onNeedAuth={() => { setTalk(null); onNeedAuth(); }} onClose={() => setTalk(null)} /> : null}
    </View>
  );
}
