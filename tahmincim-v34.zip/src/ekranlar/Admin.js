import React, { useState } from 'react';
import { View, Text, Pressable, Modal, ScrollView, Image, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import { C, marketText, today, dayOff, newId, isImg, predText, oddOf, couponPicks, couponTotal, couponStatus, dayLabel, successStats, evalMarket, canliDakika, satirPazar, satirSonuc, APP_SURUM, izinVar, IZINLER, IZIN_VARSAYILAN } from '../tema';
import { Btn, Card, Crest, Field, Icon, Seg, Toggle, s, useToast, useKeyboardHeight, Sheet, Avatar } from '../parcalar';
import { saveMatch, removeMatch, patchMatch, saveConfig, clearBanko, logout, useUsers, updateUser, saveCoupon, removeCoupon, grantRole, useRoles, modLog, useModLog, useAktifler, setIzin } from '../veri';
import { sendPushAll, countDevices, notifHistory, sendPushTo } from '../bildirim';
import { useTeams, saveTeam, removeTeam, findTeam, suggestTeams, importTeamsFromMatches, useRecentComments, deleteComment, useReports, deleteReport, deleteReportsFor, useTribune, deleteTribune, countCollection, useViewCounts, useFeedback, deleteFeedback, replyFeedback } from '../topluluk';
import { onceLabel } from './Etkilesim';
import { getApiKey, saveApiKey, testConnection } from '../veriApi';
import { LIGLER, SKOR_LIGLER, senkronTick, senkronDinle } from '../senkron';
import { useCanliSkor } from './Canli';
import HizliMenu, { askNotify } from './HizliMenu';
import TahminSec from './TahminSec';
import Hareketler, { useHareket, HareketKart } from './Hareketler';

/* Görseli küçültüp veritabanına sığacak hale getirir */
async function pickImage(maxSide, jpeg) {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('perm');
  const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 1, allowsEditing: !jpeg, aspect: [1, 1] });
  if (res.canceled || !res.assets?.length) return null;
  const a = res.assets[0];
  if (typeof ImageManipulator.manipulateAsync !== 'function') {
    // Yedek yol: küçültme aracı yoksa düşük kalitede yeniden seç
    const r2 = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.2, base64: true, allowsEditing: true, aspect: jpeg ? [3, 1] : [1, 1] });
    if (r2.canceled || !r2.assets?.[0]?.base64) return null;
    const u = `data:image/jpeg;base64,${r2.assets[0].base64}`;
    if (u.length > 300000) throw new Error('big');
    return u;
  }
  const scale = Math.min(1, maxSide / Math.max(a.width || maxSide, a.height || maxSide));
  const out = await ImageManipulator.manipulateAsync(
    a.uri,
    scale < 1 ? [{ resize: { width: Math.round((a.width || maxSide) * scale) } }] : [],
    { compress: jpeg ? 0.8 : 1, format: jpeg ? ImageManipulator.SaveFormat.JPEG : ImageManipulator.SaveFormat.PNG, base64: true }
  );
  const url = `data:image/${jpeg ? 'jpeg' : 'png'};base64,${out.base64}`;
  if (url.length > 300000) throw new Error('big');
  return url;
}

function Header({ title, onBack, right }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 }}>
      <Pressable onPress={onBack} accessibilityLabel="Geri" style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="chevron-back" />
      </Pressable>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 12, fontWeight: '700', letterSpacing: 1, color: C.mut }}>YÖNETİM PANELİ</Text>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{title}</Text>
      </View>
      {right}
    </View>
  );
}

const ACCESS = { open: 'Açık', locked: 'Kilitli', vip: 'VIP' };

export default function Admin({ visible, onClose, matches, coupons, cfg, startWith, me, perm = {}, onGoMatch, onGoTribun }) {
  const ins = useSafeAreaInsets();
  const kb = useKeyboardHeight();
  const [page, setPage] = useState('list');
  const [m, setM] = useState(null);
  const [c, setC] = useState(null);
  const [uid, setUid] = useState(null);
  const [co, setCo] = useState(null);
  const [listTab, setListTab] = useState('matches');
  const [comTab, setComTab] = useState('feedback');
  const users = useUsers(visible && (page === 'users' || page === 'user'));
  const teams = useTeams();
  const roles = useRoles(visible && (page === 'users' || page === 'user'));
  const P = (k) => izinVar(me, k);
  perm = { ...perm, i: P };
  const har = useHareket(me, matches, !!visible && !!perm.admin);
  const listeIzni = perm.admin || ['mac', 'sonuc', 'kupon', 'bildirim', 'istatistik'].some(P);
  const home = listeIzni ? 'list' : 'community';
  const goHome = () => setPage(home);

  // Maçı düzenlemeye aç: robotun maçıysa robotun kaydı değil, senin ayrı kaydın açılır
  const duzenle = (x0) => {
    if (!P('mac') || ((x0.access || 'open') !== 'open' && !P('vip'))) { if (P('sonuc')) setPage('results'); return; }
    const x = kendiKaydi(x0, matches.list) || x0;
    setM({ ...x, pollQ: x.poll?.q || '', pollOpts: [...(x.poll?.opts || []), '', '', '', ''].slice(0, 4) });
    setPage('match');
  };
  React.useEffect(() => {
    if (visible && startWith && startWith.edit && (P('mac') || P('sonuc'))) duzenle(startWith.edit);
    else if (visible && startWith && startWith.coupon && (P('kupon') || P('sonuc'))) { setCo(JSON.parse(JSON.stringify({ ...startWith.coupon, picks: startWith.coupon.picks || [] }))); setPage('coupon'); }
    else if (visible && startWith === 'new' && P('mac')) { setM(blank()); setPage('match'); }
    else if (visible) setPage(home);
  }, [visible, startWith, home]);

  const blankCoupon = () => ({ id: newId(), title: 'Günün Kuponu', date: today(), access: P('vip') ? 'locked' : 'open', cost: 5, picks: [], isNew: true });
  const blank = () => ({ id: newId(), odd: '', home: '', away: '', homeLogo: '', awayLogo: '', league: '', date: today(), time: '20:00', market: 'MS 1', marketOther: '', text: '', conf: 3, reasons: '', access: 'open', cost: 1, banko: false, status: 'upcoming', score: '', minute: '', liveText: '', result: '', p1: '', px: '', p2: '', isNew: true });

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={() => (page === home ? onClose() : page === 'user' ? setPage('users') : goHome())} statusBarTranslucent>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.adminBg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 16, paddingTop: ins.top + 16, paddingBottom: ins.bottom + 40 + kb }} keyboardShouldPersistTaps="handled">
          {page === 'list' ? (
            <List matches={matches} coupons={coupons} cfg={cfg} tab={listTab} setTab={setListTab} onClose={onClose} har={har} onHareket={() => setPage('hareket')}
              onNewCoupon={() => { setCo(blankCoupon()); setPage('coupon'); }}
              onEditCoupon={(x) => { setCo(JSON.parse(JSON.stringify({ ...x, picks: x.picks || [] }))); setPage('coupon'); }}
              onNew={() => { setM(blank()); setPage('match'); }}
              onEdit={duzenle}
              onCfg={() => { setC(JSON.parse(JSON.stringify(cfg))); setPage('cfg'); }}
              onUsers={() => setPage('users')} onPush={() => setPage('push')} onTeams={() => setPage('teams')} onCommunity={(k) => { setComTab(typeof k === 'string' ? k : 'feedback'); setPage('community'); }} onStats={() => setPage('stats')} onResults={() => setPage('results')} onBulk={() => setPage('bulk')} perm={perm} />
          ) : page === 'hareket' ? (
            <Hareketler h={har} me={me} Header={Header} onBack={() => setPage('list')}
              onMatch={(x) => { onClose(); onGoMatch && setTimeout(() => onGoMatch(x), 350); }}
              onTribun={() => { onClose(); onGoTribun && setTimeout(() => onGoTribun(), 350); }} />
          ) : page === 'match' && m ? (
            <MatchForm m={m} setM={setM} all={matches.list} teams={teams.list} cfg={cfg} perm={perm} onBack={() => setPage('list')} />
          ) : page === 'cfg' && c && perm.owner ? (
            <CfgForm c={c} setC={setC} cfg={cfg} matches={matches} teams={teams.list} onBack={() => setPage('list')} />
          ) : page === 'coupon' && co ? (
            <CouponForm co={co} setCo={setCo} matches={matches} cfg={cfg} perm={perm} onBack={() => setPage('list')} />
          ) : page === 'bulk' ? (
            <TopluEkle teams={teams.list} cfg={cfg} onBack={() => setPage('list')} />
          ) : page === 'results' ? (
            <TopluSonuc matches={matches} cfg={cfg} onBack={() => setPage('list')} />
          ) : page === 'stats' ? (
            <Istatistik matches={matches} coupons={coupons} onBack={() => setPage('list')} />
          ) : page === 'teams' ? (
            <Takimlar teams={teams} matches={matches} onBack={() => setPage('list')} />
          ) : page === 'community' ? (
            <Topluluk matches={matches} me={me} perm={perm} start={comTab} onBack={listeIzni ? goHome : onClose} onUsers={() => setPage('users')} />
          ) : page === 'push' ? (
            <Bildirim cfg={cfg} matches={matches} onBack={() => setPage('list')} />
          ) : page === 'users' ? (
            <Users users={users} roles={roles} izinliEposta={P('uyeler')} onBack={goHome} onOpen={(id) => { setUid(id); setPage('user'); }} />
          ) : page === 'user' ? (
            <UserDetail u={users.list.find((x) => x.id === uid)} role={(roles.find((r) => r.id === uid) || {}).role || ''} roleDoc={roles.find((r) => r.id === uid) || {}} me={me} perm={perm} onBack={() => setPage('users')} />
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

/* ---------------- Kontrol merkezi (admin ana sayfası) ---------------- */
const BITTI_MI = (m) => {
  if (m.status === 'finished') return !m.result;
  if (m.status === 'live' || m.auto) return false;
  const [y, mo, d] = String(m.date).split('-').map(Number); const [h, mi] = String(m.time).split(':').map(Number);
  return Date.now() > new Date(y, (mo || 1) - 1, d || 1, h || 0, mi || 0).getTime() + 130 * 60000;
};
const FILTRE = [
  ['bugun', 'Bugün', (m) => m.date === today()],
  ['yarin', 'Yarın', (m) => m.date === dayOff(1)],
  ['canli', '🔴 Canlı', (m) => m.status === 'live'],
  ['sonuc', '⏳ Sonuç bekleyen', BITTI_MI],
  ['taslak', '📝 Taslak', (m) => !!m.draft],
  ['dogrula', '⚠️ Skoru doğrula', (m) => !!m.dogrula],
  ['banko', '🔥 Banko', (m) => !!m.banko],
  ['benim', '🎯 Benim', (m) => !m.robot && !m.auto],
  ['robot', '🤖 Robot', (m) => !!m.robot],
  ['hepsi', 'Tümü', () => true],
];

function Kutu({ e, n, l, onPress, renk }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={({ pressed }) => ({ flexGrow: 1, flexBasis: '46%', backgroundColor: C.card, borderRadius: 18, padding: 14, gap: 2, borderWidth: 1.5, borderColor: renk || C.border, opacity: pressed ? 0.85 : 1 })}>
      <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{e} {n}</Text>
      <Text style={{ color: C.mut, fontWeight: '600', fontSize: 13 }}>{l}</Text>
    </Pressable>
  );
}
function Aksiyon({ e, l, onPress, ana }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={({ pressed }) => ({ flexGrow: 1, flexBasis: '22%', backgroundColor: ana ? C.hero : C.card, borderRadius: 18, paddingVertical: 14, alignItems: 'center', gap: 6, opacity: pressed ? 0.85 : 1 })}>
      <Text style={{ fontSize: 24 }}>{e}</Text>
      <Text style={{ color: ana ? '#fff' : C.ink, fontWeight: '700', fontSize: 12.5, textAlign: 'center' }}>{l}</Text>
    </Pressable>
  );
}
function Arac({ icon, l, sub, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
      <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} size={21} /></View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '700', color: C.ink, fontSize: 15.5 }}>{l}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <Icon name="chevron-forward" color={C.mut} size={18} />
    </Pressable>
  );
}
function SenkronSerit() {
  const [st, setSt] = useState(null);
  React.useEffect(() => senkronDinle(setSt), []);
  if (!st) return null;
  const son = Math.max(st.lastLive || 0, st.lastToday || 0, st.lastTomorrow || 0, st.lastTick || 0);
  const taze = son && Date.now() - son < 30 * 60000;
  const kalan = 90 - (st.calls || 0);
  const uyari = kalan <= 0 ? 'bitti' : kalan <= 20 ? 'az' : '';
  return (
    <View style={{ backgroundColor: C.card, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9, marginBottom: 12, borderWidth: uyari ? 1.5 : 0, borderColor: uyari === 'bitti' ? C.red : '#FF8A1F' }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: taze ? '#00D26A' : C.mut }} />
        <Text style={{ flex: 1, color: C.mut, fontSize: 12.5, fontWeight: '600' }}>
          Otomatik veri · son güncelleme {son ? new Date(son).toTimeString().slice(0, 5) : '—'} · sorgu {st.calls}/90
        </Text>
      </View>
      {uyari ? (
        <Text style={{ color: uyari === 'bitti' ? C.red : '#B85E00', fontSize: 12.5, fontWeight: '700', marginTop: 4 }}>
          {uyari === 'bitti'
            ? '⛔ Bugünkü sorgu hakkı bitti. Skorlar gece 03:00\'e kadar güncellenmez. Maçları kupondan "Maçı bitir" ile kapatabilirsin.'
            : `⚠️ Sorgu hakkı azalıyor (${kalan} kaldı). Canlı güncelleme seyrekleşti.`}
        </Text>
      ) : null}
    </View>
  );
}

const SEKME_AD = { today: 'Bugün', live: 'Canlı', coupons: 'Kuponlar', results: 'Sonuçlar', me: 'Ben' };
function AktifKart() {
  const ak = useAktifler(true);
  const [acik, setAcik] = useState(false);
  const once = (t) => { const d = Math.max(0, Math.round((Date.now() - (t || 0)) / 60000)); return d < 1 ? 'şimdi' : `${d} dk önce`; };
  return (
    <>
      <Pressable onPress={() => setAcik(true)} accessibilityRole="button"
        style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.hero, borderRadius: 18, padding: 14, marginBottom: 12, opacity: pressed ? 0.9 : 1 })}>
        <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: '#00D26A' }} />
        <View style={{ flex: 1 }}>
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 17 }}>{ak.list.length} kişi şu an uygulamada</Text>
          <Text style={{ color: '#AEB6C0', fontSize: 13 }}>Bugün giren: {ak.bugun == null ? '…' : ak.bugun} üye · kimler olduğunu görmek için dokun</Text>
        </View>
        <Icon name="chevron-forward" color="#fff" size={18} />
      </Pressable>
      {acik ? (
        <Sheet visible onClose={() => setAcik(false)}>
          <Text style={[s.h2, { marginBottom: 2 }]}>🟢 Şu an aktif ({ak.list.length})</Text>
          <Text style={[s.sub, { marginBottom: 12 }]}>Son 5 dakikada uygulamayı kullanan üyeler. Misafirler sayılmaz.</Text>
          {ak.list.length ? ak.list.map((u) => (
            <View key={u.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.line }}>
              <Avatar emoji={u.avatar} name={u.name} size={40} />
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{u.name || 'Üye'}{u.vipUntil > Date.now() ? ' 💎' : ''}</Text>
                <Text style={{ color: C.mut, fontSize: 13 }}>{SEKME_AD[u.sekme] ? `${SEKME_AD[u.sekme]} sekmesinde · ` : ''}{once(u.lastSeen)}</Text>
              </View>
            </View>
          )) : <Text style={[s.sub, { marginBottom: 12 }]}>Şu an aktif üye yok.</Text>}
          <View style={{ height: 12 }} />
        </Sheet>
      ) : null}
    </>
  );
}

function List({ har, onHareket, matches, coupons, cfg, tab, setTab, onClose, onNew, onEdit, onCfg, onUsers, onPush, onTeams, onCommunity, onStats, onNewCoupon, onEditCoupon, onResults, onBulk, perm = {} }) {
  if (!perm.i) perm = { ...perm, i: () => true };
  const toast = useToast();
  const [filtre, setFiltre] = useState('bugun');
  const [ara, setAra] = useState('');
  const [hizli, setHizli] = useState(null);
  const fbs = useFeedback(perm.i ? perm.i('sikayet') : true);
  const reports = useReports(perm.i ? perm.i('sikayet') : true);
  const all = matches.list;
  const say = (k) => all.filter(FILTRE.find((f) => f[0] === k)[2]).length;
  const yeniMesaj = fbs.list.filter((f) => !f.reply).length;
  const q = normAra(ara);
  const f = FILTRE.find((x) => x[0] === filtre) || FILTRE[0];
  const ms = all.filter(q ? (m) => normAra(`${m.home} ${m.away} ${m.league}`).includes(q) : f[2])
    .sort((a, b) => (filtre === 'hepsi' || q ? String(b.date + b.time).localeCompare(a.date + a.time) : String(a.date + a.time).localeCompare(b.date + b.time)));
  const cs = [...(coupons?.list || [])].sort((a, b) => String(b.date).localeCompare(a.date));
  const views = useViewCounts(tab === 'coupons' ? cs.slice(0, 30).map((x) => 'c_' + x.id) : ms.slice(0, 40).map((x) => 'm_' + x.id));
  const Goz = ({ k }) => (views[k] != null ? (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
      <Icon name="eye-outline" size={15} color={C.mut} />
      <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13 }}>{views[k]}</Text>
    </View>
  ) : null);
  const git = (k) => { setTab('matches'); setFiltre(k); setAra(''); };
  const isler = [
    say('canli') ? { e: '🔴', n: say('canli'), l: 'Canlı maç', go: () => git('canli'), renk: C.red } : null,
    say('sonuc') ? { e: '⏳', n: say('sonuc'), l: 'Sonuç girilmedi', go: onResults, renk: '#FF8A1F' } : null,
    say('dogrula') ? { e: '⚠️', n: say('dogrula'), l: 'Skoru doğrula', go: () => git('dogrula'), renk: '#FF8A1F' } : null,
    say('taslak') ? { e: '📝', n: say('taslak'), l: 'Taslak onay bekliyor', go: () => git('taslak') } : null,
    yeniMesaj && perm.i('sikayet') ? { e: '💬', n: yeniMesaj, l: 'Cevapsız mesaj', go: () => onCommunity('feedback') } : null,
    reports.list.length && perm.i('sikayet') ? { e: '🚩', n: reports.list.length, l: 'Bildirilen içerik', go: () => onCommunity('reports'), renk: C.red } : null,
  ].filter(Boolean);
  const yayinla = (m) => patchMatch(m.id, { draft: false }).then(() => toast('Yayınlandı 🚀')).catch(() => toast('Olmadı'));

  return (
    <View>
      <Header title="Kontrol merkezi" onBack={onClose}
        right={<Pressable onPress={() => logout().then(onClose)} accessibilityLabel="Çıkış yap" style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}><Icon name="log-out-outline" /></Pressable>} />
      {perm.i('istatistik') ? <AktifKart /> : null}
      {har ? <HareketKart h={har} onPress={onHareket} /> : null}
      {!perm.owner ? <IzinOzet perm={perm} /> : null}
      {cfg?.auto?.on ? <SenkronSerit /> : null}

      <Text style={[s.label, { marginTop: 0 }]}>Yapılacaklar</Text>
      {isler.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
          {isler.map((x) => <Kutu key={x.l} e={x.e} n={x.n} l={x.l} renk={x.renk} onPress={x.go} />)}
        </View>
      ) : (
        <View style={{ backgroundColor: C.card, borderRadius: 18, padding: 14, marginBottom: 14, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
          <Text style={{ fontSize: 22 }}>✅</Text>
          <Text style={{ flex: 1, color: C.ink, fontWeight: '600' }}>Bekleyen iş yok, her şey yolunda.</Text>
        </View>
      )}

      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
        {perm.i('mac') ? <Aksiyon ana e="➕" l="Maç ekle" onPress={onNew} /> : null}
        {perm.i('sonuc') ? <Aksiyon e="✅" l="Sonuç gir" onPress={onResults} /> : null}
        {perm.i('kupon') ? <Aksiyon e="🎟️" l="Kupon yap" onPress={onNewCoupon} /> : null}
        {perm.i('bildirim') ? <Aksiyon e="🔔" l="Bildirim" onPress={onPush} /> : null}
      </View>

      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 12 }}>
        {[['matches', 'Maçlar'], ['coupons', 'Kuponlar'], ['community', 'Topluluk'], ['settings', 'Ayarlar']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }}
            style={{ flex: 1, minHeight: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: tab === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: tab === k ? '800' : '600', color: tab === k ? C.ink : C.mut, fontSize: 13.5 }}>{l}</Text>
          </Pressable>
        ))}
      </View>

      {tab === 'matches' ? (
        <View>
          <Field value={ara} onChangeText={setAra} placeholder="🔍 Takım ya da lig ara" />
          {!q ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10, marginTop: -4 }} contentContainerStyle={{ gap: 6 }}>
              {FILTRE.map(([k, l]) => {
                const n = k === 'hepsi' ? all.length : say(k);
                const on = filtre === k;
                return (
                  <Pressable key={k} onPress={() => setFiltre(k)} style={{ paddingHorizontal: 12, minHeight: 36, borderRadius: 18, justifyContent: 'center', borderWidth: 1.5, borderColor: on ? C.ink : C.border, backgroundColor: on ? C.card : 'transparent' }}>
                    <Text style={{ fontWeight: on ? '800' : '600', color: on ? C.ink : C.mut, fontSize: 13 }}>{l} {n}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          ) : null}
          <Text style={[s.note, { marginBottom: 8 }]}>Dokun: düzenle · Basılı tut: hızlı menü (banko, sonuç, gizle, sil) · 👁 = gören kişi</Text>
          {ms.length ? ms.slice(0, 80).map((x) => (
            <Pressable key={x.id} onPress={() => onEdit(x)} onLongPress={() => setHizli(x)} delayLongPress={350} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
              <Crest name={x.home} logo={x.homeLogo} size={34} />
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.home} – {x.away}</Text>
                <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>
                  {x.date === today() ? '' : `${x.date.slice(5)} `}{x.time} · {x.market || 'tahmin yok'} · {ACCESS[x.access] || ''}{x.banko ? ' · 🔥' : ''}{x.auto ? ' · 🔄' : ''}{x.robot ? ' · 🤖' : ''}{x.hidden ? ' · gizli' : ''}{x.publishAt > Date.now() ? ` · ⏰ ${saatStr(x.publishAt)}` : ''}
                </Text>
                {x.status === 'live' ? <Text style={{ color: C.red, fontWeight: '800', fontSize: 12.5 }}>● CANLI {x.score || ''} {canliDakika(x)}</Text>
                  : x.status === 'finished' ? <Text style={{ color: x.result === 'won' ? '#00A854' : x.result === 'lost' ? C.red : '#FF8A1F', fontWeight: '700', fontSize: 12.5 }}>Bitti {x.score || ''} · {x.result === 'won' ? 'Tuttu ✅' : x.result === 'lost' ? 'Tutmadı' : 'sonuç bekliyor'}</Text> : null}
              </View>
              {x.draft ? (x.market ? <Btn small kind="acc" title="Yayınla" onPress={() => yayinla(x)} /> : <Text style={{ color: '#FF8A1F', fontWeight: '700', fontSize: 12.5 }}>Tahmin seç</Text>) : <Goz k={'m_' + x.id} />}
            </Pressable>
          )) : (
            <View style={s.empty}>
              <Text style={[s.h3, { marginBottom: 0 }]}>{q ? 'Bulunamadı' : 'Bu listede maç yok'}</Text>
              <Text style={s.sub}>{q ? 'Başka bir isim dene.' : '"Maç ekle" ile tahmin ekleyebilirsin.'}</Text>
            </View>
          )}
          {ms.length > 80 ? <Text style={[s.note, { textAlign: 'center' }]}>İlk 80 maç gösteriliyor, aramayı kullan.</Text> : null}
        </View>
      ) : tab === 'coupons' ? (
        <View>
          <Btn small kind="ink" title="+ Yeni kupon" onPress={onNewCoupon} style={{ marginBottom: 10 }} />
          {cs.length ? cs.map((x) => {
            const pk = couponPicks(x, matches.list);
            const st = couponStatus(pk);
            const tot = couponTotal(pk);
            return (
              <Pressable key={x.id} onPress={() => onEditCoupon(x)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
                <Text style={{ fontSize: 24 }}>{x.robot ? '🤖' : '🎟️'}</Text>
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.title || 'Kupon'} · {pk.length} maç</Text>
                  <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>
                    {x.date} · Oran {tot ? tot.toFixed(2) : '—'} · {ACCESS[x.access] || ''} · {st === 'won' ? 'Tuttu ✅' : st === 'lost' ? 'Tutmadı' : 'Bekliyor'}{x.publishAt > Date.now() ? ` · ⏰ ${saatStr(x.publishAt)}` : ''}
                  </Text>
                </View>
                <Goz k={'c_' + x.id} />
                <Icon name="chevron-forward" color={C.mut} size={18} />
              </Pressable>
            );
          }) : <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Henüz kupon yok</Text><Text style={s.sub}>"Kupon yap" ile oluştur. Robot da her gün kendi kuponunu paylaşır.</Text></View>}
        </View>
      ) : tab === 'community' ? (
        <View>
          {perm.i('sikayet') ? <Arac icon="mail-outline" l="Mesajlar" sub={`Öneri ve şikayetler${yeniMesaj ? ` · ${yeniMesaj} cevapsız` : ''}`} onPress={() => onCommunity('feedback')} /> : null}
          {perm.i('sikayet') ? <Arac icon="flag-outline" l="Bildirilen içerik" sub={reports.list.length ? `${reports.list.length} bildirim` : 'Temiz'} onPress={() => onCommunity('reports')} /> : null}
          {perm.i('yorum') || perm.i('tribun') ? <Arac icon="chatbubbles-outline" l="Yorumlar ve Tribün" sub="Son yorumlar, kullanıcı kuponları" onPress={() => onCommunity('comments')} /> : null}
          {perm.i('uyeler') || perm.i('sustur') || perm.i('anahtar') ? <Arac icon="people-outline" l="Kullanıcılar" sub={perm.owner ? 'Anahtar, VIP, susturma, yetki ve izinler' : 'Senin izinlerine göre'} onPress={onUsers} /> : null}
        </View>
      ) : (
        <View>
          {perm.owner ? <Arac icon="settings-outline" l="Uygulama ayarları" sub="Görünüm, reklam, anahtar, otomatik maçlar, robot" onPress={onCfg} /> : null}
          {perm.i('istatistik') ? <Arac icon="stats-chart-outline" l="İstatistik" sub="Başarı oranı, kullanıcı sayıları" onPress={onStats} /> : null}
          {perm.i('mac') ? <Arac icon="flash-outline" l="Toplu maç ekle" sub="Birden fazla maçı tek seferde" onPress={onBulk} /> : null}
          {perm.i('mac') ? <Arac icon="shield-outline" l="Takımlar" sub="Takım adları ve logolar" onPress={onTeams} /> : null}
        </View>
      )}
      {hizli ? <HizliMenu m={all.find((x) => x.id === hizli.id) || hizli} all={all} cfg={cfg} onEdit={onEdit} onClose={() => setHizli(null)} izin={perm.i} /> : null}
    </View>
  );
}
const normAra = (t) => String(t || '').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ı/g, 'i').trim();

/* ---------------- Maç ekle / düzenle ---------------- */
function MatchForm({ m, setM, all, teams, cfg, onBack, perm = {} }) {
  const vipIzin = perm.i ? perm.i('vip') : true;
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [bulten, setBulten] = useState(false);
  const [gelismis, setGelismis] = useState(false);
  const F = (k, v) => setM((x) => ({ ...x, [k]: v }));
  const autoText = marketText(m.market, m.home, m.away);

  const pickLogo = async (k) => {
    try { const u = await pickImage(128, false); if (u) F(k, u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const pickMarket = (k) => setM((x) => ({ ...x, market: k, text: !x.text || x.text === marketText(x.market, x.home, x.away) ? '' : x.text }));

  const publish = async () => {
    if (!m.home.trim() || !m.away.trim()) return toast('İki takımın adını da yaz');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(m.date)) return toast('Tarihi 2026-11-21 biçiminde yaz');
    const out = { ...m };
    delete out.isNew; delete out._robotdan;
    if (out.market === 'Diğer' && out.marketOther) out.market = out.marketOther.trim();
    if (!out.market) return toast('Bir tahmin seç');
    out.home = out.home.trim();
    out.away = out.away.trim();
    if (!out.text) out.text = marketText(out.market, out.home, out.away) || out.market;
    out.cost = Math.max(1, +out.cost || 1);
    out.conf = +out.conf || 3;
    out.updatedAt = Date.now();
    out.homeForm = String(out.homeForm || '').toUpperCase().replace(/[^GBM]/g, '').slice(0, 5);
    out.awayForm = String(out.awayForm || '').toUpperCase().replace(/[^GBM]/g, '').slice(0, 5);
    const opts = (out.pollOpts || []).map((x) => String(x || '').trim()).filter(Boolean).slice(0, 4);
    out.poll = String(out.pollQ || '').trim() && opts.length >= 2 ? { q: String(out.pollQ).trim().slice(0, 120), opts } : null;
    delete out.pollQ; delete out.pollOpts;
    out.draft = false; // admin kaydedince taslak yayına girer
    out.dogrula = false; // admin skoru gördü, onayladı
    setBusy(true);
    try {
      if (out.banko) await clearBanko(all, out.date, out.id);
      await saveMatch(out);
      // Logoları takım kütüphanesine kaydet (bir dahakine otomatik gelsin)
      for (const [n, l] of [[out.home, out.homeLogo], [out.away, out.awayLogo]]) {
        const tm = findTeam(teams, n);
        if (l && (!tm || tm.logo !== l)) saveTeam(n, l).catch(() => {});
      }
      toast(m.isNew ? 'Maç yayınlandı' : 'Kaydedildi');
      onBack();
      const before = (all || []).find((x) => x.id === out.id);
      if (!m.isNew && out.result === 'won' && (!before || before.result !== 'won')) {
        askNotify(cfg, '✅ Tahminimiz tuttu!', `${out.home} – ${out.away}${out.score ? ` · ${out.score}` : ''} · ${predText(out)}`, toast, 'tuttu');
      }
      if (m.isNew && !out.hidden && !(out.publishAt > Date.now())) askNotify(cfg, out.banko ? '🔥 Günün bankosu yayında!' : '⚽ Yeni tahmin yayında', `${out.home} – ${out.away} · ${out.time}`, toast, out.banko ? 'banko' : 'tahmin');
      if (out.publishAt > Date.now()) toast(`⏰ ${saatStr(out.publishAt)} itibarıyla yayında olacak`);
    } catch (e) {
      toast('Kaydedilemedi. Admin e-postanı kontrol et.');
    }
    setBusy(false);
  };

  const del = () =>
    Alert.alert('Maç silinsin mi?', `${m.home} – ${m.away} herkesten kaldırılacak.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: async () => { try { await removeMatch(m.id, m.afId); toast('Maç silindi'); onBack(); } catch (e) { toast('Silinemedi'); } } },
    ]);

  // Takım adı yazılınca kütüphanede varsa logo kendiliğinden gelir
  const setTeamName = (side, v) => setM((x) => {
    const tm = findTeam(teams, v);
    const lk = side + 'Logo';
    return { ...x, [side]: v, [lk]: tm && tm.logo ? tm.logo : (findTeam(teams, x[side]) ? '' : x[lk]) };
  });
  const pickTeam = (side, tm) => setM((x) => ({ ...x, [side]: tm.name, [side + 'Logo']: tm.logo || x[side + 'Logo'] }));
  const Oneriler = ({ text, onPick }) => {
    const sug = suggestTeams(teams, text);
    if (!sug.length) return null;
    return (
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: -6, marginBottom: 12, marginLeft: 62 }}>
        {sug.map((tm) => (
          <Pressable key={tm.id} onPress={() => onPick(tm)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, minHeight: 36, borderRadius: 18, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border }}>
            <Crest name={tm.name} logo={tm.logo} size={20} />
            <Text style={{ color: C.ink, fontWeight: '600' }}>{tm.name}</Text>
          </Pressable>
        ))}
      </View>
    );
  };

  const LogoBtn = ({ k, label }) => (
    <Pressable onPress={() => pickLogo(k)} accessibilityLabel={label} style={{ width: 52, height: 52, borderRadius: 14, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 12 }}>
      {isImg(m[k]) ? <Image source={{ uri: m[k] }} style={{ width: 52, height: 52 }} resizeMode="contain" /> : <Icon name="add" color={C.mut} />}
    </Pressable>
  );

  return (
    <View>
      <Header title={m._robotdan ? 'Kendi tahminin' : m.isNew ? 'Yeni maç ekle' : 'Maçı düzenle'} onBack={onBack} />
      {m.isNew && !m._robotdan ? (
        <Pressable onPress={() => setBulten(true)} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.hero, borderRadius: 18, padding: 16, marginBottom: 12 }}>
          <Text style={{ fontSize: 26 }}>📋</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#fff', fontWeight: '800', fontSize: 16 }}>Bültenden maç seç</Text>
            <Text style={{ color: '#C5CCD6', fontSize: 13 }}>Bugünün ve yarının maçları, canlılar dahil. Dokun, takımlar, logolar ve saat kendiliğinden dolsun.</Text>
          </View>
          <Icon name="chevron-forward" color="#fff" />
        </Pressable>
      ) : null}
      {m._robotdan ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: 16, padding: 12, marginBottom: 12, borderWidth: 1.5, borderColor: C.border }}>
          <Text style={{ fontSize: 22 }}>🤖</Text>
          <Text style={{ flex: 1, color: C.ink, fontWeight: '600', fontSize: 13.5 }}>Bu maça robot da tahmin yaptı. Robotun tahmini kendi bölümünde ayrı kalır. Burada kendi tahminini sıfırdan seç, ayrı kayıt olarak yayınlanır.</Text>
        </View>
      ) : null}
      {bulten ? <BultenSec teams={teams} onClose={() => setBulten(false)} onPick={(x) => {
        setBulten(false);
        // Senin bu maça zaten bir tahminin varsa onu aç; robotun tahmini ayrı kalır, ona dokunulmaz
        const var0 = (all || []).find((y) => y.afId === x.afId && !y.robot && !y.auto);
        if (var0) { setM({ ...var0, pollQ: var0.poll?.q || '', pollOpts: [...(var0.poll?.opts || []), '', '', '', ''].slice(0, 4) }); toast('Bu maça zaten tahmin vermişsin, düzenliyorsun'); return; }
        const rob = (all || []).some((y) => y.afId === x.afId && y.robot);
        setM((y) => ({ ...y, ...x, robot: false, auto: false, draft: false })); toast(rob ? 'Robotun tahmini ayrı kalır. Şimdi kendi tahminini seç' : 'Maç seçildi, şimdi tahmini seç');
      }} /> : null}
      <Card>
        <Text style={s.h3}>Takımlar</Text>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <LogoBtn k="homeLogo" label="Ev sahibi logosu" />
          <Field style={{ flex: 1 }} label="Ev sahibi" value={m.home} onChangeText={(v) => setTeamName('home', v)} placeholder="Örn. Galatasaray" />
        </View>
        <Oneriler text={m.home} onPick={(tm) => pickTeam('home', tm)} />
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <LogoBtn k="awayLogo" label="Deplasman logosu" />
          <Field style={{ flex: 1 }} label="Deplasman" value={m.away} onChangeText={(v) => setTeamName('away', v)} placeholder="Örn. Fenerbahçe" />
        </View>
        <Oneriler text={m.away} onPick={(tm) => pickTeam('away', tm)} />
        <Field label="Lig" value={m.league} onChangeText={(v) => F('league', v)} placeholder="Örn. Süper Lig" />
        <Text style={s.label}>Tarih</Text>
        <Seg value={m.date} onChange={(v) => F('date', v)} options={[[today(), 'Bugün'], [dayOff(1), 'Yarın'], [dayOff(2), 'Öbür gün']]} />
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Tarih (yıl-ay-gün)" value={m.date} onChangeText={(v) => F('date', v)} placeholder="2026-11-21" />
          <Field style={{ flex: 1 }} label="Saat" value={m.time} onChangeText={(v) => F('time', v)} placeholder="20:00" keyboardType="numbers-and-punctuation" />
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Tahmin</Text>
        <TahminSec value={m.market} onChange={pickMarket} home={m.home} away={m.away} />
        {m.market === 'Diğer' ? <Field label="Tahmin adı (isteğe bağlı)" value={m.marketOther} onChangeText={(v) => F('marketOther', v)} placeholder="Örn. Korner 9.5 Üst" /> : null}
        <Field label="Oran (isteğe bağlı)" value={String(m.odd || '')} onChangeText={(v) => F('odd', v.replace(',', '.'))} placeholder="Örn. 1.85" keyboardType="decimal-pad" />
        <Text style={s.label}>Güven</Text>
        <Seg value={m.conf} onChange={(v) => F('conf', v)} options={[[1, 'Zayıf'], [2, 'Orta'], [3, 'Güçlü']]} />
      </Card>

      <Card>
        <Text style={s.h3}>Kim görebilsin?</Text>
        <Seg tall value={m.access} onChange={(v) => F('access', v)} options={vipIzin ? [['open', 'Açık', 'lock-open-outline'], ['locked', 'Kilitli', 'lock-closed-outline'], ['vip', 'VIP', 'diamond-outline']] : [['open', 'Açık', 'lock-open-outline']]} />
        {!vipIzin ? <Text style={[s.note, { marginTop: -4, marginBottom: 8 }]}>Kilitli ve VIP maç için "🔒 Kilitli ve VIP içerik" izni gerekiyor.</Text> : null}
        {m.access !== 'open' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48, marginBottom: 8 }}>
            <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>Açmak için anahtar</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Btn small kind="out" title="−" onPress={() => F('cost', Math.max(1, (+m.cost || 1) - 1))} style={{ width: 48 }} />
              <Text style={{ fontSize: 20, fontWeight: '800', minWidth: 22, textAlign: 'center', color: C.ink }}>{+m.cost || 1}</Text>
              <Btn small kind="out" title="+" onPress={() => F('cost', Math.min(20, (+m.cost || 1) + 1))} style={{ width: 48 }} />
            </View>
          </View>
        ) : null}
        <Toggle label="Günün bankosu yap" sub="O günün en üstünde büyük kart olarak çıkar" value={m.banko} onChange={(v) => setM((x) => ({ ...x, banko: v, cost: v && (+x.cost || 1) < 3 ? 3 : x.cost }))} />
      </Card>

      <Pressable onPress={() => setGelismis((x) => !x)} accessibilityRole="button"
        style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: 18, padding: 14, marginBottom: 12 }}>
        <Icon name="options-outline" />
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: '800', color: C.ink, fontSize: 15.5 }}>Gelişmiş ayarlar</Text>
          <Text style={{ color: C.mut, fontSize: 12.5 }}>Açıklama, neden, yüzdeler, form, anket, zamanlı yayın</Text>
        </View>
        <Icon name={gelismis ? 'chevron-up' : 'chevron-down'} color={C.mut} />
      </Pressable>

      {gelismis ? (
        <>
          <Card>
            <Text style={s.h3}>Ayrıntılar</Text>
            <Field label="Kullanıcının göreceği yazı" value={m.text || autoText} onChangeText={(v) => F('text', v)} placeholder="Örn. Maçta 3 veya daha fazla gol olur" />
            <Field multiline label="Neden? (her satır bir madde)" value={m.reasons} onChangeText={(v) => F('reasons', v)} placeholder="İki takım da son maçlarında bol gol attı" />
            <Text style={s.label}>Olasılık %</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Field style={{ flex: 1 }} value={String(m.p1)} onChangeText={(v) => F('p1', v)} placeholder="Ev" keyboardType="number-pad" />
              <Field style={{ flex: 1 }} value={String(m.px)} onChangeText={(v) => F('px', v)} placeholder="Ber." keyboardType="number-pad" />
              <Field style={{ flex: 1 }} value={String(m.p2)} onChangeText={(v) => F('p2', v)} placeholder="Dep." keyboardType="number-pad" />
            </View>
          </Card>

          <Card>
            <Text style={s.h3}>📈 Form kartı</Text>
            <Text style={[s.sub, { fontSize: 13, marginBottom: 10 }]}>Son 5 maç: G = galibiyet, B = beraberlik, M = mağlubiyet. Kutulara dokunarak değiştir.</Text>
            <FormSecici label={m.home || 'Ev sahibi'} value={m.homeForm} onChange={(v) => F('homeForm', v)} />
            <FormSecici label={m.away || 'Deplasman'} value={m.awayForm} onChange={(v) => F('awayForm', v)} />
            <Field multiline label="Aralarındaki son maçlar (her satır bir maç)" value={m.h2h || ''} onChangeText={(v) => F('h2h', v)} placeholder={'GS 2-1 FB\nFB 0-0 GS'} />
          </Card>

          <Card>
            <Text style={s.h3}>📊 Anket</Text>
            <Field label="Soru" value={m.pollQ || ''} onChangeText={(v) => F('pollQ', v)} placeholder="İlk golü kim atar?" maxLength={120} />
            {[0, 1, 2, 3].map((i) => (
              <Field key={i} label={i < 2 ? `Seçenek ${i + 1}` : `Seçenek ${i + 1} (isteğe bağlı)`} value={(m.pollOpts || [])[i] || ''} maxLength={40}
                onChangeText={(v) => setM((x) => { const o = [...(x.pollOpts || ['', '', '', ''])]; o[i] = v; return { ...x, pollOpts: o }; })} placeholder={['Ev sahibi', 'Deplasman', 'Gol olmaz', ''][i]} />
            ))}
          </Card>

          <Card>
            <Text style={s.h3}>Yayın</Text>
            <Toggle label="Ana sayfada göster" sub="Kapalıysa maç sadece kuponlarda görünür" value={!m.hidden} onChange={(v) => F('hidden', !v)} />
            <YayinZamani value={m.publishAt} onChange={(v) => F('publishAt', v)} />
          </Card>
        </>
      ) : null}

      <Card>
        <Text style={s.h3}>Maç durumu</Text>
        <Seg value={m.status} onChange={(v) => F('status', v)} options={[['upcoming', 'Başlamadı'], ['live', 'Canlı'], ['finished', 'Bitti']]} />
        {m.status !== 'upcoming' ? (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label="Skor" value={m.score} onChangeText={(v) => F('score', v)} placeholder="1-0" keyboardType="numbers-and-punctuation" />
            <Field style={{ flex: 1 }} label="İlk yarı skoru" value={m.htScore || ''} onChangeText={(v) => F('htScore', v)} placeholder="0-0" keyboardType="numbers-and-punctuation" />
            {m.status === 'live' ? <Field style={{ flex: 1 }} label="Dakika (boş = otomatik)" value={String(m.minute || '')} onChangeText={(v) => setM((x) => ({ ...x, minute: v.replace(/\D/g, '').slice(0, 3), minuteAt: v ? Date.now() : 0 }))} placeholder={canliDakika({ ...m, minute: '' }) || '67'} keyboardType="number-pad" /> : <View style={{ flex: 1 }} />}
          </View>
        ) : null}
        {m.status === 'live' ? <Field label="Canlı tahmin yazısı" value={m.liveText} onChangeText={(v) => F('liveText', v)} placeholder="Bir gol daha gelir" /> : null}
        {m.status === 'finished' ? (
          <>
            <Text style={s.label}>Tahmin sonucu</Text>
            <Seg value={m.result} onChange={(v) => F('result', v)} options={[['won', 'Tuttu'], ['lost', 'Tutmadı'], ['', 'Belirsiz']]} />
            {!m.result && evalMarket(m.market, m) ? (
              <Btn small kind="out" title={`Skordan hesapla: ${evalMarket(m.market, m) === 'won' ? 'Tuttu ✓' : 'Tutmadı ✕'}`} onPress={() => F('result', evalMarket(m.market, m))} />
            ) : null}
          </>
        ) : null}
      </Card>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
        {m.isNew ? <Btn kind="out" title="Vazgeç" onPress={onBack} style={{ flex: 1 }} /> : <Btn kind="out" title="Sil" onPress={del} style={{ flex: 1 }} />}
        <Btn kind="ink" title={m.isNew ? 'Yayınla' : 'Kaydet'} onPress={publish} loading={busy} style={{ flex: 2 }} />
      </View>
      {!m.isNew ? (
        <Btn kind="out" icon="copy-outline" title="Bu maçı kopyala (yeni maç olarak)" style={{ marginTop: 8 }} onPress={() => {
          setM((x) => ({ ...x, id: newId(), isNew: true, banko: false, status: 'upcoming', score: '', minute: '', liveText: '', result: '', updatedAt: undefined }));
          toast('Kopyalandı · takımları ve saati değiştirip yayınla');
        }} />
      ) : null}
    </View>
  );
}

/* Kupon formunda seçilebilir maç kartı (senin maçların: dokun ekle/çıkar · robotun maçları: sadece "Kendi tahminim") */
function AdayKart({ m, p, head, onToggle, onKendi }) {
  return (
    <View>
      {head ? <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13, marginTop: 4, marginBottom: 6 }}>📅 {dayLabel(m.date)}</Text> : null}
      <Pressable onPress={onToggle || onKendi} accessibilityRole={onToggle ? 'checkbox' : 'button'} accessibilityState={onToggle ? { checked: !!p } : undefined}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: p ? 2 : 1.5, borderColor: p ? C.ink : C.border, borderRadius: 16, padding: 12, marginBottom: 8, backgroundColor: p ? C.selBg : C.card }}>
        {onToggle ? <Icon name={p ? 'checkbox' : 'square-outline'} size={24} color={p ? C.okTx : C.mut} /> : <Text style={{ fontSize: 18 }}>🤖</Text>}
        <View style={{ flex: 1 }}>
          <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{m.home} – {m.away}</Text>
          <Text numberOfLines={1} style={{ color: m.status === 'live' ? C.red : C.mut, fontSize: 13, fontWeight: m.status === 'live' ? '700' : '400' }}>
            {m.status === 'live' ? `● Canlı ${m.score || ''} · ` : `${m.time} · `}{onToggle ? predText(m) : 'robotun tahmini ayrı kalır'}
          </Text>
        </View>
        {onKendi ? <Btn small kind="out" title="Kendi tahminim" onPress={onKendi} /> : null}
      </Pressable>
    </View>
  );
}

/* Robotun maçına dokununca robotun kaydı değil, SENİN ayrı kaydın açılır (yoksa sıfırdan yeni kayıt) */
function kendiKaydi(x, all) {
  if (!x || !x.robot) return null;
  const var0 = x.afId ? (all || []).find((y) => y.afId === x.afId && !y.robot && !(y.auto && y.draft)) : null;
  if (var0) return var0;
  return {
    id: newId(), isNew: true, _robotdan: true,
    home: x.home, away: x.away, homeLogo: x.homeLogo || '', awayLogo: x.awayLogo || '', league: x.league || '', date: x.date, time: x.time,
    status: x.status || 'upcoming', score: x.score || '', htScore: x.htScore || '', afStatus: x.afStatus || '', minute: x.minute || '', minuteAt: x.minuteAt || 0,
    market: '', marketOther: '', text: '', conf: 3, reasons: '', access: 'open', cost: 1, banko: false, liveText: '', result: '', odd: '', p1: '', px: '', p2: '',
    robot: false, auto: false, draft: false,
    ...(x.afId ? { afId: x.afId } : {}),
  };
}

/* Kupondaki tek satır: tahmini değiştir · maçı bitir · çıkar */
function KuponSatiri({ p, i, robotKupon, bitirIzin = true, onMarket, onOdd, onRemove }) {
  const toast = useToast();
  const m = p.m;
  const [acik, setAcik] = useState(null); // null | 'tahmin' | 'bitir'
  const sc = String((m && m.score) || '').split('-');
  const [h, setH] = useState(sc[0] ? sc[0].trim() : '');
  const [a, setA] = useState(sc[1] ? sc[1].trim() : '');
  const hs = String((m && m.htScore) || '').split('-');
  const [ih, setIh] = useState(hs[1] != null && hs[0] !== '' ? hs[0].trim() : '');
  const [ia, setIa] = useState(hs[1] != null ? hs[1].trim() : '');
  const [busy, setBusy] = useState(false);
  const k = satirPazar(p);
  const r = satirSonuc(p);
  if (!m) {
    return (
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.bg, borderRadius: 14, padding: 12, marginBottom: 8 }}>
        <Text style={{ flex: 1, color: C.mut }}>Silinmiş maç</Text>
        <Btn small kind="out" title="Çıkar" onPress={onRemove} />
      </View>
    );
  }
  const bitir = async () => {
    if (h === '' || a === '') return toast('Maç sonu skorunu yaz');
    if ((ih === '') !== (ia === '')) return toast('İlk yarı skorunu ya tam yaz ya boş bırak');
    const score = `${+h}-${+a}`;
    const htScore = ih !== '' ? `${+ih}-${+ia}` : (m.htScore || '');
    if (htScore && (+htScore.split('-')[0] > +h || +htScore.split('-')[1] > +a)) return toast('İlk yarı skoru maç sonundan büyük olamaz');
    const son = { status: 'finished', score, htScore };
    const res = evalMarket(m.market, son);
    setBusy(true);
    try {
      await patchMatch(m.id, { ...son, result: res || m.result || '', minute: '', minuteAt: 0, elleBitti: true, dogrula: false });
      toast(`Maç bitti: ${score}${res ? (res === 'won' ? ' · Tuttu ✅' : ' · Tutmadı') : ''}`);
      setAcik(null);
    } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  return (
    <View style={{ borderWidth: 1.5, borderColor: C.border, borderRadius: 16, padding: 12, marginBottom: 8, backgroundColor: C.card }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Text style={{ color: C.mut, fontWeight: '800', width: 18 }}>{i + 1}</Text>
        <Crest name={m.home} logo={m.homeLogo} size={26} />
        <View style={{ flex: 1 }}>
          <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{m.home} – {m.away}</Text>
          <Text numberOfLines={1} style={{ fontSize: 13 }}>
            <Text style={{ color: C.okTx, fontWeight: '800' }}>{k || 'tahmin yok'}</Text>
            <Text style={{ color: m.status === 'live' ? C.red : C.mut }}>{m.status === 'live' ? ` · ● Canlı ${m.score || ''} ${canliDakika(m)}` : m.status === 'finished' ? ` · Bitti ${m.score || ''}${m.htScore ? ` (İY ${m.htScore})` : ''}` : ` · ${m.time}`}</Text>
          </Text>
          {m.dogrula ? <Text style={{ color: '#FF8A1F', fontSize: 12, fontWeight: '700' }}>⚠️ Son bilinen skorla kapatıldı, skoru doğrula</Text> : null}
        </View>
        {r ? <Icon name={r === 'won' ? 'checkmark-circle' : 'close-circle'} size={24} color={r === 'won' ? C.okTx : C.red} /> : null}
      </View>
      <View style={{ flexDirection: 'row', gap: 6, marginTop: 10 }}>
        {!robotKupon ? <Btn small kind={acik === 'tahmin' ? 'ink' : 'out'} title="Tahmini değiştir" onPress={() => setAcik(acik === 'tahmin' ? null : 'tahmin')} style={{ flex: 1 }} /> : null}
        {bitirIzin ? <Btn small kind={acik === 'bitir' ? 'ink' : 'out'} title={m.status === 'finished' ? 'Skoru düzelt' : 'Maçı bitir'} onPress={() => setAcik(acik === 'bitir' ? null : 'bitir')} style={{ flex: 1 }} /> : null}
        {!robotKupon ? <Btn small kind="out" icon="close" title="" onPress={onRemove} style={{ width: 48 }} /> : null}
      </View>
      {acik === 'tahmin' ? (
        <View style={{ marginTop: 10 }}>
          <Text style={[s.sub, { fontSize: 12.5, marginBottom: 6 }]}>Bu tahmin sadece bu kupondaki satır için. Maçın kendi tahmini ve diğer kuponlar değişmez.</Text>
          <TahminSec value={k} onChange={(v) => { onMarket(v); setAcik(null); }} compact noOther home={m.home} away={m.away} />
        </View>
      ) : null}
      {acik === 'bitir' ? (
        <View style={{ marginTop: 10 }}>
          <Text style={s.label}>Maç sonu skoru</Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8 }}>
            <Field style={{ flex: 1 }} value={h} onChangeText={(v) => setH(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder={m.home ? m.home.slice(0, 10) : 'Ev'} />
            <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink, marginBottom: 22 }}>-</Text>
            <Field style={{ flex: 1 }} value={a} onChangeText={(v) => setA(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder={m.away ? m.away.slice(0, 10) : 'Dep'} />
          </View>
          <Text style={s.label}>İlk yarı skoru (ilk yarı / ikinci yarı tahminleri için)</Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8 }}>
            <Field style={{ flex: 1 }} value={ih} onChangeText={(v) => setIh(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="İY ev" />
            <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink, marginBottom: 22 }}>-</Text>
            <Field style={{ flex: 1 }} value={ia} onChangeText={(v) => setIa(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="İY dep" />
          </View>
          <Btn small kind="ink" title="Maçı bitir, sonucu hesapla" onPress={bitir} loading={busy} />
          <Text style={[s.note, { marginTop: 6 }]}>Skor bütün kuponlara ve maçın kendi tahminine işlenir. Tuttu / Tutmadı her satır için kendi tahminine göre hesaplanır.</Text>
        </View>
      ) : null}
      {!robotKupon ? <Field style={{ marginTop: 10, marginBottom: 0 }} label="Oran" value={String(p.odd || '')} onChangeText={onOdd} placeholder="1.85" keyboardType="decimal-pad" /> : null}
    </View>
  );
}

/* ---------------- Uygulama ayarları ---------------- */
const COLORS = ['#00D26A', '#2F7BFF', '#FF8A1F', '#8B5CFF', '#E5484D', '#12B5B0', '#F2C200'];

function CfgForm({ c, setC, cfg, matches, teams, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const set = (path, v) => setC((o) => {
    const n = JSON.parse(JSON.stringify(o));
    const p = path.split('.');
    let x = n;
    while (p.length > 1) { const k = p.shift(); if (x[k] == null || typeof x[k] !== 'object') x[k] = /^\d+$/.test(p[0]) ? [] : {}; x = x[k]; }
    x[p[0]] = v;
    return n;
  });
  const pick = async (path, max, jpeg) => {
    try { const u = await pickImage(max, jpeg); if (u) set(path, u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const save = async () => {
    setBusy(true);
    try {
      await saveConfig({ ...c, name: (c.name || '').trim() || 'Tahmincim' });
      toast('Ayarlar kaydedildi');
      onBack();
    } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  const M = c.message;
  const A = c.ads;
  return (
    <View>
      <Header title="Uygulama ayarları" onBack={onBack} />
      <Card>
        <Text style={s.h3}>Görünüm</Text>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 12 }}>
          <View style={{ width: 64, height: 64, borderRadius: 18, backgroundColor: c.color, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
            {isImg(c.logo) ? <Image source={{ uri: c.logo }} style={{ width: 64, height: 64 }} /> : <Text style={{ fontWeight: '700', fontSize: 12 }}>Logo</Text>}
          </View>
          <Btn small kind="out" title="Logo yükle" onPress={() => pick('logo', 256, false)} style={{ flex: 1 }} />
          {c.logo ? <Btn small kind="out" title="Kaldır" onPress={() => set('logo', '')} /> : null}
        </View>
        <Field label="Uygulama adı" value={c.name} onChangeText={(v) => set('name', v)} />
        <Text style={s.label}>Ana renk</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
          {COLORS.map((x) => (
            <Pressable key={x} onPress={() => set('color', x)} accessibilityLabel={`Renk ${x}`} accessibilityState={{ selected: c.color === x }}
              style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: x, borderWidth: c.color === x ? 3 : 0, borderColor: C.ink }} />
          ))}
        </View>
        <Field label="Yeni kullanıcıya hediye anahtar" value={String(c.startKeys)} onChangeText={(v) => set('startKeys', +v || 0)} keyboardType="number-pad" />
      </Card>

      <Card>
        <Toggle label="Sistem mesajı" sub="Ana sayfanın üstünde görünür" value={M.on} onChange={(v) => set('message.on', v)} />
        <Field multiline label="Mesaj" value={M.text} onChangeText={(v) => set('message.text', v)} placeholder="Derbi tahmini 19:00'da yayında!" />
        <Text style={s.label}>Tür</Text>
        <Seg value={M.type} onChange={(v) => set('message.type', v)} options={[['info', 'Bilgi'], ['warn', 'Uyarı'], ['camp', 'Kampanya']]} />
      </Card>

      <Card>
        <Toggle label="Reklamlar" sub="Reklamla anahtar kazanma" value={A.on} onChange={(v) => set('ads.on', v)} />
        <Field label="Ödüllü reklam birim kimliği (AdMob)" value={A.unitId} onChangeText={(v) => set('ads.unitId', v.trim())} placeholder="ca-app-pub-xxxx/yyyy (boşsa test reklamı)" autoCapitalize="none" />
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Ödül (anahtar)" value={String(A.reward)} onChangeText={(v) => set('ads.reward', +v || 1)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="24 saatte en fazla (max 3)" value={String(Math.min(3, +A.limit || 3))} onChangeText={(v) => set('ads.limit', Math.min(3, +v || 0))} keyboardType="number-pad" />
        </View>
        <Text style={s.label}>Kendi reklam görselin (ana sayfanın altında)</Text>
        {isImg(A.bannerImg) ? <Image source={{ uri: A.bannerImg }} style={{ width: '100%', aspectRatio: 3, borderRadius: 14, marginBottom: 8 }} resizeMode="cover" /> : null}
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
          <Btn small kind="out" title={A.bannerImg ? 'Değiştir' : 'Görsel yükle'} onPress={() => pick('ads.bannerImg', 900, true)} style={{ flex: 1 }} />
          {A.bannerImg ? <Btn small kind="out" title="Kaldır" onPress={() => set('ads.bannerImg', '')} style={{ flex: 1 }} /> : null}
        </View>
        <Field label="Reklam bağlantısı (isteğe bağlı)" value={A.bannerLink} onChangeText={(v) => set('ads.bannerLink', v.trim())} placeholder="https://…" autoCapitalize="none" keyboardType="url" />
      </Card>

      <Card>
        <Toggle label="Anahtar mağazası" sub="Paketler ve fiyatlar (ödeme Google Play'e çıkınca açılır)" value={!!c.store?.on} onChange={(v) => set('store.on', v)} />
        {(c.store?.packs || []).map((p, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label={`Paket ${i + 1}: anahtar`} value={String(p.keys || '')} onChangeText={(v) => set(`store.packs.${i}.keys`, +v || 0)} keyboardType="number-pad" />
            <Field style={{ flex: 1 }} label="Fiyat" value={String(p.price || '')} onChangeText={(v) => set(`store.packs.${i}.price`, v)} placeholder="₺19,99" />
          </View>
        ))}
      </Card>

      <Card>
        <Text style={s.h3}>Ödüller ve bildirim</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Çark en az" value={String(c.rewards?.daily ?? 1)} onChangeText={(v) => set('rewards.daily', +v || 0)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="Çark büyük ödül ekstra" value={String(c.rewards?.week ?? 2)} onChangeText={(v) => set('rewards.week', +v || 0)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="Görev ödülü" value={String(c.rewards?.tasks ?? 2)} onChangeText={(v) => set('rewards.tasks', +v || 0)} keyboardType="number-pad" />
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Günlük açma sınırı (0=sınırsız)" value={String(c.keys?.dailyUnlock ?? 5)} onChangeText={(v) => set('keys.dailyUnlock', +v || 0)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="Anahtar ömrü gün (0=kapalı)" value={String(c.keys?.expireDays ?? 0)} onChangeText={(v) => set('keys.expireDays', +v || 0)} keyboardType="number-pad" />
        </View>
        <Text style={[s.sub, { fontSize: 13, marginTop: -4, marginBottom: 10 }]}>Açma sınırı VIP'lere uygulanmaz. Anahtar ömrü: o kadar gün hiç anahtar harcamayan/kazanmayanın anahtarı sıfırlanır.</Text>
        <Field label="Arkadaşına öner (paylaş) ödülü – anahtar (0 = kapalı)" value={String(c.rewards?.share ?? 2)} onChangeText={(v) => set('rewards.share', +v || 0)} keyboardType="number-pad" />
        <Field label="Expo proje kimliği (bildirimler için, kurulumda verilecek)" value={c.push?.projectId || ''} onChangeText={(v) => set('push.projectId', v.trim())} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autoCapitalize="none" />
      </Card>

      <Card>
        <Text style={s.h3}>📲 Yeni sürüm uyarısı</Text>
        <Text style={[s.sub, { fontSize: 13, marginBottom: 8 }]}>Senin telefonundaki sürüm: {APP_SURUM}. Yeni APK'yı yayınladıktan sonra buraya yeni sürüm numarasını yaz. Eski sürümü kullananların ana sayfasında "Yeni sürüm var" kartı çıkar.</Text>
        <Toggle label="Uyarıyı göster" sub="Kapalıyken kimse uyarı görmez" value={!!c.surum?.on} onChange={(v) => set('surum.on', v)} />
        <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
          <Field style={{ flex: 1 }} label="Güncel sürüm" value={c.surum?.son || ''} onChangeText={(v) => set('surum.son', v.replace(/[^\d.]/g, ''))} placeholder={APP_SURUM} keyboardType="numbers-and-punctuation" />
          <Btn small kind="out" title="Benimkini yaz" onPress={() => set('surum.son', APP_SURUM)} style={{ marginBottom: 12 }} />
        </View>
        <Field label="İndirme linki" value={c.surum?.link || ''} onChangeText={(v) => set('surum.link', v.trim())} placeholder="https://github.com/…/app-release.apk" autoCapitalize="none" keyboardType="url" />
        <Field multiline label="Ne değişti? (kısa, isteğe bağlı)" value={c.surum?.not || ''} onChangeText={(v) => set('surum.not', v)} placeholder="100'den fazla yeni tahmin seçeneği, canlıda erken sonuç" />
      </Card>

      <Card>
        <Text style={s.h3}>Bağlantılar</Text>
        <Field label="Destek / iletişim (WhatsApp, Telegram, Instagram linki)" value={c.links?.support || ''} onChangeText={(v) => set('links.support', v.trim())} placeholder="https://wa.me/90..." autoCapitalize="none" keyboardType="url" />
        <Field label="Gizlilik politikası linki" value={c.links?.privacy || ''} onChangeText={(v) => set('links.privacy', v.trim())} placeholder="https://..." autoCapitalize="none" keyboardType="url" />
      </Card>

      <VeriBaglantisi />

      <Card>
        <Text style={s.h3}>🔄 Otomatik maçlar</Text>
        <Toggle label="Maçları otomatik çek" sub="Seçili liglerin bugünkü ve yarınki maçları, canlı skor ve sonuçlar kendiliğinden gelir" value={!!c.auto?.on} onChange={(v) => set('auto.on', v)} />
        <Text style={[s.label, { marginTop: 6 }]}>Ligler</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 12 }}>
          {LIGLER.map(([id, ad]) => {
            const on = (c.auto?.leagues || []).includes(id);
            return (
              <Pressable key={id} onPress={() => set('auto.leagues', on ? (c.auto.leagues || []).filter((x) => x !== id) : [...(c.auto?.leagues || []), id])}
                style={{ paddingHorizontal: 12, minHeight: 36, borderRadius: 18, justifyContent: 'center', borderWidth: 1.5, borderColor: on ? C.ink : C.border, backgroundColor: on ? C.selBg : C.card }}>
                <Text style={{ fontWeight: on ? '800' : '600', color: on ? C.ink : C.mut, fontSize: 13 }}>{on ? '✓ ' : ''}{ad}</Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={s.label}>Gelen maçlar</Text>
        <Seg value={c.auto?.publish || 'auto'} onChange={(v) => set('auto.publish', v)} options={[['auto', 'Direkt yayınla'], ['draft', 'Taslak, ben onaylarım']]} />
        <Seg value={c.auto?.access || 'open'} onChange={(v) => set('auto.access', v)} options={[['open', 'Açık'], ['locked', 'Kilitli'], ['vip', 'VIP']]} />
        <Toggle label="🤖 Robot kupon paylaşsın" sub="Robot her gün en güvendiği maçlardan 1-2 kupon yapar. Bazıları ücretsiz, bazıları 1 anahtar." value={c.auto?.robotKupon !== false} onChange={(v) => set('auto.robotKupon', v)} />
        <Text style={[s.sub, { fontSize: 13 }]}>Robot tahmini olmayan maçlar her zaman taslak gelir. Taslağı açıp tahmin seçip kaydedince yayına girer. Lig sayısı arttıkça günlük 100 sorgu hakkı daha hızlı biter, 2-4 lig idealdir.</Text>
        <SenkronDurum cfg={cfg} matches={matches} teams={teams} />
      </Card>

      <Card>
        <Text style={s.h3}>👑 VIP paketleri</Text>
        <Toggle label="Mağazada VIP göster" value={!!c.vip?.on} onChange={(v) => set('vip.on', v)} />
        {[0, 1, 2].map((i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label={`Paket ${i + 1} – gün`} value={String(c.vip?.plans?.[i]?.days ?? '')} onChangeText={(v) => set(`vip.plans.${i}.days`, +v || 0)} keyboardType="number-pad" />
            <Field style={{ flex: 1 }} label="Fiyat" value={String(c.vip?.plans?.[i]?.price ?? '')} onChangeText={(v) => set(`vip.plans.${i}.price`, v)} placeholder="₺79,99" />
          </View>
        ))}
        <Text style={[s.sub, { fontSize: 13 }]}>Gün 0 olan paket gösterilmez. Gerçek ödeme Google Play'e çıkınca açılır.</Text>
      </Card>

      <Card>
        <Text style={s.h3}>Sosyal medya</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Doldurduğun hesaplar Ben sekmesinde "Bizi takip et" olarak görünür.</Text>
        {[['instagram', 'Instagram', 'https://instagram.com/...'], ['telegram', 'Telegram', 'https://t.me/...'], ['whatsapp', 'WhatsApp (kanal/grup)', 'https://whatsapp.com/channel/...'], ['x', 'X (Twitter)', 'https://x.com/...'], ['youtube', 'YouTube', 'https://youtube.com/@...'], ['tiktok', 'TikTok', 'https://tiktok.com/@...']].map(([k, l, ph]) => (
          <Field key={k} label={l} value={c.links?.[k] || ''} onChangeText={(v) => set('links.' + k, v.trim())} placeholder={ph} autoCapitalize="none" keyboardType="url" />
        ))}
      </Card>

      <Btn kind="ink" title="Kaydet" onPress={save} loading={busy} />
    </View>
  );
}

/* ---------------- Kullanıcılar ---------------- */
const isVipU = (u) => Number(u?.vipUntil || 0) > Date.now();
const fmtDate = (ms) => {
  if (!ms) return '—';
  const d = new Date(ms);
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
};

function Users({ users, roles = [], onBack, onOpen, izinliEposta = true }) {
  const roleOf = (id) => (roles.find((r) => r.id === id) || {}).role;
  const [q, setQ] = useState('');
  const [f, setF] = useState('all');
  const L = users.list;
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const stats = [
    ['Toplam', L.length],
    ['Bugün', L.filter((u) => (u.createdAt || 0) >= dayStart.getTime()).length],
    ['VIP', L.filter(isVipU).length],
    ['Engelli', L.filter((u) => u.banned).length],
  ];
  const staff = roles.length;
  const ql = q.trim().toLowerCase();
  const shown = L.filter((u) =>
    (f === 'all' || (f === 'vip' && isVipU(u)) || (f === 'ban' && u.banned) || (f === 'staff' && roleOf(u.id))) &&
    (!ql || String(u.name || '').toLowerCase().includes(ql) || String(u.email || '').includes(ql)));
  return (
    <View>
      <Header title="Kullanıcılar" onBack={onBack} />
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
        {stats.map(([l, v]) => (
          <View key={l} style={{ flex: 1, backgroundColor: C.card, borderRadius: 14, padding: 10, alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>{v}</Text>
            <Text style={{ fontSize: 12, color: C.mut }}>{l}</Text>
          </View>
        ))}
      </View>
      <Field value={q} onChangeText={setQ} placeholder="İsim veya e-posta ara" autoCapitalize="none" />
      <Seg value={f} onChange={setF} options={[['all', 'Tümü'], ['vip', 'VIP'], ['ban', 'Engelli'], ['staff', `Yetkili (${staff})`]]} />
      {users.loading ? (
        <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View>
      ) : users.error ? (
        <View style={s.empty}><Text style={[s.sub, { textAlign: 'center' }]}>Kullanıcılar okunamadı. Firebase kurallarını güncelledin mi?</Text></View>
      ) : !shown.length ? (
        <View style={s.empty}><Text style={s.sub}>Kullanıcı yok</Text></View>
      ) : shown.map((u) => (
        <Pressable key={u.id} onPress={() => onOpen(u.id)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
          <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: u.banned ? C.red : C.hero, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontWeight: '800' }}>{String(u.name || u.email || '?').slice(0, 1).toUpperCase()}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{u.name || '(isimsiz)'}{roleOf(u.id) === 'admin' ? '  🛠️' : roleOf(u.id) === 'mod' ? '  🛡️' : ''}{isVipU(u) ? '  👑' : ''}{u.banned ? '  ⛔' : ''}{Number(u.mutedUntil || 0) > Date.now() ? '  🔇' : ''}</Text>
            <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{izinliEposta ? u.email : 'e-posta gizli'} · {fmtDate(u.createdAt)}</Text>
          </View>
          <Text style={{ fontWeight: '800', color: C.lockTx }}>🔑 {Number(u.keys) || 0}</Text>
        </Pressable>
      ))}
    </View>
  );
}

function UserDetail({ u, onBack, role, roleDoc = {}, me, perm = {} }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!u) return <View><Header title="Kullanıcı" onBack={onBack} /><Text style={s.sub}>Kullanıcı bulunamadı.</Text></View>;
  const save = async (patch, msg) => {
    setBusy(true);
    try { await updateUser(u.id, patch); toast(msg); } catch (e) { toast('Kaydedilemedi. Firebase kurallarını kontrol et.'); }
    setBusy(false);
  };
  const keys = Number(u.keys) || 0;
  const vip = isVipU(u);
  const muted = Number(u.mutedUntil || 0) > Date.now();
  const mute = (h) => {
    save({ mutedUntil: h ? Date.now() + h * 3600e3 : 0 }, h ? `${h >= 24 ? h / 24 + ' gün' : h + ' saat'} susturuldu` : 'Susturma kaldırıldı');
    modLog(me, h ? `Susturdu (${h >= 24 ? h / 24 + ' gün' : h + ' saat'})` : 'Susturmayı kaldırdı', u.name || u.email);
  };
  const setYetki = (r) => {
    if (u.email === 'blackman0233@gmail.com') return toast('Sahibin yetkisi değiştirilemez');
    Alert.alert(r ? `${u.name || u.email} ${r === 'admin' ? 'Admin' : 'Moderatör'} yapılsın mı?` : 'Yetki kaldırılsın mı?',
      r === 'admin' ? 'Başlangıçta: maç, sonuç, kupon ve moderasyon. Kilitli/VIP içerik, bildirim, anahtar-VIP verme ve otomatik motor kapalı. Sonra izinleri tek tek açıp kapatabilirsin.' : r === 'mod' ? 'Başlangıçta: yorum, Tribün, susturma ve şikayetler. Sonra izinleri tek tek açıp kapatabilirsin.' : 'Normal kullanıcı olur, bütün izinleri kalkar.',
      [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Evet', onPress: async () => {
        try { await grantRole(u.id, r, { email: u.email, name: u.name }); toast(r ? 'Yetki verildi' : 'Yetki kaldırıldı'); modLog(me, r ? `Yetki verdi: ${r}` : 'Yetki aldı', u.name || u.email); }
        catch (e) { toast('Yapılamadı. Kuralları güncelledin mi?'); }
      } }]);
  };
  const addVip = (days) => {
    const base = Math.max(Date.now(), Number(u.vipUntil) || 0);
    save({ vipUntil: base + days * 864e5 }, `${days} gün VIP verildi`);
  };
  return (
    <View>
      <Header title={u.name || 'Kullanıcı'} onBack={onBack} />
      <Card>
        <Text style={s.label}>E-posta</Text>
        <Text style={{ fontSize: 16, fontWeight: '600', color: C.ink, marginBottom: 10 }}>{perm.i && perm.i('uyeler') ? u.email : 'Gizli (👥 Üye listesi izni gerekir)'}</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <View style={{ flex: 1 }}><Text style={s.label}>Katılma</Text><Text style={{ fontWeight: '600', color: C.ink }}>{fmtDate(u.createdAt)}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.label}>Son giriş</Text><Text style={{ fontWeight: '600', color: C.ink }}>{fmtDate(u.lastSeen)}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.label}>Açtığı maç</Text><Text style={{ fontWeight: '600', color: C.ink }}>{(u.unlocked || []).length}</Text></View>
        </View>
      </Card>

      {perm.i && perm.i('sustur') ? (
      <Card>
        <Text style={s.h3}>Susturma</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>{muted ? `${fmtDate(u.mutedUntil)} tarihine kadar yorum ve paylaşım yapamaz.` : 'Susturulan kullanıcı belirli süre yorum yazamaz, Tribün ve Skor Ligi\'nde paylaşım yapamaz.'}</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: muted ? 8 : 0 }}>
          {[[1, '1 saat'], [24, '1 gün'], [168, '7 gün']].map(([h, l]) => (
            <Btn key={h} small kind="out" title={l} disabled={busy} onPress={() => mute(h)} style={{ flex: 1 }} />
          ))}
        </View>
        {muted ? <Btn small kind="out" title="Susturmayı kaldır" disabled={busy} onPress={() => mute(0)} /> : null}
      </Card>
      ) : null}

      {perm.owner ? (
      <Card>
        <Text style={s.h3}>Yetki</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Şu an: {role === 'admin' ? '🛠️ Admin' : role === 'mod' ? '🛡️ Moderatör' : 'Normal kullanıcı'}</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Btn small kind={role === 'mod' ? 'ink' : 'out'} title="Moderatör" disabled={busy || role === 'mod'} onPress={() => setYetki('mod')} style={{ flex: 1 }} />
          <Btn small kind={role === 'admin' ? 'ink' : 'out'} title="Admin" disabled={busy || role === 'admin'} onPress={() => setYetki('admin')} style={{ flex: 1 }} />
        </View>
        {role ? <Btn small kind="out" title="Yetkiyi kaldır" onPress={() => setYetki('')} style={{ marginTop: 8 }} /> : null}
      </Card>
      ) : null}

      {perm.owner && role ? <IzinKart uid={u.id} name={u.name || u.email} role={role} izinler={roleDoc.izinler || {}} me={me} /> : null}

      {perm.i && perm.i('anahtar') ? (<>
      <Card>
        <Text style={s.h3}>Anahtar</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 16, marginBottom: 12 }}>
          <Btn small kind="out" title="−1" disabled={busy || keys <= 0} onPress={() => save({ keys: Math.max(0, keys - 1) }, 'Anahtar azaltıldı')} style={{ width: 64 }} />
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.ink, minWidth: 50, textAlign: 'center' }}>{keys}</Text>
          <Btn small kind="out" title="+1" disabled={busy} onPress={() => save({ keys: keys + 1 }, '+1 anahtar verildi')} style={{ width: 64 }} />
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[5, 10, 25].map((n) => (
            <Btn key={n} small kind="out" title={`+${n}`} disabled={busy} onPress={() => save({ keys: keys + n }, `+${n} anahtar verildi`)} style={{ flex: 1 }} />
          ))}
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>VIP üyelik</Text>
        <Text style={[s.sub, { marginBottom: 12 }]}>
          {vip ? `VIP, ${fmtDate(u.vipUntil)} tarihine kadar (${Math.ceil((u.vipUntil - Date.now()) / 864e5)} gün). Tüm kilitli ve VIP tahminleri görür.` : 'VIP değil.'}
        </Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: vip ? 8 : 0 }}>
          {[7, 30, 90].map((d) => (
            <Btn key={d} small kind="out" title={`+${d} gün`} disabled={busy} onPress={() => addVip(d)} style={{ flex: 1 }} />
          ))}
        </View>
        {vip ? <Btn small kind="out" title="VIP'i kaldır" disabled={busy} onPress={() => save({ vipUntil: 0 }, 'VIP kaldırıldı')} /> : null}
      </Card>

      </>) : null}
      {perm.owner ? (<>
      <Card>
        <Toggle label="Hesabı engelle" sub="Engellenen kullanıcı kilitli tahmin açamaz, anahtar kazanamaz" value={!!u.banned}
          onChange={(v) => save({ banned: v }, v ? 'Kullanıcı engellendi' : 'Engel kaldırıldı')} />
      </Card>
      </>) : null}
    </View>
  );
}

/* 🛡️ Sahip: bir yetkilinin izinlerini tek tek açar / kapatır */
function IzinKart({ uid, name, role, izinler, me }) {
  const toast = useToast();
  const d = IZIN_VARSAYILAN[role] || {};
  const deger = (k) => (Object.prototype.hasOwnProperty.call(izinler, k) ? !!izinler[k] : !!d[k]);
  const acik = IZINLER.filter(([k]) => deger(k)).length;
  const degistir = (k, v) => setIzin(uid, k, v)
    .then(() => { toast(v ? 'İzin açıldı' : 'İzin kapatıldı'); modLog(me, `${v ? 'İzin açtı' : 'İzin kapattı'}: ${k}`, name); })
    .catch(() => toast('Kaydedilemedi. Firestore kurallarını güncelledin mi?'));
  return (
    <Card>
      <Text style={s.h3}>🛡️ İzinler ({acik}/{IZINLER.length})</Text>
      <Text style={[s.sub, { marginBottom: 8 }]}>{name} sadece açık olan işleri yapabilir. Kapalı izinler panelinde görünmez, Firestore kuralları da engeller. Ayarlar ve yetki verme her zaman sadece sende.</Text>
      {IZINLER.map(([k, l, alt]) => <Toggle key={k} label={l} sub={alt} value={deger(k)} onChange={(v) => degistir(k, v)} />)}
    </Card>
  );
}
// Yetkiliye kendi izinlerini gösterir
function IzinOzet({ perm }) {
  const [ac, setAc] = useState(false);
  const acik = IZINLER.filter(([k]) => perm.i(k));
  return (
    <Pressable onPress={() => setAc((x) => !x)} style={{ backgroundColor: C.card, borderRadius: 14, padding: 12, marginBottom: 12 }}>
      <Text style={{ fontWeight: '700', color: C.ink }}>🛡️ İzinlerin: {acik.length}/{IZINLER.length} açık {ac ? '▲' : '▼'}</Text>
      {ac ? IZINLER.map(([k, l]) => <Text key={k} style={{ color: perm.i(k) ? C.ink : C.mut, fontSize: 13, marginTop: 4 }}>{perm.i(k) ? '✅' : '⛔'} {l}</Text>) : null}
    </Pressable>
  );
}

/* ---------------- Kupon oluştur / düzenle ---------------- */
function CouponForm({ co, setCo, matches, cfg, onBack, perm = {} }) {
  const I = (k) => (perm.i ? perm.i(k) : true);
  const kuponIzin = I('kupon') && (I('vip') || (co.access || 'open') === 'open');
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const F = (k, v) => setCo((x) => ({ ...x, [k]: v }));
  const robotKupon = !!co.robot;
  const picked = (id) => co.picks.find((p) => p.matchId === id);
  // Satırın tahmini kupona kaydedilir: maçın tahmini sonradan değişse de bu kupon etkilenmez
  const toggle = (m) => setCo((x) => ({
    ...x,
    picks: x.picks.find((p) => p.matchId === m.id) ? x.picks.filter((p) => p.matchId !== m.id) : [...x.picks, { matchId: m.id, odd: m.odd ? String(m.odd) : '', market: m.market || '' }],
  }));
  const setPick = (i, patch) => setCo((x) => ({ ...x, picks: x.picks.map((p, j) => (j === i ? { ...p, ...patch } : p)) }));
  const removePick = (i) => setCo((x) => ({ ...x, picks: x.picks.filter((p, j) => j !== i) }));
  const cands = matches.list
    .filter((m) => (m.date >= dayOff(-1) && m.status !== 'finished') || picked(m.id))
    .sort((a, b) => String(a.date + a.time).localeCompare(b.date + b.time));
  const [quick, setQuick] = useState(null);
  const [qBusy, setQBusy] = useState(false);
  const [bulten, setBulten] = useState(false);
  const [robotAc, setRobotAc] = useState(false);
  const benim = cands.filter((m) => !m.robot && !(m.auto && m.draft));
  const robotlar = cands.filter((m) => m.robot && !picked(m.id));
  // base: bültenden ya da robotun maçından gelen hazır bilgiler (takım, logo, saat, canlı skor…)
  const openQuick = (base) => setQuick({ home: '', away: '', time: '20:00', market: '', odd: '', show: true, ...(base || {}) });
  const Q = (k, v) => setQuick((x) => ({ ...x, [k]: v }));
  const tabanAl = (m) => ({ afId: m.afId || null, home: m.home, away: m.away, homeLogo: m.homeLogo || '', awayLogo: m.awayLogo || '', league: m.league || '', date: m.date, time: m.time, status: m.status, score: m.score || '', htScore: m.htScore || '', afStatus: m.afStatus || '', minute: m.minute || '', minuteAt: m.minuteAt || 0 });
  // Aynı maça daha önce kendi tahminini verdiysen: yeni kayıt açılmaz, bu kupona farklı tahminle eklenir
  const varOlan = (afId) => (afId ? matches.list.find((y) => y.afId === afId && !y.robot && !(y.auto && y.draft)) : null);
  const fromMatch = (m) => {
    const v = varOlan(m.afId);
    if (v && picked(v.id)) return toast('Bu maç zaten kuponda. Tahminini satırdan değiştirebilirsin');
    openQuick({ ...tabanAl(m), robotdan: true, ...(v ? { varId: v.id, market: v.market || '', odd: v.odd ? String(v.odd) : '' } : {}) });
  };
  const bultenSecildi = (x) => {
    setBulten(false);
    const v = varOlan(x.afId);
    if (v && picked(v.id)) return toast('Bu maç zaten kuponda. Tahminini satırdan değiştirebilirsin');
    openQuick(v ? { ...x, varId: v.id, market: v.market || '', odd: v.odd ? String(v.odd) : '' } : x);
  };
  const saveQuick = async () => {
    if (!quick.home.trim() || !quick.away.trim()) return toast('İki takımı da yaz');
    if (!quick.market) return toast('Tahminini seç');
    const odd = String(quick.odd || '').replace(',', '.');
    if (quick.varId) {
      setCo((x) => ({ ...x, picks: [...x.picks, { matchId: quick.varId, odd, market: quick.market }] }));
      setQuick(null);
      return toast('Kupona eklendi');
    }
    const m = {
      id: newId(), home: quick.home.trim(), away: quick.away.trim(), homeLogo: quick.homeLogo || '', awayLogo: quick.awayLogo || '', league: quick.league || '',
      date: quick.date || co.date, time: quick.time, market: quick.market, marketOther: '',
      text: marketText(quick.market, quick.home.trim(), quick.away.trim()) || quick.market,
      conf: 3, reasons: '', access: 'open', cost: 1, banko: false, status: quick.status || 'upcoming', score: quick.score || '', htScore: quick.htScore || '', minute: quick.minute || '', minuteAt: quick.minuteAt || 0, liveText: '',
      result: '', p1: '', px: '', p2: '', odd, hidden: !quick.show, robot: false, auto: false, draft: false, updatedAt: Date.now(),
      ...(quick.afId ? { afId: quick.afId, afStatus: quick.afStatus || '' } : {}),
    };
    setQBusy(true);
    try {
      await saveMatch(m);
      setCo((x) => ({ ...x, picks: [...x.picks, { matchId: m.id, odd: m.odd, market: m.market }] }));
      setQuick(null);
      toast('Maç eklendi ve kupona seçildi');
    } catch (e) { toast('Kaydedilemedi'); }
    setQBusy(false);
  };
  const pk = couponPicks(co, matches.list);
  const total = couponTotal(pk);
  const durum = couponStatus(pk);

  const save = async () => {
    if (!co.picks.length) return toast('En az bir maç seç');
    const out = { ...co, cost: Math.max(1, +co.cost || 1), updatedAt: Date.now() };
    delete out.isNew;
    setBusy(true);
    try {
      await saveCoupon(out);
      toast(co.isNew ? 'Kupon yayınlandı' : 'Kupon kaydedildi');
      onBack();
      if (co.isNew && !(out.publishAt > Date.now())) askNotify(cfg, `🔥 ${out.title || 'Günün Kuponu'} yayında!`, `${out.picks.length} maçlık kupon${total ? ` · Toplam oran ${total.toFixed(2)}` : ''}`, toast, 'kupon');
      if (out.publishAt > Date.now()) toast(`⏰ ${saatStr(out.publishAt)} itibarıyla yayında olacak`);
    }
    catch (e) { toast('Kaydedilemedi. Firebase kurallarını kontrol et.'); }
    setBusy(false);
  };
  const del = () => Alert.alert('Kupon silinsin mi?', co.title || 'Kupon', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Sil', style: 'destructive', onPress: async () => { try { await removeCoupon(co.id); toast('Kupon silindi'); onBack(); } catch (e) { toast('Silinemedi'); } } },
  ]);

  return (
    <View>
      <Header title={co.isNew ? 'Yeni kupon' : robotKupon ? '🤖 Robot kuponu' : 'Kuponu düzenle'} onBack={onBack} />
      <Card>
        <Field label="Kupon adı" value={co.title} onChangeText={(v) => F('title', v)} placeholder="Günün Kuponu" />
        <Text style={s.label}>Tarih</Text>
        <Seg value={co.date} onChange={(v) => F('date', v)} options={[[dayOff(-1), 'Dün'], [today(), 'Bugün'], [dayOff(1), 'Yarın']]} />
        <Field label="Tarih (yıl-ay-gün)" value={co.date} onChangeText={(v) => F('date', v)} placeholder="2026-11-21" />
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <Text style={[s.h3, { marginBottom: 0 }]}>Kupondaki maçlar ({pk.length})</Text>
          <Text style={{ fontWeight: '800', color: durum === 'won' ? C.okTx : durum === 'lost' ? C.red : C.mut }}>{durum === 'won' ? 'Tuttu ✅' : durum === 'lost' ? 'Tutmadı ✕' : 'Bekliyor'}</Text>
        </View>
        {robotKupon ? <Text style={[s.sub, { fontSize: 12.5, marginBottom: 8 }]}>Robotun kuponu: tahminlerine dokunulmaz. Gerekirse maçı bitirebilir, kuponu gizleyebilir ya da silebilirsin.</Text> : null}
        {!pk.length ? <Text style={[s.sub, { marginBottom: 8 }]}>Henüz maç yok. Aşağıdan seç.</Text> : pk.map((p, i) => (
          <KuponSatiri key={p.matchId + '_' + i} p={p} i={i} robotKupon={robotKupon || !kuponIzin} bitirIzin={I('sonuc')} onMarket={(v) => setPick(i, { market: v })} onOdd={(v) => setPick(i, { odd: v.replace(',', '.') })} onRemove={() => removePick(i)} />
        ))}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
          <Text style={{ fontWeight: '600', color: C.mut }}>Toplam oran</Text>
          <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{total ? total.toFixed(2) : '—'}</Text>
        </View>
      </Card>

      {!kuponIzin && !robotKupon ? <Text style={[s.note, { marginBottom: 10 }]}>Kupon düzenleme iznin kapalı{I('sonuc') ? ', sadece maçları bitirebilirsin' : ''}.</Text> : null}
      {robotKupon || !kuponIzin ? null : (
      <Card>
        <Text style={s.h3}>Maç ekle</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Canlı ve başlamamış maçlar. Senin maçlarına dokun: kupona girer. Satırdan tahminini değiştirebilirsin.</Text>
        <Btn kind="ink" icon="list-outline" title="📋 Bültenden maç ekle (canlılar dahil)" onPress={() => setBulten(true)} style={{ marginBottom: 12 }} />
        {bulten ? <BultenSec teams={[]} onClose={() => setBulten(false)} onPick={bultenSecildi} /> : null}
        <Text style={{ fontWeight: '800', color: C.ink, marginBottom: 6 }}>🎯 Benim tahminlerim</Text>
        {!benim.length ? <Text style={[s.sub, { marginBottom: 8 }]}>Henüz yok. Bültenden maç ekle.</Text> : benim.map((m, idx) => (
          <AdayKart key={m.id} m={m} p={picked(m.id)} head={idx === 0 || benim[idx - 1].date !== m.date} onToggle={() => toggle(m)} />
        ))}
        {robotlar.length ? (
          <Pressable onPress={() => setRobotAc((x) => !x)} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 44, marginTop: 6 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '800', color: C.ink }}>🤖 Robotun maçları ({robotlar.length})</Text>
              <Text style={{ color: C.mut, fontSize: 12.5 }}>Robotun tahmini kupona girmez. Dokun, kendi tahminini sıfırdan yap.</Text>
            </View>
            <Icon name={robotAc ? 'chevron-up' : 'chevron-down'} color={C.mut} />
          </Pressable>
        ) : null}
        {robotAc ? robotlar.map((m, idx) => (
          <AdayKart key={m.id} m={m} head={idx === 0 || robotlar[idx - 1].date !== m.date} onKendi={() => fromMatch(m)} />
        )) : null}
        {quick ? (
          <View style={{ borderWidth: 2, borderColor: C.ink, borderRadius: 16, padding: 12, marginTop: 8, backgroundColor: C.card }}>
            <Text style={[s.h3, { marginBottom: 4 }]}>Kendi tahminin</Text>
            <Text style={[s.sub, { fontSize: 12.5, marginBottom: 8 }]}>{quick.varId ? 'Bu maça daha önce tahmin vermişsin. Bu kupon için farklı bir tahmin seçebilirsin, eski tahminin değişmez.' : quick.robotdan ? 'Robotun tahmini ayrı kalır. Kendi tahminini sıfırdan seç.' : 'Tahminini seç, oranını yaz.'}</Text>
            {quick.afId ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.bg, borderRadius: 14, padding: 12, marginBottom: 12 }}>
                <Crest name={quick.home} logo={quick.homeLogo} size={28} />
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={{ fontWeight: '800', color: C.ink }}>{quick.home} – {quick.away}</Text>
                  <Text style={{ color: quick.status === 'live' ? C.red : C.mut, fontSize: 13, fontWeight: '600' }}>{quick.status === 'live' ? `● Canlı ${quick.score || ''}` : `${dayLabel(quick.date, false)} · ${quick.time}`}{quick.league ? ` · ${quick.league}` : ''}</Text>
                </View>
                <Crest name={quick.away} logo={quick.awayLogo} size={28} />
              </View>
            ) : (
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Field style={{ flex: 1 }} label="Ev sahibi" value={quick.home} onChangeText={(v) => Q('home', v)} placeholder="Ev sahibi" />
                <Field style={{ flex: 1 }} label="Deplasman" value={quick.away} onChangeText={(v) => Q('away', v)} placeholder="Deplasman" />
              </View>
            )}
            <TahminSec value={quick.market} onChange={(v) => Q('market', v)} compact noOther home={quick.home} away={quick.away} />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              {quick.afId ? null : <Field style={{ flex: 1 }} label="Saat" value={quick.time} onChangeText={(v) => Q('time', v)} placeholder="20:00" keyboardType="numbers-and-punctuation" />}
              <Field style={{ flex: 1 }} label="Oran" value={String(quick.odd || '')} onChangeText={(v) => Q('odd', v)} placeholder="1.85" keyboardType="decimal-pad" />
            </View>
            {quick.varId ? null : <Toggle label="Ana sayfada da göster" sub="Kapatırsan maç sadece bu kuponda görünür" value={quick.show} onChange={(v) => Q('show', v)} />}
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Btn small kind="out" title="Vazgeç" onPress={() => setQuick(null)} style={{ flex: 1 }} />
              <Btn small kind="ink" title="Kupona koy" onPress={saveQuick} loading={qBusy} style={{ flex: 2 }} />
            </View>
          </View>
        ) : (
          <Btn small kind="out" icon="create-outline" title="Bültende olmayan maçı elle yaz" onPress={() => openQuick()} style={{ marginTop: 8 }} />
        )}
      </Card>
      )}

      <Card>
        <Text style={s.h3}>Kim görebilsin?</Text>
        <Seg tall value={co.access} onChange={(v) => F('access', v)} options={I('vip') ? [['open', 'Açık', 'lock-open-outline'], ['locked', 'Kilitli', 'lock-closed-outline'], ['vip', 'VIP', 'diamond-outline']] : [['open', 'Açık', 'lock-open-outline']]} />
        {!I('vip') ? <Text style={[s.note, { marginTop: -4, marginBottom: 8 }]}>Kilitli ve VIP kupon için "🔒 Kilitli ve VIP içerik" izni gerekiyor.</Text> : null}
        {co.access !== 'open' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48 }}>
            <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>Açmak için anahtar</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Btn small kind="out" title="−" onPress={() => F('cost', Math.max(1, (+co.cost || 1) - 1))} style={{ width: 48 }} />
              <Text style={{ fontSize: 20, fontWeight: '800', minWidth: 22, textAlign: 'center', color: C.ink }}>{+co.cost || 1}</Text>
              <Btn small kind="out" title="+" onPress={() => F('cost', Math.min(50, (+co.cost || 1) + 1))} style={{ width: 48 }} />
            </View>
          </View>
        ) : null}
        <Text style={[s.sub, { marginTop: 8 }]}>Sonuç otomatik: tüm maçlar "Tuttu" olunca kupon Tuttu, biri "Tutmadı" olunca kupon Tutmadı olur.</Text>
        <YayinZamani value={co.publishAt} onChange={(v) => F('publishAt', v)} />
      </Card>

      {kuponIzin ? (
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
        {co.isNew ? <Btn kind="out" title="Vazgeç" onPress={onBack} style={{ flex: 1 }} /> : <Btn kind="out" title="Sil" onPress={del} style={{ flex: 1 }} />}
        <Btn kind="ink" title={co.isNew ? 'Yayınla' : 'Kaydet'} onPress={save} loading={busy} style={{ flex: 2 }} />
      </View>
      ) : <Btn kind="out" title="Geri" onPress={onBack} style={{ marginTop: 4 }} />}
    </View>
  );
}

/* ---------------- Bildirim gönder ---------------- */
const SABLONLAR = [
  ['🔥 Günün banko kuponu yüklendi!', 'Hemen aç, kaçırma!'],
  ['⚽ Yeni tahminler yayında', 'Bugünün maçları için tahminler hazır.'],
  ['✅ Kuponumuz tuttu!', 'Tutan kuponu görmek için uygulamaya gir.'],
  ['🔴 Maç başlıyor', 'Canlı tahminimizi kaçırma.'],
];
function Bildirim({ cfg, onBack, matches }) {
  const toast = useToast();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [devices, setDevices] = useState(null);
  const [hist, setHist] = useState([]);
  const load = () => {
    countDevices().then(setDevices).catch(() => setDevices(-1));
    notifHistory().then(setHist).catch(() => {});
  };
  React.useEffect(load, []);
  const ready = !!cfg.push?.projectId;
  const send = () => {
    if (!title.trim()) return toast('Başlık yaz');
    Alert.alert('Bildirim gönderilsin mi?', `${title}\n${body}\n\n${devices > 0 ? devices + ' telefona' : 'Kayıtlı tüm telefonlara'} gidecek.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Gönder', onPress: async () => {
        setBusy(true);
        try {
          const r = await sendPushAll(title.trim(), body.trim());
          toast(`${r.ok} / ${r.total} telefona gönderildi`);
          setTitle(''); setBody(''); load();
        } catch (e) { toast('Gönderilemedi, internet bağlantını kontrol et'); }
        setBusy(false);
      } },
    ]);
  };
  return (
    <View>
      <Header title="Bildirim gönder" onBack={onBack} />
      {!ready ? (
        <Card style={{ backgroundColor: C.lockBg }}>
          <Text style={{ color: C.lockTx, fontWeight: '700' }}>Bildirim kurulumu henüz tamamlanmadı.</Text>
          <Text style={{ color: C.lockTx, marginTop: 4 }}>Ayarlar → "Expo proje kimliği" alanı doldurulunca telefonlar kaydolmaya başlar.</Text>
        </Card>
      ) : null}
      <Card>
        <Text style={s.sub}>Kayıtlı telefon: <Text style={{ fontWeight: '800', color: C.ink }}>{devices == null ? '…' : devices < 0 ? '?' : devices}</Text></Text>
        <Pressable onPress={() => {
          const st = successStats(matches?.list || [], 7);
          if (!st.total) return toast('Son 7 günde sonuçlanan tahmin yok');
          setTitle(st.pct >= 60 ? `🔥 Bu hafta %${st.pct} başarı!` : `📊 Haftalık özet: ${st.won}/${st.total} tuttu`);
          setBody(`Son 7 günde ${st.total} tahminden ${st.won} tanesi tuttu. Yeni haftanın tahminleri yayında, kaçırma! ⚽`);
        }} accessibilityRole="button" style={{ borderRadius: 14, padding: 14, backgroundColor: C.okBg, marginTop: 12 }}>
          <Text style={{ fontWeight: '800', color: C.okTx }}>📰 Haftalık özeti hazırla</Text>
          <Text style={{ color: C.okTx, fontSize: 13, marginTop: 2 }}>Son 7 günün başarısıyla mesajı otomatik yazar</Text>
        </Pressable>
        <Text style={[s.label, { marginTop: 12 }]}>Hazır şablonlar</Text>
        <View style={{ gap: 8, marginBottom: 12 }}>
          {SABLONLAR.map(([t, b]) => (
            <Pressable key={t} onPress={() => { setTitle(t); setBody(b); }} accessibilityRole="button" style={{ borderWidth: 1.5, borderColor: C.border, borderRadius: 12, padding: 12, backgroundColor: C.card }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{t}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>{b}</Text>
            </Pressable>
          ))}
        </View>
        <Field label="Başlık" value={title} onChangeText={setTitle} placeholder="🔥 Günün banko kuponu yüklendi!" maxLength={65} />
        <Field multiline label="Mesaj" value={body} onChangeText={setBody} placeholder="Hemen aç, kaçırma!" maxLength={180} />
        <Btn kind="ink" icon="send-outline" title="Gönder" onPress={send} loading={busy} disabled={!ready} />
      </Card>
      {hist.length ? (
        <Card>
          <Text style={s.h3}>Son gönderilenler</Text>
          {hist.map((h) => (
            <View key={h.id} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.line }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{h.title}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>{fmtDate(h.sentAt)} · {h.count}/{h.total} telefon</Text>
            </View>
          ))}
        </Card>
      ) : null}
    </View>
  );
}

/* Yeni maç/kupon sonrası tek dokunuşla bildirim */
/* ---------------- Takım kütüphanesi ---------------- */
function Takimlar({ teams, matches, onBack }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [logo, setLogo] = useState('');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const pick = async (setter) => {
    try { const u = await pickImage(128, false); if (u) setter(u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const add = async () => {
    if (!name.trim()) return toast('Takım adını yaz');
    setBusy(true);
    try { await saveTeam(name, logo); toast('Takım kaydedildi'); setName(''); setLogo(''); } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  const importAll = async () => {
    setBusy(true);
    const n = await importTeamsFromMatches(matches.list, teams.list).catch(() => 0);
    toast(n ? `${n} takım logosu aktarıldı` : 'Aktarılacak yeni logo yok');
    setBusy(false);
  };
  const ql = q.trim().toLocaleLowerCase('tr');
  const list = [...teams.list].filter((t) => !ql || String(t.name).toLocaleLowerCase('tr').includes(ql)).sort((a, b) => String(a.name).localeCompare(String(b.name), 'tr'));
  return (
    <View>
      <Header title="Takımlar" onBack={onBack} />
      <Card>
        <Text style={s.h3}>Yeni takım</Text>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <Pressable onPress={() => pick(setLogo)} accessibilityLabel="Logo seç" style={{ width: 52, height: 52, borderRadius: 14, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 12 }}>
            {isImg(logo) ? <Image source={{ uri: logo }} style={{ width: 52, height: 52 }} resizeMode="contain" /> : <Icon name="add" color={C.mut} />}
          </Pressable>
          <Field style={{ flex: 1 }} label="Takım adı" value={name} onChangeText={setName} placeholder="Örn. Galatasaray" />
        </View>
        <Btn small kind="ink" title="Kaydet" onPress={add} loading={busy} />
        <Btn small kind="out" title="Maçlardaki logoları içe aktar" icon="download-outline" onPress={importAll} style={{ marginTop: 8 }} />
        <Text style={[s.note, { marginTop: 8 }]}>Maç eklerken takım adını yazınca logo kendiliğinden gelir.</Text>
      </Card>
      <Field value={q} onChangeText={setQ} placeholder={`Takım ara (${teams.list.length})`} />
      {list.map((tm) => (
        <View key={tm.id} style={[s.row, { minHeight: 60 }]}>
          <Pressable onPress={() => pick((u) => saveTeam(tm.name, u).then(() => toast('Logo güncellendi')).catch(() => toast('Kaydedilemedi')))} accessibilityLabel="Logoyu değiştir">
            <Crest name={tm.name} logo={tm.logo} size={40} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '700', color: C.ink }}>{tm.name}</Text>
            <Text style={{ color: C.mut, fontSize: 12.5 }}>{tm.logo ? 'Logoya dokunup değiştirebilirsin' : 'Logo yok · dokunup ekle'}</Text>
          </View>
          <Pressable onPress={() => Alert.alert('Takım silinsin mi?', tm.name, [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Sil', style: 'destructive', onPress: () => removeTeam(tm.id).catch(() => toast('Silinemedi')) }])}
            accessibilityLabel="Sil" style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="trash-outline" color={C.red} />
          </Pressable>
        </View>
      ))}
    </View>
  );
}

/* ---------------- Topluluk yönetimi ---------------- */
function Topluluk({ matches, onBack, me, perm = {}, onUsers, start }) {
  const toast = useToast();
  const I = (k) => (perm.i ? perm.i(k) : true);
  const sekmeler = [
    I('sikayet') ? ['feedback', 'Mesajlar'] : null,
    I('sikayet') ? ['reports', 'Bildirilen'] : null,
    I('yorum') ? ['comments', 'Yorumlar'] : null,
    I('tribun') ? ['tribune', 'Tribün'] : null,
    perm.owner ? ['log', '📋 Kayıt'] : null,
  ].filter(Boolean);
  const [tab, setTab] = useState(sekmeler.some((x) => x[0] === start) ? start : (sekmeler[0] || ['feedback'])[0]);
  const comments = useRecentComments(tab === 'comments');
  const fbs = useFeedback(I('sikayet'));
  const reports = useReports(I('sikayet'));
  const tribune = useTribune();
  const logs = useModLog(perm.owner && tab === 'log');
  const del = (title, fn) => Alert.alert(title, 'Bu işlem geri alınamaz.', [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Sil', style: 'destructive', onPress: fn }]);
  return (
    <View>
      <Header title="Topluluk" onBack={onBack} />
      {sekmeler.length ? <Seg value={tab} onChange={setTab} options={sekmeler.map(([k, l]) => [k, k === 'feedback' ? `${l} (${fbs.list.length})` : k === 'reports' ? `${l} (${reports.list.length})` : l])} /> : <Text style={s.sub}>Topluluk izinlerin kapalı.</Text>}
      {!perm.admin && (I('sustur') || I('uyeler') || I('anahtar')) ? <Btn small kind="out" icon="people-outline" title="Kullanıcılar" onPress={onUsers} style={{ marginBottom: 12 }} /> : null}
      {tab === 'log' ? (
        !logs.length ? <View style={s.empty}><Text style={s.sub}>Henüz kayıt yok</Text></View> : logs.map((l) => (
          <View key={l.id} style={[s.row, { alignItems: 'flex-start', minHeight: 0 }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{l.byName || 'Yetkili'} <Text style={{ color: C.mut, fontWeight: '400', fontSize: 12 }}>· {l.role === 'mod' ? 'Moderatör' : l.role === 'admin' ? 'Admin' : 'Sahip'} · {onceLabel(l.at)}</Text></Text>
              <Text style={{ color: C.ink, marginTop: 2 }}>{l.action}</Text>
              {l.detail ? <Text numberOfLines={2} style={{ color: C.mut, fontSize: 13, marginTop: 2 }}>{l.detail}</Text> : null}
            </View>
          </View>
        ))
      ) : null}
      {tab === 'log' ? null : tab === 'feedback' ? (
        !fbs.list.length ? <View style={s.empty}><Text style={s.sub}>Henüz öneri veya şikayet yok</Text></View> : fbs.list.map((f) => <MesajKart key={f.id} f={f} me={me} perm={perm} />)
      ) : tab === 'reports' ? (
        !reports.list.length ? <View style={s.empty}><Text style={s.sub}>Şikayet yok 👍</Text></View> : reports.list.map((r) => (
          <Card key={r.id}>
            <Text style={{ color: C.mut, fontSize: 12.5 }}>{r.kind === 'comment' ? 'Yorum' : 'Tribün kuponu'} · {onceLabel(r.createdAt)}</Text>
            <Text style={{ color: C.ink, marginVertical: 8 }}>{r.text}</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Btn small kind="out" title="Yoksay" onPress={() => deleteReport(r.id).catch(() => {})} style={{ flex: 1 }} />
              <Btn small kind="red" title="İçeriği sil" style={{ flex: 1 }} onPress={() => del('İçerik silinsin mi?', async () => {
                try { await (r.kind === 'comment' ? deleteComment(r.refId) : deleteTribune(r.refId, { gorunur: r.kind === 'tribuneOzel' ? 'takipci' : '' })); await deleteReportsFor(r.refId); toast('Silindi'); modLog(me, r.kind === 'comment' ? 'Şikayet edilen yorumu sildi' : 'Şikayet edilen kuponu sildi', r.text); } catch (e) { toast('Silinemedi'); }
              })} />
            </View>
          </Card>
        ))
      ) : tab === 'comments' ? (
        !comments.list.length ? <View style={s.empty}><Text style={s.sub}>Yorum yok</Text></View> : comments.list.map((c) => (
          <View key={c.id} style={[s.row, { alignItems: 'flex-start' }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{c.name} <Text style={{ color: C.mut, fontWeight: '400', fontSize: 12 }}>· {onceLabel(c.createdAt)}</Text></Text>
              <Text style={{ color: C.ink, marginTop: 2 }}>{c.text}</Text>
            </View>
            <Pressable onPress={() => del('Yorum silinsin mi?', () => deleteComment(c.id).then(() => { toast('Silindi'); modLog(me, 'Yorum sildi', `${c.name}: ${c.text}`); }).catch(() => toast('Silinemedi')))} accessibilityLabel="Sil" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="trash-outline" color={C.red} />
            </Pressable>
          </View>
        ))
      ) : (
        !tribune.list.length ? <View style={s.empty}><Text style={s.sub}>Tribün boş</Text></View> : tribune.list.slice(0, 100).map((x) => (
          <View key={x.id} style={s.row}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{x.name}</Text>
              <Text style={{ color: C.mut, fontSize: 12.5 }}>{(x.picks || []).length} maç · {onceLabel(x.createdAt)}</Text>
            </View>
            <Pressable onPress={() => del('Kupon silinsin mi?', () => deleteTribune(x.id).then(() => { toast('Silindi'); modLog(me, 'Tribün kuponu sildi', x.name); }).catch(() => toast('Silinemedi')))} accessibilityLabel="Sil" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="trash-outline" color={C.red} />
            </Pressable>
          </View>
        ))
      )}
    </View>
  );
}

/* ---------------- İstatistik paneli ---------------- */
function Istatistik({ matches, coupons, onBack }) {
  const users = useUsers(true);
  const [n, setN] = useState({});
  React.useEffect(() => {
    let on = true;
    (async () => {
      const [dev, com, tri, sco, vw] = await Promise.all([countDevices().catch(() => null), countCollection('comments'), countCollection('tribune'), countCollection('scores'), countCollection('views')]);
      if (on) setN({ dev, com, tri, sco, vw });
    })();
    return () => { on = false; };
  }, []);
  const U = users.list || [];
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const day = d0.getTime();
  const week = Date.now() - 7 * 864e5;
  const now = Date.now();
  const activeToday = U.filter((u) => (u.lastSeen || 0) >= day).length;
  const active7 = U.filter((u) => (u.lastSeen || 0) >= week).length;
  const new7 = U.filter((u) => (u.createdAt || 0) >= week).length;
  const vip = U.filter((u) => Number(u.vipUntil || 0) > now).length;
  const keys = U.reduce((t, u) => t + (Number(u.keys) || 0), 0);
  const cnt = {};
  U.forEach((u) => (u.unlocked || []).forEach((id) => { cnt[id] = (cnt[id] || 0) + 1; }));
  const byId = {};
  matches.list.forEach((m) => { byId[m.id] = `${m.home} – ${m.away}`; });
  (coupons?.list || []).forEach((c) => { byId['c_' + c.id] = c.title || 'Kupon'; byId[c.id] = c.title || 'Kupon'; });
  const top = Object.entries(cnt).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const st = successStats(matches.list, 30);
  const recent = [...matches.list].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 20);
  const vc = useViewCounts(recent.map((m) => 'm_' + m.id));
  const topV = recent.map((m) => [m, vc['m_' + m.id] || 0]).filter((x) => x[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const Kutu = ({ v, l }) => (
    <View style={{ flexBasis: '47%', flexGrow: 1, backgroundColor: C.card, borderRadius: 18, padding: 14 }}>
      <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{v == null ? '–' : v}</Text>
      <Text style={{ color: C.mut, fontSize: 13 }}>{l}</Text>
    </View>
  );
  return (
    <View>
      <Header title="İstatistik" onBack={onBack} />
      {users.loading ? <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
        <Kutu v={U.length} l="Toplam üye" />
        <Kutu v={activeToday} l="Bugün giren" />
        <Kutu v={active7} l="Son 7 gün aktif" />
        <Kutu v={new7} l="Son 7 gün yeni üye" />
        <Kutu v={n.dev} l="Bildirim açık cihaz" />
        <Kutu v={vip} l="VIP üye" />
        <Kutu v={keys} l="Kullanıcılardaki anahtar" />
        <Kutu v={st.total ? `%${st.pct}` : '–'} l={`30 gün başarı (${st.won}/${st.total})`} />
        <Kutu v={n.com} l="Yorum" />
        <Kutu v={n.tri} l="Tribün kuponu" />
        <Kutu v={n.sco} l="Skor tahmini" />
        <Kutu v={matches.list.length} l="Toplam maç" />
        <Kutu v={n.vw} l="Toplam görüntülenme" />
      </View>
      <Card>
        <Text style={s.h3}>👁 En çok görüntülenen (son 20 maç)</Text>
        {!topV.length ? <Text style={s.sub}>Henüz görüntülenme yok.</Text> : topV.map(([m, c], i) => (
          <View key={m.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderTopWidth: i ? 1 : 0, borderColor: C.line }}>
            <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{m.home} – {m.away}</Text>
            <Text style={{ color: C.okTx, fontWeight: '800' }}>{c} kişi</Text>
          </View>
        ))}
      </Card>
      <Card>
        <Text style={s.h3}>En çok açılanlar</Text>
        {!top.length ? <Text style={s.sub}>Henüz açılan kilitli içerik yok.</Text> : top.map(([id, c], i) => (
          <View key={id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderTopWidth: i ? 1 : 0, borderColor: C.line }}>
            <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{byId[id] || 'Silinmiş içerik'}</Text>
            <Text style={{ color: C.lockTx, fontWeight: '800' }}>{c} kişi</Text>
          </View>
        ))}
      </Card>
    </View>
  );
}

/* Öneri/şikayet mesajı + cevap */
function MesajKart({ f, me, perm = {} }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const send = async () => {
    const v = text.trim();
    if (v.length < 2) return toast('Cevabını yaz');
    setBusy(true);
    try {
      await replyFeedback(f.id, v, me?.name || 'Destek');
      if ((perm.i ? perm.i('sikayet') : perm.admin) && f.uid) sendPushTo(f.uid, '💬 Mesajına cevap geldi', v.slice(0, 90)).catch(() => {});
      modLog(me, 'Mesaja cevap verdi', `${f.name || 'Misafir'}: ${f.text}`);
      toast(f.uid ? 'Cevap gönderildi' : 'Cevap kaydedildi. Misafir olduğu için e-postayla dönmen gerekir.');
      setText(''); setOpen(false);
    } catch (e) { toast('Gönderilemedi. Kuralları güncelledin mi?'); }
    setBusy(false);
  };
  return (
    <Card>
      <Text style={{ color: C.mut, fontSize: 12.5 }}>{f.kind === 'oneri' ? '💡 Öneri' : f.kind === 'hata' ? '🐞 Hata' : '⚠️ Şikayet'} · {f.name || 'Misafir'} · {onceLabel(f.createdAt)}</Text>
      <Text style={{ color: C.ink, marginVertical: 8, lineHeight: 20 }}>{f.text}</Text>
      {f.contact ? <Text selectable style={{ color: C.mut, fontSize: 13, marginBottom: 8 }}>📧 {f.contact}</Text> : null}
      {f.reply ? (
        <View style={{ backgroundColor: C.okBg, borderRadius: 12, padding: 10, marginBottom: 8 }}>
          <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 12 }}>✓ CEVAPLANDI · {f.replyBy || 'Destek'} · {onceLabel(f.repliedAt)}</Text>
          <Text style={{ color: C.ink, marginTop: 4, lineHeight: 20 }}>{f.reply}</Text>
        </View>
      ) : null}
      {!f.uid && !f.reply ? <Text style={{ color: C.mut, fontSize: 12.5, marginBottom: 8 }}>Misafir mesajı: uygulamada cevabı göremez, e-posta bıraktıysa oradan dön.</Text> : null}
      {open ? (
        <View>
          <Field value={text} onChangeText={setText} multiline maxLength={1000} placeholder="Cevabını yaz…" />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn small kind="out" title="Vazgeç" onPress={() => setOpen(false)} style={{ flex: 1 }} />
            <Btn small kind="ink" icon="send" title="Gönder" onPress={send} loading={busy} style={{ flex: 2 }} />
          </View>
        </View>
      ) : (
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Btn small kind="ink" icon="chatbubble-outline" title={f.reply ? 'Tekrar cevapla' : 'Cevap yaz'} onPress={() => setOpen(true)} style={{ flex: 2 }} />
          <Btn small kind="out" title="Sil" onPress={() => Alert.alert('Mesaj silinsin mi?', 'Kullanıcı da göremez.', [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Sil', style: 'destructive', onPress: () => deleteFeedback(f.id).catch(() => toast('Silinemedi')) }])} style={{ flex: 1 }} />
        </View>
      )}
    </Card>
  );
}

/* ---------- Ortak parçalar: zamanlı yayın, form seçici ---------- */
function saatStr(ms) {
  const d = new Date(ms);
  const t = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  const today0 = new Date(); today0.setHours(0, 0, 0, 0);
  const diff = Math.round((new Date(d).setHours(0, 0, 0, 0) - today0.getTime()) / 864e5);
  return `${diff === 0 ? 'Bugün' : diff === 1 ? 'Yarın' : `${d.getDate()}.${d.getMonth() + 1}`} ${t}`;
}
function YayinZamani({ value, onChange }) {
  const on = Number(value) > 0;
  const d = on ? new Date(value) : null;
  const [day, setDay] = useState(on ? (new Date(value).toDateString() === new Date().toDateString() ? 0 : 1) : 0);
  const [time, setTime] = useState(on ? `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}` : '10:00');
  const calc = (dy, tm) => {
    const mt = /^(\d{1,2}):(\d{2})$/.exec(tm || '');
    if (!mt) return;
    const x = new Date(); x.setDate(x.getDate() + dy); x.setHours(+mt[1], +mt[2], 0, 0);
    onChange(x.getTime());
  };
  return (
    <View style={{ marginTop: 4 }}>
      <Toggle label="⏰ Zamanlı yayın" sub={on ? `${saatStr(value)} itibarıyla kullanıcılara görünür` : 'Kapalıysa hemen yayınlanır'} value={on}
        onChange={(v) => (v ? calc(day, time) : onChange(0))} />
      {on ? (
        <View>
          <Seg value={day} onChange={(v) => { setDay(v); calc(v, time); }} options={[[0, 'Bugün'], [1, 'Yarın']]} />
          <Field label="Saat" value={time} onChangeText={(v) => { setTime(v); calc(day, v); }} placeholder="10:00" keyboardType="numbers-and-punctuation" maxLength={5} />
          <Text style={[s.sub, { fontSize: 12.5 }]}>Not: Yayın saati gelince bildirim otomatik gitmez, istersen o saatte "Bildirim gönder"den atarsın.</Text>
        </View>
      ) : null}
    </View>
  );
}
const FORM_RENK = { G: '#16A34A', B: '#8A94A3', M: '#E5484D' };
function FormSecici({ label, value, onChange }) {
  const v = String(value || '').toUpperCase().replace(/[^GBM]/g, '').padEnd(5, ' ').slice(0, 5).split('');
  const next = { ' ': 'G', G: 'B', B: 'M', M: ' ' };
  const tap = (i) => { const a = [...v]; a[i] = next[a[i]] || 'G'; onChange(a.join('').replace(/\s+$/, '')); };
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
      <Text numberOfLines={1} style={{ flex: 1, fontWeight: '700', color: C.ink }}>{label}</Text>
      {v.map((c, i) => (
        <Pressable key={i} onPress={() => tap(i)} accessibilityLabel={`Maç ${i + 1}: ${c.trim() || 'boş'}`}
          style={{ width: 34, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center', backgroundColor: FORM_RENK[c] || C.bg, borderWidth: c.trim() ? 0 : 1.5, borderColor: C.border }}>
          <Text style={{ color: '#fff', fontWeight: '800' }}>{c.trim()}</Text>
        </Pressable>
      ))}
    </View>
  );
}

/* ---------------- Toplu sonuç girişi ---------------- */
function TopluSonuc({ matches, cfg, onBack }) {
  const [day, setDay] = useState(0);
  const d = dayOff(day);
  const list = matches.list.filter((m) => m.date === d).sort((a, b) => String(a.time).localeCompare(b.time));
  const pending = list.filter((m) => m.status !== 'finished' || !m.result).length;
  return (
    <View>
      <Header title="Sonuç gir" onBack={onBack} />
      <Seg value={day} onChange={setDay} options={[[-2, 'Önceki gün'], [-1, 'Dün'], [0, 'Bugün']]} />
      <Text style={[s.sub, { marginBottom: 10 }]}>{list.length} maç · {pending ? `${pending} tanesinin sonucu eksik` : 'hepsi tamam ✓'}</Text>
      {!list.length ? <View style={s.empty}><Text style={s.sub}>Bu gün için maç yok</Text></View>
        : list.map((m) => <SonucSatir key={m.id + (m.updatedAt || '')} m={m} cfg={cfg} />)}
    </View>
  );
}
function SonucSatir({ m, cfg }) {
  const toast = useToast();
  const sc = String(m.score || '').split('-');
  const [h, setH] = useState(sc[0] ? sc[0].trim() : '');
  const [a, setA] = useState(sc[1] ? sc[1].trim() : '');
  const [status, setStatus] = useState(m.status || 'upcoming');
  const [minute, setMinute] = useState(String(m.minute || ''));
  const [result, setResult] = useState(m.result || '');
  const [busy, setBusy] = useState(false);
  const hs0 = String(m.htScore || '').split('-');
  const [ih, setIh] = useState(hs0.length === 2 ? hs0[0].trim() : '');
  const [ia, setIa] = useState(hs0.length === 2 ? hs0[1].trim() : '');
  const score = h !== '' && a !== '' ? `${+h}-${+a}` : '';
  const htScore = ih !== '' && ia !== '' ? `${+ih}-${+ia}` : '';
  const auto = status === 'finished' && score ? evalMarket(m.market, { status: 'finished', score, htScore }) : '';
  const res = result || auto;
  const save = async () => {
    if (status !== 'upcoming' && !score) return toast('Skoru yaz');
    setBusy(true);
    try {
      const mChanged = String(minute) !== String(m.minute || '');
      const out = { ...m, status, score: status === 'upcoming' ? '' : score, htScore: status === 'upcoming' ? '' : htScore, dogrula: false, minute: status === 'live' ? minute : '', minuteAt: status === 'live' && minute ? (mChanged ? Date.now() : m.minuteAt || Date.now()) : 0, result: status === 'finished' ? res : '', updatedAt: Date.now() };
      await saveMatch(out);
      toast('Kaydedildi ✓');
      if (out.result === 'won' && m.result !== 'won') askNotify(cfg, '✅ Tahminimiz tuttu!', `${m.home} – ${m.away} · ${score} · ${predText(m)}`, toast, 'tuttu');
    } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  const Chip2 = ({ v, l, cur, set, col }) => (
    <Pressable onPress={() => set(v)} style={{ paddingHorizontal: 10, minHeight: 34, borderRadius: 10, justifyContent: 'center', borderWidth: 1.5, borderColor: cur === v ? (col || C.ink) : C.border, backgroundColor: cur === v ? (col ? col + '22' : C.bg) : C.card }}>
      <Text style={{ fontWeight: '700', fontSize: 13, color: cur === v ? (col || C.ink) : C.mut }}>{l}</Text>
    </Pressable>
  );
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <Text style={{ color: C.mut, fontWeight: '700', width: 44 }}>{m.time}</Text>
        <Text numberOfLines={1} style={{ flex: 1, fontWeight: '700', color: C.ink }}>{m.home} – {m.away}</Text>
        <Text style={{ fontWeight: '800', color: C.okTx }}>{m.market}</Text>
      </View>
      {m.dogrula ? <Text style={{ color: '#FF8A1F', fontWeight: '700', fontSize: 12.5, marginBottom: 6 }}>⚠️ Maç takılı kaldığı için son bilinen skorla kapatıldı. Skoru kontrol edip kaydet.</Text> : null}
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 8 }}>
        <Chip2 v="upcoming" l="Başlamadı" cur={status} set={setStatus} />
        <Chip2 v="live" l="Canlı" cur={status} set={setStatus} col="#E5484D" />
        <Chip2 v="finished" l="Bitti" cur={status} set={setStatus} col="#16A34A" />
      </View>
      {status !== 'upcoming' ? (
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Ev" value={h} onChangeText={(v) => setH(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="0" />
          <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink, marginBottom: 22 }}>-</Text>
          <Field style={{ flex: 1 }} label="Dep." value={a} onChangeText={(v) => setA(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="0" />
          {status === 'finished' ? <Field style={{ flex: 1 }} label="İY" value={ih} onChangeText={(v) => setIh(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="İY ev" /> : null}
          {status === 'finished' ? <Field style={{ flex: 1 }} label="İY" value={ia} onChangeText={(v) => setIa(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="İY dep" /> : null}
          {status === 'live' ? <Field style={{ flex: 1 }} label="Dakika" value={minute} onChangeText={(v) => setMinute(v.replace(/\D/g, '').slice(0, 3))} keyboardType="number-pad" placeholder={canliDakika({ ...m, status: 'live', minute: '' }) || 'oto'} /> : null}
        </View>
      ) : null}
      {status === 'finished' ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
          <Chip2 v="won" l="Tuttu ✓" cur={res} set={setResult} col="#16A34A" />
          <Chip2 v="lost" l="Tutmadı ✕" cur={res} set={setResult} col="#E5484D" />
          {auto && !result ? <Text style={{ color: C.mut, fontSize: 12 }}>skordan otomatik seçildi</Text> : null}
        </View>
      ) : null}
      <Btn small kind="ink" title="Kaydet" onPress={save} loading={busy} />
    </Card>
  );
}

/* ---------------- Veri bağlantısı (API-Football) ---------------- */
function VeriBaglantisi() {
  const toast = useToast();
  const [key, setKey] = useState('');
  const [saved, setSaved] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState(null);
  React.useEffect(() => { getApiKey().then((k) => { setKey(k); setSaved(k); }); }, []);
  const save = async () => {
    try { await saveApiKey(key); setSaved(key.trim()); toast('Anahtar gizli olarak kaydedildi 🔒'); } catch (e) { toast('Kaydedilemedi. Kuralları güncelledin mi?'); }
  };
  const test = async () => {
    setBusy(true); setRes(null);
    const r = await testConnection(key.trim());
    setRes(r); setBusy(false);
  };
  return (
    <Card>
      <Text style={s.h3}>📡 Veri bağlantısı (API-Football)</Text>
      <Text style={[s.sub, { fontSize: 13, marginBottom: 10 }]}>Anahtar sadece sende görünür, kullanıcılar asla göremez. Günde 100 sorgu hakkın var.</Text>
      <Field label="API anahtarı" value={key} onChangeText={setKey} secureTextEntry={!show} autoCapitalize="none" autoCorrect={false} placeholder="dashboard → Account → My Access" />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn small kind="out" title={show ? 'Gizle' : 'Göster'} onPress={() => setShow((x) => !x)} style={{ flex: 1 }} />
        <Btn small kind="ink" title={saved === key.trim() && saved ? 'Kayıtlı ✓' : 'Kaydet'} onPress={save} style={{ flex: 2 }} />
      </View>
      <Btn small kind="acc" icon="pulse-outline" title="Bağlantıyı test et (Süper Lig)" onPress={test} loading={busy} style={{ marginTop: 8 }} />
      {res ? (
        <View style={{ backgroundColor: res.ok ? C.okBg : C.redBg, borderRadius: 12, padding: 12, marginTop: 10, gap: 4 }}>
          {res.lines.map((l, i) => <Text key={i} selectable style={{ color: res.ok ? C.okTx : C.ink, fontSize: 13.5, lineHeight: 19 }}>{l}</Text>)}
        </View>
      ) : null}
    </Card>
  );
}

/* ---------------- Toplu maç ekleme ---------------- */
const HIZLI_MARKET = ['MS 1', 'MS X', 'MS 2', '2.5 Üst', '2.5 Alt', 'KG Var', 'KG Yok', '1X', 'X2'];
function TopluEkle({ teams, cfg, onBack }) {
  const toast = useToast();
  const [lig, setLig] = useState('Süper Lig');
  const [day, setDay] = useState(0);
  const [access, setAccess] = useState('open');
  const yeni = () => ({ k: newId(), home: '', away: '', time: '', market: 'MS 1' });
  const [rows, setRows] = useState([yeni()]);
  const [busy, setBusy] = useState(false);
  const up = (k, f, v) => setRows((r) => r.map((x) => (x.k === k ? { ...x, [f]: v } : x)));
  const valid = rows.filter((r) => r.home.trim() && r.away.trim() && /^\d{1,2}:\d{2}$/.test(r.time));
  const publish = async () => {
    if (!valid.length) return toast('En az bir maçı eksiksiz doldur (takımlar ve saat)');
    setBusy(true);
    let n = 0;
    for (const r of valid) {
      const h = findTeam(teams, r.home); const a = findTeam(teams, r.away);
      const m = {
        id: newId(), home: h ? h.name : r.home.trim(), away: a ? a.name : r.away.trim(), homeLogo: h?.logo || '', awayLogo: a?.logo || '',
        league: lig.trim(), date: dayOff(day), time: r.time.padStart(5, '0'), market: r.market, marketOther: '', text: '', conf: 2, reasons: '',
        access, cost: access === 'open' ? 1 : 2, banko: false, status: 'upcoming', score: '', minute: '', liveText: '', result: '', p1: '', px: '', p2: '', odd: '', updatedAt: Date.now(),
      };
      try { await saveMatch(m); n++; } catch (e) {}
    }
    setBusy(false);
    toast(`${n} maç yayınlandı ✓`);
    if (n) askNotify(cfg, `⚽ ${n} yeni tahmin yayında!`, `${lig} · ${['Bugün', 'Yarın', 'Öbür gün'][day]}`, toast, 'tahmin');
    setRows([yeni()]);
  };
  return (
    <View>
      <Header title="Toplu maç ekle" onBack={onBack} />
      <Card>
        <Field label="Lig" value={lig} onChangeText={setLig} placeholder="Süper Lig" />
        <Seg value={day} onChange={setDay} options={[[0, 'Bugün'], [1, 'Yarın'], [2, 'Öbür gün']]} />
        <Seg value={access} onChange={setAccess} options={[['open', 'Açık'], ['locked', 'Kilitli'], ['vip', 'VIP']]} />
        <Text style={[s.sub, { fontSize: 13 }]}>Takım adını yazmaya başla, kütüphanedeki takımlar logolarıyla çıkar. Detay (oran, form, anket) için sonra maça tek tek girebilirsin.</Text>
      </Card>
      {rows.map((r, i) => (
        <Card key={r.k}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <Text style={s.h3}>{i + 1}. maç</Text>
            {rows.length > 1 ? <Pressable onPress={() => setRows((x) => x.filter((y) => y.k !== r.k))} hitSlop={8}><Icon name="close" color={C.mut} /></Pressable> : null}
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TakimAlan teams={teams} up={up} r={r} f="home" ph="Ev sahibi" />
            <TakimAlan teams={teams} up={up} r={r} f="away" ph="Deplasman" />
          </View>
          <Field label="Saat" value={r.time} onChangeText={(v) => up(r.k, 'time', v)} placeholder="20:00" keyboardType="numbers-and-punctuation" maxLength={5} />
          <TahminSec value={r.market} onChange={(v) => up(r.k, 'market', v)} compact noOther home={r.home} away={r.away} />
        </Card>
      ))}
      <Btn kind="out" icon="add" title="Bir maç daha ekle" onPress={() => setRows((x) => [...x, { ...yeni(), time: x[x.length - 1]?.time || '' }])} />
      <Btn kind="ink" title={valid.length ? `${valid.length} maçı yayınla` : 'Maçları doldur'} disabled={!valid.length} loading={busy} onPress={publish} style={{ marginTop: 8, marginBottom: 20 }} />
    </View>
  );
}

function TakimAlan({ teams, up, r, f, ph }) {
  const sug = suggestTeams(teams, r[f]).filter((x) => x.name !== r[f]).slice(0, 4);
  return (
    <View style={{ flex: 1 }}>
      <Field value={r[f]} onChangeText={(v) => up(r.k, f, v)} placeholder={ph} style={{ marginBottom: sug.length ? 4 : 8 }} />
      {sug.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
          {sug.map((tm) => (
            <Pressable key={tm.id} onPress={() => up(r.k, f, tm.name)} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, minHeight: 30, borderRadius: 15, backgroundColor: C.bg }}>
              <Crest name={tm.name} logo={tm.logo} size={16} />
              <Text style={{ color: C.ink, fontSize: 12.5, fontWeight: '600' }}>{tm.name}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
}

/* Otomatik maç durumu + elle tetikleme */
function SenkronDurum({ cfg, matches, teams }) {
  const toast = useToast();
  const [st, setSt] = useState(null);
  const [busy, setBusy] = useState(false);
  React.useEffect(() => senkronDinle(setSt), []);
  const now = async () => {
    setBusy(true);
    await senkronTick({ cfg, list: matches.list, teams, force: true });
    setBusy(false);
    toast('Güncellendi');
  };
  return (
    <View style={{ marginTop: 12 }}>
      <View style={{ backgroundColor: C.bg, borderRadius: 12, padding: 12, gap: 3 }}>
        <Text style={{ color: C.ink, fontWeight: '700' }}>Bugün kullanılan sorgu: {st ? st.calls : '…'} / 90</Text>
        <Text style={{ color: C.ink, fontWeight: '700' }}>🤖 Robot tahmini · bugün: {st?.rg?.[today()] || 0} / 28 · yarın: {st?.rg?.[dayOff(1)] || 0} / 28</Text>
        <Text style={{ color: C.mut, fontSize: 12.5 }}>Sorgu hakkı her gece 03:00'te yenilenir. Hak bittiği için tahminsiz kalan maçları robot hak yenilenince kendisi doldurur. Yarının maçlarına, bugün için sorgu bolken bakar.</Text>
        <Text style={{ color: C.mut, fontSize: 13 }}>Son fikstür: {st?.lastToday ? new Date(st.lastToday).toLocaleTimeString('tr-TR').slice(0, 5) : '—'} · Son canlı: {st?.lastLive ? new Date(st.lastLive).toLocaleTimeString('tr-TR').slice(0, 5) : '—'}</Text>
        {(st?.log || []).slice(0, 5).map((l, i) => <Text key={i} style={{ color: C.mut, fontSize: 12.5 }}>{l}</Text>)}
      </View>
      <Btn small kind="out" icon="refresh" title="Şimdi güncelle" onPress={now} loading={busy} style={{ marginTop: 8 }} />
      <Text style={[s.sub, { fontSize: 12.5, marginTop: 6 }]}>Lig ayarını değiştirip en alttan kaydedince, 1 dakika içinde bugünün ve yarının maçları kendiliğinden çekilir. Güncellemeyi senin telefonun yapar: maç saatlerinde uygulama açık kalsın.</Text>
    </View>
  );
}

/* 📋 Bültenden maç seç (otomatik çekilen fikstür) */
const CANLI_ST = ['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE'];
function BultenSec({ teams, onPick, onClose }) {
  const [gun, setGun] = useState('bugun');
  const [q, setQ] = useState('');
  const bugun = useCanliSkor('bugun');
  const yarin = useCanliSkor('yarin');
  const doc0 = gun === 'bugun' ? bugun : yarin;
  const ql = q.trim().toLocaleLowerCase('tr');
  const L = (doc0.list || []).filter((x) => !['FT', 'AET', 'PEN', 'PST', 'CANC', 'ABD', 'AWD', 'WO'].includes(x.s))
    .filter((x) => !ql || `${x.h} ${x.a}`.toLocaleLowerCase('tr').includes(ql));
  const sira = (x) => (CANLI_ST.includes(x.s) ? 0 : 1);
  const gruplar = SKOR_LIGLER.map(([id, ad]) => ({ id, ad, items: L.filter((x) => x.l === id).sort((a, b) => sira(a) - sira(b) || String(a.t).localeCompare(b.t)) })).filter((g) => g.items.length);
  const pick = (x, ad) => {
    const ht = findTeam(teams, x.h); const at = findTeam(teams, x.a);
    const live = CANLI_ST.includes(x.s);
    onPick({
      afId: x.i, home: ht ? ht.name : x.h, away: at ? at.name : x.a, homeLogo: ht?.logo || x.hl || '', awayLogo: at?.logo || x.al || '',
      league: ad, date: doc0.date || today(), time: x.t,
      status: live ? 'live' : 'upcoming', score: live ? `${x.g?.[0] ?? 0}-${x.g?.[1] ?? 0}` : '', afStatus: x.s,
      minute: live && x.e ? String(x.e) : '', minuteAt: live && x.e ? Date.now() : 0,
    });
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>📋 Bülten</Text>
      <Seg value={gun} onChange={setGun} options={[['bugun', 'Bugün'], ['yarin', 'Yarın']]} />
      <Field value={q} onChangeText={setQ} placeholder="Takım ara (örn. Beşiktaş)" />
      {doc0.loading ? <Text style={s.sub}>Yükleniyor…</Text> : !gruplar.length ? (
        <Text style={[s.sub, { textAlign: 'center', marginVertical: 20 }]}>{(doc0.list || []).length ? 'Aramana uygun maç yok' : 'Bülten henüz gelmedi. Ayarlar → Otomatik maçlar → Şimdi güncelle.'}</Text>
      ) : gruplar.map((g) => (
        <View key={g.id} style={{ marginBottom: 10 }}>
          <Text style={{ fontWeight: '800', color: C.ink, marginBottom: 6 }}>{g.ad}</Text>
          {g.items.map((x) => {
            const live = CANLI_ST.includes(x.s);
            return (
              <Pressable key={x.i} onPress={() => pick(x, g.ad)} style={[s.row, { minHeight: 52, backgroundColor: C.bg }]}>
                <Text style={{ width: 50, fontWeight: '800', color: live ? C.red : C.ink, fontSize: 13 }}>{live ? `🔴 ${x.s === 'HT' ? 'İY' : (x.e || '') + "'"}` : x.t}</Text>
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.h} – {x.a}</Text>
                  {live ? <Text style={{ color: C.red, fontSize: 12.5, fontWeight: '700' }}>Canlı · {x.g?.[0] ?? 0}-{x.g?.[1] ?? 0}</Text> : null}
                </View>
                <Icon name="add-circle-outline" color={C.okTx} />
              </Pressable>
            );
          })}
        </View>
      ))}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}
