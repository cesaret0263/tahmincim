import React, { useState } from 'react';
import { View, Text, Pressable, Linking, Alert, ScrollView } from 'react-native';
import { C, badgesOf, tribuneStatus, AVATARS, adLimit, AD_WINDOW, canModerate, ROLE_LABEL, today, APP_SURUM } from '../tema';
import { Btn, Card, Icon, s, useTheme, Avatar, Sheet, Field, Crest, useToast } from '../parcalar';
import { useTeams, suggestTeams, findTeam, addFeedback, useMyFeedback, useTakipciler, useTakipEdilen, useCommentCounts } from '../topluluk';
import { profilAc } from '../profil';
import { engeliKaldir } from '../sosyal';
import { TribunKart } from './Tribun';
import { Seg } from '../parcalar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { onceLabel } from './Etkilesim';
import { isVip, MacSatiri } from './MacKart';
import { useSaved, toggleSaved } from '../kayit';
import { useGorev } from '../gorev';
import { getPrefs, savePrefs, PREF_LIST } from '../bildirim';
import { Toggle } from '../parcalar';

function Link({ icon, title, sub, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, borderTopWidth: 1, borderTopColor: C.line }}>
      <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={18} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>{title}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <Icon name="chevron-forward" size={18} color={C.mut} />
    </Pressable>
  );
}

export default function Ben({ cfg, matches, me, onAd, onMatch, isAdmin, onAdmin, onAuth, onLogout, onOnb, onRG, onBuy, onDelete, onShare, onRate, tribune, onUpdate, coupons, onNav, onCark, onGorev }) {
  const toast = useToast();
  const gv = useGorev();
  const th = useTheme();
  const saved = useSaved();
  const [kayit, setKayit] = useState(false);
  const [bild, setBild] = useState(false);
  const [gor, setGor] = useState(false);
  const [edit, setEdit] = useState(false);
  const [fb, setFb] = useState(false);
  const myFb = useMyFeedback(me && !me.guest ? me.id : null);
  const [fbSeen, setFbSeen] = useState(0);
  React.useEffect(() => { AsyncStorage.getItem('tahmincim_fb_seen').then((v) => setFbSeen(Number(v) || 0)).catch(() => {}); }, []);
  const newReplies = myFb.list.filter((f) => f.reply && (f.repliedAt || 0) > fbSeen).length;
  const openFb = () => { setFb(true); const n = Date.now(); setFbSeen(n); AsyncStorage.setItem('tahmincim_fb_seen', String(n)).catch(() => {}); };
  const mine = (tribune?.list || []).filter((x) => me && x.uid === me.id);
  const takipciler = useTakipciler(me && !me.guest ? me.id : null);
  const takipEdilen = useTakipEdilen(me && !me.guest ? me.id : null);
  const [kuponlarim, setKuponlarim] = useState(false);
  const [engelAc, setEngelAc] = useState(false);
  const mineWon = mine.filter((x) => tribuneStatus(x, matches.list) === 'won').length;
  const mineDone = mine.filter((x) => tribuneStatus(x, matches.list) !== 'pending').length;
  const badges = badgesOf(me, { tribune: mine.length, tribuneWon: mine.filter((x) => tribuneStatus(x, matches.list) === 'won').length });
  const L = cfg.links || {};
  const socials = [['instagram', 'logo-instagram', '#E1306C'], ['telegram', 'paper-plane', '#2AABEE'], ['whatsapp', 'logo-whatsapp', '#25D366'], ['x', 'logo-twitter', C.ink], ['youtube', 'logo-youtube', '#FF0000'], ['tiktok', 'logo-tiktok', C.ink]]
    .filter(([k]) => /^https?:\/\//i.test(L[k] || ''));
  const A = cfg.ads;
  const left = Math.max(0, adLimit(cfg) - (me?.adCount || 0));
  const resetH = me?.adAt ? Math.max(1, Math.ceil((me.adAt + AD_WINDOW - Date.now()) / 3600e3)) : 24;
  const F = matches.list.filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost'));
  const won = F.filter((m) => m.result === 'won').length;
  const last = [...F].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5);

  const yetkili = isAdmin || canModerate(me);
  const temaAd = { light: '☀️ Açık', dark: '🌙 Koyu', system: '📱 Otomatik' }[th.pref] || '📱 Otomatik';
  const gorevHazir = !me.guest && me.taskDay !== today() && gv.all;
  const Kutu = ({ e, t: tt, sub, onPress, dot, renk, disabled }) => (
    <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button"
      style={({ pressed }) => [{ flexBasis: '47%', flexGrow: 1, backgroundColor: renk ? renk[0] : C.card, borderRadius: 18, padding: 14, opacity: disabled ? 0.55 : 1 }, pressed && { transform: [{ scale: 0.97 }] }]}>
      <Text style={{ fontSize: 24 }}>{e}</Text>
      <Text style={{ fontWeight: '800', color: renk ? renk[1] : C.ink, marginTop: 6, fontSize: 15 }}>{tt}</Text>
      <Text numberOfLines={1} style={{ color: renk ? renk[1] : C.mut, fontSize: 12.5 }}>{sub}</Text>
      {dot ? <View style={{ position: 'absolute', top: 12, right: 12, width: 10, height: 10, borderRadius: 5, backgroundColor: C.red }} /> : null}
    </Pressable>
  );

  return (
    <View>
      {yetkili ? (
        <Pressable onPress={onAdmin} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.hero, borderRadius: 16, paddingHorizontal: 14, minHeight: 50, marginBottom: 12 }}>
          <Icon name="construct-outline" size={20} color="#fff" />
          <Text style={{ flex: 1, color: '#fff', fontWeight: '800' }}>{me.role === 'mod' ? 'Moderatör paneli' : 'Yönetim paneli'}</Text>
          <Icon name="chevron-forward" size={18} color="#fff" />
        </Pressable>
      ) : null}

      {me.guest ? (
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>Ücretsiz hesap aç</Text>
          <Text style={[s.sub, { marginTop: 4 }]}>
            Anahtar kazan, kilitli tahminleri aç; telefon değiştirsen bile her şey hesabında kalsın.
            {Number(cfg.startKeys) > 0 ? ` Kayıt olana ${Number(cfg.startKeys)} anahtar hediye!` : ''}
          </Text>
          <Btn style={{ marginTop: 14 }} title="Kayıt ol" onPress={() => onAuth('register')} />
          <Btn style={{ marginTop: 8 }} kind="out" title="Giriş yap" onPress={() => onAuth('login')} />
        </Card>
      ) : (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Pressable onPress={() => setEdit(true)} accessibilityLabel="Profili düzenle">
              <Avatar emoji={me.avatar} name={me.name || me.email} size={56} />
              <View style={{ position: 'absolute', right: -2, bottom: -2, width: 20, height: 20, borderRadius: 10, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="pencil" size={12} color={C.ink} />
              </View>
            </Pressable>
            <Pressable style={{ flex: 1 }} onPress={() => setEdit(true)}>
              <Text numberOfLines={1} style={{ fontSize: 18, fontWeight: '800', color: C.ink }}>{me.name || 'Hesabım'}</Text>
              <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{me.favTeam ? `⭐ ${me.favTeam}` : me.email}</Text>
              <View style={{ flexDirection: 'row', gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
                {isVip(me) ? (
                  <View style={{ backgroundColor: C.vipBg, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 3 }}>
                    <Text style={{ color: C.vipTx, fontWeight: '800', fontSize: 11.5 }}>{me.admin ? (ROLE_LABEL[me.role] || 'Admin').toLocaleUpperCase('tr') : `👑 VIP · ${Math.ceil((me.vipUntil - Date.now()) / 864e5)} gün`}</Text>
                  </View>
                ) : null}
                {Number(me.streak) > 0 ? (
                  <View style={{ backgroundColor: C.lockBg, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 3 }}>
                    <Text style={{ color: C.lockTx, fontWeight: '800', fontSize: 11.5 }}>🔥 {me.streak} gün seri</Text>
                  </View>
                ) : null}
              </View>
            </Pressable>
            <View style={{ alignItems: 'center', backgroundColor: C.key, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 8, minWidth: 62 }}>
              <Text style={{ fontSize: 22, fontWeight: '900', color: C.onKey }}>{me.admin ? '∞' : me.keys ?? 0}</Text>
              <Text style={{ fontSize: 11, fontWeight: '700', color: C.onKey }}>🔑 anahtar</Text>
            </View>
          </View>
          {badges.length ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12 }} contentContainerStyle={{ gap: 6 }}>
              {badges.map(([e, l]) => (
                <View key={l} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                  <Text>{e}</Text><Text style={{ fontWeight: '700', color: C.ink, fontSize: 12 }}>{l}</Text>
                </View>
              ))}
            </ScrollView>
          ) : null}
          <Pressable onPress={() => profilAc({ uid: me.id, name: me.name || 'Üye', avatar: me.avatar })} accessibilityRole="button"
            style={{ flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 12, backgroundColor: C.bg, borderRadius: 14, paddingHorizontal: 12, minHeight: 44 }}>
            <Text style={{ color: C.ink }}><Text style={{ fontWeight: '800' }}>{takipciler.list.length}</Text> takipçi</Text>
            <Text style={{ color: C.ink }}><Text style={{ fontWeight: '800' }}>{takipEdilen.list.length}</Text> takip</Text>
            <Text style={{ flex: 1, textAlign: 'right', color: C.okTx, fontWeight: '700', fontSize: 13 }}>Profilimi gör ›</Text>
          </Pressable>
          {me.banned ? (
            <View style={{ backgroundColor: C.redBg, borderRadius: 14, padding: 12, marginTop: 12 }}>
              <Text style={{ color: C.red, fontWeight: '700' }}>Hesabın askıya alındı. Kilitli tahminleri açamazsın.</Text>
            </View>
          ) : null}
        </Card>
      )}

      {!me.guest && !me.banned ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
          <Kutu e="🎯" t="Görevler" sub={me.taskDay === today() ? 'Ödül alındı ✓' : gv.all ? 'Ödülü al!' : `${gv.done}/${gv.total} tamamlandı`} onPress={onGorev} dot={gorevHazir} />
          <Kutu e="🎡" t="Şans çarkı" sub={onCark ? 'Çevirmeye hazır!' : 'Yarın tekrar'} onPress={onCark || undefined} disabled={!onCark} dot={!!onCark} renk={onCark ? [C.vipBg, C.vipTx] : null} />
          {A.on ? <Kutu e="📺" t="Reklam izle" sub={left > 0 ? `+${Number(A.reward) || 1} anahtar · ${left} hak` : `${resetH} saat sonra`} onPress={onAd} disabled={left <= 0} /> : null}
          {cfg.vip?.on || cfg.store?.on ? <Kutu e="👑" t={isVip(me) ? 'Mağaza' : 'VIP ol'} sub={isVip(me) ? 'Anahtar paketleri' : 'Hepsi açık, sınırsız'} onPress={onBuy} renk={!isVip(me) ? [C.hero, '#fff'] : null} /> : null}
        </View>
      ) : null}

      <Text style={[s.label, { marginLeft: 4 }]}>BENİM</Text>
      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          {!me.guest ? <Link icon="receipt-outline" title={`Kuponlarım${mine.length ? ` (${mine.length})` : ''}`} sub={mineDone ? `${mineWon} tuttu · %${Math.round((mineWon / mineDone) * 100)} başarı` : 'Tribün\'de paylaştığın kuponlar'} onPress={() => setKuponlarim(true)} /> : null}
          <Link icon="bookmark-outline" title={`Kaydedilenler${saved.length ? ` (${saved.length})` : ''}`} onPress={() => setKayit(true)} />
          {!me.guest && (me.engelli || []).length ? <Link icon="ban-outline" title={`Engellenenler (${me.engelli.length})`} onPress={() => setEngelAc(true)} /> : null}
          <Link icon="notifications-outline" title="Bildirim ayarları" onPress={() => setBild(true)} />
          <Link icon="contrast-outline" title="Görünüm" sub={temaAd} onPress={() => setGor(true)} />
          {Number(cfg.rewards?.share) > 0 && !me.guest && !me.shareRewarded && !me.banned ? <Link icon="gift-outline" title={`Arkadaşına öner, +${Number(cfg.rewards.share)} anahtar`} onPress={onShare} /> : null}
        </View>
      </Card>

      <Text style={[s.label, { marginLeft: 4 }]}>DESTEK</Text>
      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          <Link icon="mail-unread-outline" title="Öneri ve şikayet" sub={newReplies ? `💬 ${newReplies} yeni cevap var!` : null} onPress={openFb} />
          <Link icon="help-circle-outline" title="Nasıl kullanılır?" onPress={onOnb} />
          <Link icon="star-outline" title="Uygulamayı değerlendir" onPress={onRate} />
          {me.guest || me.shareRewarded || !(Number(cfg.rewards?.share) > 0) ? <Link icon="share-social-outline" title="Arkadaşına öner" onPress={onShare} /> : null}
          {/^https?:\/\//i.test(cfg.links?.support || '') ? <Link icon="chatbubbles-outline" title="Bize ulaş" onPress={() => Linking.openURL(cfg.links.support)} /> : null}
        </View>
      </Card>

      <Text style={[s.label, { marginLeft: 4 }]}>BİLGİ</Text>
      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          <Link icon="shield-checkmark-outline" title="Bilgilendirme" sub="Uygulama hakkında önemli notlar" onPress={onRG} />
          {/^https?:\/\//i.test(cfg.links?.privacy || '') ? <Link icon="document-text-outline" title="Gizlilik politikası" onPress={() => Linking.openURL(cfg.links.privacy)} /> : null}
        </View>
      </Card>

      {socials.length ? (
        <View style={{ flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap', gap: 10, marginVertical: 6 }}>
          {socials.map(([k, icon, col]) => (
            <Pressable key={k} onPress={() => Linking.openURL(L[k])} accessibilityLabel={k} accessibilityRole="link"
              style={{ width: 46, height: 46, borderRadius: 14, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={icon} size={22} color={col} />
            </Pressable>
          ))}
        </View>
      ) : null}

      {!me.guest ? (
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 24, marginTop: 10, marginBottom: 8 }}>
          <Pressable onPress={onLogout} hitSlop={10}><Text style={{ color: C.mut, fontWeight: '700' }}>Çıkış yap</Text></Pressable>
          <Pressable hitSlop={10} onPress={() => Alert.alert('Hesabın silinsin mi?', 'Bu işlem geri alınamaz. Anahtarların, açtığın tahminler, yorumların ve paylaşımların silinir.', [
            { text: 'Vazgeç', style: 'cancel' },
            { text: 'Sil', style: 'destructive', onPress: onDelete },
          ])}><Text style={{ color: C.red, fontWeight: '700' }}>Hesabımı sil</Text></Pressable>
        </View>
      ) : null}
      <Text style={{ textAlign: 'center', color: C.mut, fontSize: 12.5, marginTop: 6, marginBottom: 10 }}>Sürüm {APP_SURUM}</Text>
      {kuponlarim ? <Kuponlarim mine={mine} matches={matches} me={me} isAdmin={isAdmin} onClose={() => setKuponlarim(false)} /> : null}
      {engelAc ? (
        <Sheet visible onClose={() => setEngelAc(false)}>
          <Text style={[s.h2, { marginBottom: 4 }]}>Engellenenler</Text>
          <Text style={[s.sub, { marginBottom: 12 }]}>Bu kişilerin yorumlarını, kuponlarını ve skor tahminlerini görmüyorsun. Seni takip edemezler.</Text>
          {(me.engelli || []).length ? me.engelli.map((uid) => (
            <View key={uid} style={[s.row, { minHeight: 52 }]}>
              <Text numberOfLines={1} style={{ flex: 1, fontWeight: '700', color: C.ink }}>{(me.engelliAd || {})[uid] || 'Üye'}</Text>
              <Btn small kind="out" title="Engeli kaldır" onPress={() => engeliKaldir(me, uid).then(() => toast('Engel kaldırıldı')).catch(() => toast('Olmadı'))} />
            </View>
          )) : <Text style={s.sub}>Kimseyi engellemedin.</Text>}
          <Btn kind="ghost" title="Kapat" onPress={() => setEngelAc(false)} style={{ marginTop: 8 }} />
        </Sheet>
      ) : null}
      {gor ? (
        <Sheet visible onClose={() => setGor(false)}>
          <Text style={[s.h2, { marginBottom: 12 }]}>Görünüm</Text>
          {[['light', '☀️ Açık'], ['dark', '🌙 Koyu'], ['system', '📱 Telefonla aynı']].map(([k, l]) => (
            <Pressable key={k} onPress={() => { th.setPref && th.setPref(k); setGor(false); }} style={[s.row, { minHeight: 56, borderWidth: th.pref === k ? 2 : 0, borderColor: C.key }]}>
              <Text style={{ flex: 1, fontWeight: '700', color: C.ink, fontSize: 16 }}>{l}</Text>
              {th.pref === k ? <Icon name="checkmark-circle" color={C.okTx} /> : null}
            </Pressable>
          ))}
        </Sheet>
      ) : null}
      {kayit ? <Kaydedilenler saved={saved} matches={matches} coupons={coupons} me={me} onClose={() => setKayit(false)}
        onMatch={(m) => { setKayit(false); setTimeout(() => onMatch(m), 250); }} onCoupons={() => { setKayit(false); onNav && onNav('coupons'); }} /> : null}
      {bild ? <BildirimAyar onClose={() => setBild(false)} /> : null}
      {fb ? <OneriSikayet me={me} mine={myFb.list} onClose={() => setFb(false)} /> : null}
      {edit ? <ProfilDuzenle me={me} onUpdate={onUpdate} onClose={() => setEdit(false)} /> : null}
    </View>
  );
}

/* ---------------- Profil düzenle: avatar, isim, favori takım ---------------- */
function ProfilDuzenle({ me, onUpdate, onClose }) {
  const toast = useToast();
  const teams = useTeams();
  const [avatar, setAvatar] = useState(me.avatar || '');
  const [name, setName] = useState(me.name || '');
  const [fav, setFav] = useState(me.favTeam || '');
  const sug = suggestTeams(teams.list, fav);
  const save = () => {
    const n = name.trim().slice(0, 30);
    if (!n) return toast('İsmini yaz');
    const tm = findTeam(teams.list, fav);
    onUpdate && onUpdate(() => ({ avatar, name: n, favTeam: tm ? tm.name : fav.trim().slice(0, 40) }));
    toast('Profil kaydedildi');
    onClose();
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>Profilim</Text>
      <Text style={[s.label, { marginTop: 14 }]}>Avatarını seç</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
        {['', ...AVATARS].map((e) => (
          <Pressable key={e || 'harf'} onPress={() => setAvatar(e)} accessibilityLabel={e || 'Baş harf'}
            style={{ padding: 3, borderRadius: 26, borderWidth: 2, borderColor: avatar === e ? C.key : 'transparent' }}>
            <Avatar emoji={e} name={name || me.email} size={42} />
          </Pressable>
        ))}
      </View>
      <Field label="Görünen adın" value={name} onChangeText={setName} maxLength={30} placeholder="Örn. Cesaret" />
      <Field label="Favori takımın" value={fav} onChangeText={setFav} placeholder="Örn. Galatasaray" />
      {sug.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: -6, marginBottom: 12 }}>
          {sug.map((tm) => (
            <Pressable key={tm.id} onPress={() => setFav(tm.name)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, minHeight: 36, borderRadius: 18, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border }}>
              <Crest name={tm.name} logo={tm.logo} size={20} />
              <Text style={{ color: C.ink, fontWeight: '600' }}>{tm.name}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      <Text style={[s.sub, { fontSize: 13.5, marginBottom: 12 }]}>Favori takımının maçları en üstte ⭐ ile görünür ve maçtan 15 dk önce otomatik hatırlatılır.</Text>
      <Btn title="Kaydet" onPress={save} />
      <Btn kind="ghost" title="Vazgeç" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Öneri & şikayet ---------------- */
function OneriSikayet({ me, mine = [], onClose }) {
  const toast = useToast();
  const [kind, setKind] = useState('oneri');
  const [text, setText] = useState('');
  const [contact, setContact] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    const v = text.trim();
    if (v.length < 5) return toast('Biraz daha detaylı yaz');
    setBusy(true);
    try {
      await addFeedback({ kind, text: v, contact: contact.trim() || (me && !me.guest ? me.email : ''), uid: me && !me.guest ? me.id : '', name: me && !me.guest ? me.name : 'Misafir' });
      toast('Teşekkürler! Mesajın bize ulaştı 🙏');
      setText('');
    } catch (e) { toast('Gönderilemedi, internetini kontrol et'); }
    setBusy(false);
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>Öneri ve şikayet</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Uygulamayı birlikte geliştirelim. Her mesajı okuyoruz.</Text>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 12 }}>
        {[['oneri', '💡 Öneri'], ['sikayet', '⚠️ Şikayet'], ['hata', '🐞 Hata']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setKind(k)} accessibilityRole="tab" accessibilityState={{ selected: kind === k }}
            style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: kind === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: kind === k ? '800' : '600', color: kind === k ? C.ink : C.mut }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      <Field label="Mesajın" value={text} onChangeText={setText} multiline maxLength={1000}
        placeholder={kind === 'oneri' ? 'Uygulamada ne olsun istersin?' : kind === 'hata' ? 'Ne oldu, hangi ekranda?' : 'Neden memnun kalmadın?'} style={{ marginBottom: 8 }} />
      {!me || me.guest ? <Field label="Sana nasıl dönelim? (isteğe bağlı)" value={contact} onChangeText={setContact} placeholder="E-posta" autoCapitalize="none" keyboardType="email-address" /> : null}
      <Btn title="Gönder" icon="send" onPress={send} loading={busy} />
      {mine.length ? (
        <View style={{ marginTop: 18 }}>
          <Text style={s.h3}>Mesajlarım</Text>
          {mine.map((f) => (
            <View key={f.id} style={{ backgroundColor: C.bg, borderRadius: 14, padding: 12, marginBottom: 8 }}>
              <Text style={{ color: C.mut, fontSize: 12 }}>{f.kind === 'oneri' ? '💡 Öneri' : f.kind === 'hata' ? '🐞 Hata' : '⚠️ Şikayet'} · {onceLabel(f.createdAt)}</Text>
              <Text style={{ color: C.ink, marginTop: 4, lineHeight: 20 }}>{f.text}</Text>
              {f.reply ? (
                <View style={{ backgroundColor: C.okBg, borderRadius: 12, padding: 10, marginTop: 8 }}>
                  <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 12 }}>💬 {f.replyBy || 'Destek'} cevapladı · {onceLabel(f.repliedAt)}</Text>
                  <Text style={{ color: C.ink, marginTop: 4, lineHeight: 20 }}>{f.reply}</Text>
                </View>
              ) : <Text style={{ color: C.mut, fontSize: 12.5, marginTop: 6 }}>⏳ Cevap bekleniyor</Text>}
            </View>
          ))}
        </View>
      ) : null}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Kaydedilenler ---------------- */
function Kaydedilenler({ saved, matches, coupons, me, onClose, onMatch, onCoupons }) {
  const items = saved.map((x) => ({ x, m: x.k === 'm' ? matches.list.find((m) => m.id === x.id) : null, c: x.k === 'c' ? (coupons?.list || []).find((c) => c.id === x.id) : null }))
    .filter((y) => y.m || y.c);
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>🔖 Kaydedilenler</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Maç detayındaki ve kuponlardaki 🔖 işaretiyle eklersin.</Text>
      {!items.length ? <View style={s.empty}><Text style={[s.sub, { textAlign: 'center' }]}>Henüz kaydettiğin bir şey yok.</Text></View> : items.map(({ x, m, c }) => (
        <View key={x.k + x.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ flex: 1 }}>
            {m ? <MacSatiri m={m} me={me} onPress={() => onMatch(m)} /> : (
              <Pressable onPress={onCoupons} style={s.row}>
                <Icon name="receipt-outline" size={24} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700', color: C.ink }}>{c.title || 'Günün Kuponu'}</Text>
                  <Text style={{ color: C.mut, fontSize: 13 }}>{c.date} · {(c.picks || []).length} maç</Text>
                </View>
              </Pressable>
            )}
          </View>
          <Pressable onPress={() => toggleSaved(x)} accessibilityLabel="Kayıttan çıkar" hitSlop={6} style={{ width: 36, height: 36, alignItems: 'center', justifyContent: 'center', marginBottom: 10 }}>
            <Icon name="close" size={18} color={C.mut} />
          </Pressable>
        </View>
      ))}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Bildirim ayarları ---------------- */
function BildirimAyar({ onClose }) {
  const toast = useToast();
  const [p, setP] = useState(null);
  React.useEffect(() => { getPrefs().then(setP); }, []);
  const set = (k, v) => { const n = { ...p, [k]: v }; setP(n); savePrefs(n).catch(() => {}); };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>🔔 Bildirim ayarları</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Kapattığın türde bildirim gelmez. Mesaj cevapları her zaman gelir.</Text>
      {!p ? <Text style={s.sub}>Yükleniyor…</Text> : PREF_LIST.map(([k, l]) => (
        <Toggle key={k} label={l} value={p[k] !== false} onChange={(v) => set(k, v)} />
      ))}
      <Btn title="Tamam" onPress={() => { toast('Kaydedildi'); onClose(); }} style={{ marginTop: 8 }} />
    </Sheet>
  );
}

/* 🧾 Kuponlarım: kullanıcının Tribün'de paylaştığı bütün kuponlar (herkese açık + takipçilere özel) */
function Kuponlarim({ mine, matches, me, isAdmin, onClose }) {
  const [f, setF] = useState('all');
  const st = (x) => tribuneStatus(x, matches.list);
  const L = mine.filter((x) => f === 'all' || st(x) === f);
  const yorumSay = useCommentCounts(L.slice(0, 30).map((x) => 't_' + x.id));
  const won = mine.filter((x) => st(x) === 'won').length;
  const lost = mine.filter((x) => st(x) === 'lost').length;
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>Kuponlarım</Text>
      <Text style={[s.sub, { marginTop: 2, marginBottom: 10 }]}>{mine.length} kupon · {won} tuttu · {lost} tutmadı{won + lost ? ` · %${Math.round((won / (won + lost)) * 100)} başarı` : ''}</Text>
      <Seg value={f} onChange={setF} options={[['all', 'Tümü'], ['won', 'Tutan'], ['pending', 'Bekleyen'], ['lost', 'Tutmayan']]} />
      {!L.length ? <Text style={[s.sub, { marginVertical: 16, textAlign: 'center' }]}>{mine.length ? 'Bu filtrede kupon yok.' : 'Henüz kupon paylaşmadın. Ortadaki + düğmesiyle ilk kuponunu paylaş!'}</Text>
        : L.slice(0, 60).map((x) => <TribunKart key={x.id} tc={x} matchList={matches.list} me={me} isAdmin={isAdmin} onNeedAuth={() => {}} yorumSay={yorumSay['t_' + x.id] || 0} />)}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 8 }} />
    </Sheet>
  );
}
