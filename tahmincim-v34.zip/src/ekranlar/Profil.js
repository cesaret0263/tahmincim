// Herkese açık kullanıcı profili: takip, rozetler, Tribün ve Skor Ligi başarısı, kuponları
import React, { useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { C, tribuneStatus, scorePoints, skorTam, monthKey } from '../tema';
import { Avatar, Btn, Icon, Sheet, Seg, s, useToast } from '../parcalar';
import { useUserScores, useTakipciler, useTakipEdilen, useCommentCounts } from '../topluluk';
import { profilAc } from '../profil';
import { engelliMi, engelleSor, engeliKaldir } from '../sosyal';
import { TribunKart } from './Tribun';
import { useTakipIslem } from './TakipButon';

function KisiSatiri({ uid, name, avatar, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={[s.row, { minHeight: 52, paddingVertical: 8, backgroundColor: C.bg }]}>
      <Avatar emoji={avatar} name={name} size={34} />
      <Text numberOfLines={1} style={{ flex: 1, fontWeight: '700', color: C.ink }}>{name || 'Üye'}</Text>
    </Pressable>
  );
}

export default function ProfilPenceresi({ p, tribune, matches, me, isAdmin, onNeedAuth, onShareCard, onClose }) {
  const toast = useToast();
  const [sekme, setSekme] = useState('kupon');
  const scores = useUserScores(p.uid);
  const takipciler = useTakipciler(p.uid);
  const takipEdilen = useTakipEdilen(p.uid);
  const benim = !!(me && me.id === p.uid);
  const engelli = engelliMi(me, p.uid);
  const mine = (tribune?.list || []).filter((x) => x.uid === p.uid);
  const st = mine.map((x) => ({ x, st: tribuneStatus(x, matches.list) }));
  const won = st.filter((y) => y.st === 'won').length;
  const lost = st.filter((y) => y.st === 'lost').length;
  const pct = won + lost ? Math.round((won / (won + lost)) * 100) : null;
  const byId = {};
  matches.list.forEach((m) => { byId[m.id] = m; });
  const mk = monthKey();
  let pts = 0; let exact = 0; let monthPts = 0;
  scores.list.forEach((sc) => {
    const m = byId[sc.matchId];
    const pt = scorePoints(sc, m);
    if (pt == null) return;
    pts += pt; if (skorTam(sc, m)) exact++;
    if (sc.month === mk) monthPts += pt;
  });
  const last = scores.list[0] || mine[0];
  const name = p.name || last?.name || 'Üye';
  const avatar = p.avatar || last?.avatar || '';
  const yorumSay = useCommentCounts(mine.slice(0, 10).map((x) => 't_' + x.id));
  const badges = [];
  if (mine.length >= 1) badges.push(['🧾', 'Kuponcu']);
  if (won >= 5) badges.push(['🏆', 'Kupon ustası']);
  if (pct != null && won + lost >= 5 && pct >= 60) badges.push(['🎯', 'Keskin nişancı']);
  if (scores.list.length >= 10) badges.push(['⚽', 'Lig oyuncusu']);
  if (exact >= 3) badges.push(['🔮', 'Skor kahini']);
  if (takipciler.list.length >= 10) badges.push(['⭐', 'Sevilen tahminci']);

  const tk = useTakipIslem(me, { uid: p.uid, name, avatar }, onNeedAuth);
  const engelMenu = () => {
    if (engelli) {
      return Alert.alert(`${name} engelli`, 'Engeli kaldırırsan yorumları ve kuponları yeniden görünür.', [
        { text: 'Vazgeç', style: 'cancel' },
        { text: 'Engeli kaldır', onPress: () => engeliKaldir(me, p.uid).then(() => toast('Engel kaldırıldı')).catch(() => toast('Olmadı')) },
      ]);
    }
    engelleSor(me, { uid: p.uid, name }, toast);
  };
  const ac = (x) => { onClose(); setTimeout(() => profilAc(x), 250); };

  const Kutu = ({ v, l, onPress, on }) => (
    <Pressable onPress={onPress} disabled={!onPress} style={{ flex: 1, backgroundColor: on ? C.selBg : C.bg, borderRadius: 16, padding: 12, alignItems: 'center', borderWidth: on ? 1.5 : 0, borderColor: C.ink }}>
      <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{v}</Text>
      <Text style={{ fontSize: 12, color: C.mut, textAlign: 'center' }}>{l}</Text>
    </Pressable>
  );
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ alignItems: 'center', gap: 6 }}>
        <Avatar emoji={avatar} name={name} size={72} />
        <Text style={[s.h2, { marginTop: 4 }]}>{name}</Text>
        {badges.length ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 6, marginTop: 4 }}>
            {badges.map(([e, l]) => (
              <View key={l} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                <Text>{e}</Text><Text style={{ fontWeight: '700', color: C.ink, fontSize: 12.5 }}>{l}</Text>
              </View>
            ))}
          </View>
        ) : null}
      </View>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 14 }}>
        <Kutu v={takipciler.list.length} l="Takipçi" on={sekme === 'takipci'} onPress={() => setSekme(sekme === 'takipci' ? 'kupon' : 'takipci')} />
        <Kutu v={takipEdilen.list.length} l="Takip" on={sekme === 'takip'} onPress={() => setSekme(sekme === 'takip' ? 'kupon' : 'takip')} />
        <Kutu v={mine.length} l="Kupon" on={sekme === 'kupon'} onPress={() => setSekme('kupon')} />
      </View>
      {!benim ? (
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
          {engelli ? null : <Btn kind={tk.takipte ? 'out' : 'ink'} icon={tk.takipte ? 'checkmark' : 'person-add-outline'} title={tk.takipte ? 'Takiptesin' : 'Takip et'} loading={tk.mesgul} onPress={tk.takip} style={{ flex: 2 }} />}
          {!engelli && tk.takipte ? (
            <Pressable onPress={tk.zil} accessibilityLabel={tk.bildir ? 'Kupon bildirimini kapat' : 'Kupon bildirimini aç'}
              style={{ width: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: tk.bildir ? C.okBg : C.card }}>
              <Icon name={tk.bildir ? 'notifications' : 'notifications-off-outline'} size={20} color={tk.bildir ? C.okTx : C.mut} />
            </Pressable>
          ) : null}
          {me && me.id && !me.guest ? <Btn kind="out" title={engelli ? 'Engeli kaldır' : 'Engelle'} onPress={engelMenu} style={{ flex: 1 }} /> : null}
        </View>
      ) : null}

      <Text style={[s.h3, { marginTop: 18 }]}>🧾 Tribün</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Kutu v={won} l="Tuttu" />
        <Kutu v={lost} l="Tutmadı" />
        <Kutu v={pct == null ? '–' : `%${pct}`} l="Başarı" />
      </View>
      <Text style={[s.h3, { marginTop: 16 }]}>⚽ Skor Ligi</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Kutu v={monthPts} l="Bu ay puan" />
        <Kutu v={pts} l="Toplam puan" />
        <Kutu v={exact} l="Tam skor" />
      </View>

      <View style={{ marginTop: 16 }}>
        {sekme === 'takipci' || sekme === 'takip' ? (
          <View>
            <Text style={s.h3}>{sekme === 'takipci' ? 'Takipçileri' : 'Takip ettikleri'}</Text>
            {(sekme === 'takipci' ? takipciler.list : takipEdilen.list).length ? (sekme === 'takipci' ? takipciler.list : takipEdilen.list)
              .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
              .filter((x) => !engelliMi(me, sekme === 'takipci' ? x.from : x.to))
              .slice(0, 200)
              .map((x) => (sekme === 'takipci'
                ? <KisiSatiri key={x.id} uid={x.from} name={x.fromName} avatar={x.fromAvatar} onPress={() => ac({ uid: x.from, name: x.fromName, avatar: x.fromAvatar })} />
                : <KisiSatiri key={x.id} uid={x.to} name={x.toName} avatar={x.toAvatar} onPress={() => ac({ uid: x.to, name: x.toName, avatar: x.toAvatar })} />))
              : <Text style={s.sub}>{sekme === 'takipci' ? 'Henüz takipçisi yok.' : 'Henüz kimseyi takip etmiyor.'}</Text>}
          </View>
        ) : engelli ? (
          <Text style={s.sub}>Bu kullanıcıyı engelledin. Kuponlarını görmek için engeli kaldır.</Text>
        ) : mine.length ? (
          <View>
            <Text style={s.h3}>Kuponları</Text>
            {mine.slice(0, 10).map((x) => (
              <TribunKart key={x.id} tc={x} matchList={matches.list} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} onShareCard={onShareCard} yorumSay={yorumSay['t_' + x.id] || 0} />
            ))}
            {mine.length > 10 ? <Text style={s.note}>Son 10 kupon gösteriliyor ({mine.length} kupon).</Text> : null}
          </View>
        ) : <Text style={s.sub}>Henüz paylaştığı kupon yok.</Text>}
      </View>
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 8 }} />
    </Sheet>
  );
}
