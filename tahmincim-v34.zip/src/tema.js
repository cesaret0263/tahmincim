export const LIGHT = {
  bg: '#F4F5F0',
  ink: '#12161C',
  hero: '#12161C',
  mut: '#5B6470',
  line: '#E2E5DD',
  card: '#FFFFFF',
  track: '#E9ECE4',
  border: '#D5DAD0',
  key: '#FF8A1F',
  onKey: '#2A1400',
  lockBg: '#FFF1E3',
  lockTx: '#8A3A00',
  vipBg: '#FFF6D6',
  vipTx: '#6B4D00',
  okBg: '#E6FBEF',
  okTx: '#047A42',
  red: '#B42318',
  redBg: '#FDE8E8',
  dark2: '#262C35',
  adminBg: '#EEF0EA',
  selBg: '#E6F8EE',
  dark: false,
};
export const DARK = {
  bg: '#0E1116',
  ink: '#F2F4F7',
  hero: '#1C222B',
  mut: '#9AA3AF',
  line: '#262C35',
  card: '#171B22',
  track: '#222831',
  border: '#343B46',
  key: '#FF8A1F',
  onKey: '#2A1400',
  lockBg: '#3A2716',
  lockTx: '#FFB46B',
  vipBg: '#3A3215',
  vipTx: '#FFD666',
  okBg: '#12301F',
  okTx: '#4ADE80',
  red: '#FF6B7D',
  redBg: '#3A1618',
  dark2: '#2A313B',
  adminBg: '#0B0E12',
  selBg: '#13261B',
  dark: true,
};
// Renkler tek yerden; tema değişince içerik güncellenir
export const C = { ...LIGHT };
export function applyTheme(dark) {
  Object.assign(C, dark ? DARK : LIGHT);
}

export const DEFAULT_CFG = {
  name: 'Tahmincim',
  logo: '',
  color: '#00D26A',
  startKeys: 3,
  message: { on: false, text: '', type: 'info' },
  ads: { on: true, unitId: '', reward: 1, limit: 3, bannerImg: '', bannerLink: '' },
  keys: { expireDays: 0, dailyUnlock: 5 },
  auto: { on: true, leagues: [203, 204, 2, 39, 140, 135, 78], publish: 'auto', access: 'open', robotKupon: true },
  vip: { on: true, plans: [{ days: 7, price: '₺29,99' }, { days: 30, price: '₺79,99' }, { days: 90, price: '₺199,99' }] },
  links: { support: '', privacy: '', instagram: '', telegram: '', whatsapp: '', x: '', youtube: '', tiktok: '' },
  push: { projectId: '' },
  rewards: { share: 2, daily: 1, week: 2, tasks: 2 },
  store: { on: true, packs: [{ keys: 5, price: '₺19,99' }, { keys: 15, price: '₺49,99' }, { keys: 40, price: '₺99,99' }] },
  surum: { on: false, son: '', link: 'https://github.com/cesaret0263/tahmincim/releases/latest/download/app-release.apk', not: '' },
};

export function mergeCfg(c) {
  const o = JSON.parse(JSON.stringify(DEFAULT_CFG));
  if (c && typeof c === 'object') {
    Object.assign(o, c);
    o.message = { ...DEFAULT_CFG.message, ...(c.message || {}) };
    o.ads = { ...DEFAULT_CFG.ads, ...(c.ads || {}) };
    o.store = { ...DEFAULT_CFG.store, ...(c.store || {}) };
    o.links = { ...DEFAULT_CFG.links, ...(c.links || {}) };
    o.push = { ...DEFAULT_CFG.push, ...(c.push || {}) };
    o.rewards = { ...DEFAULT_CFG.rewards, ...(c.rewards || {}) };
    o.keys = { ...DEFAULT_CFG.keys, ...(c.keys || {}) };
    o.auto = { ...DEFAULT_CFG.auto, ...(c.auto || {}) };
    if (!Array.isArray(o.auto.leagues)) o.auto.leagues = DEFAULT_CFG.auto.leagues;
    o.vip = { ...DEFAULT_CFG.vip, ...(c.vip || {}) };
    o.surum = { ...DEFAULT_CFG.surum, ...(c.surum || {}) };
    if (!Array.isArray(o.vip.plans)) o.vip.plans = DEFAULT_CFG.vip.plans;
    if (!Array.isArray(o.store.packs)) o.store.packs = DEFAULT_CFG.store.packs;
  }
  return o;
}

// Tahmin seçenekleri: [kod, açıklama]. Hepsi skordan (ve ilk yarı skorundan) otomatik sonuçlanır.
const M = (k, t) => [k, t];
const AU = (n, pre = '', who = 'Maçta') => [
  M(`${pre}${n}.5 Üst`, `${who} ${n + 1} veya daha fazla gol olur`),
  M(`${pre}${n}.5 Alt`, n === 0 ? `${who} gol olmaz` : `${who} en fazla ${n} gol olur`),
];
export const MARKET_GRUP_TAM = [
  ['Maç sonucu', [M('MS 1', '{h} kazanır'), M('MS X', 'Maç berabere biter'), M('MS 2', '{a} kazanır')]],
  ['Çifte şans', [M('1X', '{h} kaybetmez'), M('X2', '{a} kaybetmez'), M('12', 'Maç berabere bitmez')]],
  ['Alt / Üst', [0, 1, 2, 3, 4, 5, 6].flatMap((n) => AU(n))],
  ['Karşılıklı gol', [M('KG Var', 'İki takım da gol atar'), M('KG Yok', 'En az bir takım gol atamaz')]],
  ['Takım golleri', [
    ...[0, 1, 2].flatMap((n) => [M(`Ev ${n}.5 Üst`, `{h} en az ${n + 1} gol atar`), M(`Ev ${n}.5 Alt`, n === 0 ? '{h} gol atamaz' : `{h} en fazla ${n} gol atar`)]),
    ...[0, 1, 2].flatMap((n) => [M(`Dep ${n}.5 Üst`, `{a} en az ${n + 1} gol atar`), M(`Dep ${n}.5 Alt`, n === 0 ? '{a} gol atamaz' : `{a} en fazla ${n} gol atar`)]),
  ]],
  ['Handikap', [
    M('Ev -1.5', '{h} en az 2 farkla kazanır'), M('Ev -2.5', '{h} en az 3 farkla kazanır'), M('Ev +1.5', '{h} kaybetmez ya da en fazla 1 farkla kaybeder'),
    M('Dep -1.5', '{a} en az 2 farkla kazanır'), M('Dep -2.5', '{a} en az 3 farkla kazanır'), M('Dep +1.5', '{a} kaybetmez ya da en fazla 1 farkla kaybeder'),
  ]],
  ['Toplam gol', [
    M('Gol 0-1', 'Maçta 0 ya da 1 gol olur'), M('Gol 2-3', 'Maçta 2 ya da 3 gol olur'), M('Gol 4-5', 'Maçta 4 ya da 5 gol olur'), M('Gol 6+', 'Maçta 6 veya daha fazla gol olur'),
    M('Gol Tek', 'Maçtaki toplam gol sayısı tek olur'), M('Gol Çift', 'Maçtaki toplam gol sayısı çift olur (0 dahil)'),
  ]],
  ['İlk yarı', [
    M('İY 1', 'İlk yarıyı {h} önde bitirir'), M('İY X', 'İlk yarı berabere biter'), M('İY 2', 'İlk yarıyı {a} önde bitirir'),
    M('İY 1X', 'İlk yarıda {h} geride kalmaz'), M('İY X2', 'İlk yarıda {a} geride kalmaz'), M('İY 12', 'İlk yarı berabere bitmez'),
    M('İY 0.5 Üst', 'İlk yarıda gol olur'), M('İY 0.5 Alt', 'İlk yarıda gol olmaz'),
    M('İY 1.5 Üst', 'İlk yarıda en az 2 gol olur'), M('İY 1.5 Alt', 'İlk yarıda en fazla 1 gol olur'),
    M('İY 2.5 Üst', 'İlk yarıda en az 3 gol olur'), M('İY 2.5 Alt', 'İlk yarıda en fazla 2 gol olur'),
    M('İY KG Var', 'İlk yarıda iki takım da gol atar'), M('İY KG Yok', 'İlk yarıda en az bir takım gol atamaz'),
  ]],
  ['İkinci yarı', [
    M('2Y 1', 'İkinci yarıda {h} daha çok gol atar'), M('2Y X', 'İkinci yarıda iki takım eşit gol atar'), M('2Y 2', 'İkinci yarıda {a} daha çok gol atar'),
    M('2Y 0.5 Üst', 'İkinci yarıda gol olur'), M('2Y 0.5 Alt', 'İkinci yarıda gol olmaz'),
    M('2Y 1.5 Üst', 'İkinci yarıda en az 2 gol olur'), M('2Y 1.5 Alt', 'İkinci yarıda en fazla 1 gol olur'),
    M('2Y KG Var', 'İkinci yarıda iki takım da gol atar'), M('2Y KG Yok', 'İkinci yarıda en az bir takım gol atamaz'),
  ]],
  ['İY / MS', ['1', 'X', '2'].flatMap((i) => ['1', 'X', '2'].map((s) => {
    const ad = (x) => (x === '1' ? '{h} önde' : x === '2' ? '{a} önde' : 'berabere');
    return M(`İY/MS ${i}/${s}`, `İlk yarı ${ad(i)}, maç sonu ${s === '1' ? '{h} kazanır' : s === '2' ? '{a} kazanır' : 'berabere'}`);
  }))],
  ['Daha çok gol', [
    M('Çok gol İY', 'İlk yarıda ikinci yarıdan çok gol olur'), M('Çok gol 2Y', 'İkinci yarıda ilk yarıdan çok gol olur'), M('Çok gol Eşit', 'İki yarıda eşit sayıda gol olur'),
  ]],
  ['Kombine', [
    M('MS 1 & 1.5 Üst', '{h} kazanır ve maçta 2+ gol olur'), M('MS 2 & 1.5 Üst', '{a} kazanır ve maçta 2+ gol olur'),
    M('MS 1 & 2.5 Üst', '{h} kazanır ve maçta 3+ gol olur'), M('MS 2 & 2.5 Üst', '{a} kazanır ve maçta 3+ gol olur'),
    M('MS 1 & 2.5 Alt', '{h} kazanır ve maçta en fazla 2 gol olur'), M('MS 2 & 2.5 Alt', '{a} kazanır ve maçta en fazla 2 gol olur'),
    M('MS 1 & KG Var', '{h} kazanır ve iki takım da gol atar'), M('MS 2 & KG Var', '{a} kazanır ve iki takım da gol atar'),
    M('MS 1 & Dep 0.5 Alt', '{h} gol yemeden kazanır'), M('MS 2 & Ev 0.5 Alt', '{a} gol yemeden kazanır'),
    M('MS X & KG Var', 'Maç golcü beraberlikle biter'), M('MS X & KG Yok', 'Maç 0-0 biter'),
    M('1X & 1.5 Üst', '{h} kaybetmez ve maçta 2+ gol olur'), M('X2 & 1.5 Üst', '{a} kaybetmez ve maçta 2+ gol olur'),
    M('1X & 2.5 Üst', '{h} kaybetmez ve maçta 3+ gol olur'), M('X2 & 2.5 Üst', '{a} kaybetmez ve maçta 3+ gol olur'),
    M('1X & KG Var', '{h} kaybetmez ve iki takım da gol atar'), M('X2 & KG Var', '{a} kaybetmez ve iki takım da gol atar'),
    M('KG Var & 2.5 Üst', 'İki takım da gol atar ve maçta 3+ gol olur'), M('KG Var & 3.5 Üst', 'İki takım da gol atar ve maçta 4+ gol olur'),
    M('KG Yok & 2.5 Alt', 'En az bir takım gol atamaz ve maçta en fazla 2 gol olur'), M('KG Yok & 2.5 Üst', 'Bir takım gol atamaz ama maçta 3+ gol olur'),
  ]],
];
export const MARKETS = [...MARKET_GRUP_TAM.flatMap(([, l]) => l), M('Diğer', '')];
// Tahmin seçicide gruplar (yalnız kodlar)
export const MARKET_GRUP = [...MARKET_GRUP_TAM.map(([g, l]) => [g, l.map((x) => x[0])]), ['Diğer', ['Diğer']]];
// Kesin skor: "Skor 2-1"
export const SKOR_PAZAR = /^Skor (\d{1,2})-(\d{1,2})$/;
export const CONF = ['Zayıf', 'Orta', 'Güçlü'];

const MARKET_TXT = Object.fromEntries(MARKETS);
function tekMetin(k) {
  const mm = SKOR_PAZAR.exec(k);
  if (mm) return `Maç ${mm[1]}-${mm[2]} biter`;
  return MARKET_TXT[k] || '';
}
export function marketText(market, home, away) {
  const k = String(market || '').trim();
  let t = MARKET_TXT[k];
  if (t == null) {
    // "Kendin birleştir" ile yapılan kombine: parçaların açıklamaları "ve" ile birleşir
    const parts = k.split(' & ').map((x) => x.trim()).filter(Boolean);
    const tx = parts.map(tekMetin);
    t = tx.length && tx.every(Boolean) ? tx.map((x, i) => (i ? x.charAt(0).toLocaleLowerCase('tr') + x.slice(1) : x)).join(' ve ') : '';
  }
  return t.split('{h}').join(home || 'Ev sahibi').split('{a}').join(away || 'Deplasman');
}
export function predText(m) {
  // eski robot kayıtlarında "Robot analizi: ev %…" yazısı var; onun yerine anlaşılır tahmin cümlesini göster
  const txt = m.robot && String(m.text || '').includes('Robot analizi') ? '' : m.text;
  return txt || marketText(m.market, m.home, m.away) || m.market || '';
}

export function lum(hex) {
  const r = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!r) return 1;
  const n = parseInt(r[1], 16);
  const c = [n >> 16, (n >> 8) & 255, n & 255].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}
export function accentOf(cfg) {
  const acc = /^#[0-9a-f]{6}$/i.test(cfg?.color || '') ? cfg.color : '#00D26A';
  return { acc, onAcc: lum(acc) > 0.35 ? '#0B2416' : '#FFFFFF' };
}

export function hashColor(s) {
  let h = 0;
  for (const ch of String(s || '')) h = (h * 31 + ch.charCodeAt(0)) | 0;
  const p = ['#E2231A', '#1D4BA8', '#2B2F36', '#7A1F3D', '#0E7C4A', '#C25400', '#5B3FD1', '#0B6E99', '#A3122E', '#3D5A1E'];
  return p[Math.abs(h) % p.length];
}
export function initials(n) {
  const w = String(n || '?').trim().split(/\s+/);
  return (w.length > 1 ? w[0][0] + w[1][0] : w[0].slice(0, 3)).toUpperCase();
}

export function ymd(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
export function dayOff(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return ymd(d);
}
export const today = () => ymd(new Date());

export function isImg(u) {
  return typeof u === 'string' && (/^data:image\/(png|jpeg|webp);base64,/.test(u) || /^https:\/\/\S+$/.test(u));
}
export function scoreOf(m) {
  const s = String(m.score || '').split('-');
  return [(s[0] || '0').trim(), (s[1] || '0').trim()];
}
export const byTime = (a, b) => String(a.time || '').localeCompare(String(b.time || ''));
export const newId = () => 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* ---------- kupon yardımcıları ---------- */
export const oddOf = (v) => {
  const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  return isFinite(n) && n > 0 ? n : 0;
};
export function couponPicks(c, matchList) {
  const byId = {};
  (matchList || []).forEach((m) => { byId[m.id] = m; });
  return (c.picks || []).map((p) => ({ ...p, m: byId[p.matchId] || null }));
}
export function couponTotal(picks) {
  const odds = picks.map((p) => oddOf(p.odd || (p.m && p.m.odd))).filter((x) => x > 0);
  return odds.length ? odds.reduce((a, b) => a * b, 1) : 0;
}
export function couponStatus(picks) {
  if (!picks.length) return 'pending';
  const res = picks.map(satirSonuc);
  if (res.some((r) => r === 'lost')) return 'lost';
  if (res.every((r) => r === 'won')) return 'won';
  return 'pending';
}

const AYLAR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const GUNLER = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
// "2026-11-21" -> "21 Kasım Cumartesi" (bugün/yarın/dün ise başına eklenir)
export function dayLabel(d, withRel = true) {
  if (!d || !/^\d{4}-\d{2}-\d{2}$/.test(d)) return '';
  const [y, m, g] = d.split('-').map(Number);
  const dt = new Date(y, m - 1, g);
  const base = `${g} ${AYLAR[m - 1]} ${GUNLER[dt.getDay()]}`;
  if (!withRel) return base;
  const rel = d === dayOff(0) ? 'Bugün' : d === dayOff(1) ? 'Yarın' : d === dayOff(-1) ? 'Dün' : '';
  return rel ? `${rel} · ${base}` : base;
}

export const PLAY_PACKAGE = 'com.tahmincim.app';

/* ---------- Tahmin değerlendirme (Tuttu / Tutmadı) ---------- */
// Tribün'de de admin ile aynı seçenekler var (Diğer hariç)
export const TRIBUNE_MARKETS = MARKETS.map((x) => x[0]).filter((k) => k !== 'Diğer');
const SKOR_RE = /^\s*\d+\s*-\s*\d+\s*$/;
const skor2 = (v) => (SKOR_RE.test(String(v || '')) ? String(v).split('-').map((x) => parseInt(x, 10)) : null);
const ms3 = (x, y) => (x > y ? '1' : x < y ? '2' : 'X');
// Tek bir seçeneği kesin skorla değerlendirir: true / false / undefined (bilinmiyor)
// h-a: maç sonu, ih-ia: ilk yarı (bilinmiyorsa null)
function tekPazar(k, h, a, ih, ia) {
  const t = h + a;
  const iy = ih != null && ia != null;
  const h2 = iy ? h - ih : null; const a2 = iy ? a - ia : null;
  let mm;
  if (k === 'MS 1') return h > a;
  if (k === 'MS X') return h === a;
  if (k === 'MS 2') return a > h;
  if (k === '1X') return h >= a;
  if (k === 'X2') return a >= h;
  if (k === '12') return h !== a;
  if (k === 'KG Var') return h > 0 && a > 0;
  if (k === 'KG Yok') return !(h > 0 && a > 0);
  if ((mm = /^(\d+)\.5 (Üst|Alt)$/.exec(k))) return mm[2] === 'Üst' ? t > +mm[1] : t <= +mm[1];
  if ((mm = /^(Ev|Dep) (\d+)\.5 (Üst|Alt)$/.exec(k))) { const g = mm[1] === 'Ev' ? h : a; return mm[3] === 'Üst' ? g > +mm[2] : g <= +mm[2]; }
  if ((mm = /^(Ev|Dep) ([-+])(\d+)\.5$/.exec(k))) { const fark = mm[1] === 'Ev' ? h - a : a - h; const n = +mm[3]; return mm[2] === '-' ? fark > n : fark > -(n + 1); }
  if ((mm = /^Gol (\d+)-(\d+)$/.exec(k))) return t >= +mm[1] && t <= +mm[2];
  if ((mm = /^Gol (\d+)\+$/.exec(k))) return t >= +mm[1];
  if (k === 'Gol Tek') return t % 2 === 1;
  if (k === 'Gol Çift') return t % 2 === 0;
  if ((mm = SKOR_PAZAR.exec(k))) return h === +mm[1] && a === +mm[2];
  // İlk yarı
  if (k.startsWith('İY ') || k.startsWith('İY/MS') || k.startsWith('2Y ') || k.startsWith('Çok gol')) { if (!iy) return undefined; }
  if (k === 'İY 1') return ih > ia;
  if (k === 'İY X') return ih === ia;
  if (k === 'İY 2') return ia > ih;
  if (k === 'İY 1X') return ih >= ia;
  if (k === 'İY X2') return ia >= ih;
  if (k === 'İY 12') return ih !== ia;
  if (k === 'İY KG Var') return ih > 0 && ia > 0;
  if (k === 'İY KG Yok') return !(ih > 0 && ia > 0);
  if ((mm = /^İY (\d+)\.5 (Üst|Alt)$/.exec(k))) return mm[2] === 'Üst' ? ih + ia > +mm[1] : ih + ia <= +mm[1];
  if ((mm = /^İY\/MS ([1X2])\/([1X2])$/.exec(k))) return ms3(ih, ia) === mm[1] && ms3(h, a) === mm[2];
  // İkinci yarı (maç sonu eksi ilk yarı)
  if (k === '2Y 1') return h2 > a2;
  if (k === '2Y X') return h2 === a2;
  if (k === '2Y 2') return a2 > h2;
  if (k === '2Y KG Var') return h2 > 0 && a2 > 0;
  if (k === '2Y KG Yok') return !(h2 > 0 && a2 > 0);
  if ((mm = /^2Y (\d+)\.5 (Üst|Alt)$/.exec(k))) return mm[2] === 'Üst' ? h2 + a2 > +mm[1] : h2 + a2 <= +mm[1];
  if (k === 'Çok gol İY') return ih + ia > h2 + a2;
  if (k === 'Çok gol 2Y') return h2 + a2 > ih + ia;
  if (k === 'Çok gol Eşit') return h2 + a2 === ih + ia;
  return undefined;
}
const parcalar = (market) => String(market || '').split(' & ').map((x) => x.trim()).filter(Boolean);
// Bu seçenek otomatik değerlendirilebilir mi? (Diğer / elle yazılan pazar değilse)
export function otomatikMi(market) {
  const ps = parcalar(market);
  return !!ps.length && ps.every((k) => tekPazar(k, 1, 1, 0, 0) !== undefined);
}
function birlestir(market, h, a, ih, ia) {
  const ps = parcalar(market);
  if (!ps.length) return undefined;
  const rs = ps.map((k) => tekPazar(k, h, a, ih, ia));
  if (rs.some((r) => r === false)) return false;
  if (rs.some((r) => r === undefined)) return undefined;
  return true;
}
// Maç bittiyse kesin sonuç: 'won' | 'lost' | ''
export function evalMarket(market, m) {
  if (!m || m.status !== 'finished') return '';
  const fs = skor2(m.score);
  if (!fs) return '';
  const hs = skor2(m.htScore);
  const r = birlestir(market, fs[0], fs[1], hs ? hs[0] : null, hs ? hs[1] : null);
  return r === undefined ? '' : r ? 'won' : 'lost';
}
// Maç devam ederken: sonuç artık değişemiyorsa 'won' / 'lost', değişebiliyorsa ''.
// Goller sadece artar: olası bütün maç sonlarını dener, hepsi aynı sonucu veriyorsa kesinleşmiştir.
const EK = 9; // denenecek en fazla ek gol (bundan fazlası sonucu değiştirmez)
const canliCache = new Map();
export function evalCanli(market, m) {
  if (!m) return '';
  if (m.status === 'finished') return evalMarket(market, m);
  if (m.status !== 'live') return '';
  const ilkYari = !skor2(m.htScore) && (m.afStatus === '1H' || (!m.afStatus && (parseInt(m.minute, 10) || 0) > 0 && (parseInt(m.minute, 10) || 0) <= 45));
  const key = `${market}|${m.score}|${m.htScore || ''}|${ilkYari ? 1 : 0}`;
  if (canliCache.has(key)) return canliCache.get(key);
  const r = canliHesapla(market, m, ilkYari);
  if (canliCache.size > 2000) canliCache.clear();
  canliCache.set(key, r);
  return r;
}
function canliHesapla(market, m, ilkYari) {
  if (!otomatikMi(market)) return '';
  const cs = skor2(m.score) || [0, 0];
  const hs = skor2(m.htScore);
  // ilk yarı skoru aralığı
  let ihL; let ihH; let iaL; let iaH;
  if (hs) { [ihL, iaL] = hs; ihH = ihL; iaH = iaL; }
  else if (ilkYari) { ihL = cs[0]; ihH = cs[0] + 6; iaL = cs[1]; iaH = cs[1] + 6; }
  else { ihL = 0; ihH = cs[0]; iaL = 0; iaH = cs[1]; }
  let won = false; let lost = false;
  for (let ih = ihL; ih <= ihH; ih++) for (let ia = iaL; ia <= iaH; ia++) {
    const h0 = Math.max(cs[0], ih); const a0 = Math.max(cs[1], ia);
    for (let h = h0; h <= h0 + EK; h++) for (let a = a0; a <= a0 + EK; a++) {
      const r = birlestir(market, h, a, ih, ia);
      if (r === undefined) return '';
      if (r) won = true; else lost = true;
      if (won && lost) return '';
    }
  }
  return won ? 'won' : lost ? 'lost' : '';
}
// Ekranda gösterilecek sonuç: bitmiş maçta kayıtlı sonuç, canlıda kesinleşmişse erken sonuç
export function gorunenSonuc(m) {
  if (!m) return '';
  if (m.status === 'finished') return m.result || '';
  if (m.status === 'live') return m.result || evalCanli(m.market, m);
  return '';
}
// Kupondaki satırın tahmini ve sonucu (satırın kendi tahmini yoksa maçın tahmini)
export const satirPazar = (p) => (p && (p.market || (p.m && p.m.market))) || '';
export function satirSonuc(p) {
  if (!p) return '';
  if (p.result) return p.result;                    // admin elle işaretlediyse
  const m = p.m;
  if (!m) return '';
  const k = satirPazar(p);
  if (!p.market || p.market === m.market) return gorunenSonuc(m);   // maçın kendi tahmini: kayıtlı sonucu kullan
  if (m.status === 'finished') return evalMarket(k, m) || '';
  return evalCanli(k, m);
}
// Tribün satırının sonucu: yönetici işaretlediyse o (kullanıcı değiştiremez), yoksa elle yazılan maçta kayıtlı sonuç, bülten maçında skordan
export function tribunSatirSonuc(tc, p, i, byId) {
  const y = tc && tc.yonetici ? tc.yonetici[String(i)] : '';
  if (y === 'won' || y === 'lost') return y;
  if (p.custom) return p.result || '';
  return evalCanli(p.market, byId[p.matchId]);
}
export function tribuneStatus(tc, matchList) {
  const byId = {};
  (matchList || []).forEach((m) => { byId[m.id] = m; });
  const res = (tc.picks || []).map((p, i) => tribunSatirSonuc(tc, p, i, byId));
  if (!res.length) return 'pending';
  if (res.some((r) => r === 'lost')) return 'lost';
  if (res.every((r) => r === 'won')) return 'won';
  return 'pending';
}
// Kullanıcının kendi eklediği maç varsa kupon doğrulanmamıştır (sıralamaya girmez)
export const isVerified = (tc) => !(tc.picks || []).some((p) => p.custom && !p.otoSonuc);  // otomatik sonuçlanan maçlar doğrulanmış sayılır
export function weekStart() {
  const d = new Date();
  const day = (d.getDay() + 6) % 7; // Pazartesi = 0
  d.setDate(d.getDate() - day);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
export const normName = (n) => String(n || '').trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');
export const teamId = (n) => normName(n).replace(/[^a-z0-9çğıöşü]+/g, '-').replace(/^-|-$/g, '').slice(0, 80) || 'takim';

/* ---------- Rozetler ---------- */
export function badgesOf(me, stats) {
  const list = [];
  if (!me || me.guest) return list;
  list.push(['🎉', 'Hoş geldin']);
  if ((stats?.tribune || 0) >= 1) list.push(['🧾', 'İlk kupon']);
  if ((stats?.tribuneWon || 0) >= 5) list.push(['🏆', 'Kupon ustası']);
  if ((Number(me.maxStreak) || 0) >= 7) list.push(['🔥', '7 gün seri']);
  if ((Number(me.maxStreak) || 0) >= 30) list.push(['💎', '30 gün seri']);
  if (me.createdAt && Date.now() - me.createdAt > 30 * 864e5) list.push(['🤝', 'Sadık üye']);
  if (me.shareRewarded) list.push(['📣', 'Paylaşımcı']);
  if (Number(me.vipUntil || 0) > Date.now()) list.push(['👑', 'VIP']);
  return list;
}

/* ---------- Başarı istatistiği ---------- */
export function successStats(list, days) {
  const from = days ? dayOff(-days) : '';
  const F = (list || []).filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost') && (!from || String(m.date) >= from));
  const won = F.filter((m) => m.result === 'won').length;
  return { total: F.length, won, lost: F.length - won, pct: F.length ? Math.round((won / F.length) * 100) : 0 };
}

/* ---------- Maç başlangıç zamanı ---------- */
export function matchStart(m) {
  const [y, mo, d] = String(m.date || '').split('-').map(Number);
  const [h, mi] = String(m.time || '').split(':').map(Number);
  if (!y || !mo || !d) return 0;
  return new Date(y, mo - 1, d, h || 0, mi || 0).getTime();
}

/* ---------- Skor ligi ---------- */
export const monthKey = (t) => { const x = t ? new Date(t) : new Date(); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}`; };
export const canPredictScore = (m) => m && m.status === 'upcoming' && matchStart(m) > Date.now();
// Skor Ligi puanı: tam skor 3, doğru sonuç 1. ⭐ Büyük maçta 2 kat (6 / 2).
export function scorePoints(p, m) {
  if (!m || m.status !== 'finished' || !/^\s*\d+\s*-\s*\d+\s*$/.test(String(m.score || ''))) return null;
  const [h, a] = String(m.score).split('-').map((x) => parseInt(x, 10));
  const kat = m.buyuk ? 2 : 1;
  if (+p.h === h && +p.a === a) return 3 * kat;
  return Math.sign(+p.h - +p.a) === Math.sign(h - a) ? kat : 0;
}
// Skoru tam bildi mi?
export function skorTam(p, m) {
  if (!m || m.status !== 'finished' || !/^\s*\d+\s*-\s*\d+\s*$/.test(String(m.score || ''))) return false;
  const [h, a] = String(m.score).split('-').map((x) => parseInt(x, 10));
  return +p.h === h && +p.a === a;
}

/* ---------- Avatarlar ---------- */
export const AVATARS = ['⚽', '🦁', '🦅', '🐺', '🐯', '🐻', '🦊', '🐉', '🔥', '⚡', '👑', '🎯', '🚀', '💎', '🏆', '😎'];

/* ---------- Favori takım ---------- */
export const isFav = (m, fav) => !!fav && (normName(m.home) === normName(fav) || normName(m.away) === normName(fav));

/* ---------- Anahtar kuralları ---------- */
export const AD_MAX = 3;                 // AdMob güvenliği: 24 saatte en fazla 3 ödüllü reklam
export const AD_WINDOW = 24 * 3600 * 1000;
export const BONUS_GAP = 12 * 3600 * 1000;
export const adLimit = (cfg) => Math.max(0, Math.min(AD_MAX, Number(cfg?.ads?.limit) || AD_MAX));

/* ---------- Yetki yardımcıları ---------- */
export const canModerate = (me) => !!me && ['owner', 'admin', 'mod'].includes(me.role);

/* ---------- 🛡️ Yetki izinleri: sahip her admin / moderatör için tek tek açar-kapatır ---------- */
// [anahtar, başlık, açıklama]. Firestore kuralları da aynı anahtarlarla korur.
export const IZINLER = [
  ['mac', '⚽ Maç ekle, düzenle, sil', 'Tahmin yazar, banko ve büyük maç seçer, maçı gizler'],
  ['vip', '🔒 Kilitli ve VIP içerik', 'Anahtarla açılan ya da VIP maç ve kupon yayınlar'],
  ['sonuc', '✅ Sonuç gir', 'Skor ve Tuttu / Tutmadı girer, maçı bitirir'],
  ['kupon', '🧾 Kupon yap', 'Kupon oluşturur, düzenler, siler'],
  ['bildirim', '🔔 Bildirim gönder', 'Herkese bildirim atar'],
  ['yorum', '💬 Yorum yönetimi', 'Herkesin yorumunu siler'],
  ['tribun', '🎟️ Tribün yönetimi', 'Kupon siler, Tuttu / Tutmadı işaretler, takipçilere özel kuponları görür'],
  ['sustur', '🔇 Kullanıcı susturma', 'Yorum ve paylaşımı geçici kapatır'],
  ['sikayet', '📨 Şikayet ve mesajlar', 'Bildirilenleri ve öneri-şikayet kutusunu görür, cevaplar'],
  ['uyeler', '👥 Üye listesi', 'Üyeleri ve e-posta adreslerini görür'],
  ['anahtar', '🔑 Anahtar ve VIP verme', 'Üyelere anahtar ya da VIP verir'],
  ['istatistik', '📊 İstatistik', 'Aktif kişi sayısı, görüntülenme ve genel sayıları görür'],
  ['motor', '⚙️ Otomatik veri motoru', 'Bülten, robot, canlı skor ve otomatik bildirimler onun telefonunda da çalışır'],
];
// Yeni yetki verildiğinde başlangıç izinleri (sahip sonra istediğini değiştirir)
export const IZIN_VARSAYILAN = {
  admin: { mac: true, vip: false, sonuc: true, kupon: true, bildirim: false, yorum: true, tribun: true, sustur: true, sikayet: true, uyeler: true, anahtar: false, istatistik: true, motor: false },
  mod: { mac: false, vip: false, sonuc: false, kupon: false, bildirim: false, yorum: true, tribun: true, sustur: true, sikayet: true, uyeler: false, anahtar: false, istatistik: false, motor: false },
};
export function izinVar(me, k) {
  if (!me) return false;
  if (me.role === 'owner') return true;
  const d = IZIN_VARSAYILAN[me.role];
  if (!d) return false;
  const m = me.izinler || {};
  return Object.prototype.hasOwnProperty.call(m, k) ? !!m[k] : !!d[k];
}
export const isOwnerMe = (me) => !!me && me.role === 'owner';
export const ROLE_LABEL = { owner: 'Sahip', admin: 'Admin', mod: 'Moderatör' };

/* ---------- Otomatik canlı dakika ---------- */
// Admin dakika girdiyse oradan sayar, girmediyse maç saatinden hesaplar (devre arası dahil)
export function canliDakika(m, now = Date.now()) {
  if (!m || m.status !== 'live') return '';
  if (m.afStatus === 'HT') return 'İY';
  if (m.afStatus === 'P') return 'Penaltılar';
  const man = parseInt(m.minute, 10);
  let d;
  if (man > 0 && Number(m.minuteAt) > 0 && now - m.minuteAt < 3 * 3600e3) {
    d = man + Math.floor((now - m.minuteAt) / 60000);
    if (man <= 45 && d > 45) return "45+'";
  } else {
    const st = matchStart(m);
    if (!st) return man > 0 ? `${man}'` : 'Canlı';
    const e = Math.floor((now - st) / 60000) + 1;
    if (e < 1) return "1'";
    if (e <= 45) d = e;
    else if (e <= 48) return "45+'";
    else if (e <= 63) return 'İY';
    else d = e - 18;
  }
  if (d > 90) return "90+'";
  return `${Math.max(1, d)}'`;
}

// Ben sekmesinin altında görünen sürüm (app.json ile aynı tut)
export const APP_SURUM = '2.1.4';
// "2.0.10" > "2.0.7" gibi sürüm karşılaştırma: a < b ise negatif
export function surumKarsilastir(a, b) {
  const x = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0);
  const y = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; }
  return 0;
}
