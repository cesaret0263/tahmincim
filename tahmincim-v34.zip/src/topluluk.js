// Topluluk: takımlar, beğeni, yorum, Tribün kuponları, şikayetler
import { useEffect, useState } from 'react';
import { collection, doc, onSnapshot, setDoc, deleteDoc, addDoc, updateDoc, query, where, orderBy, limit, getDocs, getCountFromServer } from 'firebase/firestore';
import { db, configured } from './firebase';
import { normName, teamId } from './tema';

function useQuery(build, deps, enabled = true) {
  const [state, setState] = useState({ list: [], loading: true });
  useEffect(() => {
    if (!configured || !enabled) return;
    let q;
    try { q = build(); } catch (e) { setState({ list: [], loading: false }); return; }
    return onSnapshot(q, (snap) => setState({ list: snap.docs.map((d) => ({ id: d.id, ...d.data() })), loading: false }),
      () => setState((x) => ({ ...x, loading: false, error: true })));
  }, deps); // eslint-disable-line
  return state;
}

/* ---------- Takım kütüphanesi ---------- */
export const useTeams = () => useQuery(() => collection(db, 'teams'), []);
export const saveTeam = (name, logo) =>
  setDoc(doc(db, 'teams', teamId(name)), { name: String(name).trim(), logo: logo || '', key: normName(name), updatedAt: Date.now() });
export const removeTeam = (id) => deleteDoc(doc(db, 'teams', id));
export function findTeam(teams, name) {
  const k = normName(name);
  return (teams || []).find((t) => t.key === k || normName(t.name) === k) || null;
}
export function suggestTeams(teams, text) {
  const k = normName(text);
  if (k.length < 2) return [];
  return (teams || []).filter((t) => (t.key || normName(t.name)).includes(k) && (t.key || normName(t.name)) !== k).slice(0, 5);
}
// Maçlardaki logoları kütüphaneye aktarır (bir kerelik)
export async function importTeamsFromMatches(matches, teams) {
  let n = 0;
  for (const m of matches) {
    for (const [name, logo] of [[m.home, m.homeLogo], [m.away, m.awayLogo]]) {
      if (!name || !logo) continue;
      const t = findTeam(teams, name);
      if (t && t.logo) continue;
      try { await saveTeam(name, logo); n++; teams = [...teams, { name, logo, key: normName(name) }]; } catch (e) {}
    }
  }
  return n;
}

/* ---------- Beğeni (👍 / 👎) ---------- */
export function useVotes(target) {
  const st = useQuery(() => query(collection(db, 'votes'), where('target', '==', target)), [target], !!target);
  return st.list;
}
export async function castVote(target, uid, v, current, thread) {
  const ref = doc(db, 'votes', `${target}__${uid}`);
  if (current === v) return deleteDoc(ref);
  return setDoc(ref, { target, uid, v, at: Date.now(), ...(thread ? { thread } : {}) });
}
// Bir sayfadaki tüm yorum beğenileri tek sorguda
export function useThreadVotes(thread) {
  const st = useQuery(() => query(collection(db, 'votes'), where('thread', '==', thread)), [thread], !!thread);
  return st.list;
}

/* ---------- Yorumlar ---------- */
const KOTU = ['amk', 'aq', 'orospu', 'piç', 'pic', 'siktir', 'sik', 'yarrak', 'göt', 'got', 'ibne', 'pezevenk', 'kahpe', 'oç', 'amına', 'amina', 'sikerim', 'gavat'];
export function cleanText(t) {
  let out = String(t || '');
  KOTU.forEach((w) => {
    const re = new RegExp(`(^|[^a-zçğıöşü])(${w})(?=$|[^a-zçğıöşü])`, 'gi');
    out = out.replace(re, (m0, p1, p2) => p1 + '*'.repeat(p2.length));
  });
  return out;
}
export function useComments(target) {
  const st = useQuery(() => query(collection(db, 'comments'), where('target', '==', target)), [target], !!target);
  return { ...st, list: [...st.list].sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)) };
}
// Birden çok gönderinin yorum sayısı (tek dinleyici, en fazla 30 hedef)
export function useCommentCounts(targets) {
  const key = (targets || []).slice(0, 30).join(',');
  const st = useQuery(() => query(collection(db, 'comments'), where('target', 'in', key.split(','))), [key], !!key);
  const out = {};
  st.list.forEach((c) => { out[c.target] = (out[c.target] || 0) + 1; });
  return out;
}
// Admin yorumları en üstte sabit
export function pinAdmin(list) {
  return [...list.filter((c) => c.admin), ...list.filter((c) => !c.admin)];
}
export const addComment = (target, uid, name, text, admin, avatar, mod) =>
  addDoc(collection(db, 'comments'), { target, uid, name: String(name || 'Üye').slice(0, 40), text: cleanText(text).slice(0, 500), createdAt: Date.now(), admin: !!admin, mod: !!mod && !admin, avatar: avatar || '' });
export const deleteComment = (id) => deleteDoc(doc(db, 'comments', id));
export const useRecentComments = (enabled) =>
  useQuery(() => query(collection(db, 'comments'), orderBy('createdAt', 'desc'), limit(100)), [], enabled);

/* ---------- Tribün ---------- */
// Herkese açık kuponlar 'tribune', takipçilere özel kuponlar 'tribuneOzel' koleksiyonunda (kurallar sadece izinlilere okutur)
const kol = (tc) => (tc && tc.gorunur === 'takipci' ? 'tribuneOzel' : 'tribune');
export const useTribune = () =>
  useQuery(() => query(collection(db, 'tribune'), orderBy('createdAt', 'desc'), limit(300)), []);
// Takipçilere özel kuponlardan benim görebildiklerim: kendi kuponlarım + izin verilenler (yönetici hepsini görür)
export function useTribuneOzel(uid, mod) {
  const hepsi = useQuery(() => query(collection(db, 'tribuneOzel'), orderBy('createdAt', 'desc'), limit(300)), [], !!uid && !!mod);
  const izinli = useQuery(() => query(collection(db, 'tribuneOzel'), where('izinli', 'array-contains', uid), limit(200)), [uid], !!uid && !mod);
  const benim = useQuery(() => query(collection(db, 'tribuneOzel'), where('uid', '==', uid), limit(200)), [uid], !!uid && !mod);
  if (!uid) return { list: [], loading: false };
  if (mod) return hepsi;
  const map = {};
  [...izinli.list, ...benim.list].forEach((x) => { map[x.id] = x; });
  return { list: Object.values(map), loading: izinli.loading && benim.loading };
}
export const addTribune = (uid, name, picks, admin, avatar, gizli) =>
  addDoc(collection(db, gizli ? 'tribuneOzel' : 'tribune'), {
    uid, name: String(name || 'Üye').slice(0, 40), picks, createdAt: Date.now(), admin: !!admin, avatar: avatar || '',
    ...(gizli ? { gorunur: 'takipci', izinli: (gizli.izinli || []).slice(0, 2000) } : {}),
  });
export const deleteTribune = (id, tc) => deleteDoc(doc(db, kol(tc), id));
// Kullanıcı kendi eklediği maçın sonucunu işaretler
export const setTribunePicks = (id, picks, tc) => updateDoc(doc(db, kol(tc), id), { picks });
// Yönetici/moderatör işareti: kullanıcının kendi değiştiremeyeceği ayrı alanda durur (kurallar korur)
export const setTribuneYonetici = (id, yonetici, tc) => updateDoc(doc(db, kol(tc), id), { yonetici });

/* ---------- 👥 Takip ---------- */
// takip/{takipEden}__{takipEdilen}: { from, to, fromName, fromAvatar, toName, toAvatar, createdAt }
export const useTakipciler = (uid) => useQuery(() => query(collection(db, 'takip'), where('to', '==', uid), limit(1000)), [uid], !!uid);
export const useTakipEdilen = (uid) => useQuery(() => query(collection(db, 'takip'), where('from', '==', uid), limit(1000)), [uid], !!uid);
export const takipEt = (me, p) => setDoc(doc(db, 'takip', `${me.id}__${p.uid}`), {
  from: me.id, to: p.uid, fromName: String(me.name || 'Üye').slice(0, 40), fromAvatar: me.avatar || '',
  toName: String(p.name || 'Üye').slice(0, 40), toAvatar: p.avatar || '', createdAt: Date.now(), bildir: true,
  ...(p.oto ? { oto: true } : {}),
});
export const takibiBirak = (fromUid, toUid) => deleteDoc(doc(db, 'takip', `${fromUid}__${toUid}`));
// 🔔 Takip ettiğim kişi kupon paylaşınca bildirim gelsin mi (sadece takip eden değiştirir)
export const takipBildir = (fromUid, toUid, v) => updateDoc(doc(db, 'takip', `${fromUid}__${toUid}`), { bildir: !!v });
// Benim takip ettiklerim: { [uid]: takipKaydı }. Bütün kartlar tek bir dinleyiciyi paylaşır.
const tk = { uid: null, unsub: null, data: null, subs: new Set() };
export function useTakiplerim(uid) {
  const [, tetik] = useState(0);
  useEffect(() => {
    if (!configured || !uid) return undefined;
    if (tk.uid !== uid) {
      if (tk.unsub) tk.unsub();
      tk.uid = uid; tk.data = null;
      tk.unsub = onSnapshot(query(collection(db, 'takip'), where('from', '==', uid), limit(1000)), (snap) => {
        const d = {};
        snap.docs.forEach((x) => { const v = x.data(); if (v.to) d[v.to] = v; });
        tk.data = d;
        tk.subs.forEach((f) => f((n) => n + 1));
      }, () => {});
    }
    tk.subs.add(tetik);
    return () => { tk.subs.delete(tetik); };
  }, [uid]);
  return uid && tk.uid === uid ? tk.data : null;
}
// 👑 Uygulama sahibinin herkese açık kartı (otomatik takip için): app/sahip { uid, name, avatar }
export function useSahip() {
  const [v, setV] = useState(null);
  useEffect(() => {
    if (!configured) return undefined;
    return onSnapshot(doc(db, 'app', 'sahip'), (s) => setV(s.exists() ? s.data() : null), () => {});
  }, []);
  return v;
}
export const sahipYayinla = (me) => setDoc(doc(db, 'app', 'sahip'), { uid: me.id, name: String(me.name || 'Tahmincim').slice(0, 40), avatar: me.avatar || '', updatedAt: Date.now() });
// Takipçilere özel kupon paylaşırken o anki takipçilerin listesi
export async function takipciIdleri(uid) {
  const snap = await getDocs(query(collection(db, 'takip'), where('to', '==', uid), limit(2000)));
  return snap.docs.map((d) => d.data().from).filter(Boolean);
}
// Belirli maçın bütün skor tahminleri (⭐ Büyük Maç)
export const useMacSkorlari = (matchId) => useQuery(() => query(collection(db, 'scores'), where('matchId', '==', matchId), limit(1000)), [matchId], !!matchId);

/* ---------- Şikayetler ---------- */
export const addReport = (kind, refId, text, reporter) =>
  addDoc(collection(db, 'reports'), { kind, refId, text: String(text || '').slice(0, 300), reporter, createdAt: Date.now() });
export const useReports = (enabled) =>
  useQuery(() => query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(100)), [], enabled);
export const deleteReport = (id) => deleteDoc(doc(db, 'reports', id));
export async function deleteReportsFor(refId) {
  const snap = await getDocs(query(collection(db, 'reports'), where('refId', '==', refId)));
  for (const d of snap.docs) { try { await deleteDoc(d.ref); } catch (e) {} }
}

/* ---------- Skor ligi ---------- */
export const useScores = (month, enabled = true) =>
  useQuery(() => query(collection(db, 'scores'), where('month', '==', month), limit(3000)), [month], enabled);
export const saveScore = (m, uid, name, avatar, admin, h, a) =>
  setDoc(doc(db, 'scores', m.id + '__' + uid), {
    matchId: m.id, uid, name: String(name || 'Üye').slice(0, 40), avatar: avatar || '', admin: !!admin,
    h: Math.max(0, Math.min(20, +h || 0)), a: Math.max(0, Math.min(20, +a || 0)),
    month: String(m.date || '').slice(0, 7), createdAt: Date.now(),
  });

/* ---------- Admin istatistik ---------- */
export async function countCollection(name) {
  try { const snap = await getCountFromServer(collection(db, name)); return snap.data().count; } catch (e) { return null; }
}

/* ---------- Görüntülenme (kim kaç kez görmüş: tekil kişi) ---------- */
let viewerId = null;
const seen = new Set();
async function getViewer(uid) {
  if (uid) return uid;
  if (viewerId) return viewerId;
  try {
    const AS = require('@react-native-async-storage/async-storage').default;
    viewerId = await AS.getItem('tahmincim_cihaz');
    if (!viewerId) { viewerId = 'g_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10); await AS.setItem('tahmincim_cihaz', viewerId); }
  } catch (e) { viewerId = 'g_' + Math.random().toString(36).slice(2, 12); }
  return viewerId;
}
export async function markView(target, uid) {
  if (!configured || !target) return;
  try {
    const v = await getViewer(uid);
    const key = target + '__' + v;
    if (seen.has(key)) return;
    seen.add(key);
    await setDoc(doc(db, 'views', key), { target, uid: v, at: Date.now() });
  } catch (e) {}
}
export async function countViews(target) {
  try { const snap = await getCountFromServer(query(collection(db, 'views'), where('target', '==', target))); return snap.data().count; } catch (e) { return null; }
}
// Admin listesinde görüntülenme sayıları
export function useViewCounts(targets) {
  const [map, setMap] = useState({});
  const key = targets.join('|');
  useEffect(() => {
    let on = true;
    (async () => {
      for (const t of targets) {
        const n = await countViews(t);
        if (!on) return;
        setMap((m) => ({ ...m, [t]: n }));
      }
    })();
    return () => { on = false; };
  }, [key]); // eslint-disable-line
  return map;
}

/* ---------- Öneri & şikayet ---------- */
export const addFeedback = (f) => addDoc(collection(db, 'feedback'), {
  kind: f.kind, text: String(f.text || '').slice(0, 1000), contact: String(f.contact || '').slice(0, 100),
  uid: f.uid || '', name: String(f.name || '').slice(0, 40), createdAt: Date.now(),
});
export const useFeedback = (enabled) => useQuery(() => query(collection(db, 'feedback'), orderBy('createdAt', 'desc'), limit(200)), [], enabled);
export const deleteFeedback = (id) => deleteDoc(doc(db, 'feedback', id));
export const replyFeedback = (id, text, by) => updateDoc(doc(db, 'feedback', id), { reply: String(text).slice(0, 1000), repliedAt: Date.now(), replyBy: String(by || '').slice(0, 40) });
export const useMyFeedback = (uid) => {
  const st = useQuery(() => query(collection(db, 'feedback'), where('uid', '==', uid)), [uid], !!uid);
  return { ...st, list: [...st.list].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)) };
};

// Bir kullanıcının skor tahminleri (profil için)
export const useUserScores = (uid) => useQuery(() => query(collection(db, 'scores'), where('uid', '==', uid), limit(300)), [uid], !!uid);

/* ---------- Maç anketi ---------- */
export const usePollVotes = (matchId) => useQuery(() => query(collection(db, 'pollVotes'), where('matchId', '==', matchId)), [matchId], !!matchId);
export const votePoll = (matchId, uid, opt) => setDoc(doc(db, 'pollVotes', `${matchId}__${uid}`), { matchId, uid, opt, at: Date.now() });

/* ---------- Maç takibi (gol bildirimi) ---------- */
export const followMatch = (matchId, uid, on) => (on
  ? setDoc(doc(db, 'follows', `${matchId}__${uid}`), { matchId, uid, at: Date.now() })
  : deleteDoc(doc(db, 'follows', `${matchId}__${uid}`)));
export const useMyFollows = (uid) => useQuery(() => query(collection(db, 'follows'), where('uid', '==', uid)), [uid], !!uid);
