import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, Modal, Image, Share } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, CONF, predText, scoreOf, isImg, oddOf, dayLabel } from '../tema';
import { Btn, Crest, Field, Icon, Sheet, s, useTheme, Tik } from '../parcalar';
import { register, login, resetPassword, authError } from '../veri';
import { VoteBar, Yorumlar } from './Etkilesim';

/* ---------------- Paylaş ---------------- */
export function paylas(text) {
  Share.share({ message: text }).catch(() => {});
}
export function macPaylasMetni(m, appName) {
  const odd = oddOf(m.odd);
  return `⚽ ${m.home} – ${m.away}\n📅 ${dayLabel(m.date, false)} ${m.time || ''}${m.league ? `\n🏆 ${m.league}` : ''}\n🎯 Tahmin: ${predText(m)}${odd ? ` (Oran ${odd.toFixed(2)})` : ''}\n\n${appName || 'Tahmincim'} uygulamasında daha fazlası 📲\n18+ · Tahminler garanti değildir.`;
}

/* ---------------- Tahmin detayı ---------------- */
export function Detay({ m, onClose, appName, me, isAdmin, onNeedAuth }) {
  const t = useTheme();
  if (!m) return null;
  const p = [+m.p1 || 0, +m.px || 0, +m.p2 || 0];
  const ps = p[0] + p[1] + p[2];
  const why = String(m.reasons || '').split('\n').map((x) => x.trim()).filter(Boolean);
  const live = m.status === 'live';
  const fin = m.status === 'finished';
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ flexDirection: 'row' }}>
          <Crest name={m.home} logo={m.homeLogo} size={40} />
          <View style={{ marginLeft: -8 }}><Crest name={m.away} logo={m.awayLogo} size={40} /></View>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: '700', fontSize: 17, color: C.ink }}>{m.home} – {m.away}</Text>
          <Text style={[s.sub, live && { color: C.red, fontWeight: '700' }]}>
            {live ? `Canlı ${m.minute || ''}' · ${scoreOf(m).join('-')}` : fin ? `${dayLabel(m.date)} · Bitti · ${scoreOf(m).join('-')}` : `${dayLabel(m.date)} · ${m.time}`}
            {m.league ? ` · ${m.league}` : ''}
          </Text>
        </View>
      </View>

      <View style={{ backgroundColor: C.hero, borderRadius: 24, padding: 20, marginTop: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={{ color: t.acc, fontWeight: '800', fontSize: 12, letterSpacing: 1 }}>TAHMİNİMİZ</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Text style={{ color: '#C5CCD6', fontWeight: '700', fontSize: 12 }}>{appName || 'Tahmincim'}</Text>
            <Tik size={14} />
          </View>
        </View>
        <Text style={{ color: '#fff', fontSize: 25, fontWeight: '800', marginTop: 10, marginBottom: 6, lineHeight: 30 }}>{predText(m)}</Text>
        {m.market && m.market !== 'Diğer' ? <Text style={{ color: '#A3ADBA' }}>Bahis dilinde: {m.market}{oddOf(m.odd) ? `  ·  Oran ${oddOf(m.odd).toFixed(2)}` : ''}</Text> : null}
        <View style={{ flexDirection: 'row', gap: 6, marginTop: 14 }}>
          {CONF.map((c, i) => {
            const on = (m.conf || 3) === i + 1;
            return (
              <View key={c} style={{ flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: 'center', backgroundColor: on ? t.acc : C.dark2 }}>
                <Text style={{ color: on ? t.onAcc : '#A3ADBA', fontWeight: on ? '700' : '600' }}>{c}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {live && m.liveText ? (
        <View style={{ backgroundColor: C.redBg, borderRadius: 16, padding: 14, marginTop: 12 }}>
          <Text style={{ color: C.red, fontWeight: '700' }}>● Canlı: {m.liveText}</Text>
        </View>
      ) : null}
      {fin && m.result ? (
        <View style={{ backgroundColor: m.result === 'won' ? C.okBg : C.redBg, borderRadius: 16, padding: 14, marginTop: 12 }}>
          <Text style={{ color: m.result === 'won' ? C.okTx : C.red, fontWeight: '700' }}>{m.result === 'won' ? '✓ Bu tahmin tuttu' : '✕ Bu tahmin tutmadı'}</Text>
        </View>
      ) : null}

      {ps > 0 ? (
        <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 18, marginTop: 12 }}>
          <Text style={s.h3}>Kim kazanır?</Text>
          <View style={{ flexDirection: 'row', height: 14, borderRadius: 8, overflow: 'hidden', gap: 3, marginBottom: 10 }}>
            <View style={{ flex: p[0], backgroundColor: C.hero }} />
            <View style={{ flex: p[1], backgroundColor: '#B8BDB3' }} />
            <View style={{ flex: p[2], backgroundColor: C.key }} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 6 }}>
            <Text style={{ flex: 1, color: C.ink }}><Text style={{ fontWeight: '800' }}>%{p[0]}</Text> {m.home}</Text>
            <Text style={{ color: C.mut }}><Text style={{ fontWeight: '800' }}>%{p[1]}</Text> Ber.</Text>
            <Text style={{ flex: 1, textAlign: 'right', color: C.ink }}><Text style={{ fontWeight: '800' }}>%{p[2]}</Text> {m.away}</Text>
          </View>
        </View>
      ) : null}

      {why.length ? (
        <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 18, marginTop: 12 }}>
          <Text style={[s.h3, { marginBottom: 4 }]}>Neden böyle düşünüyoruz?</Text>
          {why.map((w, i) => (
            <View key={i} style={{ flexDirection: 'row', gap: 12, marginTop: 10, alignItems: 'flex-start' }}>
              <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: C.okBg, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="checkmark" size={15} color={C.okTx} />
              </View>
              <Text style={{ flex: 1, fontSize: 15, lineHeight: 21, color: C.ink }}>{w}</Text>
            </View>
          ))}
        </View>
      ) : null}

      <VoteBar target={'m_' + m.id} me={me} onNeedAuth={onNeedAuth} />
      <Yorumlar target={'m_' + m.id} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} />
      <Text style={s.note}>Tahminler bilgi amaçlıdır, garanti değildir · 18+</Text>
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
        <Btn kind="out" icon="share-social-outline" title="Paylaş" onPress={() => paylas(macPaylasMetni(m, appName))} style={{ flex: 1 }} />
        <Btn kind="ink" title="Tamam" onPress={onClose} style={{ flex: 1 }} />
      </View>
    </Sheet>
  );
}

/* ---------------- Kilitli maç / kupon ---------------- */
export function Kilit({ m, me, cfg, onClose, onAd, onKey, onBuy }) {
  const t = useTheme();
  if (!m) return null;
  const cost = Math.max(1, Number(m.cost) || 1);
  const A = cfg.ads;
  const left = (Number(A.limit) || 0) - (me?.adCount || 0);
  const vip = m.access === 'vip';
  const keys = me?.keys || 0;
  const enough = keys >= cost;
  const need = cost - keys;
  const title = m.isCoupon ? m.label : `${m.home} – ${m.away}`;
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ alignItems: 'center', gap: 8 }}>
        <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: vip ? C.vipBg : C.lockBg, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={vip ? 'diamond-outline' : 'lock-closed-outline'} size={32} color={vip ? C.vipTx : '#C25400'} />
        </View>
        <Text style={[s.h1, { textAlign: 'center' }]}>{title}</Text>
        {m.date ? <Text style={{ color: C.mut, fontWeight: '600' }}>📅 {dayLabel(m.date)}{m.time && !m.isCoupon ? ` · ${m.time}` : ''}</Text> : null}
        <View style={{ backgroundColor: C.bg, borderRadius: 16, padding: 14, alignSelf: 'stretch', alignItems: 'center', marginTop: 6 }}>
          <Text style={{ fontSize: 16, color: C.ink, textAlign: 'center' }}>
            {vip ? 'VIP ' : ''}{m.isCoupon ? 'Kuponu' : 'Tahmini'} görmek için <Text style={{ fontWeight: '800' }}>{cost} anahtar</Text> gerekli
          </Text>
          <Text style={{ color: enough ? C.okTx : C.lockTx, fontWeight: '700', marginTop: 4 }}>
            Elinde {keys} anahtar var{enough ? ' ✓' : ` · ${need} anahtar daha lazım`}
          </Text>
        </View>
      </View>
      {enough ? (
        <Pressable onPress={onKey} accessibilityRole="button"
          style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: t.acc, borderRadius: 20, padding: 16, minHeight: 72, marginTop: 16 }}>
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="key-outline" size={20} color={C.onKey} />
          </View>
          <Text style={{ color: t.onAcc, fontWeight: '800', fontSize: 17, flex: 1 }}>{cost} anahtar kullan ve aç</Text>
        </Pressable>
      ) : null}
      {A.on && left > 0 ? (
        <Pressable onPress={onAd} accessibilityRole="button"
          style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: enough ? C.card : t.acc, borderWidth: enough ? 2 : 0, borderColor: C.line, borderRadius: 20, padding: 16, minHeight: 72, marginTop: 12 }}>
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: enough ? C.hero : t.onAcc, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="play" size={18} color={enough ? '#fff' : t.acc} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: enough ? C.ink : t.onAcc, fontWeight: '800', fontSize: 17 }}>Reklam izle, +{Number(A.reward) || 1} anahtar</Text>
            <Text style={{ color: enough ? C.mut : t.onAcc, fontSize: 14 }}>Ücretsiz · bugün {left} hakkın var</Text>
          </View>
        </Pressable>
      ) : null}
      {cfg.store?.on ? (
        <Pressable onPress={onBuy} accessibilityRole="button"
          style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: C.card, borderWidth: 2, borderColor: C.line, borderRadius: 20, padding: 14, minHeight: 72, marginTop: 12 }}>
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.vipBg, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="cart-outline" size={20} color={C.vipTx} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.ink, fontWeight: '800', fontSize: 17 }}>Anahtar satın al</Text>
            <Text style={{ color: C.mut, fontSize: 14 }}>Beklemeden hemen aç</Text>
          </View>
        </Pressable>
      ) : null}
      <Btn kind="ghost" title="Vazgeç" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Mağaza ---------------- */
export function Magaza({ cfg, me, onClose, onSoon }) {
  const t = useTheme();
  const packs = (cfg.store?.packs || []).filter((p) => Number(p.keys) > 0);
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>Anahtar satın al</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 14 }]}>Elinde {me?.keys || 0} anahtar var. Kilitli tahmin ve kuponları beklemeden aç.</Text>
      {packs.map((p, i) => (
        <Pressable key={i} onPress={onSoon} accessibilityRole="button"
          style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: i === 1 ? C.selBg : C.card, borderWidth: 2, borderColor: i === 1 ? t.acc : C.line, borderRadius: 20, padding: 16, marginBottom: 10 }}>
          <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontWeight: '800', fontSize: 18, color: C.onKey }}>{p.keys}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '800', fontSize: 17, color: C.ink }}>{p.keys} anahtar</Text>
            {i === 1 ? <Text style={{ color: C.okTx, fontWeight: '700', fontSize: 13 }}>En çok tercih edilen</Text> : null}
          </View>
          <Text style={{ fontWeight: '800', fontSize: 17, color: C.ink }}>{p.price}</Text>
        </Pressable>
      ))}
      <Text style={s.note}>Ödemeler Google Play üzerinden güvenle alınır.</Text>
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Sorumlu oyun ---------------- */
export function SorumluOyun({ onClose }) {
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>Sorumlu oyun</Text>
      <View style={{ backgroundColor: C.bg, borderRadius: 20, padding: 16, marginVertical: 14, gap: 8 }}>
        <Text style={s.sub}>• Tahminler istatistik ve yoruma dayanır, hiçbir sonuç garanti değildir.</Text>
        <Text style={s.sub}>• Kaybetmeyi göze alamayacağın parayla oynama.</Text>
        <Text style={s.sub}>• 18 yaşından küçükler bahis oynayamaz.</Text>
        <Text style={s.sub}>• Kontrolü kaybettiğini düşünüyorsan Yeşilay Danışmanlık Merkezi'nden (YEDAM) ücretsiz destek alabilirsin: 115</Text>
      </View>
      <Btn kind="ink" title="Anladım" onPress={onClose} />
    </Sheet>
  );
}

/* ---------------- Kayıt ol / Giriş yap ---------------- */
export function Hesap({ startMode = 'register', reason, startKeys, onClose, onDone }) {
  const t = useTheme();
  const [mode, setMode] = useState(startMode); // 'register' | 'login' | 'reset'
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');

  const go = async () => {
    setErr('');
    setInfo('');
    if (mode === 'register' && name.trim().length < 2) return setErr('Adını yaz.');
    if (!email.includes('@')) return setErr('E-posta adresi geçersiz.');
    if (mode !== 'reset' && pass.length < 6) return setErr('Şifre en az 6 karakter olmalı.');
    setBusy(true);
    try {
      if (mode === 'register') {
        await register(name, email, pass, startKeys);
        onDone && onDone('Hoş geldin! Hesabın oluşturuldu.', 'register');
        onClose();
      } else if (mode === 'login') {
        await login(email, pass);
        onDone && onDone('Giriş yapıldı');
        onClose();
      } else {
        await resetPassword(email);
        setInfo('Şifre sıfırlama bağlantısı e-postana gönderildi. Gereksiz (spam) klasörünü de kontrol et.');
      }
    } catch (e) {
      setErr(authError(e));
    }
    setBusy(false);
  };

  const Tab = ({ k, label }) => (
    <Pressable onPress={() => { setMode(k); setErr(''); setInfo(''); }} accessibilityRole="tab" accessibilityState={{ selected: mode === k }}
      style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: mode === k ? C.card : 'transparent' }}>
      <Text style={{ fontWeight: mode === k ? '700' : '600', color: mode === k ? C.ink : C.mut }}>{label}</Text>
    </Pressable>
  );

  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>{mode === 'register' ? 'Ücretsiz kayıt ol' : mode === 'login' ? 'Giriş yap' : 'Şifremi unuttum'}</Text>
      {reason && mode !== 'reset' ? <Text style={[s.sub, { marginTop: 4 }]}>{reason}</Text> : null}
      {mode !== 'reset' ? (
        <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginVertical: 16 }}>
          <Tab k="register" label="Kayıt ol" />
          <Tab k="login" label="Giriş yap" />
        </View>
      ) : <View style={{ height: 14 }} />}
      {mode === 'register' ? <Field label="Adın" value={name} onChangeText={setName} autoComplete="name" placeholder="Örn. Ahmet" /> : null}
      <Field label="E-posta" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" placeholder="ornek@gmail.com" />
      {mode !== 'reset' ? <Field label="Şifre (en az 6 karakter)" value={pass} onChangeText={setPass} secureTextEntry autoComplete={mode === 'register' ? 'new-password' : 'password'} /> : null}
      {err ? <Text style={{ color: C.red, fontWeight: '600', marginBottom: 10 }}>{err}</Text> : null}
      {info ? <Text style={{ color: C.okTx, fontWeight: '600', marginBottom: 10 }}>{info}</Text> : null}
      <Btn kind={mode === 'register' ? 'acc' : 'ink'} loading={busy} onPress={go}
        title={mode === 'register' ? 'Kayıt ol' : mode === 'login' ? 'Giriş yap' : 'Bağlantı gönder'} />
      {mode === 'register' && Number(startKeys) > 0 ? (
        <Text style={[s.note, { marginTop: 10 }]}>Kayıt olana {Number(startKeys)} anahtar hediye 🔑</Text>
      ) : null}
      {mode === 'login' ? <Btn kind="ghost" title="Şifremi unuttum" onPress={() => { setMode('reset'); setErr(''); }} style={{ marginTop: 4 }} /> : null}
      {mode === 'reset' ? <Btn kind="ghost" title="Girişe dön" onPress={() => { setMode('login'); setInfo(''); setErr(''); }} style={{ marginTop: 4 }} /> : null}
    </Sheet>
  );
}

/* ---------------- Hoş geldin ---------------- */
export function Hosgeldin({ cfg, me, onClose, onShare, onRate }) {
  const gift = Number(cfg.startKeys) || 0;
  const shareN = Number(cfg.rewards?.share) || 0;
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ alignItems: 'center', gap: 10 }}>
        <Text style={{ fontSize: 56 }}>🎉</Text>
        <Text style={[s.h1, { textAlign: 'center' }]}>Hoş geldin{me?.name ? `, ${me.name}` : ''}!</Text>
        {gift > 0 ? (
          <View style={{ backgroundColor: C.lockBg, borderRadius: 16, padding: 14, alignSelf: 'stretch', alignItems: 'center' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.lockTx }}>🎁 {gift} anahtar hesabına eklendi</Text>
            <Text style={{ color: C.lockTx, marginTop: 2 }}>Kilitli tahminleri açmak için kullanabilirsin</Text>
          </View>
        ) : null}
      </View>
      {shareN > 0 && !me?.shareRewarded ? (
        <Btn style={{ marginTop: 16 }} icon="share-social-outline" title={`Arkadaşına öner, +${shareN} anahtar kazan`} onPress={onShare} />
      ) : null}
      <Btn style={{ marginTop: 10 }} kind="out" icon="star-outline" title="Bizi değerlendir ⭐" onPress={onRate} />
      <Btn kind="ghost" title="Başla" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Günlük bonus ---------------- */
export function GunlukBonus({ info, onClose }) {
  const t = useTheme();
  if (!info) return null;
  const day = ((info.streak - 1) % 7) + 1;
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ alignItems: 'center', gap: 8 }}>
        <Text style={{ fontSize: 52 }}>🎁</Text>
        <Text style={[s.h1, { textAlign: 'center' }]}>Günlük bonus: +{info.gift} anahtar</Text>
        <Text style={[s.sub, { textAlign: 'center' }]}>🔥 {info.streak} gündür üst üste geliyorsun!</Text>
      </View>
      <View style={{ flexDirection: 'row', gap: 6, marginTop: 16 }}>
        {[1, 2, 3, 4, 5, 6, 7].map((d) => {
          const done = d <= day;
          return (
            <View key={d} style={{ flex: 1, alignItems: 'center', gap: 4 }}>
              <View style={{ width: '100%', aspectRatio: 1, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: done ? t.acc : C.bg, borderWidth: d === 7 ? 2 : 0, borderColor: C.key }}>
                <Text style={{ fontSize: d === 7 ? 18 : 14, fontWeight: '800', color: done ? t.onAcc : C.mut }}>{d === 7 ? '🎁' : done ? '✓' : d}</Text>
              </View>
              <Text style={{ fontSize: 11, color: C.mut }}>{d}. gün</Text>
            </View>
          );
        })}
      </View>
      <Text style={[s.note, { marginTop: 12 }]}>7. günde ekstra bonus var. Bir gün kaçırırsan seri baştan başlar.</Text>
      <Btn title="Harika!" onPress={onClose} style={{ marginTop: 12 }} />
    </Sheet>
  );
}

/* ---------------- Tanıtım ---------------- */
export function Tanitim({ visible, cfg, onDone }) {
  const t = useTheme();
  const ins = useSafeAreaInsets();
  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onDone} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: C.hero, paddingHorizontal: 24, paddingTop: ins.top + 40, paddingBottom: ins.bottom + 28, gap: 28 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Logo cfg={cfg} />
          <Text style={{ color: '#fff', fontSize: 22, fontWeight: '800' }}>{cfg.name}</Text>
        </View>
        <Text style={{ color: '#fff', fontSize: 40, fontWeight: '800', lineHeight: 44, letterSpacing: -1 }}>
          Maçı seç.{'\n'}Tahmini gör.{'\n'}<Text style={{ color: t.acc }}>Bu kadar.</Text>
        </Text>
        <View style={{ gap: 12 }}>
          {['Bir maça dokun', 'Tahmini sade bir dille oku', 'Kilitliyse kısa bir reklamla aç'].map((x, i) => (
            <View key={x} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#1E242D', alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: t.acc, fontWeight: '800' }}>{i + 1}</Text>
              </View>
              <Text style={{ color: '#fff', fontSize: 16 }}>{x}</Text>
            </View>
          ))}
        </View>
        <View style={{ marginTop: 'auto', gap: 12, alignItems: 'center' }}>
          <Btn title="Hadi başlayalım" onPress={onDone} style={{ alignSelf: 'stretch' }} />
          <Text style={{ color: '#A3ADBA', fontSize: 12.5, textAlign: 'center' }}>18 yaş ve üzeri içindir · Tahminler bilgi amaçlıdır, garanti değildir</Text>
        </View>
      </View>
    </Modal>
  );
}

export function Logo({ cfg, size = 40 }) {
  const t = useTheme();
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.32, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      {isImg(cfg.logo) ? <Image source={{ uri: cfg.logo }} style={{ width: size, height: size }} resizeMode="cover" /> : <Icon name="checkmark" size={size * 0.55} color={t.onAcc} />}
    </View>
  );
}

/* ---------------- Yedek reklam ekranı (AdMob yoksa) ---------------- */
export function SayacReklam({ visible, cfg, seconds = 15, onDone, onCancel }) {
  const t = useTheme();
  const ins = useSafeAreaInsets();
  const [left, setLeft] = useState(seconds);
  const timer = useRef(null);
  useEffect(() => {
    if (!visible) return;
    setLeft(seconds);
    timer.current = setInterval(() => setLeft((x) => (x <= 1 ? (clearInterval(timer.current), 0) : x - 1)), 1000);
    return () => clearInterval(timer.current);
  }, [visible, seconds]);
  const img = cfg.ads.bannerImg;
  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onCancel} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: '#0b0d11', paddingTop: ins.top + 10, paddingBottom: ins.bottom + 20, paddingHorizontal: 18 }}>
        <View style={{ height: 5, backgroundColor: '#222', borderRadius: 3, overflow: 'hidden' }}>
          <View style={{ height: 5, width: `${((seconds - left) / seconds) * 100}%`, backgroundColor: t.acc }} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
          <Text style={{ color: '#aaa' }}>Reklam · {left} sn</Text>
          <Pressable onPress={onCancel} accessibilityLabel="Kapat" style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: '#1d2128', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="close" color="#ccc" />
          </Pressable>
        </View>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          {isImg(img) ? (
            <Image source={{ uri: img }} style={{ width: '100%', aspectRatio: 1.2, borderRadius: 18 }} resizeMode="contain" />
          ) : (
            <View style={{ width: '100%', aspectRatio: 1, borderRadius: 24, borderWidth: 2, borderStyle: 'dashed', borderColor: '#3a404a', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
              <Text style={{ color: '#8b94a1', textAlign: 'center', lineHeight: 22 }}>Reklam alanı{'\n'}(Test sürümü: gerçek reklam APK'da görünür)</Text>
            </View>
          )}
        </View>
        <Btn title={left > 0 ? 'İzlemeye devam et…' : 'Ödülü al'} disabled={left > 0} onPress={onDone} />
      </View>
    </Modal>
  );
}
