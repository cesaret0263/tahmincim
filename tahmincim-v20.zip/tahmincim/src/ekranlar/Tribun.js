import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { C, canModerate, isOwnerMe, TRIBUNE_MARKETS, evalMarket, tribuneStatus, weekStart, today, dayOff, byTime, dayLabel, isVerified } from '../tema';
import { Btn, Crest, Icon, Sheet, s, useTheme, useToast, Tik, Avatar, Field, Seg } from '../parcalar';
import { addTribune, deleteTribune, addReport, useVotes, castVote, setTribunePicks, cleanText } from '../topluluk';
import { updateUser, addKeys, modLog } from '../veri';
import { onceLabel } from './Etkilesim';
import SkorLigi from './SkorLigi';
import { profilAc } from '../profil';
import { gorevAyarla } from '../gorev';
import { Gir, Iskelet, konfeti } from '../efekt';

const ST = {
  pending: { t: 'Bekliyor', bg: () => C.track, fg: () => C.mut },
  won: { t: 'Tuttu ✓', bg: () => C.okBg, fg: () => C.okTx },
  lost: { t: 'Tutmadı ✕', bg: () => C.redBg, fg: () => C.red },
};

function Begeni({ target, me, onNeedAuth }) {
  const t = useTheme();
  const votes = useVotes(target);
  const n = votes.filter((v) => v.v === 1).length;
  const mine = me && me.id ? votes.find((v) => v.uid === me.id && v.v === 1) : null;
  const press = () => {
    if (!me || me.guest || !me.id) return onNeedAuth();
    castVote(target, me.id, 1, mine ? 1 : undefined).catch(() => {});
  };
  return (
    <Pressable onPress={press} accessibilityRole="button" accessibilityLabel="Beğen" style={{ flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 40, paddingHorizontal: 12, borderRadius: 12, backgroundColor: mine ? C.okBg : C.bg }}>
      <Icon name={mine ? 'heart' : 'heart-outline'} size={18} color={mine ? C.red : C.mut} />
      <Text style={{ fontWeight: '700', color: C.ink }}>{n}</Text>
    </Pressable>
  );
}

function TribunKart({ tc, matchList, me, isAdmin, onNeedAuth, onShareCard }) {
  const toast = useToast();
  const byId = {};
  matchList.forEach((m) => { byId[m.id] = m; });
  const st = tribuneStatus(tc, matchList);
  const S = ST[st];
  const own = me && me.id === tc.uid;
  const save = (i, result) => {
    const picks = (tc.picks || []).map((x, j) => (j === i ? { ...x, result } : x));
    setTribunePicks(tc.id, picks).then(() => toast('Sonuç kaydedildi')).catch(() => toast('Kaydedilemedi'));
  };
  const more = () => {
    const b = [{ text: 'Vazgeç', style: 'cancel' }];
    if (onShareCard) b.push({ text: 'Resim olarak paylaş', onPress: () => onShareCard({
      title: 'Tribün kuponu', by: tc.name, sub: dayLabel(today(), false), status: st,
      lines: (tc.picks || []).map((p) => { const m = p.custom ? null : byId[p.matchId]; return { t: m ? `${m.home} – ${m.away}` : p.custom ? `${p.home} – ${p.away}` : 'Maç', p: p.market, r: p.custom ? p.result || '' : evalMarket(p.market, m) }; }),
      text: `🧾 ${tc.name} kuponu\n` + (tc.picks || []).map((p) => { const m = byId[p.matchId]; return `⚽ ${m ? `${m.home} – ${m.away}` : `${p.home || ''} – ${p.away || ''}`} · ${p.market}`; }).join('\n'),
    }) });
    if (own || canModerate(me)) b.push({ text: 'Sil', style: 'destructive', onPress: () => deleteTribune(tc.id).then(() => { toast('Kupon silindi'); if (!own) modLog(me, 'Tribün kuponu sildi', tc.name); }).catch(() => toast('Silinemedi')) });
    if (!own && me && !me.guest) b.push({ text: 'Şikayet et', onPress: () => addReport('tribune', tc.id, `${tc.name} kuponu`, me.id).then(() => toast('Teşekkürler, inceleyeceğiz')).catch(() => {}) });
    Alert.alert('Kupon', `${tc.name} · ${(tc.picks || []).length} maç`, b);
  };
  return (
    <View style={{ backgroundColor: C.card, borderRadius: 20, padding: 14, marginBottom: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 }}>
        <Pressable onPress={() => profilAc({ uid: tc.uid, name: tc.name, avatar: tc.avatar })} accessibilityLabel="Profili aç">
          <Avatar emoji={tc.avatar} name={tc.name} size={36} />
        </Pressable>
        <Pressable style={{ flex: 1 }} onPress={() => profilAc({ uid: tc.uid, name: tc.name, avatar: tc.avatar })}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink, flexShrink: 1 }}>{tc.name}{own ? ' (sen)' : ''}</Text>
            {tc.admin ? <Tik size={15} label="Admin" /> : null}
          </View>
          <Text style={{ color: C.mut, fontSize: 12 }}>{onceLabel(tc.createdAt)}</Text>
        </Pressable>
        <View style={{ backgroundColor: S.bg(), borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
          <Text style={{ color: S.fg(), fontWeight: '800', fontSize: 12 }}>{S.t}</Text>
        </View>
      </View>
      {!isVerified(tc) ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.bg, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6, marginBottom: 6 }}>
          <Icon name="alert-circle-outline" size={15} color={C.mut} />
          <Text style={{ color: C.mut, fontSize: 12.5, flex: 1 }}>Kullanıcının eklediği maç var · sonuç doğrulanmamış, sıralamaya girmez</Text>
        </View>
      ) : null}
      {(tc.picks || []).map((p, i) => {
        const m = p.custom ? null : byId[p.matchId];
        const r = p.custom ? p.result || '' : evalMarket(p.market, m);
        const canMark = p.custom && own && !p.result;
        const mark = () => Alert.alert(`${p.home} – ${p.away}`, `Tahminin: ${p.market}. Sonuç ne oldu?`, [
          { text: 'Vazgeç', style: 'cancel' },
          { text: 'Tutmadı ✕', onPress: () => save(i, 'lost') },
          { text: 'Tuttu ✓', onPress: () => save(i, 'won') },
        ]);
        return (
          <Pressable key={i} disabled={!canMark} onPress={mark} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6, borderTopWidth: i ? 1 : 0, borderTopColor: C.line }}>
            {m ? <Crest name={m.home} logo={m.homeLogo} size={22} /> : p.custom ? <Icon name="person-circle-outline" size={22} color={C.mut} /> : null}
            <View style={{ flex: 1 }}>
              <Text numberOfLines={1} style={{ color: C.ink, fontSize: 14 }}>{m ? `${m.home} – ${m.away}` : p.custom ? `${p.home} – ${p.away}` : 'Silinmiş maç'}</Text>
              {p.custom ? <Text style={{ color: C.mut, fontSize: 11.5 }}>{dayLabel(p.date)}{p.time ? ` · ${p.time}` : ''}{canMark ? ' · sonucu işaretlemek için dokun' : ''}</Text> : null}
            </View>
            <Text style={{ fontWeight: '800', color: C.ink, fontSize: 14 }}>{p.market}</Text>
            {r ? <Icon name={r === 'won' ? 'checkmark-circle' : 'close-circle'} size={20} color={r === 'won' ? C.okTx : C.red} /> : <View style={{ width: 20 }} />}
          </Pressable>
        );
      })}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
        <Begeni target={'t_' + tc.id} me={me} onNeedAuth={onNeedAuth} />
        <Pressable onPress={more} accessibilityLabel="Seçenekler" style={{ width: 44, height: 40, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="ellipsis-horizontal" color={C.mut} />
        </Pressable>
      </View>
    </View>
  );
}

function KuponYap({ matches, me, isAdmin, mineToday, onClose }) {
  const t = useTheme();
  const toast = useToast();
  const [picks, setPicks] = useState({});
  const [open, setOpen] = useState(null);
  const [busy, setBusy] = useState(false);
  const [custom, setCustom] = useState([]);
  const [form, setForm] = useState(null);
  const list = matches.list.filter((m) => m.status === 'upcoming' && m.date >= today() && !m.hidden)
    .sort((a, b) => String(a.date + a.time).localeCompare(b.date + b.time)).slice(0, 40);
  const n = Object.keys(picks).length + custom.length;
  const addCustom = () => {
    const h = cleanText(form.home.trim()).slice(0, 30);
    const a = cleanText(form.away.trim()).slice(0, 30);
    if (h.length < 2 || a.length < 2) return toast('İki takımın adını da yaz');
    if (!form.market) return toast('Tahminini seç');
    if (n >= 10) return toast('Kupona en fazla 10 maç eklenebilir');
    setCustom((x) => [...x, { key: Date.now(), home: h, away: a, date: form.date, time: /^\d{1,2}:\d{2}$/.test(form.time) ? form.time : '', market: form.market }]);
    setForm(null);
  };
  const send = async () => {
    if (!n) return toast('En az bir maç seç');
    if (!isAdmin && mineToday >= 3) return toast('Günde en fazla 3 kupon paylaşabilirsin');
    if (me.muted) return toast('Bir süre paylaşım yapman kısıtlandı');
    setBusy(true);
    try {
      const all = [
        ...Object.entries(picks).map(([matchId, market]) => ({ matchId, market })),
        ...custom.map((c) => ({ custom: true, home: c.home, away: c.away, date: c.date, time: c.time, market: c.market, result: '' })),
      ];
      await addTribune(me.id, me.name || 'Üye', all, isAdmin, me.avatar);
      konfeti();
      gorevAyarla('paylas', 1);
      toast('Kuponun Tribün\'de! 🎉');
      onClose();
    } catch (e) { toast('Paylaşılamadı'); }
    setBusy(false);
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>Kuponunu yap</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Maça dokun, tahminini seç. Listede yoksa en alttan kendin ekle. En fazla 10 maç.</Text>
      {!list.length ? <Text style={[s.sub, { marginBottom: 8 }]}>Uygulamada şu an açık maç yok. Aşağıdan kendi maçını ekleyebilirsin.</Text> : list.map((m, idx) => {
        const sel = picks[m.id];
        const head = idx === 0 || list[idx - 1].date !== m.date;
        return (
          <View key={m.id}>
            {head ? <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13, marginTop: idx ? 8 : 0, marginBottom: 6 }}>📅 {dayLabel(m.date)}</Text> : null}
            <Pressable onPress={() => setOpen(open === m.id ? null : m.id)} accessibilityRole="button"
              style={{ borderWidth: sel ? 2 : 1.5, borderColor: sel ? t.acc : C.border, borderRadius: 14, padding: 12, marginBottom: 8, backgroundColor: sel ? C.selBg : C.card }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Text style={{ color: C.mut, fontWeight: '700', width: 44 }}>{m.time}</Text>
                <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{m.home} – {m.away}</Text>
                {sel ? <Text style={{ fontWeight: '800', color: C.okTx }}>{sel}</Text> : <Icon name="chevron-down" size={18} color={C.mut} />}
              </View>
              {open === m.id ? (
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 }}>
                  {TRIBUNE_MARKETS.map((k) => {
                    const on = sel === k;
                    return (
                      <Pressable key={k} onPress={() => { setPicks((x) => { const y = { ...x }; if (on) delete y[m.id]; else if (Object.keys(y).length + custom.length < 10 || y[m.id]) y[m.id] = k; return y; }); setOpen(null); }}
                        style={{ paddingHorizontal: 12, minHeight: 40, justifyContent: 'center', borderRadius: 10, borderWidth: 1.5, borderColor: on ? C.ink : C.border, backgroundColor: on ? t.acc : C.card }}>
                        <Text style={{ fontWeight: '700', color: on ? t.onAcc : C.ink }}>{k}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              ) : null}
            </Pressable>
          </View>
        );
      })}
      {custom.length ? (
        <View style={{ marginTop: 4 }}>
          <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13, marginBottom: 6 }}>✍️ Senin eklediğin maçlar</Text>
          {custom.map((c) => (
            <View key={c.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 2, borderColor: t.acc, backgroundColor: C.selBg, borderRadius: 14, padding: 12, marginBottom: 8 }}>
              <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{c.home} – {c.away}</Text>
              <Text style={{ fontWeight: '800', color: C.okTx }}>{c.market}</Text>
              <Pressable onPress={() => setCustom((x) => x.filter((y) => y.key !== c.key))} accessibilityLabel="Kaldır" hitSlop={8}>
                <Icon name="close" size={18} color={C.mut} />
              </Pressable>
            </View>
          ))}
        </View>
      ) : null}
      {form ? (
        <View style={{ borderWidth: 1.5, borderColor: C.border, borderRadius: 16, padding: 12, marginTop: 4, backgroundColor: C.card }}>
          <Text style={[s.h3, { marginBottom: 8 }]}>Listede olmayan maç</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label="Ev sahibi" value={form.home} onChangeText={(v) => setForm((f) => ({ ...f, home: v }))} maxLength={30} placeholder="Örn. Arsenal" />
            <Field style={{ flex: 1 }} label="Deplasman" value={form.away} onChangeText={(v) => setForm((f) => ({ ...f, away: v }))} maxLength={30} placeholder="Örn. Chelsea" />
          </View>
          <Seg value={form.date} onChange={(v) => setForm((f) => ({ ...f, date: v }))} options={[[today(), 'Bugün'], [dayOff(1), 'Yarın'], [dayOff(2), 'Öbür gün']]} />
          <Field label="Saat (isteğe bağlı)" value={form.time} onChangeText={(v) => setForm((f) => ({ ...f, time: v }))} maxLength={5} placeholder="21:45" keyboardType="numbers-and-punctuation" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
            {TRIBUNE_MARKETS.map((k) => (
              <Pressable key={k} onPress={() => setForm((f) => ({ ...f, market: k }))}
                style={{ paddingHorizontal: 12, minHeight: 40, justifyContent: 'center', borderRadius: 10, borderWidth: 1.5, borderColor: form.market === k ? C.ink : C.border, backgroundColor: form.market === k ? t.acc : C.card }}>
                <Text style={{ fontWeight: '700', color: form.market === k ? t.onAcc : C.ink }}>{k}</Text>
              </Pressable>
            ))}
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn small kind="out" title="Vazgeç" onPress={() => setForm(null)} style={{ flex: 1 }} />
            <Btn small kind="ink" title="Kupona ekle" onPress={addCustom} style={{ flex: 2 }} />
          </View>
          <Text style={[s.note, { marginTop: 8 }]}>Kendi eklediğin maçların sonucu doğrulanmaz, kupon haftalık sıralamaya girmez.</Text>
        </View>
      ) : (
        <Btn small kind="out" icon="add" title="Listede olmayan maçı ekle" onPress={() => n >= 10 ? toast('Kupona en fazla 10 maç eklenebilir') : setForm({ home: '', away: '', date: today(), time: '', market: '' })} style={{ marginTop: 4 }} />
      )}
      <Btn style={{ marginTop: 8 }} title={n ? `${n} maçlık kuponu paylaş` : 'Maç seç'} disabled={!n} loading={busy} onPress={send} />
    </Sheet>
  );
}

function Siralama({ tribune, matches, isAdmin }) {
  const toast = useToast();
  const ws = weekStart();
  const agg = {};
  tribune.list.filter((x) => (x.createdAt || 0) >= ws && isVerified(x)).forEach((x) => {
    const st = tribuneStatus(x, matches.list);
    const a = (agg[x.uid] = agg[x.uid] || { uid: x.uid, name: x.name, avatar: x.avatar, admin: x.admin, won: 0, lost: 0, total: 0 });
    a.total++;
    if (st === 'won') a.won++;
    if (st === 'lost') a.lost++;
  });
  const rows = Object.values(agg).filter((r) => !r.admin).sort((a, b) => b.won - a.won || (b.won / Math.max(1, b.won + b.lost)) - (a.won / Math.max(1, a.won + a.lost)) || b.total - a.total).slice(0, 20);
  const reward = (r) => Alert.alert(`${r.name} ödüllendirilsin mi?`, 'Seçtiğin ödül hesabına eklenecek.', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: '+10 anahtar', onPress: () => addKeys(r.uid, 10).then(() => toast('+10 anahtar verildi 🎁')).catch(() => toast('Verilemedi')) },
    { text: '7 gün VIP', onPress: () => updateUser(r.uid, { vipUntil: Date.now() + 7 * 864e5 }).then(() => toast('7 gün VIP verildi 👑')).catch(() => toast('Verilemedi')) },
  ]);
  const medal = ['🥇', '🥈', '🥉'];
  return (
    <View>
      <Text style={[s.sub, { marginBottom: 10 }]}>Bu haftanın en çok kupon tutturanları. Sıralama her pazartesi sıfırlanır.</Text>
      {!rows.length ? <View style={s.empty}><Text style={s.sub}>Bu hafta henüz sonuçlanan kupon yok.</Text></View> : rows.map((r, i) => (
        <Pressable key={r.uid} onPress={() => profilAc({ uid: r.uid, name: r.name, avatar: r.avatar })} style={[s.row, { minHeight: 56 }]}>
          <Text style={{ width: 30, fontSize: 18, fontWeight: '800', color: C.ink, textAlign: 'center' }}>{medal[i] || i + 1}</Text>
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{r.name}</Text>
            <Text style={{ color: C.mut, fontSize: 13 }}>{r.total} kupon · %{Math.round((r.won / Math.max(1, r.won + r.lost)) * 100)} başarı</Text>
          </View>
          <Text style={{ fontWeight: '800', color: C.okTx, fontSize: 16 }}>{r.won} ✓</Text>
          {isAdmin ? <Pressable onPress={() => reward(r)} accessibilityLabel="Ödül ver" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 20 }}>🎁</Text></Pressable> : null}
        </Pressable>
      ))}
    </View>
  );
}

export default function Tribun({ tribune, matches, me, isAdmin, onNeedAuth, start: startTab, onShareCard, shareTick }) {
  const t = useTheme();
  const [tab, setTab] = useState(startTab || 'feed');
  const [make, setMake] = useState(false);
  const toast = useToast();
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const mineToday = me && me.id ? tribune.list.filter((x) => x.uid === me.id && (x.createdAt || 0) >= dayStart.getTime()).length : 0;
  const start = () => {
    if (!me || me.guest || !me.id) return onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    setMake(true);
  };
  useEffect(() => { if (shareTick) { setTab('feed'); start(); } }, [shareTick]); // eslint-disable-line
  return (
    <View>
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 12 }}>
        {[['feed', 'Kuponlar'], ['rank', '🏆 Haftalık'], ['score', '⚽ Skor Ligi']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }}
            style={{ flex: 1, minHeight: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: tab === k ? C.ink : C.border, backgroundColor: tab === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: tab === k ? '800' : '600', color: tab === k ? C.ink : C.mut, fontSize: 13.5 }} numberOfLines={1}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {tab === 'feed' ? <Btn icon="add" title="Kendi kuponunu paylaş" onPress={start} style={{ marginBottom: 12 }} /> : null}
      {tab === 'score' ? <SkorLigi matches={matches} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} /> : tab === 'rank' ? <Siralama tribune={tribune} matches={matches} isAdmin={isOwnerMe(me)} /> : tribune.loading ? (
        <Iskelet n={3} h={110} />
      ) : !tribune.list.length ? (
        <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Tribün boş</Text><Text style={[s.sub, { textAlign: 'center' }]}>İlk kuponu sen paylaş!</Text></View>
      ) : tribune.list.slice(0, 60).map((tc, i) => <Gir key={tc.id} i={i}><TribunKart tc={tc} matchList={matches.list} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} onShareCard={onShareCard} /></Gir>)}
      {make ? <KuponYap matches={matches} me={me} isAdmin={isAdmin} mineToday={mineToday} onClose={() => setMake(false)} /> : null}
    </View>
  );
}
