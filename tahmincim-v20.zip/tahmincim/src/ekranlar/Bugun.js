import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Pressable, Image, Linking, ScrollView } from 'react-native';
import { C, dayOff, byTime, isImg, successStats, isFav, canPredictScore } from '../tema';
import { Icon, s, useTheme, Btn } from '../parcalar';
import { MacSatiri, BankoKart } from './MacKart';
import { Gir, Iskelet } from '../efekt';
import Hikayeler from './Hikayeler';

const DAYS = ['Dün', 'Bugün', 'Yarın'];

export default function Bugun({ cfg, matches, coupons, me, onMatch, isAdmin, onAdminMenu, onAddMatch, onScoreLeague, onStats, onNav, onCark, onGorev }) {
  const t = useTheme();
  const lp = (m) => (isAdmin && onAdminMenu ? () => onAdminMenu(m) : undefined);
  const [day, setDay] = useState(0);
  // Açılışta bugün maç yoksa, maç olan güne (yarın) kendiliğinden geç
  const picked = useRef(false);
  useEffect(() => {
    if (picked.current || matches.loading) return;
    picked.current = true;
    const has = (n) => matches.list.some((m) => m.date === dayOff(n) && !m.hidden);
    if (!has(0) && has(1)) setDay(1);
  }, [matches.loading]); // eslint-disable-line
  const d = dayOff(day);
  const fav = me && me.favTeam;
  const [lig, setLig] = useState('');
  const [bolum, setBolum] = useState('biz'); // 'biz' = bizim tahminler, 'robot' = robot tahminleri
  const bizden = (m) => !m.robot && !(m.auto && m.draft);
  const uygun = (m) => (bolum === 'robot' ? !!m.robot : bizden(m));
  const robotKupon = (coupons?.list || []).filter((c) => c.robot && c.date === dayOff(0)).length;
  const dayAll = matches.list.filter((m) => m.date === d && !m.hidden && uygun(m));
  const ligs = [...new Set(dayAll.map((m) => String(m.league || '').trim()).filter(Boolean))];
  // Sıra: canlı → başlayacaklar (favori takım önce, sonra saat) → bitenler en altta
  const rank = (m) => (m.status === 'live' ? 0 : m.status === 'finished' ? 2 : 1);
  const list = dayAll.filter((m) => !lig || String(m.league || '').trim() === lig).sort(byTime)
    .sort((a, b) => rank(a) - rank(b) || (isFav(b, fav) ? 1 : 0) - (isFav(a, fav) ? 1 : 0));
  const son5 = matches.list.filter((m) => uygun(m) && m.status === 'finished' && (m.result === 'won' || m.result === 'lost'))
    .sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5).reverse();
  const st = successStats(matches.list.filter(uygun), 30);
  const scoreOpen = matches.list.filter((m) => !m.hidden && canPredictScore(m)).length;
  const banko = bolum === 'biz' ? list.find((m) => m.banko) : null;
  const rest = list.filter((m) => m !== banko);
  const M = cfg.message;
  const A = cfg.ads;
  const msgStyle = M.type === 'warn' ? { bg: C.lockBg, fg: C.lockTx } : M.type === 'camp' ? { bg: t.acc, fg: t.onAcc } : { bg: C.hero, fg: '#fff' };

  return (
    <View>
      {onNav ? <Hikayeler matches={matches} coupons={coupons} onMatch={onMatch} onNav={onNav} onCark={onCark} onGorev={onGorev} me={me} /> : null}
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 10 }}>
        {[['biz', '🎯 Tahminlerimiz'], ['robot', '🤖 Robot Tahminleri']].map(([k, l]) => {
          const on = bolum === k;
          return (
            <Pressable key={k} onPress={() => { setBolum(k); setLig(''); }} accessibilityRole="tab" accessibilityState={{ selected: on }}
              style={{ flex: 1, minHeight: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.hero : C.card, borderWidth: 1.5, borderColor: on ? C.hero : C.border }}>
              <Text style={{ fontWeight: '800', color: on ? '#fff' : C.ink, fontSize: 14.5 }}>{l}</Text>
            </Pressable>
          );
        })}
      </View>
      {bolum === 'robot' ? (
        <View style={{ backgroundColor: C.card, borderRadius: 16, padding: 12, marginBottom: 10, gap: 8 }}>
          <Text style={{ color: C.mut, fontSize: 13 }}>Robot, takımların son maçlarına ve istatistiklerine bakarak tahmini kendisi üretir. Sonuçlar maç bitince otomatik işlenir.</Text>
          {robotKupon ? (
            <Pressable onPress={() => onNav && onNav('coupons', 'robot')} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.hero, borderRadius: 12, padding: 12 }}>
              <Text style={{ fontSize: 18 }}>🎟️</Text>
              <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Robotun bugünkü kuponları ({robotKupon})</Text>
              <Icon name="chevron-forward" color="#fff" size={18} />
            </Pressable>
          ) : null}
        </View>
      ) : null}
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4 }}>
        {DAYS.map((label, i) => {
          const on = day === i - 1;
          return (
            <Pressable key={label} onPress={() => { setDay(i - 1); setLig(''); }} accessibilityRole="tab" accessibilityState={{ selected: on }}
              style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.card : 'transparent' }}>
              <Text style={{ fontWeight: on ? '700' : '600', color: on ? C.ink : C.mut, fontSize: 15 }}>{label}</Text>
            </Pressable>
          );
        })}
      </View>

      {M.on && M.text ? (
        <View style={{ flexDirection: 'row', gap: 10, backgroundColor: msgStyle.bg, borderRadius: 16, padding: 14, marginTop: 14, alignItems: 'flex-start' }}>
          <Icon name="information-circle-outline" color={msgStyle.fg} size={20} />
          <Text style={{ color: msgStyle.fg, fontWeight: '600', flex: 1, lineHeight: 20 }}>{M.text}</Text>
        </View>
      ) : null}

      {banko ? <BankoKart m={banko} me={me} onPress={() => onMatch(banko)} onLongPress={lp(banko)} /> : null}

      {st.total >= 3 || scoreOpen ? (
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 14 }}>
          {st.total >= 3 ? (
            <Pressable onPress={onStats} accessibilityRole="button" style={{ flex: 1, backgroundColor: C.okBg, borderRadius: 18, padding: 14 }}>
              <Text style={{ color: C.okTx, fontSize: 24, fontWeight: '800' }}>%{st.pct}</Text>
              <Text style={{ color: C.okTx, fontWeight: '600', fontSize: 13 }}>Son 30 gün başarı{`\n`}{st.won}/{st.total} tahmin tuttu</Text>
              {son5.length >= 3 ? (
                <View style={{ flexDirection: 'row', gap: 3, marginTop: 6 }}>
                  {son5.map((m) => (
                    <View key={m.id} style={{ width: 18, height: 18, borderRadius: 5, backgroundColor: m.result === 'won' ? C.okTx : C.red, alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ color: '#fff', fontSize: 11, fontWeight: '900' }}>{m.result === 'won' ? '✓' : '✕'}</Text>
                    </View>
                  ))}
                </View>
              ) : null}
            </Pressable>
          ) : null}
          {scoreOpen ? (
            <Pressable onPress={onScoreLeague} accessibilityRole="button" style={{ flex: 1, backgroundColor: C.lockBg, borderRadius: 18, padding: 14 }}>
              <Text style={{ fontSize: 24 }}>⚽</Text>
              <Text style={{ color: C.lockTx, fontWeight: '700', fontSize: 13 }}>Skor Ligi{`\n`}Skoru tahmin et, puan topla</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 22, marginBottom: 10 }}>
        <Text style={s.h2}>{['Dünün maçları', 'Bugünün maçları', 'Yarının maçları'][day + 1]}</Text>
        {list.length ? <Text style={{ color: C.mut }}>{list.length} maç</Text> : null}
      </View>
      {ligs.length >= 2 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -18, marginBottom: 10 }} contentContainerStyle={{ paddingHorizontal: 18, gap: 6 }}>
          {['', ...ligs].map((l) => (
            <Pressable key={l || 'tum'} onPress={() => setLig(l)} accessibilityRole="tab" accessibilityState={{ selected: lig === l }}
              style={{ paddingHorizontal: 14, minHeight: 36, borderRadius: 18, justifyContent: 'center', borderWidth: 1.5, borderColor: lig === l ? C.ink : C.border, backgroundColor: lig === l ? C.card : 'transparent' }}>
              <Text style={{ fontWeight: lig === l ? '800' : '600', color: lig === l ? C.ink : C.mut, fontSize: 13.5 }}>{l || 'Tümü'}</Text>
            </Pressable>
          ))}
        </ScrollView>
      ) : null}

      {matches.loading && !matches.error ? (
        <Iskelet n={4} />
      ) : matches.error === 'config' ? (
        <View style={s.empty}><Text style={s.h3}>Kurulum tamamlanmadı</Text><Text style={[s.sub, { textAlign: 'center' }]}>src/ayarlar.js dosyasına Firebase bilgilerini gir.</Text></View>
      ) : matches.error && !matches.list.length ? (
        <View style={s.empty}><Text style={s.h3}>Bağlanılamıyor</Text><Text style={[s.sub, { textAlign: 'center' }]}>İnternet bağlantını kontrol et.</Text></View>
      ) : !list.length ? (
        <View style={s.empty}>
          <Text style={[s.h3, { marginBottom: 0 }]}>Henüz maç yok</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>{bolum === 'robot' ? 'Robot bu gün için henüz tahmin üretmedi.' : 'Bu gün için tahmin eklenmedi.'}</Text>
          {isAdmin && bolum === 'biz' ? <Btn small kind="ink" title="+ Maç ekle" onPress={onAddMatch} style={{ marginTop: 12, alignSelf: 'stretch' }} /> : null}
        </View>
      ) : (
        rest.map((m, i) => <Gir key={m.id + '_' + day} i={i}><MacSatiri m={m} me={me} onPress={() => onMatch(m)} onLongPress={lp(m)} /></Gir>)
      )}

      {A.on && isImg(A.bannerImg) ? (
        <Pressable onPress={() => /^https?:\/\//i.test(A.bannerLink || '') && Linking.openURL(A.bannerLink)} accessibilityRole="link" accessibilityLabel="Reklam" style={{ marginTop: 14, borderRadius: 18, overflow: 'hidden', backgroundColor: C.card }}>
          <Image source={{ uri: A.bannerImg }} style={{ width: '100%', aspectRatio: 3 }} resizeMode="cover" />
          <Text style={{ position: 'absolute', top: 8, left: 8, backgroundColor: 'rgba(0,0,0,.6)', color: '#fff', fontSize: 11, fontWeight: '700', paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6, overflow: 'hidden' }}>Reklam</Text>
        </Pressable>
      ) : null}
    </View>
  );
}
