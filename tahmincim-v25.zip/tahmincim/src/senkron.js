// 🔄 Otomatik fikstür + canlı skor + robot tahmini (API-Football, ücretsiz paket)
// Sunucu olmadığı için bu işi admin telefonu yapar; sonuçlar Firestore'a yazılır, herkes görür.
import AsyncStorage from '@react-native-async-storage/async-storage';
import { doc, setDoc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import { getApiKey } from './veriApi';
import { evalMarket, normName } from './tema';
import { findTeam, saveTeam } from './topluluk';
import { sendPushTakip, sendPushAll } from './bildirim';

const BASE = 'https://v3.football.api-sports.io';
const STATE_KEY = 'tahmincim_senkron';
const DAILY_BUDGET = 90;            // 100 hakkın 10'u teste ve yedeğe kalsın
const ROBOT_MAX = 28;               // günde en fazla robot tahmini
const TODAY_EVERY = 3 * 3600e3;     // bugünün fikstürü
const TOMORROW_EVERY = 12 * 3600e3; // yarının fikstürü
// Kalan hakka göre canlı güncelleme aralığı
const liveEvery = (calls) => (calls < 45 ? 5 : calls < 65 ? 8 : 12) * 60 * 1000;

// Canlı skor bölümünde gösterilen ligler (tek sorguda geliyor, ekstra hak harcamaz)
export const SKOR_LIGLER = [
  [203, 'Süper Lig'], [204, '1. Lig'], [206, 'Türkiye Kupası'], [205, '2. Lig'],
  [2, 'Şampiyonlar Ligi'], [3, 'Avrupa Ligi'], [848, 'Konferans Ligi'], [1, 'Dünya Kupası'], [4, 'Avrupa Şampiyonası'], [5, 'Uluslar Ligi'],
  [39, 'Premier Lig'], [40, 'Championship'], [45, 'FA Cup'], [140, 'La Liga'], [143, 'İspanya Kral Kupası'], [135, 'Serie A'], [137, 'İtalya Kupası'],
  [78, 'Bundesliga'], [81, 'Almanya Kupası'], [61, 'Ligue 1'], [66, 'Fransa Kupası'], [88, 'Eredivisie'], [94, 'Portekiz Ligi'], [144, 'Belçika Ligi'],
  [179, 'İskoçya Ligi'],
];
const SKOR_IDS = SKOR_LIGLER.map(([i]) => i);
const SKOR_AD = Object.fromEntries(SKOR_LIGLER);

export const LIGLER = [
  [203, 'Süper Lig'], [204, '1. Lig'], [206, 'Türkiye Kupası'], [2, 'Şampiyonlar Ligi'], [3, 'Avrupa Ligi'], [848, 'Konferans Ligi'],
  [39, 'Premier Lig'], [140, 'La Liga'], [135, 'Serie A'], [78, 'Bundesliga'], [61, 'Ligue 1'],
];
const LIG_AD = Object.fromEntries(LIGLER);

let st = null;
let running = false;
const subs = new Set();
const utcDay = () => new Date().toISOString().slice(0, 10);

async function loadSt() {
  if (!st) { try { st = JSON.parse((await AsyncStorage.getItem(STATE_KEY)) || 'null'); } catch (e) { st = null; } }
  if (!st || st.day !== utcDay()) st = { day: utcDay(), calls: 0, robots: 0, lastToday: 0, lastTomorrow: st?.lastTomorrow || 0, lastLive: 0, pred: st?.pred || {}, log: [], skor: st?.skor || null, rk: st?.rk || '' };
  return st;
}
async function saveSt() {
  try { await AsyncStorage.setItem(STATE_KEY, JSON.stringify(st)); } catch (e) {}
  subs.forEach((f) => f({ ...st }));
}
export function senkronDinle(f) { subs.add(f); loadSt().then((s) => f({ ...s })); return () => subs.delete(f); }
function log(t) { st.log = [`${new Date().toTimeString().slice(0, 5)} ${t}`, ...(st.log || [])].slice(0, 8); }

async function api(path, key) {
  if (st.calls >= DAILY_BUDGET) throw new Error('Günlük sorgu hakkı doldu');
  st.calls++;
  const res = await fetch(BASE + path, { headers: { 'x-apisports-key': key } });
  const j = await res.json().catch(() => ({}));
  const errs = j && j.errors && (Array.isArray(j.errors) ? j.errors : Object.values(j.errors));
  if (errs && errs.length) throw new Error(errs.map(String).join(' · '));
  return j.response || [];
}

const ymdTR = (offsetDays = 0) => {
  const d = new Date(Date.now() + offsetDays * 864e5 + 3 * 3600e3); // Türkiye saati
  return d.toISOString().slice(0, 10);
};
function statusOf(short) {
  if (['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE', 'INT', 'SUSP'].includes(short)) return 'live';
  if (['FT', 'AET', 'PEN', 'AWD', 'WO'].includes(short)) return 'finished';
  return 'upcoming'; // NS, TBD, PST, CANC, ABD
}
const formTR = (f) => String(f || '').replace(/W/g, 'G').replace(/D/g, 'B').replace(/L/g, 'M').replace(/[^GBM]/g, '').slice(-5);
const pct = (x) => parseInt(String(x || '0').replace('%', ''), 10) || 0;

/* API tahmininden bizim tahmin alanlarımızı üret */
export function robotdan(p) {
  const pr = p.predictions || {};
  const ph = pct(pr.percent?.home); const pd = pct(pr.percent?.draw); const pa = pct(pr.percent?.away);
  const uo = String(pr.under_over || '');
  const uoN = parseFloat(uo.replace(/[^\d.]/g, '')) || 0;
  let market = '';
  if (ph >= 50) market = 'MS 1';
  else if (pa >= 50) market = 'MS 2';
  else if (uo.startsWith('+') && uoN >= 2.5) market = '2.5 Üst';
  else if (uo.startsWith('-') && uoN <= 2.5 && uoN > 0) market = '2.5 Alt';
  else if (ph + pd >= 70) market = '1X';
  else if (pa + pd >= 70) market = 'X2';
  else if (ph || pa) market = ph >= pa ? '1X' : 'X2';
  const top = Math.max(ph, pa, ph + pd > 75 || pa + pd > 75 ? 55 : 0);
  const conf = top >= 55 ? 3 : top >= 45 ? 2 : 1;
  const cmp = p.comparison || {};
  const satir = (l, k) => (cmp[k] ? `${l}: ev ${cmp[k].home} · dep ${cmp[k].away}` : null);
  const ozet = `Kazanma ihtimali: ev %${ph} · beraberlik %${pd} · deplasman %${pa}${uo ? ` · gol beklentisi ${uo.startsWith('+') ? 'üst' : 'alt'} ${uoN}` : ''}`;
  const reasons = [ozet, satir('Form', 'form'), satir('Hücum', 'att'), satir('Savunma', 'def'), satir('Aralarındaki maçlar', 'h2h')].filter(Boolean).join('\n');
  const h2h = (p.h2h || []).slice(0, 5).map((f) => `${f.teams?.home?.name} ${f.goals?.home ?? '-'}-${f.goals?.away ?? '-'} ${f.teams?.away?.name}`).join('\n');
  return {
    market, conf, reasons, h2h,
    p1: ph ? String(ph) : '', px: pd ? String(pd) : '', p2: pa ? String(pa) : '',
    homeForm: formTR(p.teams?.home?.league?.form), awayForm: formTR(p.teams?.away?.league?.form),
    text: '',
    robot: true,
  };
}

export function canliAlanlar(f, m) {
  const short = f.fixture?.status?.short || 'NS';
  const status = statusOf(short);
  const out = { status, afStatus: short, updatedAt: Date.now() };
  if (status !== 'upcoming') out.score = `${f.goals?.home ?? 0}-${f.goals?.away ?? 0}`;
  const ht = f.score?.halftime;
  if (ht && ht.home != null && ht.away != null) out.htScore = `${ht.home}-${ht.away}`;
  if (status === 'live') {
    const el = f.fixture?.status?.elapsed;
    out.minute = short !== 'HT' && el ? String(el) : '';
    out.minuteAt = out.minute ? Date.now() : 0;
  } else { out.minute = ''; out.minuteAt = 0; }
  if (status === 'finished' && m && m.market && !m.result) {
    const r = evalMarket(m.market, { status: 'finished', score: out.score, htScore: out.htScore });
    if (r) out.result = r;
  }
  return out;
}

/* İstatistik + olay akışı (maç detayında gösterilir) */
const ISTAT = { 'Ball Possession': 'pos', 'Total Shots': 'shots', 'Shots on Goal': 'sot', 'Corner Kicks': 'corners', 'Fouls': 'fouls', 'Yellow Cards': 'yellow', 'Red Cards': 'red', 'Offsides': 'offs', 'Goalkeeper Saves': 'saves' };
export function detayAlanlar(f) {
  const out = {};
  const hid = f.teams?.home?.id;
  if (Array.isArray(f.statistics) && f.statistics.length >= 2) {
    const stats = {};
    f.statistics.forEach((t) => {
      const side = t.team?.id === hid ? 0 : 1;
      (t.statistics || []).forEach((x) => {
        const k = ISTAT[x.type];
        if (!k) return;
        stats[k] = stats[k] || [0, 0];
        stats[k][side] = parseInt(String(x.value ?? 0).replace('%', ''), 10) || 0;
      });
    });
    if (Object.keys(stats).length) out.stats = stats;
  }
  if (Array.isArray(f.events)) {
    out.events = f.events.slice(-30).map((e) => ({
      m: (e.time?.elapsed || 0) + (e.time?.extra ? `+${e.time.extra}` : ''),
      t: e.type === 'Goal' ? (e.detail === 'Own Goal' ? 'og' : e.detail === 'Missed Penalty' ? 'mp' : e.detail === 'Penalty' ? 'pen' : 'goal')
        : e.type === 'Card' ? (String(e.detail).includes('Red') ? 'red' : 'yellow') : e.type === 'subst' ? 'sub' : e.type === 'Var' ? 'var' : 'other',
      s: e.team?.id === hid ? 'h' : 'a',
      p: e.player?.name || '', a: e.assist?.name || '',
    })).filter((e) => e.t !== 'other');
  }
  return out;
}

/* ⚽ Gol ve maç sonu bildirimi: maçı takip edenlere ve favori takımı olanlara */
async function golBildir(m, c) {
  const eski = String(m.score || '0-0').split('-').map((x) => parseInt(x, 10) || 0);
  const yeni = String(c.score || '').split('-').map((x) => parseInt(x, 10) || 0);
  const gol = !!c.score && (yeni[0] > eski[0] || yeni[1] > eski[1]);
  const bitti = c.status === 'finished' && m.status !== 'finished';
  if (!gol && !bitti) return;
  let title; let body;
  if (bitti) {
    title = `🏁 Maç bitti: ${m.home} ${c.score} ${m.away}`;
    body = c.result === 'won' ? `Tahminimiz tuttu ✅ (${m.market})` : c.result === 'lost' ? `Bu sefer olmadı (${m.market})` : 'Sonuçlar uygulamada';
  } else {
    const atan = yeni[0] > eski[0] ? m.home : m.away;
    const ev = (c.events || []).filter((e) => ['goal', 'pen', 'og'].includes(e.t)).slice(-1)[0];
    title = `⚽ GOL! ${m.home} ${c.score} ${m.away}`;
    body = `${atan}${ev && ev.p ? ` · ${ev.p}` : ''}${c.minute ? ` (${c.minute}')` : ''}`;
  }
  await sendPushTakip(m, title, body, bitti ? 'tuttu' : 'gol');
}

/* Takım adı eşleştirme (elle eklenen maçla aynı mı?) */
const sade = (n) => normName(n).replace(/\b(fk|sk|jk|as|a s|fc|spor kulubu|kulubu|futbol)\b/g, '').replace(/spor$/, '').replace(/\s+/g, '');
const ayniTakim = (a, b) => { const x = sade(a); const y = sade(b); return !!x && !!y && (x === y || x.includes(y) || y.includes(x)); };

/* Canlı skor listesi için kısa kayıt */
function skorKaydi(f) {
  return {
    i: f.fixture?.id, l: f.league?.id, h: f.teams?.home?.name || '', a: f.teams?.away?.name || '',
    hl: f.teams?.home?.logo || '', al: f.teams?.away?.logo || '',
    t: String(f.fixture?.date || '').slice(11, 16), s: f.fixture?.status?.short || 'NS', e: f.fixture?.status?.elapsed || 0,
    g: [f.goals?.home, f.goals?.away],
    ...(Array.isArray(f.events) && f.events.length ? { ev: kisaOlay(f) } : {}),
  };
}
/* Canlı skor için kısa olay listesi: [dakika, tür, oyuncu, taraf(0/1)] — ek sorgu harcamaz */
function kisaOlay(f) {
  const hid = f.teams?.home?.id;
  return f.events.slice(-24).map((e) => {
    const t = e.type === 'Goal' ? (e.detail === 'Own Goal' ? 'og' : e.detail === 'Missed Penalty' ? 'mp' : e.detail === 'Penalty' ? 'pen' : 'goal')
      : e.type === 'Card' ? (String(e.detail).includes('Red') ? 'red' : 'yellow') : e.type === 'subst' ? 'sub' : '';
    if (!t) return null;
    return { m: (e.time?.elapsed || 0) + (e.time?.extra ? `+${e.time.extra}` : ''), t, s: e.team?.id === hid ? 'h' : 'a', p: String(e.player?.name || '').slice(0, 30), a: t === 'sub' ? String(e.assist?.name || '').slice(0, 30) : '' };
  }).filter(Boolean);
}
async function skorYaz(list, date) {
  st.skor = { date, list };
  await setDoc(doc(db, 'canli', 'bugun'), { date, updatedAt: Date.now(), list }).catch(() => {});
}

/* Bir günün fikstürünü içeri al */
async function gunAl(key, cfg, list, teams, off) {
  const lig = (cfg.auto?.leagues || [203]).map(Number);
  const byId = {}; list.forEach((m) => { byId[m.id] = m; });
  const day = ymdTR(off);
  let silinen = [];
  try { const sd = await getDoc(doc(db, 'canli', 'silinen')); silinen = (sd.exists() && sd.data().ids) || []; } catch (e) {}
  const fx = await api(`/fixtures?date=${day}&timezone=Europe/Istanbul`, key);
  const sk = fx.filter((f) => SKOR_IDS.includes(f.league?.id)).map(skorKaydi);
  if (off === 0) {
    // Önceden toplanan olayları (gol, kart) kaybetme
    const eskiEv = {}; ((st.skor && st.skor.date === day && st.skor.list) || []).forEach((x) => { if (x.ev) eskiEv[x.i] = x.ev; });
    sk.forEach((x) => { if (!x.ev && eskiEv[x.i]) x.ev = eskiEv[x.i]; });
    await skorYaz(sk, day);
  }
  else await setDoc(doc(db, 'canli', 'yarin'), { date: day, updatedAt: Date.now(), list: sk }).catch(() => {});
  // Robot önceliği: seçili lig sırası, sonra saat
  const secili = fx.filter((f) => lig.includes(f.league?.id))
    .sort((a, b) => lig.indexOf(a.league.id) - lig.indexOf(b.league.id) || String(a.fixture.date).localeCompare(String(b.fixture.date)));
  let yeni = 0; let guncel = 0;
  // 1) Senin elle eklediğin maçlar: 25 ligin bülteninde aynı maçı bul, bağla (skor ve sonuç otomatik gelsin)
  const skorFx = fx.filter((f) => SKOR_IDS.includes(f.league?.id));
  for (const m of list.filter((x) => !x.afId && x.date === day && x.status !== 'finished')) {
    const f = skorFx.find((y) => ayniTakim(m.home, y.teams?.home?.name) && ayniTakim(m.away, y.teams?.away?.name));
    if (!f) continue;
    await updateDoc(doc(db, 'matches', m.id), { afId: f.fixture.id, ...canliAlanlar(f, m) }).catch(() => {});
    m.afId = f.fixture.id; guncel++;
  }
  // 2) Bağlı tüm maçları güncelle (senin maçın + robotun maçı ayrı ayrı)
  const fxById = {}; fx.forEach((f) => { fxById[f.fixture?.id] = f; });
  for (const m of list.filter((x) => x.afId && fxById[x.afId] && x.status !== 'finished')) {
    await updateDoc(doc(db, 'matches', m.id), canliAlanlar(fxById[m.afId], m)).catch(() => {});
    guncel++;
  }
  // 3) Robot: seçili liglerde kendi tahmin kaydını açar (senin maçlarından ayrı)
  for (const f of secili) {
    const id = 'af_' + f.fixture.id;
    if (silinen.includes(f.fixture.id)) continue; // senin sildiğin maç geri gelmesin
    const iso = String(f.fixture?.date || '');
    const date = iso.slice(0, 10); const time = iso.slice(11, 16);
    const hn = f.teams?.home?.name || ''; const an = f.teams?.away?.name || '';
    if (byId[id]) {
      if (byId[id].date !== date || byId[id].time !== time) await updateDoc(doc(db, 'matches', id), { date, time }).catch(() => {});
      continue;
    }
    const ht = findTeam(teams, hn); const at = findTeam(teams, an);
    const homeLogo = ht?.logo || f.teams?.home?.logo || '';
    const awayLogo = at?.logo || f.teams?.away?.logo || '';
    if (!ht && homeLogo) saveTeam(hn, homeLogo).catch(() => {});
    if (!at && awayLogo) saveTeam(an, awayLogo).catch(() => {});
    let rob = {};
    const baslamadi = statusOf(f.fixture?.status?.short) === 'upcoming';
    if (baslamadi && !st.pred[f.fixture.id] && (st.robots || 0) < ROBOT_MAX && st.calls < DAILY_BUDGET - 15) {
      try { const p = await api(`/predictions?fixture=${f.fixture.id}`, key); if (p[0]) rob = robotdan(p[0]); st.pred[f.fixture.id] = 1; st.robots = (st.robots || 0) + 1; }
      catch (e) { st.pred[f.fixture.id] = 1; log('Robot: ' + e.message); }
    }
    // Robot tahmini olmayan maç taslak kalır (kullanıcı görmez), canlı skorda yine görünür
    const draft = cfg.auto?.publish === 'draft' || !rob.market;
    const m = {
      afId: f.fixture.id, auto: true, draft,
      home: ht ? ht.name : hn, away: at ? at.name : an, homeLogo, awayLogo,
      league: LIG_AD[f.league?.id] || SKOR_AD[f.league?.id] || f.league?.name || '', date, time,
      market: rob.market || '', marketOther: '', text: rob.text || '', conf: rob.conf || 2, reasons: rob.reasons || '',
      access: cfg.auto?.access || 'open', cost: (cfg.auto?.access || 'open') === 'open' ? 1 : 2, banko: false,
      liveText: '', result: '', odd: '',
      p1: rob.p1 || '', px: rob.px || '', p2: rob.p2 || '', homeForm: rob.homeForm || '', awayForm: rob.awayForm || '', h2h: rob.h2h || '', robot: !!rob.robot,
      score: '', minute: '', minuteAt: 0, updatedAt: Date.now(),
      ...canliAlanlar(f, { market: rob.market }),
    };
    await setDoc(doc(db, 'matches', id), m).catch(() => {});
    yeni++;
  }
  if (off === 0) await eskiyiBitir(key, list);
  log(`${off ? 'Yarın' : 'Bugün'}: ${yeni} yeni maç, ${guncel} güncellendi`);
}

/* Maç saati: başlangıçtan bu yana geçen dakika */
function basladiDk(m) {
  const [y, mo, d] = String(m.date).split('-').map(Number); const [h, mi] = String(m.time).split(':').map(Number);
  return (Date.now() - new Date(y, (mo || 1) - 1, d || 1, h || 0, mi || 0).getTime()) / 60000;
}
/* Önceki günlerden bitmemiş kalan maçlar (ör. gece biten maç) → tek sorguda sonuç */
async function eskiyiBitir(key, list) {
  const td = ymdTR(0);
  const eski = list.filter((m) => m.afId && m.status !== 'finished' && m.date < td && m.date >= ymdTR(-3));
  const ids = [...new Set(eski.map((m) => m.afId))].slice(0, 20);
  if (!ids.length || st.calls > DAILY_BUDGET - 10) return;
  try {
    const fx = await api(`/fixtures?ids=${ids.join('-')}&timezone=Europe/Istanbul`, key);
    for (const f of fx) for (const m of eski.filter((x) => x.afId === f.fixture?.id)) {
      await updateDoc(doc(db, 'matches', m.id), canliAlanlar(f, m)).catch(() => {});
    }
  } catch (e) { log('Eski maçlar: ' + e.message); }
}

/* Canlı: tek sorguda dünyadaki tüm canlı maçlar */
async function canliGuncelle(key, list) {
  const lv = await api('/fixtures?live=all&timezone=Europe/Istanbul', key);
  const liveById = {}; lv.forEach((f) => { liveById[f.fixture?.id] = f; });
  // 1) Bizim tahmin maçlarımız: canlı olanlar + canlıdan yeni düşenler → tek sorguda istatistik ve olaylarla
  let n = 0;
  // canlı olanlar + başlama saati geçmiş ama henüz bitmemiş görünenler (bitişi kaçırmamak için)
  const takip = list.filter((m) => m.afId && m.status !== 'finished' && (liveById[m.afId] || m.status === 'live' || (basladiDk(m) > 0 && basladiDk(m) < 360)));
  const ids = [...new Set(takip.map((m) => m.afId))].slice(0, 20);
  if (ids.length) {
    let fx = [];
    try { fx = await api(`/fixtures?ids=${ids.join('-')}&timezone=Europe/Istanbul`, key); }
    catch (e) { log('Detay: ' + e.message); fx = ids.map((i) => liveById[i]).filter(Boolean); }
    for (const f of fx) {
      const hepsi = takip.filter((x) => x.afId === f.fixture?.id);
      if (!hepsi.length) continue;
      const det = detayAlanlar(f);
      let c0 = null;
      for (const m of hepsi) {
        const c = { ...canliAlanlar(f, m), ...det };   // sonuç (tuttu/tutmadı) her tahmine göre ayrı hesaplanır
        await updateDoc(doc(db, 'matches', m.id), c).catch(() => {});
        n++;
        if (!c0) c0 = c;
      }
      // bildirim bir kez: önce senin tahminin, yoksa robotun
      const asil = hepsi.find((x) => !x.robot && !x.draft) || hepsi[0];
      golBildir(asil, { ...canliAlanlar(f, asil), ...det }).catch(() => {});
    }
  }
  // 2) Canlı skor listesi
  if (st.skor && st.skor.date === ymdTR(0)) {
    const L = st.skor.list.map((x) => {
      const f = liveById[x.i];
      if (f) return skorKaydi(f);
      if (['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE'].includes(x.s)) return { ...x, s: 'FT' }; // canlıdan düştü → bitti
      return x;
    });
    // Listede olmayan yeni canlı maçlar (ör. ertelenen) ekle
    lv.forEach((f) => { if (SKOR_IDS.includes(f.league?.id) && !L.some((x) => x.i === f.fixture?.id)) L.push(skorKaydi(f)); });
    await skorYaz(L, st.skor.date);
  }
  st.lastLive = Date.now();
  if (n) log(`Canlı: ${n} tahmin maçı güncellendi`);
}

/* Şu an canlı ya da başlamak üzere maç var mı? */
function canliVarMi(list) {
  const now = Date.now();
  const yakin = (date, time) => {
    const [y, mo, d] = String(date).split('-').map(Number); const [h, mi] = String(time).split(':').map(Number);
    const ks = new Date(y, mo - 1, d, h || 0, mi || 0).getTime();
    return now >= ks - 3 * 60000 && now <= ks + 200 * 60000;
  };
  if (list.some((m) => m.afId && m.status !== 'finished' && (m.status === 'live' || yakin(m.date, m.time)))) return true;
  const sk = st.skor && st.skor.date === ymdTR(0) ? st.skor.list : [];
  return sk.some((x) => ['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE'].includes(x.s) || (x.s === 'NS' && yakin(st.skor.date, x.t)));
}

/* Elle eklenen maçı, elimizdeki bültenle eşleştir (sorgu harcamaz) */
async function baglaYerel(list) {
  const sk = st.skor && st.skor.date === ymdTR(0) ? st.skor.list : [];
  if (!sk.length) return;
  for (const m of list.filter((x) => !x.afId && x.date === st.skor.date && x.status !== 'finished')) {
    const x = sk.find((y) => ayniTakim(m.home, y.h) && ayniTakim(m.away, y.a));
    if (!x) continue;
    m.afId = x.i;
    await updateDoc(doc(db, 'matches', m.id), { afId: x.i, time: x.t || m.time }).catch(() => {});
  }
}

/* Ana döngü: App her dakika çağırır */
export async function senkronTick({ cfg, list, teams, force }) {
  if (running || !cfg?.auto?.on) return;
  running = true;
  try {
    await loadSt();
    const key = await getApiKey();
    if (!key) { running = false; return; }
    const now = Date.now();
    await baglaYerel(list);
    if (force || !st.lastToday || now - st.lastToday > TODAY_EVERY || !st.skor || st.skor.date !== ymdTR(0)) {
      await gunAl(key, cfg, list, teams, 0);
      st.lastToday = now;
    } else if (!st.lastTomorrow || now - st.lastTomorrow > TOMORROW_EVERY || new Date(st.lastTomorrow).toDateString() !== new Date().toDateString()) {
      await gunAl(key, cfg, list, teams, 1);
      st.lastTomorrow = now;
    } else if (st.calls < DAILY_BUDGET - 3 && now - (st.lastLive || 0) >= liveEvery(st.calls) && canliVarMi(list)) {
      await canliGuncelle(key, list);
    }
    await robotKupon(cfg, list);
  } catch (e) {
    log('Hata: ' + (e.message || 'bağlantı'));
  }
  await saveSt();
  running = false;
}
export { normName };

/* 🤖 Robot kuponu: robotun o günkü en güvendiği maçlardan kendi kuponunu yapar (ek sorgu harcamaz) */
const gucu = (m) => (+m.conf || 2) * 100 + Math.max(+m.p1 || 0, +m.px || 0, +m.p2 || 0);
function zar(str) { let h = 7; for (const ch of String(str)) h = (h * 31 + ch.charCodeAt(0)) % 100003; return h; }
async function robotKupon(cfg, list) {
  if (cfg?.auto?.robotKupon === false) return;
  const td = ymdTR(0);
  if (st.rk === td) return;
  const saat = new Date().getHours();
  const aday = list.filter((m) => m.robot && !m.draft && !m.hidden && m.date === td && m.status === 'upcoming' && m.market)
    .sort((a, b) => gucu(b) - gucu(a));
  // Sabah robot tahminleri birikmeden kupon yapma; öğleden sonra elde ne varsa onunla yap
  if (aday.length < 3 || (aday.length < 6 && saat < 13)) return;
  const kuponlar = [
    { n: 1, title: '🤖 Robotun Güvenli Kuponu', picks: aday.slice(0, 3) },
    aday.length >= 6 ? { n: 2, title: '🤖 Robotun Sürpriz Kuponu', picks: aday.slice(3, 7) } : null,
  ].filter(Boolean);
  let yapilan = 0;
  for (const k of kuponlar) {
    const id = `rk_${td}_${k.n}`;
    try {
      const var0 = await getDoc(doc(db, 'coupons', id));
      if (var0.exists()) continue;
      // Robot kafasına göre: bazı kuponlar ücretsiz, bazıları 1 anahtar
      const acik = zar(id) % 100 < 45;
      await setDoc(doc(db, 'coupons', id), {
        title: k.title, date: td, robot: true, access: acik ? 'open' : 'locked', cost: 1,
        picks: k.picks.map((m) => ({ matchId: m.id, odd: m.odd ? String(m.odd) : '' })), createdAt: Date.now(),
      });
      yapilan++;
      if (k.n === 1) sendPushAll('🤖 Robot kuponunu hazırladı!', `${k.picks.length} maçlık günün kuponu${acik ? ' · bugün ücretsiz' : ''}`, 'kupon').catch(() => {});
    } catch (e) { log('Robot kupon: ' + (e.message || 'hata')); return; }
  }
  st.rk = td;
  if (yapilan) log(`🤖 Robot ${yapilan} kupon paylaştı`);
}
