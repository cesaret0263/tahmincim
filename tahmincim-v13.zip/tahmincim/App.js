import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, ScrollView, Share, Linking, useColorScheme, RefreshControl } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, accentOf, PLAY_PACKAGE, applyTheme, today, dayOff, isFav, canPredictScore, matchStart, adLimit, AD_WINDOW, BONUS_GAP } from './src/tema';
import { autoRemind } from './src/hatirlat';
import { KonfetiHost, konfeti, titret } from './src/efekt';
import { profilDinle } from './src/profil';
import ProfilPenceresi from './src/ekranlar/Profil';
import { getPrefs } from './src/bildirim';
import { setupNotifications, registerPush } from './src/bildirim';
import { Theme, ToastHost, useToast, Icon, refreshStyles } from './src/parcalar';
import { useTribune } from './src/topluluk';
import { useConfig, useMatches, useCoupons, useAccount, logout, deleteAccount, authError } from './src/veri';
import { initAds, adsAvailable, showRewarded } from './src/reklam';
import Bugun from './src/ekranlar/Bugun';
import Canli from './src/ekranlar/Canli';
import Ben from './src/ekranlar/Ben';
import Kuponlar, { couponKey } from './src/ekranlar/Kuponlar';
import Sonuclar from './src/ekranlar/Sonuclar';
import Admin from './src/ekranlar/Admin';
import { isOpen, isVip } from './src/ekranlar/MacKart';
import { Detay, Kilit, SorumluOyun, Hesap, Tanitim, Logo, SayacReklam, Magaza, Hosgeldin, GunlukBonus } from './src/ekranlar/Pencereler';

const THEME_KEY = 'tahmincim_theme';
export default function App() {
  const cfg = useConfig();
  const sys = useColorScheme();
  const [pref, setPref] = useState('system'); // 'light' | 'dark' | 'system'
  useEffect(() => { AsyncStorage.getItem(THEME_KEY).then((v) => v && setPref(v)).catch(() => {}); }, []);
  const choose = (v) => { setPref(v); AsyncStorage.setItem(THEME_KEY, v).catch(() => {}); };
  const dark = pref === 'dark' || (pref === 'system' && sys === 'dark');
  applyTheme(dark);
  refreshStyles();
  const theme = useMemo(() => ({ ...accentOf(cfg), dark, pref, setPref: choose }), [cfg, dark, pref]);
  return (
    <SafeAreaProvider>
      <Theme.Provider value={theme}>
        <ToastHost key={dark ? 'koyu' : 'acik'}>
          <Main cfg={cfg} />
          <KonfetiHost />
        </ToastHost>
      </Theme.Provider>
    </SafeAreaProvider>
  );
}

const TABS = [
  ['today', 'Bugün', 'football-outline'],
  ['live', 'Canlı', 'radio-outline'],
  ['coupons', 'Kuponlar', 'receipt-outline'],
  ['results', 'Sonuçlar', 'trophy-outline'],
  ['me', 'Ben', 'person-outline'],
];

function Main({ cfg }) {
  const ins = useSafeAreaInsets();
  const toast = useToast();
  const matchesRaw = useMatches();
  const couponsRaw = useCoupons();
  const tribune = useTribune();
  const acc = useAccount(cfg.startKeys);
  const { me, updateMe, isAdmin, isMod, isOwner, onboarded, setOnboarded } = acc;
  // Zamanlı yayın: saati gelmeyen içerik kullanıcıya görünmez (dakikada bir kontrol)
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(t); }, []);
  const matches = useMemo(() => (isAdmin ? matchesRaw : { ...matchesRaw, list: matchesRaw.list.filter((m) => !(m.publishAt > now)) }), [matchesRaw, isAdmin, now]);
  const coupons = useMemo(() => (isAdmin ? couponsRaw : { ...couponsRaw, list: couponsRaw.list.filter((c) => !(c.publishAt > now)) }), [couponsRaw, isAdmin, now]);
  const [profil, setProfil] = useState(null);
  useEffect(() => profilDinle(setProfil), []);
  const go = (t, j = null) => { setJump(j); setTab(t); };
  const [tab, setTab] = useState('today');
  const [detail, setDetail] = useState(null);
  const [jump, setJump] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  // Veriler zaten canlı akıyor; aşağı çekince kısa bir yenileme hissi verir
  const pullRefresh = () => { setRefreshing(true); titret('hafif'); setTimeout(() => { setRefreshing(false); toast('Güncel ✓'); }, 700); };
  const [lock, setLock] = useState(null);
  const [sheet, setSheet] = useState(null); // 'rg' | 'store' | 'welcome'
  const [authSheet, setAuthSheet] = useState(null); // { mode, reason }
  const [admin, setAdmin] = useState(null); // null | 'list' | 'new'
  const [fakeAd, setFakeAd] = useState(null); // { forId }
  const [adBusy, setAdBusy] = useState(false);
  const [bonus, setBonus] = useState(null);
  const bonusDone = useRef(false);

  // Favori takımın maçlarını otomatik hatırlat (bildirim izni verilmişse)
  useEffect(() => {
    if (!me.favTeam || matches.loading) return;
    const soon = Date.now() + 3 * 864e5;
    const L = matches.list.filter((m) => !m.hidden && isFav(m, me.favTeam) && canPredictScore(m) && matchStart(m) < soon);
    getPrefs().then((p) => { if (p.favori !== false) autoRemind(L).catch(() => {}); }).catch(() => {});
  }, [me.favTeam, matches.list.length, matches.loading]); // eslint-disable-line

  // Günlük giriş bonusu ve seri
  useEffect(() => {
    if (bonusDone.current || me.guest || me.loading || !me.id || me.banned || me.admin) return;
    if (me.lastBonusDay === today()) { bonusDone.current = true; return; }
    if (Date.now() - (Number(me.lastBonusAt) || 0) < BONUS_GAP) { bonusDone.current = true; return; }
    bonusDone.current = true;
    const streak = me.lastBonusDay === dayOff(-1) ? (Number(me.streak) || 0) + 1 : 1;
    const daily = Number(cfg.rewards?.daily ?? 1) || 0;
    const week = streak % 7 === 0 ? Number(cfg.rewards?.week ?? 3) || 0 : 0;
    const gift = daily + week;
    if (gift <= 0) return;
    updateMe((x) => ({ keys: x.keys + gift, lastBonusDay: today(), lastBonusAt: Date.now(), streak, maxStreak: Math.max(Number(x.maxStreak) || 0, streak) }));
    setTimeout(() => { setBonus({ gift, streak }); konfeti(); }, onboarded ? 800 : 4000);
  }, [me.id, me.loading, me.lastBonusDay]);

  // Kullanılmayan anahtarların süresi (admin ayarı, 0 = kapalı)
  const expDays = Number(cfg.keys?.expireDays) || 0;
  useEffect(() => {
    if (me.guest || me.loading || !me.id || me.admin) return;
    if (!me.keyAt) { updateMe(() => ({ keyAt: Date.now() })); return; }
    if (expDays > 0 && me.keys > 0 && Date.now() - me.keyAt > expDays * 864e5) {
      updateMe(() => ({ keys: 0 }));
      toast(`${expDays} gün kullanılmayan anahtarların sıfırlandı`);
    }
  }, [me.id, me.loading, expDays]); // eslint-disable-line

  useEffect(() => { initAds(); setupNotifications(); }, []);
  const pushId = cfg.push?.projectId;
  const uidNow = acc.user ? acc.user.uid : null;
  useEffect(() => { if (pushId) registerPush(pushId, uidNow); }, [pushId, uidNow]);

  const playUrl = `https://play.google.com/store/apps/details?id=${PLAY_PACKAGE}`;
  const rateApp = () => Linking.openURL(`market://details?id=${PLAY_PACKAGE}`).catch(() => Linking.openURL(playUrl).catch(() => {}));
  const shareApp = async () => {
    try {
      await Share.share({ message: `⚽ ${cfg.name} — günün tahminleri, banko kuponlar ve canlı tahminler tek uygulamada!\n📲 ${playUrl}\n18+` });
      const n = Number(cfg.rewards?.share) || 0;
      if (n > 0 && !me.guest && !me.shareRewarded && !me.banned) {
        updateMe((x) => ({ keys: x.keys + n, shareRewarded: true }));
        toast(`Teşekkürler! +${n} anahtar hesabına eklendi 🎁`);
      }
    } catch (e) {}
  };

  const liveCount = matches.list.filter((m) => m.status === 'live').length;
  const hour = new Date().getHours();
  const greet = hour < 6 ? 'İyi geceler' : hour < 12 ? 'Günaydın' : hour < 18 ? 'İyi günler' : 'İyi akşamlar';

  const askAuth = (reason, mode = 'register') => setAuthSheet({ mode, reason });
  const openMatch = (m) => {
    if (isOpen(m, me)) return setDetail(m);
    if (me.guest) return askAuth('Kilitli tahminleri açmak için ücretsiz kayıt ol. Anahtarların hesabında saklanır.');
    if (me.banned) return toast('Hesabın askıya alındı');
    setLock(m);
  };

  const openCouponLock = (c) => {
    if (me.guest) return askAuth('Kilitli kuponları açmak için ücretsiz kayıt ol.');
    if (me.banned) return toast('Hesabın askıya alındı');
    setLock({ id: couponKey(c), cost: c.cost, access: c.access, label: c.title || 'Günün Kuponu', date: c.date, isCoupon: true });
  };
  const opened = (t) => {
    konfeti();
    if (t.isCoupon) toast('Kupon açıldı! 🎉');
    else { toast('Tahmin açıldı!'); setTimeout(() => setDetail(t), 350); }
  };
  const isUnlocked = (t) => (t.isCoupon ? (me.unlocked || []).includes(t.id) : isOpen(t, me));

  const dailyMax = Number(cfg.keys?.dailyUnlock) || 0;
  const limitHit = () => dailyMax > 0 && !isVip(me) && (me.unlockCount || 0) >= dailyMax;
  const unlockPatch = (x) => ({ unlockDay: today(), unlockCount: (x.unlockCount || 0) + 1 });
  const unlockWithKeys = (t) => {
    const cost = Math.max(1, Number(t.cost) || 1);
    if ((me?.keys || 0) < cost) return toast('Yeterli anahtarın yok');
    if (limitHit()) return toast(`Bugün en fazla ${dailyMax} tahmin açabilirsin. Yarın tekrar gel 🙂`);
    setLock(null);
    updateMe((x) => ({ ...unlockPatch(x), unlocked: [...x.unlocked, t.id], keys: Math.max(0, x.keys - cost) }), true)
      .then(() => opened(t))
      .catch(() => toast('Açılamadı, internetini kontrol edip tekrar dene. Anahtarın gitmedi.'));
  };

  // Reklam izlendi: anahtarı ver, bir maç için izlendiyse ve yetiyorsa maçı aç
  const reward = (t) => {
    const r = Number(cfg.ads.reward) || 1;
    const m = t || null;
    const cost = m ? Math.max(1, Number(m.cost) || 1) : 0;
    const willOpen = m && !isUnlocked(m) && (me?.keys || 0) + r >= cost && !limitHit();
    return updateMe((x) => {
      const keys = x.keys + r;
      // 24 saatlik pencere: ilk reklamla başlar
      const fresh = !x.adAt || Date.now() - x.adAt >= AD_WINDOW;
      const ad = fresh ? { adAt: Date.now(), adCount: 1 } : { adCount: x.adCount + 1 };
      return willOpen
        ? { ...ad, ...unlockPatch(x), keys: keys - cost, unlocked: [...x.unlocked, m.id] }
        : { ...ad, keys };
    }, true).then(() => {
      if (willOpen) opened(m);
      else { titret('basari'); toast(`+${r} anahtar kazandın!`); }
    }).catch(() => toast('Ödül kaydedilemedi, internetini kontrol et'));
  };

  const watchAd = async (target) => {
    const A = cfg.ads;
    if (!A.on) return;
    if (me.guest) { setLock(null); return askAuth('Reklam izleyip anahtar kazanmak için ücretsiz kayıt ol.'); }
    if (me.banned) return toast('Hesabın askıya alındı');
    if ((me?.adCount || 0) >= adLimit(cfg)) {
      const h = Math.max(1, Math.ceil((me.adAt + AD_WINDOW - Date.now()) / 3600e3));
      return toast(`Reklam hakkın bitti, ${h} saat sonra yenilenir`);
    }
    setLock(null);
    if (!adsAvailable()) return setFakeAd({ target });
    setAdBusy(true);
    toast('Reklam yükleniyor…');
    const r = await showRewarded(A.unitId);
    setAdBusy(false);
    if (r === 'earned') reward(target);
    else if (r === 'closed') toast('Reklam yarıda kaldı, anahtar verilmedi');
    else toast('Şu an reklam yok, biraz sonra tekrar dene');
  };

  if (!acc.ready) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style={C.dark ? 'light' : 'dark'} />
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={pullRefresh} colors={[accentOf(cfg).acc]} tintColor={C.mut} progressBackgroundColor={C.card} />}
        contentContainerStyle={{ paddingTop: ins.top + 16, paddingHorizontal: 18, paddingBottom: ins.bottom + 110 }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, gap: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
            <Logo cfg={cfg} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.mut, fontSize: 13 }}>{greet}</Text>
              <Text numberOfLines={1} style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{cfg.name}</Text>
            </View>
          </View>
          {me.guest ? (
            <Pressable onPress={() => askAuth(null, 'login')} accessibilityRole="button"
              style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.hero, borderRadius: 22, paddingHorizontal: 14, minHeight: 44 }}>
              <Icon name="person-outline" size={17} color="#fff" />
              <Text style={{ fontWeight: '700', fontSize: 15, color: '#fff' }}>Giriş</Text>
            </Pressable>
          ) : (
            <Pressable onPress={() => setTab('me')} accessibilityLabel={`Anahtarların: ${me.keys}`}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.key, borderRadius: 22, paddingHorizontal: 14, minHeight: 44 }}>
              <Icon name="key" size={17} color={C.onKey} />
              <Text style={{ fontWeight: '800', fontSize: 16, color: C.onKey }}>{me.admin ? '∞' : me.keys}</Text>
            </Pressable>
          )}
        </View>

        {tab === 'today' ? (
          <Bugun cfg={cfg} matches={matches} coupons={coupons} me={me} onMatch={openMatch} isAdmin={isAdmin} onAddMatch={() => setAdmin('new')}
            onScoreLeague={() => go('coupons', 'score')} onStats={() => go('results')} onNav={go} />
        ) : tab === 'live' ? (
          <Canli matches={matches} me={me} onMatch={openMatch} />
        ) : tab === 'coupons' ? (
          <Kuponlar coupons={coupons} matches={matches} me={me} onLocked={openCouponLock} appName={cfg.name} logo={cfg.logo}
            tribune={tribune} isAdmin={isAdmin} jump={jump} onNeedAuth={() => askAuth('Katılmak için ücretsiz kayıt ol.')} />
        ) : tab === 'results' ? (
          <Sonuclar matches={matches} me={me} onMatch={openMatch} />
        ) : (
          <Ben cfg={cfg} matches={matches} me={me} onMatch={openMatch} isAdmin={isAdmin}
            onAd={() => !adBusy && watchAd(null)} onAdmin={() => setAdmin('list')}
            onAuth={(mode) => askAuth(null, mode)} onLogout={() => logout().then(() => toast('Çıkış yapıldı'))}
            onOnb={() => setOnboarded(false)} onRG={() => setSheet('rg')} onBuy={() => setSheet('store')}
            onDelete={async () => { try { await deleteAccount(); toast('Hesabın silindi'); } catch (e) { toast(authError(e)); } }}
            onShare={shareApp} onRate={rateApp} tribune={tribune} onUpdate={updateMe} coupons={coupons} onNav={go} />
        )}
      </ScrollView>

      {/* Alt menü */}
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8, paddingBottom: ins.bottom + 10, flexDirection: 'row' }}>
        {TABS.map(([k, label, icon]) => (
          <TabBtn key={k} on={tab === k} label={label} icon={icon} badge={k === 'live' ? liveCount : 0} onPress={() => { setJump(null); setTab(k); }} />
        ))}
      </View>

      {profil ? <ProfilPenceresi p={profil} tribune={tribune} matches={matches} onClose={() => setProfil(null)} /> : null}
      {detail ? <Detay m={detail} appName={cfg.name} logo={cfg.logo} me={me} isAdmin={isAdmin} onNeedAuth={() => { setDetail(null); askAuth('Yorum yapmak ve oy vermek için ücretsiz kayıt ol.'); }} onClose={() => setDetail(null)} /> : null}
      {bonus ? <GunlukBonus info={bonus} onClose={() => setBonus(null)} /> : null}
      {lock ? <Kilit m={lock} me={me} cfg={cfg} onClose={() => setLock(null)} onAd={() => watchAd(lock)} onKey={() => unlockWithKeys(lock)} onBuy={() => { setLock(null); setTimeout(() => setSheet('store'), 300); }} /> : null}
      {sheet === 'rg' ? <SorumluOyun onClose={() => setSheet(null)} /> : null}
      {sheet === 'welcome' ? <Hosgeldin cfg={cfg} me={me} onClose={() => setSheet(null)} onShare={() => { setSheet(null); setTimeout(shareApp, 300); }} onRate={rateApp} /> : null}
      {sheet === 'store' ? <Magaza cfg={cfg} me={me} onClose={() => setSheet(null)} onSoon={() => toast('Satın alma, uygulama Google Play\'e çıkınca açılacak')} /> : null}
      {authSheet ? <Hesap startMode={authSheet.mode} reason={authSheet.reason} startKeys={cfg.startKeys} onClose={() => setAuthSheet(null)} onDone={(msg, kind) => { setTab('today'); if (kind === 'register') setTimeout(() => setSheet('welcome'), 400); else toast(msg); }} /> : null}
      <Admin visible={!!admin && isMod} startWith={admin} onClose={() => setAdmin(null)} matches={matchesRaw} coupons={couponsRaw} cfg={cfg} me={me} perm={{ owner: isOwner, admin: isAdmin, mod: isMod }} />
      <SayacReklam visible={!!fakeAd} cfg={cfg} seconds={15}
        onCancel={() => { setFakeAd(null); toast('Reklam yarıda kaldı, anahtar verilmedi'); }}
        onDone={() => { const f = fakeAd; setFakeAd(null); reward(f?.target); }} />
      <Tanitim visible={!onboarded} cfg={cfg} onDone={() => setOnboarded(true)} />
    </View>
  );
}

function TabBtn({ on, label, icon, badge, onPress }) {
  const t = React.useContext(Theme);
  return (
    <Pressable onPress={onPress} accessibilityRole="tab" accessibilityState={{ selected: on }} style={{ flex: 1, alignItems: 'center', gap: 4, minHeight: 52 }}>
      <ThemedPill on={on}><Icon name={on ? icon.replace('-outline', '') : icon} size={22} color={on ? t.onAcc : C.mut} /></ThemedPill>
      <Text numberOfLines={1} style={{ fontSize: 12, fontWeight: on ? '700' : '600', color: on ? C.ink : C.mut }}>{label}</Text>
      {badge ? (
        <View style={{ position: 'absolute', top: 0, left: '58%', backgroundColor: '#E5484D', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
          <Text style={{ color: '#fff', fontSize: 10.5, fontWeight: '700' }}>{badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

function ThemedPill({ on, children }) {
  const t = React.useContext(Theme);
  return <View style={{ paddingHorizontal: 14, paddingVertical: 5, borderRadius: 16, backgroundColor: on ? t.acc : 'transparent' }}>{children}</View>;
}
