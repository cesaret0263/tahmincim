export const LIGHT = {
  bg: '#F4F5F0',
  ink: '#12161C',
  hero: '#12161C',
  mut: '#5B6470',
  line: '#E2E5DD',
  card: '#FFFFFF',
  track: '#E9ECE4',
  border: '#D5DAD0',
  key: '#FF8A1F',
  onKey: '#2A1400',
  lockBg: '#FFF1E3',
  lockTx: '#8A3A00',
  vipBg: '#FFF6D6',
  vipTx: '#6B4D00',
  okBg: '#E6FBEF',
  okTx: '#047A42',
  red: '#B42318',
  redBg: '#FDE8E8',
  dark2: '#262C35',
  adminBg: '#EEF0EA',
  selBg: '#E6F8EE',
  dark: false,
};
export const DARK = {
  bg: '#0E1116',
  ink: '#F2F4F7',
  hero: '#1C222B',
  mut: '#9AA3AF',
  line: '#262C35',
  card: '#171B22',
  track: '#222831',
  border: '#343B46',
  key: '#FF8A1F',
  onKey: '#2A1400',
  lockBg: '#3A2716',
  lockTx: '#FFB46B',
  vipBg: '#3A3215',
  vipTx: '#FFD666',
  okBg: '#12301F',
  okTx: '#4ADE80',
  red: '#FF6B7D',
  redBg: '#3A1618',
  dark2: '#2A313B',
  adminBg: '#0B0E12',
  selBg: '#13261B',
  dark: true,
};
// Renkler tek yerden; tema değişince içerik güncellenir
export const C = { ...LIGHT };
export function applyTheme(dark) {
  Object.assign(C, dark ? DARK : LIGHT);
}

export const DEFAULT_CFG = {
  name: 'Tahmincim',
  logo: '',
  color: '#00D26A',
  startKeys: 3,
  message: { on: false, text: '', type: 'info' },
  ads: { on: true, unitId: '', reward: 1, limit: 3, bannerImg: '', bannerLink: '' },
  keys: { expireDays: 0, dailyUnlock: 5 },
  vip: { on: true, plans: [{ days: 7, price: '₺29,99' }, { days: 30, price: '₺79,99' }, { days: 90, price: '₺199,99' }] },
  links: { support: '', privacy: '', instagram: '', telegram: '', whatsapp: '', x: '', youtube: '', tiktok: '' },
  push: { projectId: '' },
  rewards: { share: 2, daily: 1, week: 2 },
  store: { on: true, packs: [{ keys: 5, price: '₺19,99' }, { keys: 15, price: '₺49,99' }, { keys: 40, price: '₺99,99' }] },
};

export function mergeCfg(c) {
  const o = JSON.parse(JSON.stringify(DEFAULT_CFG));
  if (c && typeof c === 'object') {
    Object.assign(o, c);
    o.message = { ...DEFAULT_CFG.message, ...(c.message || {}) };
    o.ads = { ...DEFAULT_CFG.ads, ...(c.ads || {}) };
    o.store = { ...DEFAULT_CFG.store, ...(c.store || {}) };
    o.links = { ...DEFAULT_CFG.links, ...(c.links || {}) };
    o.push = { ...DEFAULT_CFG.push, ...(c.push || {}) };
    o.rewards = { ...DEFAULT_CFG.rewards, ...(c.rewards || {}) };
    o.keys = { ...DEFAULT_CFG.keys, ...(c.keys || {}) };
    o.vip = { ...DEFAULT_CFG.vip, ...(c.vip || {}) };
    if (!Array.isArray(o.vip.plans)) o.vip.plans = DEFAULT_CFG.vip.plans;
    if (!Array.isArray(o.store.packs)) o.store.packs = DEFAULT_CFG.store.packs;
  }
  return o;
}

export const MARKETS = [
  ['MS 1', '{h} kazanır'],
  ['MS X', 'Maç berabere biter'],
  ['MS 2', '{a} kazanır'],
  ['2.5 Üst', 'Maçta 3 veya daha fazla gol olur'],
  ['2.5 Alt', 'Maçta en fazla 2 gol olur'],
  ['KG Var', 'İki takım da gol atar'],
  ['KG Yok', 'En az bir takım gol atamaz'],
  ['1.5 Üst', 'Maçta 2 veya daha fazla gol olur'],
  ['İY 0.5 Üst', 'İlk yarıda gol olur'],
  ['1X', '{h} kaybetmez'],
  ['X2', '{a} kaybetmez'],
  ['Diğer', ''],
];
export const CONF = ['Zayıf', 'Orta', 'Güçlü'];

export function marketText(market, home, away) {
  const f = MARKETS.find((x) => x[0] === market);
  return ((f && f[1]) || '').replace('{h}', home || '').replace('{a}', away || '');
}
export function predText(m) {
  return m.text || marketText(m.market, m.home, m.away) || m.market || '';
}

export function lum(hex) {
  const r = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!r) return 1;
  const n = parseInt(r[1], 16);
  const c = [n >> 16, (n >> 8) & 255, n & 255].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}
export function accentOf(cfg) {
  const acc = /^#[0-9a-f]{6}$/i.test(cfg?.color || '') ? cfg.color : '#00D26A';
  return { acc, onAcc: lum(acc) > 0.35 ? '#0B2416' : '#FFFFFF' };
}

export function hashColor(s) {
  let h = 0;
  for (const ch of String(s || '')) h = (h * 31 + ch.charCodeAt(0)) | 0;
  const p = ['#E2231A', '#1D4BA8', '#2B2F36', '#7A1F3D', '#0E7C4A', '#C25400', '#5B3FD1', '#0B6E99', '#A3122E', '#3D5A1E'];
  return p[Math.abs(h) % p.length];
}
export function initials(n) {
  const w = String(n || '?').trim().split(/\s+/);
  return (w.length > 1 ? w[0][0] + w[1][0] : w[0].slice(0, 3)).toUpperCase();
}

export function ymd(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
export function dayOff(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return ymd(d);
}
export const today = () => ymd(new Date());

export function isImg(u) {
  return typeof u === 'string' && /^data:image\/(png|jpeg|webp);base64,/.test(u);
}
export function scoreOf(m) {
  const s = String(m.score || '').split('-');
  return [(s[0] || '0').trim(), (s[1] || '0').trim()];
}
export const byTime = (a, b) => String(a.time || '').localeCompare(String(b.time || ''));
export const newId = () => 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* ---------- kupon yardımcıları ---------- */
export const oddOf = (v) => {
  const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  return isFinite(n) && n > 0 ? n : 0;
};
export function couponPicks(c, matchList) {
  const byId = {};
  (matchList || []).forEach((m) => { byId[m.id] = m; });
  return (c.picks || []).map((p) => ({ ...p, m: byId[p.matchId] || null }));
}
export function couponTotal(picks) {
  const odds = picks.map((p) => oddOf(p.odd || (p.m && p.m.odd))).filter((x) => x > 0);
  return odds.length ? odds.reduce((a, b) => a * b, 1) : 0;
}
export function couponStatus(picks) {
  if (!picks.length) return 'pending';
  const res = picks.map((p) => (p.m && p.m.status === 'finished' ? p.m.result : ''));
  if (res.some((r) => r === 'lost')) return 'lost';
  if (res.every((r) => r === 'won')) return 'won';
  return 'pending';
}

const AYLAR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const GUNLER = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
// "2026-11-21" -> "21 Kasım Cumartesi" (bugün/yarın/dün ise başına eklenir)
export function dayLabel(d, withRel = true) {
  if (!d || !/^\d{4}-\d{2}-\d{2}$/.test(d)) return '';
  const [y, m, g] = d.split('-').map(Number);
  const dt = new Date(y, m - 1, g);
  const base = `${g} ${AYLAR[m - 1]} ${GUNLER[dt.getDay()]}`;
  if (!withRel) return base;
  const rel = d === dayOff(0) ? 'Bugün' : d === dayOff(1) ? 'Yarın' : d === dayOff(-1) ? 'Dün' : '';
  return rel ? `${rel} · ${base}` : base;
}

export const PLAY_PACKAGE = 'com.tahmincim.app';

/* ---------- Tribün: kullanıcı tahmini sonucu skordan hesaplanır ---------- */
export const TRIBUNE_MARKETS = ['MS 1', 'MS X', 'MS 2', '2.5 Üst', '2.5 Alt', 'KG Var', 'KG Yok', '1.5 Üst', '1X', 'X2'];
export function evalMarket(market, m) {
  if (!m || m.status !== 'finished' || !/^\s*\d+\s*-\s*\d+\s*$/.test(String(m.score || ''))) return '';
  const [h, a] = String(m.score).split('-').map((x) => parseInt(x, 10));
  const t = h + a;
  const r = {
    'MS 1': h > a, 'MS X': h === a, 'MS 2': a > h,
    '2.5 Üst': t >= 3, '2.5 Alt': t <= 2, '1.5 Üst': t >= 2,
    'KG Var': h > 0 && a > 0, 'KG Yok': !(h > 0 && a > 0),
    '1X': h >= a, 'X2': a >= h,
  }[market];
  return r === undefined ? '' : r ? 'won' : 'lost';
}
export function tribuneStatus(tc, matchList) {
  const byId = {};
  (matchList || []).forEach((m) => { byId[m.id] = m; });
  const res = (tc.picks || []).map((p) => (p.custom ? p.result || '' : evalMarket(p.market, byId[p.matchId])));
  if (!res.length) return 'pending';
  if (res.some((r) => r === 'lost')) return 'lost';
  if (res.every((r) => r === 'won')) return 'won';
  return 'pending';
}
// Kullanıcının kendi eklediği maç varsa kupon doğrulanmamıştır (sıralamaya girmez)
export const isVerified = (tc) => !(tc.picks || []).some((p) => p.custom);
export function weekStart() {
  const d = new Date();
  const day = (d.getDay() + 6) % 7; // Pazartesi = 0
  d.setDate(d.getDate() - day);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
export const normName = (n) => String(n || '').trim().toLocaleLowerCase('tr').replace(/\s+/g, ' ');
export const teamId = (n) => normName(n).replace(/[^a-z0-9çğıöşü]+/g, '-').replace(/^-|-$/g, '').slice(0, 80) || 'takim';

/* ---------- Rozetler ---------- */
export function badgesOf(me, stats) {
  const list = [];
  if (!me || me.guest) return list;
  list.push(['🎉', 'Hoş geldin']);
  if ((stats?.tribune || 0) >= 1) list.push(['🧾', 'İlk kupon']);
  if ((stats?.tribuneWon || 0) >= 5) list.push(['🏆', 'Kupon ustası']);
  if ((Number(me.maxStreak) || 0) >= 7) list.push(['🔥', '7 gün seri']);
  if ((Number(me.maxStreak) || 0) >= 30) list.push(['💎', '30 gün seri']);
  if (me.createdAt && Date.now() - me.createdAt > 30 * 864e5) list.push(['🤝', 'Sadık üye']);
  if (me.shareRewarded) list.push(['📣', 'Paylaşımcı']);
  if (Number(me.vipUntil || 0) > Date.now()) list.push(['👑', 'VIP']);
  return list;
}

/* ---------- Başarı istatistiği ---------- */
export function successStats(list, days) {
  const from = days ? dayOff(-days) : '';
  const F = (list || []).filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost') && (!from || String(m.date) >= from));
  const won = F.filter((m) => m.result === 'won').length;
  return { total: F.length, won, lost: F.length - won, pct: F.length ? Math.round((won / F.length) * 100) : 0 };
}

/* ---------- Maç başlangıç zamanı ---------- */
export function matchStart(m) {
  const [y, mo, d] = String(m.date || '').split('-').map(Number);
  const [h, mi] = String(m.time || '').split(':').map(Number);
  if (!y || !mo || !d) return 0;
  return new Date(y, mo - 1, d, h || 0, mi || 0).getTime();
}

/* ---------- Skor ligi ---------- */
export const monthKey = (t) => { const x = t ? new Date(t) : new Date(); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}`; };
export const canPredictScore = (m) => m && m.status === 'upcoming' && matchStart(m) > Date.now();
// Tam skor 3 puan, doğru sonuç (1/X/2) 1 puan
export function scorePoints(p, m) {
  if (!m || m.status !== 'finished' || !/^\s*\d+\s*-\s*\d+\s*$/.test(String(m.score || ''))) return null;
  const [h, a] = String(m.score).split('-').map((x) => parseInt(x, 10));
  if (+p.h === h && +p.a === a) return 3;
  return Math.sign(+p.h - +p.a) === Math.sign(h - a) ? 1 : 0;
}

/* ---------- Avatarlar ---------- */
export const AVATARS = ['⚽', '🦁', '🦅', '🐺', '🐯', '🐻', '🦊', '🐉', '🔥', '⚡', '👑', '🎯', '🚀', '💎', '🏆', '😎'];

/* ---------- Favori takım ---------- */
export const isFav = (m, fav) => !!fav && (normName(m.home) === normName(fav) || normName(m.away) === normName(fav));

/* ---------- Anahtar kuralları ---------- */
export const AD_MAX = 3;                 // AdMob güvenliği: 24 saatte en fazla 3 ödüllü reklam
export const AD_WINDOW = 24 * 3600 * 1000;
export const BONUS_GAP = 12 * 3600 * 1000;
export const adLimit = (cfg) => Math.max(0, Math.min(AD_MAX, Number(cfg?.ads?.limit) || AD_MAX));

/* ---------- Yetki yardımcıları ---------- */
export const canModerate = (me) => !!me && ['owner', 'admin', 'mod'].includes(me.role);
export const isOwnerMe = (me) => !!me && me.role === 'owner';
export const ROLE_LABEL = { owner: 'Sahip', admin: 'Admin', mod: 'Moderatör' };
