import React, { useState } from 'react';
import { View, Text, Pressable, Linking, Alert } from 'react-native';
import { C, badgesOf, tribuneStatus, AVATARS, adLimit, AD_WINDOW, canModerate, ROLE_LABEL } from '../tema';
import { Btn, Card, Icon, s, useTheme, Avatar, Sheet, Field, Crest, useToast } from '../parcalar';
import { useTeams, suggestTeams, findTeam, addFeedback, useMyFeedback } from '../topluluk';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { onceLabel } from './Etkilesim';
import { isVip, MacSatiri } from './MacKart';
import { useSaved, toggleSaved } from '../kayit';
import { getPrefs, savePrefs, PREF_LIST } from '../bildirim';
import { Toggle } from '../parcalar';

function Link({ icon, title, sub, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, borderTopWidth: 1, borderTopColor: C.line }}>
      <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={18} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>{title}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <Icon name="chevron-forward" size={18} color={C.mut} />
    </Pressable>
  );
}

export default function Ben({ cfg, matches, me, onAd, onMatch, isAdmin, onAdmin, onAuth, onLogout, onOnb, onRG, onBuy, onDelete, onShare, onRate, tribune, onUpdate, coupons, onNav }) {
  const th = useTheme();
  const saved = useSaved();
  const [kayit, setKayit] = useState(false);
  const [bild, setBild] = useState(false);
  const [edit, setEdit] = useState(false);
  const [fb, setFb] = useState(false);
  const myFb = useMyFeedback(me && !me.guest ? me.id : null);
  const [fbSeen, setFbSeen] = useState(0);
  React.useEffect(() => { AsyncStorage.getItem('tahmincim_fb_seen').then((v) => setFbSeen(Number(v) || 0)).catch(() => {}); }, []);
  const newReplies = myFb.list.filter((f) => f.reply && (f.repliedAt || 0) > fbSeen).length;
  const openFb = () => { setFb(true); const n = Date.now(); setFbSeen(n); AsyncStorage.setItem('tahmincim_fb_seen', String(n)).catch(() => {}); };
  const mine = (tribune?.list || []).filter((x) => me && x.uid === me.id);
  const badges = badgesOf(me, { tribune: mine.length, tribuneWon: mine.filter((x) => tribuneStatus(x, matches.list) === 'won').length });
  const L = cfg.links || {};
  const socials = [['instagram', 'logo-instagram', '#E1306C'], ['telegram', 'paper-plane', '#2AABEE'], ['whatsapp', 'logo-whatsapp', '#25D366'], ['x', 'logo-twitter', C.ink], ['youtube', 'logo-youtube', '#FF0000'], ['tiktok', 'logo-tiktok', C.ink]]
    .filter(([k]) => /^https?:\/\//i.test(L[k] || ''));
  const A = cfg.ads;
  const left = Math.max(0, adLimit(cfg) - (me?.adCount || 0));
  const resetH = me?.adAt ? Math.max(1, Math.ceil((me.adAt + AD_WINDOW - Date.now()) / 3600e3)) : 24;
  const F = matches.list.filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost'));
  const won = F.filter((m) => m.result === 'won').length;
  const last = [...F].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5);

  return (
    <View>
      {me.guest ? (
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>Ücretsiz hesap aç</Text>
          <Text style={[s.sub, { marginTop: 4 }]}>
            Anahtar kazan, kilitli tahminleri aç; telefon değiştirsen bile her şey hesabında kalsın.
            {Number(cfg.startKeys) > 0 ? ` Kayıt olana ${Number(cfg.startKeys)} anahtar hediye!` : ''}
          </Text>
          <Btn style={{ marginTop: 14 }} title="Kayıt ol" onPress={() => onAuth('register')} />
          <Btn style={{ marginTop: 8 }} kind="out" title="Giriş yap" onPress={() => onAuth('login')} />
        </Card>
      ) : (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <Pressable onPress={() => setEdit(true)} accessibilityLabel="Profili düzenle">
              <Avatar emoji={me.avatar} name={me.name || me.email} size={52} />
              <View style={{ position: 'absolute', right: -2, bottom: -2, width: 20, height: 20, borderRadius: 10, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="pencil" size={12} color={C.ink} />
              </View>
            </Pressable>
            <Pressable style={{ flex: 1 }} onPress={() => setEdit(true)}>
              <Text numberOfLines={1} style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>{me.name || 'Hesabım'}</Text>
              <Text numberOfLines={1} style={{ color: C.mut }}>{me.favTeam ? `⭐ ${me.favTeam}` : me.email}</Text>
            </Pressable>
            {isVip(me) ? (
              <View style={{ backgroundColor: C.vipBg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                <Text style={{ color: C.vipTx, fontWeight: '800', fontSize: 12 }}>{me.admin ? `${(ROLE_LABEL[me.role] || 'Admin').toLocaleUpperCase('tr')} · Sınırsız` : `VIP · ${Math.ceil((me.vipUntil - Date.now()) / 864e5)} gün`}</Text>
              </View>
            ) : null}
          </View>
          {me.banned ? (
            <View style={{ backgroundColor: C.redBg, borderRadius: 14, padding: 12, marginBottom: 12 }}>
              <Text style={{ color: C.red, fontWeight: '700' }}>Hesabın askıya alındı. Kilitli tahminleri açamazsın.</Text>
            </View>
          ) : null}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 26, fontWeight: '800', color: C.onKey }}>{me.admin ? '∞' : me.keys ?? 0}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>Anahtarların</Text>
              <Text style={s.sub}>{me.admin ? 'Admin olduğun için her şey sınırsız açık' : isVip(me) ? 'VIP olduğun için tüm tahminler açık' : 'Kilitli tahminleri açmak için kullanılır'}</Text>
            </View>
          </View>
          {Number(me.streak) > 0 ? (
            <Text style={{ color: C.lockTx, fontWeight: '700', marginTop: 12 }}>🔥 {me.streak} günlük seri · her gün gir, bonusu kaçırma</Text>
          ) : null}
          {badges.length ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 12 }}>
              {badges.map(([e, l]) => (
                <View key={l} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                  <Text>{e}</Text><Text style={{ fontWeight: '700', color: C.ink, fontSize: 12.5 }}>{l}</Text>
                </View>
              ))}
            </View>
          ) : null}
          {cfg.vip?.on && !isVip(me) && !me.banned ? (
            <Pressable onPress={onBuy} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.vipBg, borderRadius: 16, padding: 14, marginTop: 16 }}>
              <Text style={{ fontSize: 24 }}>👑</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '800', color: C.vipTx, fontSize: 16 }}>VIP ol</Text>
                <Text style={{ color: C.vipTx, fontSize: 13 }}>Tüm tahminler açık, anahtar derdi yok</Text>
              </View>
              <Icon name="chevron-forward" color={C.vipTx} size={18} />
            </Pressable>
          ) : null}
          {A.on && !me.banned ? (
            <Btn style={{ marginTop: 16 }} icon="play" disabled={left <= 0} onPress={onAd}
              title={left > 0 ? `Reklam izle, +${Number(A.reward) || 1} anahtar (${left} hak)` : `Reklam hakkın ${resetH} saat sonra yenilenir`} />
          ) : null}
          {cfg.store?.on && !me.banned ? (
            <Btn style={{ marginTop: 8 }} kind="out" icon="cart-outline" title="Anahtar satın al" onPress={onBuy} />
          ) : null}
          {Number(cfg.rewards?.share) > 0 && !me.shareRewarded && !me.banned ? (
            <Btn style={{ marginTop: 8 }} kind="out" icon="share-social-outline" title={`Arkadaşına öner, +${Number(cfg.rewards.share)} anahtar`} onPress={onShare} />
          ) : null}
        </Card>
      )}

      <Card>
        <Text style={s.h3}>Görünüm</Text>
        <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4 }}>
          {[['light', '☀️ Açık'], ['dark', '🌙 Koyu'], ['system', '📱 Otomatik']].map(([k, l]) => (
            <Pressable key={k} onPress={() => th.setPref && th.setPref(k)} accessibilityRole="tab" accessibilityState={{ selected: th.pref === k }}
              style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: th.pref === k ? C.card : 'transparent' }}>
              <Text style={{ fontWeight: th.pref === k ? '800' : '600', color: th.pref === k ? C.ink : C.mut, fontSize: 14 }}>{l}</Text>
            </Pressable>
          ))}
        </View>
      </Card>

      {socials.length ? (
        <Card>
          <Text style={s.h3}>Bizi takip et</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {socials.map(([k, icon, col]) => (
              <Pressable key={k} onPress={() => Linking.openURL(L[k])} accessibilityLabel={k} accessibilityRole="link"
                style={{ width: 52, height: 52, borderRadius: 16, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={icon} size={26} color={col} />
              </Pressable>
            ))}
          </View>
        </Card>
      ) : null}

      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          {isAdmin || canModerate(me) ? <Link icon="construct-outline" title={me.role === 'mod' ? 'Moderatör paneli' : 'Yönetim paneli'} sub={me.role === 'mod' ? 'Yorumlar, şikayetler, kullanıcılar' : 'Maç, kupon, kullanıcı ve ayarlar'} onPress={onAdmin} /> : null}
          <Link icon="help-circle-outline" title="Nasıl kullanılır?" sub="Tanıtımı tekrar göster" onPress={onOnb} />
          <Link icon="bookmark-outline" title={`Kaydedilenler${saved.length ? ` (${saved.length})` : ''}`} sub="Yer imine eklediğin maçlar ve kuponlar" onPress={() => setKayit(true)} />
          <Link icon="notifications-outline" title="Bildirim ayarları" sub="Hangi bildirimleri almak istediğini seç" onPress={() => setBild(true)} />
          <Link icon="mail-unread-outline" title="Öneri ve şikayet" sub={newReplies ? `💬 ${newReplies} yeni cevap var!` : 'Fikrini, sorununu bize yaz'} onPress={openFb} />
          <Link icon="star-outline" title="Uygulamayı değerlendir" sub="Görüşün bizim için önemli" onPress={onRate} />
          <Link icon="share-social-outline" title="Arkadaşına öner" onPress={onShare} />
          <Link icon="shield-checkmark-outline" title="Sorumlu oyun" sub="18+ · Bilgilendirme" onPress={onRG} />
          {/^https?:\/\//i.test(cfg.links?.support || '') ? <Link icon="chatbubbles-outline" title="Bize ulaş" sub="Soru, öneri ve destek" onPress={() => Linking.openURL(cfg.links.support)} /> : null}
          {/^https?:\/\//i.test(cfg.links?.privacy || '') ? <Link icon="document-text-outline" title="Gizlilik politikası" onPress={() => Linking.openURL(cfg.links.privacy)} /> : null}
          {!me.guest ? <Link icon="log-out-outline" title="Çıkış yap" onPress={onLogout} /> : null}
          {!me.guest ? <Link icon="trash-outline" title="Hesabımı sil" sub="Hesabın ve anahtarların kalıcı olarak silinir"
            onPress={() => Alert.alert('Hesabın silinsin mi?', 'Bu işlem geri alınamaz. Anahtarların ve açtığın tahminler silinir.', [
              { text: 'Vazgeç', style: 'cancel' },
              { text: 'Sil', style: 'destructive', onPress: onDelete },
            ])} /> : null}
        </View>
      </Card>
      {kayit ? <Kaydedilenler saved={saved} matches={matches} coupons={coupons} me={me} onClose={() => setKayit(false)}
        onMatch={(m) => { setKayit(false); setTimeout(() => onMatch(m), 250); }} onCoupons={() => { setKayit(false); onNav && onNav('coupons'); }} /> : null}
      {bild ? <BildirimAyar onClose={() => setBild(false)} /> : null}
      {fb ? <OneriSikayet me={me} mine={myFb.list} onClose={() => setFb(false)} /> : null}
      {edit ? <ProfilDuzenle me={me} onUpdate={onUpdate} onClose={() => setEdit(false)} /> : null}
    </View>
  );
}

/* ---------------- Profil düzenle: avatar, isim, favori takım ---------------- */
function ProfilDuzenle({ me, onUpdate, onClose }) {
  const toast = useToast();
  const teams = useTeams();
  const [avatar, setAvatar] = useState(me.avatar || '');
  const [name, setName] = useState(me.name || '');
  const [fav, setFav] = useState(me.favTeam || '');
  const sug = suggestTeams(teams.list, fav);
  const save = () => {
    const n = name.trim().slice(0, 30);
    if (!n) return toast('İsmini yaz');
    const tm = findTeam(teams.list, fav);
    onUpdate && onUpdate(() => ({ avatar, name: n, favTeam: tm ? tm.name : fav.trim().slice(0, 40) }));
    toast('Profil kaydedildi');
    onClose();
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>Profilim</Text>
      <Text style={[s.label, { marginTop: 14 }]}>Avatarını seç</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
        {['', ...AVATARS].map((e) => (
          <Pressable key={e || 'harf'} onPress={() => setAvatar(e)} accessibilityLabel={e || 'Baş harf'}
            style={{ padding: 3, borderRadius: 26, borderWidth: 2, borderColor: avatar === e ? C.key : 'transparent' }}>
            <Avatar emoji={e} name={name || me.email} size={42} />
          </Pressable>
        ))}
      </View>
      <Field label="Görünen adın" value={name} onChangeText={setName} maxLength={30} placeholder="Örn. Cesaret" />
      <Field label="Favori takımın" value={fav} onChangeText={setFav} placeholder="Örn. Galatasaray" />
      {sug.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: -6, marginBottom: 12 }}>
          {sug.map((tm) => (
            <Pressable key={tm.id} onPress={() => setFav(tm.name)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, minHeight: 36, borderRadius: 18, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border }}>
              <Crest name={tm.name} logo={tm.logo} size={20} />
              <Text style={{ color: C.ink, fontWeight: '600' }}>{tm.name}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      <Text style={[s.sub, { fontSize: 13.5, marginBottom: 12 }]}>Favori takımının maçları en üstte ⭐ ile görünür ve maçtan 15 dk önce otomatik hatırlatılır.</Text>
      <Btn title="Kaydet" onPress={save} />
      <Btn kind="ghost" title="Vazgeç" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Öneri & şikayet ---------------- */
function OneriSikayet({ me, mine = [], onClose }) {
  const toast = useToast();
  const [kind, setKind] = useState('oneri');
  const [text, setText] = useState('');
  const [contact, setContact] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    const v = text.trim();
    if (v.length < 5) return toast('Biraz daha detaylı yaz');
    setBusy(true);
    try {
      await addFeedback({ kind, text: v, contact: contact.trim() || (me && !me.guest ? me.email : ''), uid: me && !me.guest ? me.id : '', name: me && !me.guest ? me.name : 'Misafir' });
      toast('Teşekkürler! Mesajın bize ulaştı 🙏');
      setText('');
    } catch (e) { toast('Gönderilemedi, internetini kontrol et'); }
    setBusy(false);
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>Öneri ve şikayet</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Uygulamayı birlikte geliştirelim. Her mesajı okuyoruz.</Text>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 12 }}>
        {[['oneri', '💡 Öneri'], ['sikayet', '⚠️ Şikayet'], ['hata', '🐞 Hata']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setKind(k)} accessibilityRole="tab" accessibilityState={{ selected: kind === k }}
            style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: kind === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: kind === k ? '800' : '600', color: kind === k ? C.ink : C.mut }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      <Field label="Mesajın" value={text} onChangeText={setText} multiline maxLength={1000}
        placeholder={kind === 'oneri' ? 'Uygulamada ne olsun istersin?' : kind === 'hata' ? 'Ne oldu, hangi ekranda?' : 'Neden memnun kalmadın?'} style={{ marginBottom: 8 }} />
      {!me || me.guest ? <Field label="Sana nasıl dönelim? (isteğe bağlı)" value={contact} onChangeText={setContact} placeholder="E-posta" autoCapitalize="none" keyboardType="email-address" /> : null}
      <Btn title="Gönder" icon="send" onPress={send} loading={busy} />
      {mine.length ? (
        <View style={{ marginTop: 18 }}>
          <Text style={s.h3}>Mesajlarım</Text>
          {mine.map((f) => (
            <View key={f.id} style={{ backgroundColor: C.bg, borderRadius: 14, padding: 12, marginBottom: 8 }}>
              <Text style={{ color: C.mut, fontSize: 12 }}>{f.kind === 'oneri' ? '💡 Öneri' : f.kind === 'hata' ? '🐞 Hata' : '⚠️ Şikayet'} · {onceLabel(f.createdAt)}</Text>
              <Text style={{ color: C.ink, marginTop: 4, lineHeight: 20 }}>{f.text}</Text>
              {f.reply ? (
                <View style={{ backgroundColor: C.okBg, borderRadius: 12, padding: 10, marginTop: 8 }}>
                  <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 12 }}>💬 {f.replyBy || 'Destek'} cevapladı · {onceLabel(f.repliedAt)}</Text>
                  <Text style={{ color: C.ink, marginTop: 4, lineHeight: 20 }}>{f.reply}</Text>
                </View>
              ) : <Text style={{ color: C.mut, fontSize: 12.5, marginTop: 6 }}>⏳ Cevap bekleniyor</Text>}
            </View>
          ))}
        </View>
      ) : null}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Kaydedilenler ---------------- */
function Kaydedilenler({ saved, matches, coupons, me, onClose, onMatch, onCoupons }) {
  const items = saved.map((x) => ({ x, m: x.k === 'm' ? matches.list.find((m) => m.id === x.id) : null, c: x.k === 'c' ? (coupons?.list || []).find((c) => c.id === x.id) : null }))
    .filter((y) => y.m || y.c);
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>🔖 Kaydedilenler</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Maç detayındaki ve kuponlardaki 🔖 işaretiyle eklersin.</Text>
      {!items.length ? <View style={s.empty}><Text style={[s.sub, { textAlign: 'center' }]}>Henüz kaydettiğin bir şey yok.</Text></View> : items.map(({ x, m, c }) => (
        <View key={x.k + x.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ flex: 1 }}>
            {m ? <MacSatiri m={m} me={me} onPress={() => onMatch(m)} /> : (
              <Pressable onPress={onCoupons} style={s.row}>
                <Icon name="receipt-outline" size={24} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700', color: C.ink }}>{c.title || 'Günün Kuponu'}</Text>
                  <Text style={{ color: C.mut, fontSize: 13 }}>{c.date} · {(c.picks || []).length} maç</Text>
                </View>
              </Pressable>
            )}
          </View>
          <Pressable onPress={() => toggleSaved(x)} accessibilityLabel="Kayıttan çıkar" hitSlop={6} style={{ width: 36, height: 36, alignItems: 'center', justifyContent: 'center', marginBottom: 10 }}>
            <Icon name="close" size={18} color={C.mut} />
          </Pressable>
        </View>
      ))}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Bildirim ayarları ---------------- */
function BildirimAyar({ onClose }) {
  const toast = useToast();
  const [p, setP] = useState(null);
  React.useEffect(() => { getPrefs().then(setP); }, []);
  const set = (k, v) => { const n = { ...p, [k]: v }; setP(n); savePrefs(n).catch(() => {}); };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>🔔 Bildirim ayarları</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Kapattığın türde bildirim gelmez. Mesaj cevapları her zaman gelir.</Text>
      {!p ? <Text style={s.sub}>Yükleniyor…</Text> : PREF_LIST.map(([k, l]) => (
        <Toggle key={k} label={l} value={p[k] !== false} onChange={(v) => set(k, v)} />
      ))}
      <Btn title="Tamam" onPress={() => { toast('Kaydedildi'); onClose(); }} style={{ marginTop: 8 }} />
    </Sheet>
  );
}
