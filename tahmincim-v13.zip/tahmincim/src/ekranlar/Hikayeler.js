// Instagram hikayesi gibi üst halkalar: yeni içerik varsa renkli yanar
import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { C, today, weekStart, couponPicks, couponStatus, canPredictScore } from '../tema';
import { useTheme } from '../parcalar';
import { titret } from '../efekt';

const KEY = 'tahmincim_hikaye';

export default function Hikayeler({ matches, coupons, onMatch, onNav }) {
  const t = useTheme();
  const [seen, setSeen] = useState({});
  useEffect(() => { AsyncStorage.getItem(KEY).then((v) => setSeen(JSON.parse(v || '{}') || {})).catch(() => {}); }, []);
  const td = today();
  const L = matches.list.filter((m) => !m.hidden);
  const banko = L.find((m) => m.date === td && m.banko);
  const cps = (coupons?.list || []).filter((c) => c.date === td);
  const live = L.filter((m) => m.status === 'live').length;
  const open = L.filter((m) => canPredictScore(m)).length;
  const won = (coupons?.list || []).filter((c) => couponStatus(couponPicks(c, matches.list)) === 'won').length;
  const items = [
    banko && { k: 'banko', e: '🔥', l: 'Banko', sig: banko.id + (banko.status || ''), go: () => onMatch(banko) },
    cps.length && { k: 'kupon', e: '🎫', l: 'Kupon', sig: cps.map((c) => c.id).join(','), go: () => onNav('coupons') },
    live && { k: 'canli', e: '🔴', l: `Canlı (${live})`, sig: td + '_' + live, go: () => onNav('live') },
    open && { k: 'skor', e: '⚽', l: 'Skor Ligi', sig: td + '_' + open, go: () => onNav('coupons', 'score') },
    { k: 'hafta', e: '🏆', l: 'Haftalık', sig: String(weekStart()), go: () => onNav('coupons', 'rank') },
    won && { k: 'kazanan', e: '✅', l: 'Kazananlar', sig: String(won), go: () => onNav('coupons', 'won') },
  ].filter(Boolean);
  if (items.length < 2) return null;
  const press = (it) => {
    titret('hafif');
    const n = { ...seen, [it.k]: it.sig };
    setSeen(n);
    AsyncStorage.setItem(KEY, JSON.stringify(n)).catch(() => {});
    it.go();
  };
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -18, marginBottom: 14 }} contentContainerStyle={{ paddingHorizontal: 18, gap: 14 }}>
      {items.map((it) => {
        const fresh = seen[it.k] !== it.sig;
        return (
          <Pressable key={it.k} onPress={() => press(it)} accessibilityRole="button" accessibilityLabel={it.l} style={{ alignItems: 'center', width: 70 }}>
            <View style={{ width: 66, height: 66, borderRadius: 33, padding: 3, borderWidth: 2.5, borderColor: fresh ? t.acc : C.border }}>
              <View style={{ flex: 1, borderRadius: 30, backgroundColor: it.k === 'canli' ? C.redBg : it.k === 'banko' ? C.hero : C.card, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 26 }}>{it.e}</Text>
              </View>
            </View>
            <Text numberOfLines={1} style={{ fontSize: 12, marginTop: 5, color: fresh ? C.ink : C.mut, fontWeight: fresh ? '700' : '500' }}>{it.l}</Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}
