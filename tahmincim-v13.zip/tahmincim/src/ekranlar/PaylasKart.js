// Kupon / maç paylaşım kartı: şık bir resim olarak WhatsApp, Instagram, TikTok'a
import React, { useRef, useState } from 'react';
import { View, Text, Image, Share } from 'react-native';
import { C, isImg } from '../tema';
import { Btn, Icon, Sheet, s, useTheme, useToast } from '../parcalar';
import { titret } from '../efekt';

let shot = null;
let sharing = null;
try { shot = require('react-native-view-shot'); } catch (e) { shot = null; }
try { sharing = require('expo-sharing'); } catch (e) { sharing = null; }

/* data: { title, sub, lines: [{ t, p, o, r }], total, status, by, text } */
export default function PaylasKart({ data, appName, logo, onClose }) {
  const t = useTheme();
  const toast = useToast();
  const ref = useRef(null);
  const [busy, setBusy] = useState(false);
  if (!data) return null;
  const won = data.status === 'won';
  const share = async () => {
    setBusy(true);
    titret('hafif');
    try {
      if (shot && sharing && ref.current) {
        const uri = await shot.captureRef(ref, { format: 'png', quality: 1, result: 'tmpfile' });
        if (await sharing.isAvailableAsync()) {
          await sharing.shareAsync(uri, { mimeType: 'image/png', dialogTitle: 'Paylaş' });
          setBusy(false);
          return;
        }
      }
      await Share.share({ message: data.text || data.title });
    } catch (e) {
      try { await Share.share({ message: data.text || data.title }); } catch (e2) { toast('Paylaşılamadı'); }
    }
    setBusy(false);
  };
  const BG = '#0E1116';
  return (
    <Sheet visible onClose={onClose}>
      <Text style={[s.h2, { marginBottom: 12 }]}>Paylaşım kartı</Text>
      <View ref={ref} collapsable={false} style={{ backgroundColor: BG, borderRadius: 26, padding: 20, overflow: 'hidden' }}>
        <View pointerEvents="none" style={{ position: 'absolute', width: 260, height: 260, borderRadius: 130, backgroundColor: won ? '#2EE59D' : t.acc, opacity: 0.14, top: -110, right: -90 }} />
        <View pointerEvents="none" style={{ position: 'absolute', width: 160, height: 160, borderRadius: 80, backgroundColor: '#FF8A1F', opacity: 0.08, bottom: -70, left: -50 }} />
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
            {isImg(logo) ? <Image source={{ uri: logo }} style={{ width: 38, height: 38 }} /> : <Icon name="checkmark" size={22} color={t.onAcc} />}
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#fff', fontWeight: '800', fontSize: 16 }}>{appName || 'Tahmincim'}</Text>
            <Text style={{ color: '#9AA3AF', fontSize: 12 }}>{data.by ? `${data.by} paylaştı` : 'Günün tahminleri'}</Text>
          </View>
          {won ? (
            <View style={{ backgroundColor: '#2EE59D', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 6 }}>
              <Text style={{ color: '#062B18', fontWeight: '900', fontSize: 13 }}>🏆 KAZANDI</Text>
            </View>
          ) : null}
        </View>
        <Text style={{ color: t.acc, fontWeight: '800', fontSize: 12, letterSpacing: 1, marginTop: 18 }}>{String(data.title || '').toLocaleUpperCase('tr')}</Text>
        {data.sub ? <Text style={{ color: '#C5CCD6', fontSize: 13, marginTop: 2 }}>📅 {data.sub}</Text> : null}
        <View style={{ gap: 8, marginTop: 12 }}>
          {(data.lines || []).slice(0, 10).map((l, i) => (
            <View key={i} style={{ backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 14, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={{ color: '#fff', fontWeight: '700', fontSize: 14 }}>{l.t}</Text>
                <Text numberOfLines={1} style={{ color: t.acc, fontWeight: '700', fontSize: 13.5 }}>{l.p}</Text>
              </View>
              {l.o ? <Text style={{ color: '#fff', fontWeight: '800' }}>{l.o}</Text> : null}
              {l.r ? <Icon name={l.r === 'won' ? 'checkmark-circle' : 'close-circle'} size={22} color={l.r === 'won' ? '#2EE59D' : '#FF6B7D'} /> : null}
            </View>
          ))}
        </View>
        {data.total ? (
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 }}>
            <Text style={{ color: '#C5CCD6' }}>Toplam oran</Text>
            <Text style={{ color: won ? '#2EE59D' : t.acc, fontSize: 28, fontWeight: '900' }}>{data.total}</Text>
          </View>
        ) : null}
        <View style={{ borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)', marginTop: 14, paddingTop: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: '#9AA3AF', fontSize: 12 }}>📲 {appName || 'Tahmincim'} uygulamasında</Text>
          <Text style={{ color: '#9AA3AF', fontSize: 12 }}>18+ · Garanti değildir</Text>
        </View>
      </View>
      <Btn icon="share-social" title="Resim olarak paylaş" onPress={share} loading={busy} style={{ marginTop: 14 }} />
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 4 }} />
    </Sheet>
  );
}
