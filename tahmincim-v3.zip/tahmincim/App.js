import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, Pressable, ScrollView, Share, Linking } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, accentOf, PLAY_PACKAGE } from './src/tema';
import { setupNotifications, registerPush } from './src/bildirim';
import { Theme, ToastHost, useToast, Icon } from './src/parcalar';
import { useConfig, useMatches, useCoupons, useAccount, logout, deleteAccount, authError } from './src/veri';
import { initAds, adsAvailable, showRewarded } from './src/reklam';
import Bugun from './src/ekranlar/Bugun';
import Canli from './src/ekranlar/Canli';
import Ben from './src/ekranlar/Ben';
import Kuponlar, { couponKey } from './src/ekranlar/Kuponlar';
import Sonuclar from './src/ekranlar/Sonuclar';
import Admin from './src/ekranlar/Admin';
import { isOpen } from './src/ekranlar/MacKart';
import { Detay, Kilit, SorumluOyun, Hesap, Tanitim, Logo, SayacReklam, Magaza, Hosgeldin } from './src/ekranlar/Pencereler';

export default function App() {
  const cfg = useConfig();
  const theme = useMemo(() => accentOf(cfg), [cfg]);
  return (
    <SafeAreaProvider>
      <Theme.Provider value={theme}>
        <ToastHost>
          <Main cfg={cfg} />
        </ToastHost>
      </Theme.Provider>
    </SafeAreaProvider>
  );
}

const TABS = [
  ['today', 'Bugün', 'football-outline'],
  ['live', 'Canlı', 'radio-outline'],
  ['coupons', 'Kuponlar', 'receipt-outline'],
  ['results', 'Sonuçlar', 'trophy-outline'],
  ['me', 'Ben', 'person-outline'],
];

function Main({ cfg }) {
  const ins = useSafeAreaInsets();
  const toast = useToast();
  const matches = useMatches();
  const coupons = useCoupons();
  const acc = useAccount(cfg.startKeys);
  const { me, updateMe, isAdmin, onboarded, setOnboarded } = acc;
  const [tab, setTab] = useState('today');
  const [detail, setDetail] = useState(null);
  const [lock, setLock] = useState(null);
  const [sheet, setSheet] = useState(null); // 'rg' | 'store' | 'welcome'
  const [authSheet, setAuthSheet] = useState(null); // { mode, reason }
  const [admin, setAdmin] = useState(null); // null | 'list' | 'new'
  const [fakeAd, setFakeAd] = useState(null); // { forId }
  const [adBusy, setAdBusy] = useState(false);

  useEffect(() => { initAds(); setupNotifications(); }, []);
  const pushId = cfg.push?.projectId;
  const uidNow = acc.user ? acc.user.uid : null;
  useEffect(() => { if (pushId) registerPush(pushId, uidNow); }, [pushId, uidNow]);

  const playUrl = `https://play.google.com/store/apps/details?id=${PLAY_PACKAGE}`;
  const rateApp = () => Linking.openURL(`market://details?id=${PLAY_PACKAGE}`).catch(() => Linking.openURL(playUrl).catch(() => {}));
  const shareApp = async () => {
    try {
      await Share.share({ message: `⚽ ${cfg.name} — günün tahminleri, banko kuponlar ve canlı tahminler tek uygulamada!\n📲 ${playUrl}\n18+` });
      const n = Number(cfg.rewards?.share) || 0;
      if (n > 0 && !me.guest && !me.shareRewarded && !me.banned) {
        updateMe((x) => ({ keys: x.keys + n, shareRewarded: true }));
        toast(`Teşekkürler! +${n} anahtar hesabına eklendi 🎁`);
      }
    } catch (e) {}
  };

  const liveCount = matches.list.filter((m) => m.status === 'live').length;
  const hour = new Date().getHours();
  const greet = hour < 6 ? 'İyi geceler' : hour < 12 ? 'Günaydın' : hour < 18 ? 'İyi günler' : 'İyi akşamlar';

  const askAuth = (reason, mode = 'register') => setAuthSheet({ mode, reason });
  const openMatch = (m) => {
    if (isOpen(m, me)) return setDetail(m);
    if (me.guest) return askAuth('Kilitli tahminleri açmak için ücretsiz kayıt ol. Anahtarların hesabında saklanır.');
    if (me.banned) return toast('Hesabın askıya alındı');
    setLock(m);
  };

  const openCouponLock = (c) => {
    if (me.guest) return askAuth('Kilitli kuponları açmak için ücretsiz kayıt ol.');
    if (me.banned) return toast('Hesabın askıya alındı');
    setLock({ id: couponKey(c), cost: c.cost, access: c.access, label: c.title || 'Günün Kuponu', date: c.date, isCoupon: true });
  };
  const opened = (t) => {
    if (t.isCoupon) toast('Kupon açıldı! 🎉');
    else { toast('Tahmin açıldı!'); setTimeout(() => setDetail(t), 350); }
  };
  const isUnlocked = (t) => (t.isCoupon ? (me.unlocked || []).includes(t.id) : isOpen(t, me));

  const unlockWithKeys = (t) => {
    const cost = Math.max(1, Number(t.cost) || 1);
    if ((me?.keys || 0) < cost) return toast('Yeterli anahtarın yok');
    updateMe((x) => ({ keys: Math.max(0, x.keys - cost), unlocked: [...x.unlocked, t.id] }));
    setLock(null);
    opened(t);
  };

  // Reklam izlendi: anahtarı ver, bir maç için izlendiyse ve yetiyorsa maçı aç
  const reward = (t) => {
    const r = Number(cfg.ads.reward) || 1;
    const m = t || null;
    const cost = m ? Math.max(1, Number(m.cost) || 1) : 0;
    const willOpen = m && !isUnlocked(m) && (me?.keys || 0) + r >= cost;
    updateMe((x) => {
      const keys = x.keys + r;
      return willOpen
        ? { keys: keys - cost, unlocked: [...x.unlocked, m.id], adCount: x.adCount + 1 }
        : { keys, adCount: x.adCount + 1 };
    });
    if (willOpen) opened(m);
    else toast(`+${r} anahtar kazandın!`);
  };

  const watchAd = async (target) => {
    const A = cfg.ads;
    if (!A.on) return;
    if (me.guest) { setLock(null); return askAuth('Reklam izleyip anahtar kazanmak için ücretsiz kayıt ol.'); }
    if (me.banned) return toast('Hesabın askıya alındı');
    if ((me?.adCount || 0) >= (Number(A.limit) || 0)) return toast('Bugünkü reklam hakkın bitti, yarın tekrar gel');
    setLock(null);
    if (!adsAvailable()) return setFakeAd({ target });
    setAdBusy(true);
    toast('Reklam yükleniyor…');
    const r = await showRewarded(A.unitId);
    setAdBusy(false);
    if (r === 'earned') reward(target);
    else if (r === 'closed') toast('Reklam yarıda kaldı, anahtar verilmedi');
    else toast('Şu an reklam yok, biraz sonra tekrar dene');
  };

  if (!acc.ready) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{ paddingTop: ins.top + 16, paddingHorizontal: 18, paddingBottom: ins.bottom + 110 }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, gap: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
            <Logo cfg={cfg} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.mut, fontSize: 13 }}>{greet}</Text>
              <Text numberOfLines={1} style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{cfg.name}</Text>
            </View>
          </View>
          {me.guest ? (
            <Pressable onPress={() => askAuth(null, 'login')} accessibilityRole="button"
              style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.ink, borderRadius: 22, paddingHorizontal: 14, minHeight: 44 }}>
              <Icon name="person-outline" size={17} color="#fff" />
              <Text style={{ fontWeight: '700', fontSize: 15, color: '#fff' }}>Giriş</Text>
            </Pressable>
          ) : (
            <Pressable onPress={() => setTab('me')} accessibilityLabel={`Anahtarların: ${me.keys}`}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.key, borderRadius: 22, paddingHorizontal: 14, minHeight: 44 }}>
              <Icon name="key" size={17} color={C.onKey} />
              <Text style={{ fontWeight: '800', fontSize: 16, color: C.onKey }}>{me.keys}</Text>
            </Pressable>
          )}
        </View>

        {tab === 'today' ? (
          <Bugun cfg={cfg} matches={matches} me={me} onMatch={openMatch} isAdmin={isAdmin} onAddMatch={() => setAdmin('new')} />
        ) : tab === 'live' ? (
          <Canli matches={matches} me={me} onMatch={openMatch} />
        ) : tab === 'coupons' ? (
          <Kuponlar coupons={coupons} matches={matches} me={me} onLocked={openCouponLock} appName={cfg.name} />
        ) : tab === 'results' ? (
          <Sonuclar matches={matches} me={me} onMatch={openMatch} />
        ) : (
          <Ben cfg={cfg} matches={matches} me={me} onMatch={openMatch} isAdmin={isAdmin}
            onAd={() => !adBusy && watchAd(null)} onAdmin={() => setAdmin('list')}
            onAuth={(mode) => askAuth(null, mode)} onLogout={() => logout().then(() => toast('Çıkış yapıldı'))}
            onOnb={() => setOnboarded(false)} onRG={() => setSheet('rg')} onBuy={() => setSheet('store')}
            onDelete={async () => { try { await deleteAccount(); toast('Hesabın silindi'); } catch (e) { toast(authError(e)); } }}
            onShare={shareApp} onRate={rateApp} />
        )}
      </ScrollView>

      {/* Alt menü */}
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8, paddingBottom: ins.bottom + 10, flexDirection: 'row' }}>
        {TABS.map(([k, label, icon]) => (
          <TabBtn key={k} on={tab === k} label={label} icon={icon} badge={k === 'live' ? liveCount : 0} onPress={() => setTab(k)} />
        ))}
      </View>

      {detail ? <Detay m={detail} appName={cfg.name} onClose={() => setDetail(null)} /> : null}
      {lock ? <Kilit m={lock} me={me} cfg={cfg} onClose={() => setLock(null)} onAd={() => watchAd(lock)} onKey={() => unlockWithKeys(lock)} onBuy={() => { setLock(null); setTimeout(() => setSheet('store'), 300); }} /> : null}
      {sheet === 'rg' ? <SorumluOyun onClose={() => setSheet(null)} /> : null}
      {sheet === 'welcome' ? <Hosgeldin cfg={cfg} me={me} onClose={() => setSheet(null)} onShare={() => { setSheet(null); setTimeout(shareApp, 300); }} onRate={rateApp} /> : null}
      {sheet === 'store' ? <Magaza cfg={cfg} me={me} onClose={() => setSheet(null)} onSoon={() => toast('Satın alma, uygulama Google Play\'e çıkınca açılacak')} /> : null}
      {authSheet ? <Hesap startMode={authSheet.mode} reason={authSheet.reason} startKeys={cfg.startKeys} onClose={() => setAuthSheet(null)} onDone={(msg, kind) => (kind === 'register' ? setTimeout(() => setSheet('welcome'), 400) : toast(msg))} /> : null}
      <Admin visible={!!admin && isAdmin} startWith={admin} onClose={() => setAdmin(null)} matches={matches} coupons={coupons} cfg={cfg} />
      <SayacReklam visible={!!fakeAd} cfg={cfg} seconds={15}
        onCancel={() => { setFakeAd(null); toast('Reklam yarıda kaldı, anahtar verilmedi'); }}
        onDone={() => { const f = fakeAd; setFakeAd(null); reward(f?.target); }} />
      <Tanitim visible={!onboarded} cfg={cfg} onDone={() => setOnboarded(true)} />
    </View>
  );
}

function TabBtn({ on, label, icon, badge, onPress }) {
  const t = React.useContext(Theme);
  return (
    <Pressable onPress={onPress} accessibilityRole="tab" accessibilityState={{ selected: on }} style={{ flex: 1, alignItems: 'center', gap: 4, minHeight: 52 }}>
      <ThemedPill on={on}><Icon name={on ? icon.replace('-outline', '') : icon} size={22} color={on ? t.onAcc : C.mut} /></ThemedPill>
      <Text numberOfLines={1} style={{ fontSize: 12, fontWeight: on ? '700' : '600', color: on ? C.ink : C.mut }}>{label}</Text>
      {badge ? (
        <View style={{ position: 'absolute', top: 0, left: '58%', backgroundColor: '#E5484D', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
          <Text style={{ color: '#fff', fontSize: 10.5, fontWeight: '700' }}>{badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

function ThemedPill({ on, children }) {
  const t = React.useContext(Theme);
  return <View style={{ paddingHorizontal: 14, paddingVertical: 5, borderRadius: 16, backgroundColor: on ? t.acc : 'transparent' }}>{children}</View>;
}
