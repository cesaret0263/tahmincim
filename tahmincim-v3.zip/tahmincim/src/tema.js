export const C = {
  bg: '#F4F5F0',
  ink: '#12161C',
  mut: '#5B6470',
  line: '#E2E5DD',
  card: '#FFFFFF',
  key: '#FF8A1F',
  onKey: '#2A1400',
  lockBg: '#FFF1E3',
  lockTx: '#8A3A00',
  vipBg: '#FFF6D6',
  vipTx: '#6B4D00',
  okBg: '#E6FBEF',
  okTx: '#047A42',
  red: '#B42318',
  redBg: '#FDE8E8',
  dark2: '#262C35',
  adminBg: '#EEF0EA',
};

export const DEFAULT_CFG = {
  name: 'Tahmincim',
  logo: '',
  color: '#00D26A',
  startKeys: 3,
  message: { on: false, text: '', type: 'info' },
  ads: { on: true, unitId: '', reward: 1, limit: 10, bannerImg: '', bannerLink: '' },
  links: { support: '', privacy: '' },
  push: { projectId: '' },
  rewards: { share: 2 },
  store: { on: true, packs: [{ keys: 5, price: '₺19,99' }, { keys: 15, price: '₺49,99' }, { keys: 40, price: '₺99,99' }] },
};

export function mergeCfg(c) {
  const o = JSON.parse(JSON.stringify(DEFAULT_CFG));
  if (c && typeof c === 'object') {
    Object.assign(o, c);
    o.message = { ...DEFAULT_CFG.message, ...(c.message || {}) };
    o.ads = { ...DEFAULT_CFG.ads, ...(c.ads || {}) };
    o.store = { ...DEFAULT_CFG.store, ...(c.store || {}) };
    o.links = { ...DEFAULT_CFG.links, ...(c.links || {}) };
    o.push = { ...DEFAULT_CFG.push, ...(c.push || {}) };
    o.rewards = { ...DEFAULT_CFG.rewards, ...(c.rewards || {}) };
    if (!Array.isArray(o.store.packs)) o.store.packs = DEFAULT_CFG.store.packs;
  }
  return o;
}

export const MARKETS = [
  ['MS 1', '{h} kazanır'],
  ['MS X', 'Maç berabere biter'],
  ['MS 2', '{a} kazanır'],
  ['2.5 Üst', 'Maçta 3 veya daha fazla gol olur'],
  ['2.5 Alt', 'Maçta en fazla 2 gol olur'],
  ['KG Var', 'İki takım da gol atar'],
  ['KG Yok', 'En az bir takım gol atamaz'],
  ['1.5 Üst', 'Maçta 2 veya daha fazla gol olur'],
  ['İY 0.5 Üst', 'İlk yarıda gol olur'],
  ['1X', '{h} kaybetmez'],
  ['X2', '{a} kaybetmez'],
  ['Diğer', ''],
];
export const CONF = ['Zayıf', 'Orta', 'Güçlü'];

export function marketText(market, home, away) {
  const f = MARKETS.find((x) => x[0] === market);
  return ((f && f[1]) || '').replace('{h}', home || '').replace('{a}', away || '');
}
export function predText(m) {
  return m.text || marketText(m.market, m.home, m.away) || m.market || '';
}

export function lum(hex) {
  const r = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!r) return 1;
  const n = parseInt(r[1], 16);
  const c = [n >> 16, (n >> 8) & 255, n & 255].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}
export function accentOf(cfg) {
  const acc = /^#[0-9a-f]{6}$/i.test(cfg?.color || '') ? cfg.color : '#00D26A';
  return { acc, onAcc: lum(acc) > 0.35 ? '#0B2416' : '#FFFFFF' };
}

export function hashColor(s) {
  let h = 0;
  for (const ch of String(s || '')) h = (h * 31 + ch.charCodeAt(0)) | 0;
  const p = ['#E2231A', '#1D4BA8', '#2B2F36', '#7A1F3D', '#0E7C4A', '#C25400', '#5B3FD1', '#0B6E99', '#A3122E', '#3D5A1E'];
  return p[Math.abs(h) % p.length];
}
export function initials(n) {
  const w = String(n || '?').trim().split(/\s+/);
  return (w.length > 1 ? w[0][0] + w[1][0] : w[0].slice(0, 3)).toUpperCase();
}

export function ymd(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
export function dayOff(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return ymd(d);
}
export const today = () => ymd(new Date());

export function isImg(u) {
  return typeof u === 'string' && /^data:image\/(png|jpeg|webp);base64,/.test(u);
}
export function scoreOf(m) {
  const s = String(m.score || '').split('-');
  return [(s[0] || '0').trim(), (s[1] || '0').trim()];
}
export const byTime = (a, b) => String(a.time || '').localeCompare(String(b.time || ''));
export const newId = () => 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* ---------- kupon yardımcıları ---------- */
export const oddOf = (v) => {
  const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  return isFinite(n) && n > 0 ? n : 0;
};
export function couponPicks(c, matchList) {
  const byId = {};
  (matchList || []).forEach((m) => { byId[m.id] = m; });
  return (c.picks || []).map((p) => ({ ...p, m: byId[p.matchId] || null }));
}
export function couponTotal(picks) {
  const odds = picks.map((p) => oddOf(p.odd || (p.m && p.m.odd))).filter((x) => x > 0);
  return odds.length ? odds.reduce((a, b) => a * b, 1) : 0;
}
export function couponStatus(picks) {
  if (!picks.length) return 'pending';
  const res = picks.map((p) => (p.m && p.m.status === 'finished' ? p.m.result : ''));
  if (res.some((r) => r === 'lost')) return 'lost';
  if (res.every((r) => r === 'won')) return 'won';
  return 'pending';
}

const AYLAR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const GUNLER = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
// "2026-11-21" -> "21 Kasım Cumartesi" (bugün/yarın/dün ise başına eklenir)
export function dayLabel(d, withRel = true) {
  if (!d || !/^\d{4}-\d{2}-\d{2}$/.test(d)) return '';
  const [y, m, g] = d.split('-').map(Number);
  const dt = new Date(y, m - 1, g);
  const base = `${g} ${AYLAR[m - 1]} ${GUNLER[dt.getDay()]}`;
  if (!withRel) return base;
  const rel = d === dayOff(0) ? 'Bugün' : d === dayOff(1) ? 'Yarın' : d === dayOff(-1) ? 'Dün' : '';
  return rel ? `${rel} · ${base}` : base;
}

export const PLAY_PACKAGE = 'com.tahmincim.app';
