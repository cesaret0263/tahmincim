import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { C, predText, scoreOf, dayLabel } from '../tema';
import { Crest, Chip, ConfBars, Icon, s, useTheme } from '../parcalar';

export const isVip = (me) => !!me && !me.banned && Number(me.vipUntil || 0) > Date.now();
export const isOpen = (m, me) =>
  m.access === 'open' || m.status === 'finished' || isVip(me) || (!me?.banned && (me?.unlocked || []).includes(m.id));

function Right({ m, me }) {
  if (m.status === 'finished' && m.result)
    return m.result === 'won' ? <Chip text="Tuttu ✓" bg={C.okBg} color={C.okTx} /> : <Chip text="Tutmadı ✕" bg={C.redBg} color={C.red} />;
  if (m.status === 'live' || m.status === 'finished') {
    const sc = scoreOf(m);
    return (
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={{ fontSize: 19, fontWeight: '800', color: C.ink }}>{sc[0]}</Text>
        <Text style={{ fontSize: 19, fontWeight: '800', color: C.ink }}>{sc[1]}</Text>
      </View>
    );
  }
  if (isOpen(m, me)) return <Chip text={m.market && m.market !== 'Diğer' ? m.market : 'Tahmin'} bg={C.okBg} color={C.okTx} />;
  return m.access === 'vip' ? <Chip text="VIP" icon="diamond-outline" bg={C.vipBg} color={C.vipTx} /> : <Chip text="Aç" icon="lock-closed" bg={C.lockBg} color={C.lockTx} />;
}

export function MacSatiri({ m, me, onPress }) {
  const live = m.status === 'live';
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={`${m.home} - ${m.away}`} style={({ pressed }) => [s.row, pressed && { opacity: 0.85 }]}>
      <Text style={{ width: 48, fontWeight: '700', fontSize: 14, color: live ? C.red : C.ink }}>
        {live ? `${m.minute || ''}'` : m.status === 'finished' ? 'Bitti' : m.time}
      </Text>
      <View style={{ flex: 1, gap: 4 }}>
        {[[m.home, m.homeLogo], [m.away, m.awayLogo]].map(([n, l], i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Crest name={n} logo={l} size={22} />
            <Text numberOfLines={1} style={{ fontWeight: '600', fontSize: 15, color: C.ink, flex: 1 }}>{n}</Text>
          </View>
        ))}
      </View>
      <Right m={m} me={me} />
    </Pressable>
  );
}

export function BankoKart({ m, me, onPress }) {
  const t = useTheme();
  const open = isOpen(m, me);
  const showScore = m.status === 'live' || m.status === 'finished';
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={({ pressed }) => [{ backgroundColor: C.ink, borderRadius: 26, padding: 20, marginTop: 14 }, pressed && { opacity: 0.92 }]}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: t.acc, fontWeight: '800', fontSize: 12, letterSpacing: 1 }}>GÜNÜN BANKOSU</Text>
        <Text style={{ color: '#C5CCD6', fontSize: 14 }}>{m.status === 'live' ? `Canlı ${m.minute || ''}'` : m.time}</Text>
      </View>
      <Text style={{ color: '#C5CCD6', fontSize: 13, marginTop: 2 }}>📅 {dayLabel(m.date)}{m.league ? ` · ${m.league}` : ''}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: 16 }}>
        {[[m.home, m.homeLogo], null, [m.away, m.awayLogo]].map((x, i) =>
          x ? (
            <View key={i} style={{ width: '40%', alignItems: 'center', gap: 8 }}>
              <Crest name={x[0]} logo={x[1]} size={52} />
              <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '600', fontSize: 15, textAlign: 'center' }}>{x[0]}</Text>
            </View>
          ) : (
            <Text key={i} style={{ color: showScore ? '#fff' : '#8C96A3', fontSize: showScore ? 30 : 18, fontWeight: '800' }}>
              {showScore ? scoreOf(m).join(' – ') : 'vs'}
            </Text>
          )
        )}
      </View>
      {open ? (
        <View style={{ backgroundColor: t.acc, borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <Text style={{ color: t.onAcc, fontWeight: '800', fontSize: 17, flex: 1 }}>{predText(m)}</Text>
          {m.status === 'finished' && m.result ? (
            <Text style={{ color: t.onAcc, fontWeight: '700' }}>{m.result === 'won' ? 'Tuttu ✓' : 'Tutmadı'}</Text>
          ) : (
            <ConfBars n={m.conf || 3} color={t.onAcc} />
          )}
        </View>
      ) : (
        <View style={{ backgroundColor: C.dark2, borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Icon name="lock-closed" color="#fff" size={18} />
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16, flex: 1 }}>Tahmini görmek için dokun</Text>
          {m.access === 'vip' ? <Text style={{ color: '#FFD666', fontWeight: '800' }}>VIP</Text> : null}
        </View>
      )}
    </Pressable>
  );
}
