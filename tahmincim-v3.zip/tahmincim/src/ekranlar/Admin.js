import React, { useState } from 'react';
import { View, Text, Pressable, Modal, ScrollView, Image, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import { C, MARKETS, marketText, today, dayOff, newId, isImg, predText, oddOf, couponPicks, couponTotal, couponStatus } from '../tema';
import { Btn, Card, Crest, Field, Icon, Seg, Toggle, s, useToast } from '../parcalar';
import { saveMatch, removeMatch, saveConfig, clearBanko, logout, useUsers, updateUser, saveCoupon, removeCoupon } from '../veri';
import { sendPushAll, countDevices, notifHistory } from '../bildirim';

/* Görseli küçültüp veritabanına sığacak hale getirir */
async function pickImage(maxSide, jpeg) {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('perm');
  const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 1, allowsEditing: !jpeg, aspect: [1, 1] });
  if (res.canceled || !res.assets?.length) return null;
  const a = res.assets[0];
  if (typeof ImageManipulator.manipulateAsync !== 'function') {
    // Yedek yol: küçültme aracı yoksa düşük kalitede yeniden seç
    const r2 = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.2, base64: true, allowsEditing: true, aspect: jpeg ? [3, 1] : [1, 1] });
    if (r2.canceled || !r2.assets?.[0]?.base64) return null;
    const u = `data:image/jpeg;base64,${r2.assets[0].base64}`;
    if (u.length > 300000) throw new Error('big');
    return u;
  }
  const scale = Math.min(1, maxSide / Math.max(a.width || maxSide, a.height || maxSide));
  const out = await ImageManipulator.manipulateAsync(
    a.uri,
    scale < 1 ? [{ resize: { width: Math.round((a.width || maxSide) * scale) } }] : [],
    { compress: jpeg ? 0.8 : 1, format: jpeg ? ImageManipulator.SaveFormat.JPEG : ImageManipulator.SaveFormat.PNG, base64: true }
  );
  const url = `data:image/${jpeg ? 'jpeg' : 'png'};base64,${out.base64}`;
  if (url.length > 300000) throw new Error('big');
  return url;
}

function Header({ title, onBack, right }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 }}>
      <Pressable onPress={onBack} accessibilityLabel="Geri" style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="chevron-back" />
      </Pressable>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 12, fontWeight: '700', letterSpacing: 1, color: C.mut }}>ADMİN PANELİ</Text>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{title}</Text>
      </View>
      {right}
    </View>
  );
}

const ACCESS = { open: 'Açık', locked: 'Kilitli', vip: 'VIP' };

export default function Admin({ visible, onClose, matches, coupons, cfg, startWith }) {
  const ins = useSafeAreaInsets();
  const [page, setPage] = useState('list');
  const [m, setM] = useState(null);
  const [c, setC] = useState(null);
  const [uid, setUid] = useState(null);
  const [co, setCo] = useState(null);
  const [listTab, setListTab] = useState('matches');
  const users = useUsers(visible && (page === 'users' || page === 'user'));

  React.useEffect(() => {
    if (visible && startWith === 'new') { setM(blank()); setPage('match'); }
    else if (visible) setPage('list');
  }, [visible, startWith]);

  const blankCoupon = () => ({ id: newId(), title: 'Günün Kuponu', date: today(), access: 'open', cost: 1, picks: [], isNew: true });
  const blank = () => ({ id: newId(), odd: '', home: '', away: '', homeLogo: '', awayLogo: '', league: '', date: today(), time: '20:00', market: 'MS 1', marketOther: '', text: '', conf: 3, reasons: '', access: 'open', cost: 1, banko: false, status: 'upcoming', score: '', minute: '', liveText: '', result: '', p1: '', px: '', p2: '', isNew: true });

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={() => (page === 'list' ? onClose() : setPage('list'))} statusBarTranslucent>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.adminBg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 16, paddingTop: ins.top + 16, paddingBottom: ins.bottom + 40 }} keyboardShouldPersistTaps="handled">
          {page === 'list' ? (
            <List matches={matches} coupons={coupons} tab={listTab} setTab={setListTab} onClose={onClose}
              onNewCoupon={() => { setCo(blankCoupon()); setPage('coupon'); }}
              onEditCoupon={(x) => { setCo(JSON.parse(JSON.stringify({ ...x, picks: x.picks || [] }))); setPage('coupon'); }}
              onNew={() => { setM(blank()); setPage('match'); }}
              onEdit={(x) => { setM({ ...x }); setPage('match'); }}
              onCfg={() => { setC(JSON.parse(JSON.stringify(cfg))); setPage('cfg'); }}
              onUsers={() => setPage('users')} onPush={() => setPage('push')} />
          ) : page === 'match' && m ? (
            <MatchForm m={m} setM={setM} all={matches.list} onBack={() => setPage('list')} />
          ) : page === 'cfg' && c ? (
            <CfgForm c={c} setC={setC} onBack={() => setPage('list')} />
          ) : page === 'coupon' && co ? (
            <CouponForm co={co} setCo={setCo} matches={matches} onBack={() => setPage('list')} />
          ) : page === 'push' ? (
            <Bildirim cfg={cfg} onBack={() => setPage('list')} />
          ) : page === 'users' ? (
            <Users users={users} onBack={() => setPage('list')} onOpen={(id) => { setUid(id); setPage('user'); }} />
          ) : page === 'user' ? (
            <UserDetail u={users.list.find((x) => x.id === uid)} onBack={() => setPage('users')} />
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

/* ---------------- Maç listesi ---------------- */
function List({ matches, coupons, tab, setTab, onClose, onNew, onEdit, onCfg, onUsers, onPush, onNewCoupon, onEditCoupon }) {
  const ms = [...matches.list].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time));
  return (
    <View>
      <Header title="Maçlar" onBack={onClose}
        right={<Pressable onPress={() => logout().then(onClose)} accessibilityLabel="Çıkış yap" style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }}><Icon name="log-out-outline" /></Pressable>} />
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
        <Btn small kind="ink" title="+ Yeni maç" onPress={onNew} style={{ flex: 1 }} />
        <Btn small kind="ink" title="+ Yeni kupon" onPress={onNewCoupon} style={{ flex: 1 }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
        <Btn small kind="out" title="Kullanıcılar" icon="people-outline" onPress={onUsers} style={{ flex: 1 }} />
        <Btn small kind="out" title="Ayarlar" icon="settings-outline" onPress={onCfg} style={{ flex: 1 }} />
      </View>
      <Btn small kind="out" title="Bildirim gönder" icon="notifications-outline" onPress={onPush} style={{ marginTop: -8, marginBottom: 16 }} />
      <Seg value={tab} onChange={setTab} options={[['matches', `Maçlar (${matches.list.length})`], ['coupons', `Kuponlar (${(coupons?.list || []).length})`]]} />
      {tab === 'coupons' ? (
        (coupons?.list || []).length ? [...coupons.list].sort((a, b) => String(b.date).localeCompare(a.date)).map((x) => {
          const pk = couponPicks(x, matches.list);
          const st = couponStatus(pk);
          const tot = couponTotal(pk);
          return (
            <Pressable key={x.id} onPress={() => onEditCoupon(x)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
              <Icon name="receipt-outline" size={26} />
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.title || 'Kupon'} · {pk.length} maç</Text>
                <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>
                  {x.date} · Oran {tot ? tot.toFixed(2) : '—'} · {ACCESS[x.access] || ''} · {st === 'won' ? 'Kazandı' : st === 'lost' ? 'Kaybetti' : 'Bekliyor'}
                </Text>
              </View>
              <Icon name="chevron-forward" color={C.mut} size={18} />
            </Pressable>
          );
        }) : <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Henüz kupon yok</Text><Text style={s.sub}>"+ Yeni kupon" ile oluştur.</Text></View>
      ) : ms.length ? ms.map((x) => (
        <Pressable key={x.id} onPress={() => onEdit(x)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
          <Crest name={x.home} logo={x.homeLogo} size={34} />
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{x.home} – {x.away}</Text>
            <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>
              {x.date} {x.time} · {x.market} · {ACCESS[x.access] || ''}{x.banko ? ' · Banko' : ''}{x.status === 'live' ? ' · CANLI' : x.status === 'finished' ? ' · Bitti' : ''}
            </Text>
          </View>
          <Icon name="chevron-forward" color={C.mut} size={18} />
        </Pressable>
      )) : (
        <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Henüz maç yok</Text><Text style={s.sub}>"+ Yeni maç" ile ilk tahminini ekle.</Text></View>
      )}
    </View>
  );
}

/* ---------------- Maç ekle / düzenle ---------------- */
function MatchForm({ m, setM, all, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const F = (k, v) => setM((x) => ({ ...x, [k]: v }));
  const autoText = marketText(m.market, m.home, m.away);

  const pickLogo = async (k) => {
    try { const u = await pickImage(128, false); if (u) F(k, u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const pickMarket = (k) => setM((x) => ({ ...x, market: k, text: !x.text || x.text === marketText(x.market, x.home, x.away) ? '' : x.text }));

  const publish = async () => {
    if (!m.home.trim() || !m.away.trim()) return toast('İki takımın adını da yaz');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(m.date)) return toast('Tarihi 2026-11-21 biçiminde yaz');
    const out = { ...m };
    delete out.isNew;
    if (out.market === 'Diğer' && out.marketOther) out.market = out.marketOther.trim();
    out.home = out.home.trim();
    out.away = out.away.trim();
    if (!out.text) out.text = marketText(out.market, out.home, out.away) || out.market;
    out.cost = Math.max(1, +out.cost || 1);
    out.conf = +out.conf || 3;
    out.updatedAt = Date.now();
    setBusy(true);
    try {
      if (out.banko) await clearBanko(all, out.date, out.id);
      await saveMatch(out);
      toast(m.isNew ? 'Maç yayınlandı' : 'Kaydedildi');
      onBack();
    } catch (e) {
      toast('Kaydedilemedi. Admin e-postanı kontrol et.');
    }
    setBusy(false);
  };

  const del = () =>
    Alert.alert('Maç silinsin mi?', `${m.home} – ${m.away} herkesten kaldırılacak.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Sil', style: 'destructive', onPress: async () => { try { await removeMatch(m.id); toast('Maç silindi'); onBack(); } catch (e) { toast('Silinemedi'); } } },
    ]);

  const LogoBtn = ({ k, label }) => (
    <Pressable onPress={() => pickLogo(k)} accessibilityLabel={label} style={{ width: 52, height: 52, borderRadius: 14, borderWidth: 2, borderStyle: 'dashed', borderColor: '#B8BDB3', backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 12 }}>
      {isImg(m[k]) ? <Image source={{ uri: m[k] }} style={{ width: 52, height: 52 }} resizeMode="contain" /> : <Icon name="add" color={C.mut} />}
    </Pressable>
  );

  return (
    <View>
      <Header title={m.isNew ? 'Yeni maç ekle' : 'Maçı düzenle'} onBack={onBack} />
      <Card>
        <Text style={s.h3}>Takımlar</Text>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <LogoBtn k="homeLogo" label="Ev sahibi logosu" />
          <Field style={{ flex: 1 }} label="Ev sahibi" value={m.home} onChangeText={(v) => F('home', v)} placeholder="Örn. Galatasaray" />
        </View>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <LogoBtn k="awayLogo" label="Deplasman logosu" />
          <Field style={{ flex: 1 }} label="Deplasman" value={m.away} onChangeText={(v) => F('away', v)} placeholder="Örn. Fenerbahçe" />
        </View>
        <Field label="Lig" value={m.league} onChangeText={(v) => F('league', v)} placeholder="Örn. Süper Lig" />
        <Text style={s.label}>Tarih</Text>
        <Seg value={m.date} onChange={(v) => F('date', v)} options={[[today(), 'Bugün'], [dayOff(1), 'Yarın'], [dayOff(2), 'Öbür gün']]} />
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Tarih (yıl-ay-gün)" value={m.date} onChangeText={(v) => F('date', v)} placeholder="2026-11-21" />
          <Field style={{ flex: 1 }} label="Saat" value={m.time} onChangeText={(v) => F('time', v)} placeholder="20:00" keyboardType="numbers-and-punctuation" />
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Tahmin</Text>
        <Seg value={m.market} onChange={pickMarket} options={MARKETS.map(([k]) => [k, k])} />
        {m.market === 'Diğer' ? <Field label="Bahis adı (isteğe bağlı)" value={m.marketOther} onChangeText={(v) => F('marketOther', v)} placeholder="Örn. Korner 9.5 Üst" /> : null}
        <Field label="Oran (isteğe bağlı, kuponlarda kullanılır)" value={String(m.odd || '')} onChangeText={(v) => F('odd', v.replace(',', '.'))} placeholder="Örn. 1.85" keyboardType="decimal-pad" />
        <Field label="Kullanıcının göreceği yazı" value={m.text || autoText} onChangeText={(v) => F('text', v)} placeholder="Örn. Maçta 3 veya daha fazla gol olur" />
        <Text style={s.label}>Güven</Text>
        <Seg value={m.conf} onChange={(v) => F('conf', v)} options={[[1, 'Zayıf'], [2, 'Orta'], [3, 'Güçlü']]} />
        <Field multiline label="Neden? (her satır bir madde, isteğe bağlı)" value={m.reasons} onChangeText={(v) => F('reasons', v)} placeholder="İki takım da son maçlarında bol gol attı" />
        <Text style={s.label}>Kazanma ihtimali % (isteğe bağlı)</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} value={String(m.p1)} onChangeText={(v) => F('p1', v)} placeholder="Ev" keyboardType="number-pad" />
          <Field style={{ flex: 1 }} value={String(m.px)} onChangeText={(v) => F('px', v)} placeholder="Ber." keyboardType="number-pad" />
          <Field style={{ flex: 1 }} value={String(m.p2)} onChangeText={(v) => F('p2', v)} placeholder="Dep." keyboardType="number-pad" />
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Kim görebilsin?</Text>
        <Seg tall value={m.access} onChange={(v) => F('access', v)} options={[['open', 'Açık', 'lock-open-outline'], ['locked', 'Kilitli', 'lock-closed-outline'], ['vip', 'VIP', 'diamond-outline']]} />
        {m.access !== 'open' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48, marginBottom: 8 }}>
            <Text style={{ fontWeight: '600', fontSize: 15 }}>Açmak için anahtar</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Btn small kind="out" title="−" onPress={() => F('cost', Math.max(1, (+m.cost || 1) - 1))} style={{ width: 48 }} />
              <Text style={{ fontSize: 20, fontWeight: '800', minWidth: 22, textAlign: 'center' }}>{+m.cost || 1}</Text>
              <Btn small kind="out" title="+" onPress={() => F('cost', Math.min(20, (+m.cost || 1) + 1))} style={{ width: 48 }} />
            </View>
          </View>
        ) : null}
        <Toggle label="Günün bankosu yap" sub="O günün en üstünde büyük kart olarak çıkar" value={m.banko} onChange={(v) => F('banko', v)} />
      </Card>

      <Card>
        <Text style={s.h3}>Maç durumu</Text>
        <Seg value={m.status} onChange={(v) => F('status', v)} options={[['upcoming', 'Başlamadı'], ['live', 'Canlı'], ['finished', 'Bitti']]} />
        {m.status !== 'upcoming' ? (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label="Skor" value={m.score} onChangeText={(v) => F('score', v)} placeholder="1-0" keyboardType="numbers-and-punctuation" />
            {m.status === 'live' ? <Field style={{ flex: 1 }} label="Dakika" value={String(m.minute)} onChangeText={(v) => F('minute', v)} placeholder="67" keyboardType="number-pad" /> : <View style={{ flex: 1 }} />}
          </View>
        ) : null}
        {m.status === 'live' ? <Field label="Canlı tahmin yazısı" value={m.liveText} onChangeText={(v) => F('liveText', v)} placeholder="Bir gol daha gelir" /> : null}
        {m.status === 'finished' ? (
          <>
            <Text style={s.label}>Tahmin sonucu</Text>
            <Seg value={m.result} onChange={(v) => F('result', v)} options={[['won', 'Tuttu'], ['lost', 'Tutmadı'], ['', 'Belirsiz']]} />
          </>
        ) : null}
      </Card>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
        {m.isNew ? <Btn kind="out" title="Vazgeç" onPress={onBack} style={{ flex: 1 }} /> : <Btn kind="out" title="Sil" onPress={del} style={{ flex: 1 }} />}
        <Btn kind="ink" title={m.isNew ? 'Yayınla' : 'Kaydet'} onPress={publish} loading={busy} style={{ flex: 2 }} />
      </View>
    </View>
  );
}

/* ---------------- Uygulama ayarları ---------------- */
const COLORS = ['#00D26A', '#2F7BFF', '#FF8A1F', '#8B5CFF', '#E5484D', '#12B5B0', '#F2C200'];

function CfgForm({ c, setC, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const set = (path, v) => setC((o) => {
    const n = JSON.parse(JSON.stringify(o));
    const p = path.split('.');
    let x = n;
    while (p.length > 1) x = x[p.shift()];
    x[p[0]] = v;
    return n;
  });
  const pick = async (path, max, jpeg) => {
    try { const u = await pickImage(max, jpeg); if (u) set(path, u); }
    catch (e) { toast(e.message === 'perm' ? 'Fotoğraflara izin vermen gerekiyor' : e.message === 'big' ? 'Görsel çok büyük' : 'Görsel alınamadı'); }
  };
  const save = async () => {
    setBusy(true);
    try {
      await saveConfig({ ...c, name: (c.name || '').trim() || 'Tahmincim' });
      toast('Ayarlar kaydedildi');
      onBack();
    } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  const M = c.message;
  const A = c.ads;
  return (
    <View>
      <Header title="Uygulama ayarları" onBack={onBack} />
      <Card>
        <Text style={s.h3}>Görünüm</Text>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 12 }}>
          <View style={{ width: 64, height: 64, borderRadius: 18, backgroundColor: c.color, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
            {isImg(c.logo) ? <Image source={{ uri: c.logo }} style={{ width: 64, height: 64 }} /> : <Text style={{ fontWeight: '700', fontSize: 12 }}>Logo</Text>}
          </View>
          <Btn small kind="out" title="Logo yükle" onPress={() => pick('logo', 256, false)} style={{ flex: 1 }} />
          {c.logo ? <Btn small kind="out" title="Kaldır" onPress={() => set('logo', '')} /> : null}
        </View>
        <Field label="Uygulama adı" value={c.name} onChangeText={(v) => set('name', v)} />
        <Text style={s.label}>Ana renk</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
          {COLORS.map((x) => (
            <Pressable key={x} onPress={() => set('color', x)} accessibilityLabel={`Renk ${x}`} accessibilityState={{ selected: c.color === x }}
              style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: x, borderWidth: c.color === x ? 3 : 0, borderColor: C.ink }} />
          ))}
        </View>
        <Field label="Yeni kullanıcıya hediye anahtar" value={String(c.startKeys)} onChangeText={(v) => set('startKeys', +v || 0)} keyboardType="number-pad" />
      </Card>

      <Card>
        <Toggle label="Sistem mesajı" sub="Ana sayfanın üstünde görünür" value={M.on} onChange={(v) => set('message.on', v)} />
        <Field multiline label="Mesaj" value={M.text} onChangeText={(v) => set('message.text', v)} placeholder="Derbi tahmini 19:00'da yayında!" />
        <Text style={s.label}>Tür</Text>
        <Seg value={M.type} onChange={(v) => set('message.type', v)} options={[['info', 'Bilgi'], ['warn', 'Uyarı'], ['camp', 'Kampanya']]} />
      </Card>

      <Card>
        <Toggle label="Reklamlar" sub="Reklamla anahtar kazanma" value={A.on} onChange={(v) => set('ads.on', v)} />
        <Field label="Ödüllü reklam birim kimliği (AdMob)" value={A.unitId} onChangeText={(v) => set('ads.unitId', v.trim())} placeholder="ca-app-pub-xxxx/yyyy (boşsa test reklamı)" autoCapitalize="none" />
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Field style={{ flex: 1 }} label="Ödül (anahtar)" value={String(A.reward)} onChangeText={(v) => set('ads.reward', +v || 1)} keyboardType="number-pad" />
          <Field style={{ flex: 1 }} label="Günlük sınır" value={String(A.limit)} onChangeText={(v) => set('ads.limit', +v || 0)} keyboardType="number-pad" />
        </View>
        <Text style={s.label}>Kendi reklam görselin (ana sayfanın altında)</Text>
        {isImg(A.bannerImg) ? <Image source={{ uri: A.bannerImg }} style={{ width: '100%', aspectRatio: 3, borderRadius: 14, marginBottom: 8 }} resizeMode="cover" /> : null}
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
          <Btn small kind="out" title={A.bannerImg ? 'Değiştir' : 'Görsel yükle'} onPress={() => pick('ads.bannerImg', 900, true)} style={{ flex: 1 }} />
          {A.bannerImg ? <Btn small kind="out" title="Kaldır" onPress={() => set('ads.bannerImg', '')} style={{ flex: 1 }} /> : null}
        </View>
        <Field label="Reklam bağlantısı (isteğe bağlı)" value={A.bannerLink} onChangeText={(v) => set('ads.bannerLink', v.trim())} placeholder="https://…" autoCapitalize="none" keyboardType="url" />
      </Card>

      <Card>
        <Toggle label="Anahtar mağazası" sub="Paketler ve fiyatlar (ödeme Google Play'e çıkınca açılır)" value={!!c.store?.on} onChange={(v) => set('store.on', v)} />
        {(c.store?.packs || []).map((p, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8 }}>
            <Field style={{ flex: 1 }} label={`Paket ${i + 1}: anahtar`} value={String(p.keys || '')} onChangeText={(v) => set(`store.packs.${i}.keys`, +v || 0)} keyboardType="number-pad" />
            <Field style={{ flex: 1 }} label="Fiyat" value={String(p.price || '')} onChangeText={(v) => set(`store.packs.${i}.price`, v)} placeholder="₺19,99" />
          </View>
        ))}
      </Card>

      <Card>
        <Text style={s.h3}>Ödüller ve bildirim</Text>
        <Field label="Arkadaşına öner (paylaş) ödülü – anahtar (0 = kapalı)" value={String(c.rewards?.share ?? 2)} onChangeText={(v) => set('rewards.share', +v || 0)} keyboardType="number-pad" />
        <Field label="Expo proje kimliği (bildirimler için, kurulumda verilecek)" value={c.push?.projectId || ''} onChangeText={(v) => set('push.projectId', v.trim())} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autoCapitalize="none" />
      </Card>

      <Card>
        <Text style={s.h3}>Bağlantılar</Text>
        <Field label="Destek / iletişim (WhatsApp, Telegram, Instagram linki)" value={c.links?.support || ''} onChangeText={(v) => set('links.support', v.trim())} placeholder="https://wa.me/90..." autoCapitalize="none" keyboardType="url" />
        <Field label="Gizlilik politikası linki" value={c.links?.privacy || ''} onChangeText={(v) => set('links.privacy', v.trim())} placeholder="https://..." autoCapitalize="none" keyboardType="url" />
      </Card>

      <Btn kind="ink" title="Kaydet" onPress={save} loading={busy} />
    </View>
  );
}

/* ---------------- Kullanıcılar ---------------- */
const isVipU = (u) => Number(u?.vipUntil || 0) > Date.now();
const fmtDate = (ms) => {
  if (!ms) return '—';
  const d = new Date(ms);
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
};

function Users({ users, onBack, onOpen }) {
  const [q, setQ] = useState('');
  const [f, setF] = useState('all');
  const L = users.list;
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const stats = [
    ['Toplam', L.length],
    ['Bugün', L.filter((u) => (u.createdAt || 0) >= dayStart.getTime()).length],
    ['VIP', L.filter(isVipU).length],
    ['Engelli', L.filter((u) => u.banned).length],
  ];
  const ql = q.trim().toLowerCase();
  const shown = L.filter((u) =>
    (f === 'all' || (f === 'vip' && isVipU(u)) || (f === 'ban' && u.banned)) &&
    (!ql || String(u.name || '').toLowerCase().includes(ql) || String(u.email || '').includes(ql)));
  return (
    <View>
      <Header title="Kullanıcılar" onBack={onBack} />
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
        {stats.map(([l, v]) => (
          <View key={l} style={{ flex: 1, backgroundColor: '#fff', borderRadius: 14, padding: 10, alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>{v}</Text>
            <Text style={{ fontSize: 12, color: C.mut }}>{l}</Text>
          </View>
        ))}
      </View>
      <Field value={q} onChangeText={setQ} placeholder="İsim veya e-posta ara" autoCapitalize="none" />
      <Seg value={f} onChange={setF} options={[['all', 'Tümü'], ['vip', 'VIP'], ['ban', 'Engelli']]} />
      {users.loading ? (
        <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View>
      ) : users.error ? (
        <View style={s.empty}><Text style={[s.sub, { textAlign: 'center' }]}>Kullanıcılar okunamadı. Firebase kurallarını güncelledin mi?</Text></View>
      ) : !shown.length ? (
        <View style={s.empty}><Text style={s.sub}>Kullanıcı yok</Text></View>
      ) : shown.map((u) => (
        <Pressable key={u.id} onPress={() => onOpen(u.id)} accessibilityRole="button" style={[s.row, { borderRadius: 18 }]}>
          <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: u.banned ? C.red : C.ink, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontWeight: '800' }}>{String(u.name || u.email || '?').slice(0, 1).toUpperCase()}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{u.name || '(isimsiz)'}{isVipU(u) ? '  👑' : ''}{u.banned ? '  ⛔' : ''}</Text>
            <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{u.email} · {fmtDate(u.createdAt)}</Text>
          </View>
          <Text style={{ fontWeight: '800', color: C.lockTx }}>🔑 {Number(u.keys) || 0}</Text>
        </Pressable>
      ))}
    </View>
  );
}

function UserDetail({ u, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!u) return <View><Header title="Kullanıcı" onBack={onBack} /><Text style={s.sub}>Kullanıcı bulunamadı.</Text></View>;
  const save = async (patch, msg) => {
    setBusy(true);
    try { await updateUser(u.id, patch); toast(msg); } catch (e) { toast('Kaydedilemedi. Firebase kurallarını kontrol et.'); }
    setBusy(false);
  };
  const keys = Number(u.keys) || 0;
  const vip = isVipU(u);
  const addVip = (days) => {
    const base = Math.max(Date.now(), Number(u.vipUntil) || 0);
    save({ vipUntil: base + days * 864e5 }, `${days} gün VIP verildi`);
  };
  return (
    <View>
      <Header title={u.name || 'Kullanıcı'} onBack={onBack} />
      <Card>
        <Text style={s.label}>E-posta</Text>
        <Text style={{ fontSize: 16, fontWeight: '600', color: C.ink, marginBottom: 10 }}>{u.email}</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <View style={{ flex: 1 }}><Text style={s.label}>Katılma</Text><Text style={{ fontWeight: '600' }}>{fmtDate(u.createdAt)}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.label}>Son giriş</Text><Text style={{ fontWeight: '600' }}>{fmtDate(u.lastSeen)}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.label}>Açtığı maç</Text><Text style={{ fontWeight: '600' }}>{(u.unlocked || []).length}</Text></View>
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Anahtar</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 16, marginBottom: 12 }}>
          <Btn small kind="out" title="−1" disabled={busy || keys <= 0} onPress={() => save({ keys: Math.max(0, keys - 1) }, 'Anahtar azaltıldı')} style={{ width: 64 }} />
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.ink, minWidth: 50, textAlign: 'center' }}>{keys}</Text>
          <Btn small kind="out" title="+1" disabled={busy} onPress={() => save({ keys: keys + 1 }, '+1 anahtar verildi')} style={{ width: 64 }} />
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[5, 10, 25].map((n) => (
            <Btn key={n} small kind="out" title={`+${n}`} disabled={busy} onPress={() => save({ keys: keys + n }, `+${n} anahtar verildi`)} style={{ flex: 1 }} />
          ))}
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>VIP üyelik</Text>
        <Text style={[s.sub, { marginBottom: 12 }]}>
          {vip ? `VIP, ${fmtDate(u.vipUntil)} tarihine kadar (${Math.ceil((u.vipUntil - Date.now()) / 864e5)} gün). Tüm kilitli ve VIP tahminleri görür.` : 'VIP değil.'}
        </Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: vip ? 8 : 0 }}>
          {[7, 30, 90].map((d) => (
            <Btn key={d} small kind="out" title={`+${d} gün`} disabled={busy} onPress={() => addVip(d)} style={{ flex: 1 }} />
          ))}
        </View>
        {vip ? <Btn small kind="out" title="VIP'i kaldır" disabled={busy} onPress={() => save({ vipUntil: 0 }, 'VIP kaldırıldı')} /> : null}
      </Card>

      <Card>
        <Toggle label="Hesabı engelle" sub="Engellenen kullanıcı kilitli tahmin açamaz, anahtar kazanamaz" value={!!u.banned}
          onChange={(v) => save({ banned: v }, v ? 'Kullanıcı engellendi' : 'Engel kaldırıldı')} />
      </Card>
    </View>
  );
}

/* ---------------- Kupon oluştur / düzenle ---------------- */
function CouponForm({ co, setCo, matches, onBack }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const F = (k, v) => setCo((x) => ({ ...x, [k]: v }));
  const picked = (id) => co.picks.find((p) => p.matchId === id);
  const toggle = (m) => setCo((x) => ({
    ...x,
    picks: x.picks.find((p) => p.matchId === m.id) ? x.picks.filter((p) => p.matchId !== m.id) : [...x.picks, { matchId: m.id, odd: m.odd ? String(m.odd) : '' }],
  }));
  const setOdd = (id, v) => setCo((x) => ({ ...x, picks: x.picks.map((p) => (p.matchId === id ? { ...p, odd: v.replace(',', '.') } : p)) }));
  const cands = matches.list
    .filter((m) => m.date === co.date || picked(m.id))
    .sort((a, b) => String(a.date + a.time).localeCompare(b.date + b.time));
  const pk = couponPicks(co, matches.list);
  const total = couponTotal(pk);

  const save = async () => {
    if (!co.picks.length) return toast('En az bir maç seç');
    const out = { ...co, cost: Math.max(1, +co.cost || 1), updatedAt: Date.now() };
    delete out.isNew;
    setBusy(true);
    try { await saveCoupon(out); toast(co.isNew ? 'Kupon yayınlandı' : 'Kupon kaydedildi'); onBack(); }
    catch (e) { toast('Kaydedilemedi. Firebase kurallarını kontrol et.'); }
    setBusy(false);
  };
  const del = () => Alert.alert('Kupon silinsin mi?', co.title || 'Kupon', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Sil', style: 'destructive', onPress: async () => { try { await removeCoupon(co.id); toast('Kupon silindi'); onBack(); } catch (e) { toast('Silinemedi'); } } },
  ]);

  return (
    <View>
      <Header title={co.isNew ? 'Yeni kupon' : 'Kuponu düzenle'} onBack={onBack} />
      <Card>
        <Field label="Kupon adı" value={co.title} onChangeText={(v) => F('title', v)} placeholder="Günün Kuponu" />
        <Text style={s.label}>Tarih</Text>
        <Seg value={co.date} onChange={(v) => F('date', v)} options={[[dayOff(-1), 'Dün'], [today(), 'Bugün'], [dayOff(1), 'Yarın']]} />
        <Field label="Tarih (yıl-ay-gün)" value={co.date} onChangeText={(v) => F('date', v)} placeholder="2026-11-21" />
      </Card>

      <Card>
        <Text style={s.h3}>Maçları seç</Text>
        <Text style={[s.sub, { marginBottom: 10 }]}>Seçtiğin tarihteki maçlar listelenir. Kupondaki tahmin, maçın kendi tahminidir.</Text>
        {!cands.length ? <Text style={s.sub}>Bu tarihte maç yok. Önce maç ekle.</Text> : cands.map((m) => {
          const p = picked(m.id);
          return (
            <View key={m.id} style={{ borderWidth: p ? 2 : 1.5, borderColor: p ? C.ink : '#D9DCD4', borderRadius: 16, padding: 12, marginBottom: 8, backgroundColor: p ? '#F4FFF8' : '#fff' }}>
              <Pressable onPress={() => toggle(m)} accessibilityRole="checkbox" accessibilityState={{ checked: !!p }} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Icon name={p ? 'checkbox' : 'square-outline'} size={24} color={p ? C.okTx : C.mut} />
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{m.home} – {m.away}</Text>
                  <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{m.time} · {m.market} · {predText(m)}</Text>
                </View>
              </Pressable>
              {p ? <Field style={{ marginTop: 10, marginBottom: 0 }} label="Oran" value={String(p.odd || '')} onChangeText={(v) => setOdd(m.id, v)} placeholder="1.85" keyboardType="decimal-pad" /> : null}
            </View>
          );
        })}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
          <Text style={{ fontWeight: '600', color: C.mut }}>{co.picks.length} maç · Toplam oran</Text>
          <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>{total ? total.toFixed(2) : '—'}</Text>
        </View>
      </Card>

      <Card>
        <Text style={s.h3}>Kim görebilsin?</Text>
        <Seg tall value={co.access} onChange={(v) => F('access', v)} options={[['open', 'Açık', 'lock-open-outline'], ['locked', 'Kilitli', 'lock-closed-outline'], ['vip', 'VIP', 'diamond-outline']]} />
        {co.access !== 'open' ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48 }}>
            <Text style={{ fontWeight: '600', fontSize: 15 }}>Açmak için anahtar</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Btn small kind="out" title="−" onPress={() => F('cost', Math.max(1, (+co.cost || 1) - 1))} style={{ width: 48 }} />
              <Text style={{ fontSize: 20, fontWeight: '800', minWidth: 22, textAlign: 'center' }}>{+co.cost || 1}</Text>
              <Btn small kind="out" title="+" onPress={() => F('cost', Math.min(50, (+co.cost || 1) + 1))} style={{ width: 48 }} />
            </View>
          </View>
        ) : null}
        <Text style={[s.sub, { marginTop: 8 }]}>Sonuç otomatik: tüm maçlar "Tuttu" olunca kupon Kazandı, biri "Tutmadı" olunca Kaybetti olur.</Text>
      </Card>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
        {co.isNew ? <Btn kind="out" title="Vazgeç" onPress={onBack} style={{ flex: 1 }} /> : <Btn kind="out" title="Sil" onPress={del} style={{ flex: 1 }} />}
        <Btn kind="ink" title={co.isNew ? 'Yayınla' : 'Kaydet'} onPress={save} loading={busy} style={{ flex: 2 }} />
      </View>
    </View>
  );
}

/* ---------------- Bildirim gönder ---------------- */
const SABLONLAR = [
  ['🔥 Günün banko kuponu yüklendi!', 'Hemen aç, kaçırma!'],
  ['⚽ Yeni tahminler yayında', 'Bugünün maçları için tahminler hazır.'],
  ['🏆 Kuponumuz kazandı!', 'Kazanan kuponu görmek için uygulamaya gir.'],
  ['🔴 Maç başlıyor', 'Canlı tahminimizi kaçırma.'],
];
function Bildirim({ cfg, onBack }) {
  const toast = useToast();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [devices, setDevices] = useState(null);
  const [hist, setHist] = useState([]);
  const load = () => {
    countDevices().then(setDevices).catch(() => setDevices(-1));
    notifHistory().then(setHist).catch(() => {});
  };
  React.useEffect(load, []);
  const ready = !!cfg.push?.projectId;
  const send = () => {
    if (!title.trim()) return toast('Başlık yaz');
    Alert.alert('Bildirim gönderilsin mi?', `${title}\n${body}\n\n${devices > 0 ? devices + ' telefona' : 'Kayıtlı tüm telefonlara'} gidecek.`, [
      { text: 'Vazgeç', style: 'cancel' },
      { text: 'Gönder', onPress: async () => {
        setBusy(true);
        try {
          const r = await sendPushAll(title.trim(), body.trim());
          toast(`${r.ok} / ${r.total} telefona gönderildi`);
          setTitle(''); setBody(''); load();
        } catch (e) { toast('Gönderilemedi, internet bağlantını kontrol et'); }
        setBusy(false);
      } },
    ]);
  };
  return (
    <View>
      <Header title="Bildirim gönder" onBack={onBack} />
      {!ready ? (
        <Card style={{ backgroundColor: C.lockBg }}>
          <Text style={{ color: C.lockTx, fontWeight: '700' }}>Bildirim kurulumu henüz tamamlanmadı.</Text>
          <Text style={{ color: C.lockTx, marginTop: 4 }}>Ayarlar → "Expo proje kimliği" alanı doldurulunca telefonlar kaydolmaya başlar.</Text>
        </Card>
      ) : null}
      <Card>
        <Text style={s.sub}>Kayıtlı telefon: <Text style={{ fontWeight: '800', color: C.ink }}>{devices == null ? '…' : devices < 0 ? '?' : devices}</Text></Text>
        <Text style={[s.label, { marginTop: 12 }]}>Hazır şablonlar</Text>
        <View style={{ gap: 8, marginBottom: 12 }}>
          {SABLONLAR.map(([t, b]) => (
            <Pressable key={t} onPress={() => { setTitle(t); setBody(b); }} accessibilityRole="button" style={{ borderWidth: 1.5, borderColor: '#D9DCD4', borderRadius: 12, padding: 12, backgroundColor: '#fff' }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{t}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>{b}</Text>
            </Pressable>
          ))}
        </View>
        <Field label="Başlık" value={title} onChangeText={setTitle} placeholder="🔥 Günün banko kuponu yüklendi!" maxLength={65} />
        <Field multiline label="Mesaj" value={body} onChangeText={setBody} placeholder="Hemen aç, kaçırma!" maxLength={180} />
        <Btn kind="ink" icon="send-outline" title="Gönder" onPress={send} loading={busy} disabled={!ready} />
      </Card>
      {hist.length ? (
        <Card>
          <Text style={s.h3}>Son gönderilenler</Text>
          {hist.map((h) => (
            <View key={h.id} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.line }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{h.title}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>{fmtDate(h.sentAt)} · {h.count}/{h.total} telefon</Text>
            </View>
          ))}
        </Card>
      ) : null}
    </View>
  );
}
