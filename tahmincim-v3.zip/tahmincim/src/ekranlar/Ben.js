import React from 'react';
import { View, Text, Pressable, Linking, Alert } from 'react-native';
import { C } from '../tema';
import { Btn, Card, Icon, s } from '../parcalar';
import { isVip } from './MacKart';

function Link({ icon, title, sub, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, borderTopWidth: 1, borderTopColor: C.line }}>
      <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={18} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>{title}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <Icon name="chevron-forward" size={18} color={C.mut} />
    </Pressable>
  );
}

export default function Ben({ cfg, matches, me, onAd, onMatch, isAdmin, onAdmin, onAuth, onLogout, onOnb, onRG, onBuy, onDelete, onShare, onRate }) {
  const A = cfg.ads;
  const left = Math.max(0, (Number(A.limit) || 0) - (me?.adCount || 0));
  const F = matches.list.filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost'));
  const won = F.filter((m) => m.result === 'won').length;
  const last = [...F].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5);

  return (
    <View>
      {me.guest ? (
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>Ücretsiz hesap aç</Text>
          <Text style={[s.sub, { marginTop: 4 }]}>
            Anahtar kazan, kilitli tahminleri aç; telefon değiştirsen bile her şey hesabında kalsın.
            {Number(cfg.startKeys) > 0 ? ` Kayıt olana ${Number(cfg.startKeys)} anahtar hediye!` : ''}
          </Text>
          <Btn style={{ marginTop: 14 }} title="Kayıt ol" onPress={() => onAuth('register')} />
          <Btn style={{ marginTop: 8 }} kind="out" title="Giriş yap" onPress={() => onAuth('login')} />
        </Card>
      ) : (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: C.ink, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 18 }}>{String(me.name || me.email || '?').slice(0, 1).toUpperCase()}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text numberOfLines={1} style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>{me.name || 'Hesabım'}</Text>
              <Text numberOfLines={1} style={{ color: C.mut }}>{me.email}</Text>
            </View>
            {isVip(me) ? (
              <View style={{ backgroundColor: C.vipBg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                <Text style={{ color: C.vipTx, fontWeight: '800', fontSize: 12 }}>VIP · {Math.ceil((me.vipUntil - Date.now()) / 864e5)} gün</Text>
              </View>
            ) : null}
          </View>
          {me.banned ? (
            <View style={{ backgroundColor: C.redBg, borderRadius: 14, padding: 12, marginBottom: 12 }}>
              <Text style={{ color: C.red, fontWeight: '700' }}>Hesabın askıya alındı. Kilitli tahminleri açamazsın.</Text>
            </View>
          ) : null}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 26, fontWeight: '800', color: C.onKey }}>{me.keys ?? 0}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>Anahtarların</Text>
              <Text style={s.sub}>{isVip(me) ? 'VIP olduğun için tüm tahminler açık' : 'Kilitli tahminleri açmak için kullanılır'}</Text>
            </View>
          </View>
          {A.on && !me.banned ? (
            <Btn style={{ marginTop: 16 }} icon="play" disabled={left <= 0} onPress={onAd}
              title={left > 0 ? `Reklam izle, +${Number(A.reward) || 1} anahtar (${left} hak)` : 'Bugünkü reklam hakkın bitti'} />
          ) : null}
          {cfg.store?.on && !me.banned ? (
            <Btn style={{ marginTop: 8 }} kind="out" icon="cart-outline" title="Anahtar satın al" onPress={onBuy} />
          ) : null}
          {Number(cfg.rewards?.share) > 0 && !me.shareRewarded && !me.banned ? (
            <Btn style={{ marginTop: 8 }} kind="out" icon="share-social-outline" title={`Arkadaşına öner, +${Number(cfg.rewards.share)} anahtar`} onPress={onShare} />
          ) : null}
        </Card>
      )}

      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          {isAdmin ? <Link icon="construct-outline" title="Admin paneli" sub="Maç ekle, logo, mesaj, reklam" onPress={onAdmin} /> : null}
          <Link icon="help-circle-outline" title="Nasıl kullanılır?" sub="Tanıtımı tekrar göster" onPress={onOnb} />
          <Link icon="star-outline" title="Uygulamayı değerlendir" sub="Görüşün bizim için önemli" onPress={onRate} />
          <Link icon="share-social-outline" title="Arkadaşına öner" onPress={onShare} />
          <Link icon="shield-checkmark-outline" title="Sorumlu oyun" sub="18+ · Bilgilendirme" onPress={onRG} />
          {/^https?:\/\//i.test(cfg.links?.support || '') ? <Link icon="chatbubbles-outline" title="Bize ulaş" sub="Soru, öneri ve destek" onPress={() => Linking.openURL(cfg.links.support)} /> : null}
          {/^https?:\/\//i.test(cfg.links?.privacy || '') ? <Link icon="document-text-outline" title="Gizlilik politikası" onPress={() => Linking.openURL(cfg.links.privacy)} /> : null}
          {!me.guest ? <Link icon="log-out-outline" title="Çıkış yap" onPress={onLogout} /> : null}
          {!me.guest ? <Link icon="trash-outline" title="Hesabımı sil" sub="Hesabın ve anahtarların kalıcı olarak silinir"
            onPress={() => Alert.alert('Hesabın silinsin mi?', 'Bu işlem geri alınamaz. Anahtarların ve açtığın tahminler silinir.', [
              { text: 'Vazgeç', style: 'cancel' },
              { text: 'Sil', style: 'destructive', onPress: onDelete },
            ])} /> : null}
        </View>
      </Card>
    </View>
  );
}
