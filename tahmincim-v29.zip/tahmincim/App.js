import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, ScrollView, Share, Linking, useColorScheme, RefreshControl, AppState } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, accentOf, PLAY_PACKAGE, applyTheme, today, dayOff, isFav, canPredictScore, matchStart, adLimit, AD_WINDOW, BONUS_GAP, APP_SURUM, surumKarsilastir } from './src/tema';
import { autoRemind } from './src/hatirlat';
import { KonfetiHost, konfeti, titret } from './src/efekt';
import { profilDinle } from './src/profil';
import ProfilPenceresi from './src/ekranlar/Profil';
import { getPrefs } from './src/bildirim';
import Cark from './src/ekranlar/Cark';
import { senkronTick } from './src/senkron';
import { useCanliSkor } from './src/ekranlar/Canli';
import { useTeams } from './src/topluluk';
import Gorevler from './src/ekranlar/Gorevler';
import { gorevAyarla, gorevYap } from './src/gorev';
import { setupNotifications, registerPush } from './src/bildirim';
import { Theme, ToastHost, useToast, Icon, refreshStyles } from './src/parcalar';
import { useTribune } from './src/topluluk';
import { useConfig, useMatches, useCoupons, useAccount, logout, deleteAccount, authError, aktifSinyal } from './src/veri';
import { initAds, adsAvailable, showRewarded } from './src/reklam';
import Bugun from './src/ekranlar/Bugun';
import Canli from './src/ekranlar/Canli';
import Ben from './src/ekranlar/Ben';
import Kuponlar, { couponKey } from './src/ekranlar/Kuponlar';
import Sonuclar from './src/ekranlar/Sonuclar';
import Admin from './src/ekranlar/Admin';
import HizliMenu from './src/ekranlar/HizliMenu';
import { isOpen, isVip } from './src/ekranlar/MacKart';
import { Detay, Kilit, SorumluOyun, Hesap, Tanitim, Logo, SayacReklam, Magaza, Hosgeldin, GunlukBonus } from './src/ekranlar/Pencereler';

const THEME_KEY = 'tahmincim_theme';
export default function App() {
  const cfg = useConfig();
  const sys = useColorScheme();
  const [pref, setPref] = useState('system'); // 'light' | 'dark' | 'system'
  useEffect(() => { AsyncStorage.getItem(THEME_KEY).then((v) => v && setPref(v)).catch(() => {}); }, []);
  const choose = (v) => { setPref(v); AsyncStorage.setItem(THEME_KEY, v).catch(() => {}); };
  const dark = pref === 'dark' || (pref === 'system' && sys === 'dark');
  applyTheme(dark);
  refreshStyles();
  const theme = useMemo(() => ({ ...accentOf(cfg), dark, pref, setPref: choose }), [cfg, dark, pref]);
  return (
    <SafeAreaProvider>
      <Theme.Provider value={theme}>
        <ToastHost key={dark ? 'koyu' : 'acik'}>
          <Main cfg={cfg} />
          <KonfetiHost />
        </ToastHost>
      </Theme.Provider>
    </SafeAreaProvider>
  );
}

const TABS = [
  ['today', 'Bugün', 'football-outline'],
  ['live', 'Canlı', 'radio-outline'],
  ['coupons', 'Kuponlar', 'receipt-outline'],
  ['results', 'Sonuçlar', 'trophy-outline'],
  ['me', 'Ben', 'person-outline'],
];

function Main({ cfg }) {
  const ins = useSafeAreaInsets();
  const toast = useToast();
  const matchesRaw = useMatches();
  const couponsRaw = useCoupons();
  const tribune = useTribune();
  const acc = useAccount(cfg.startKeys);
  const { me, updateMe, isAdmin, isMod, isOwner, onboarded, setOnboarded } = acc;
  // Zamanlı yayın: saati gelmeyen içerik kullanıcıya görünmez (dakikada bir kontrol)
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(t); }, []);
  const matches = useMemo(() => (isAdmin ? matchesRaw : { ...matchesRaw, list: matchesRaw.list.filter((m) => !(m.publishAt > now) && !m.draft) }), [matchesRaw, isAdmin, now]);
  // 🔄 Otomatik fikstür + canlı skor: sahip/admin telefonu dakikada bir kontrol eder
  const teamsLib = useTeams();
  const senkronRef = useRef({});
  senkronRef.current = { cfg, list: matchesRaw.list, teams: teamsLib.list, tribune: tribune.list, coupons: couponsRaw.list };
  useEffect(() => {
    if (!isAdmin || matchesRaw.loading) return;
    const run = () => senkronTick(senkronRef.current).catch(() => {});
    const t0 = setTimeout(run, 4000);
    const t = setInterval(run, 60000);
    return () => { clearTimeout(t0); clearInterval(t); };
  }, [isAdmin, matchesRaw.loading]);
  const coupons = useMemo(() => (isAdmin ? couponsRaw : { ...couponsRaw, list: couponsRaw.list.filter((c) => !(c.publishAt > now)) }), [couponsRaw, isAdmin, now]);
  const [profil, setProfil] = useState(null);
  useEffect(() => profilDinle(setProfil), []);
  const go = (t, j = null) => { setJump(j); setTab(t); };
  const [tab, setTab] = useState('today');
  // 🟢 Aktiflik sinyali: uygulama ön plandayken 3 dakikada bir + sekme değişince
  const sonSinyal = useRef(0);
  const uid = me && !me.guest ? me.id : null;
  useEffect(() => {
    if (!uid) return;
    const gonder = (zorla) => {
      if (AppState.currentState !== 'active') return;
      if (!zorla && Date.now() - sonSinyal.current < 170000) return;
      sonSinyal.current = Date.now();
      aktifSinyal(uid, tab);
    };
    if (Date.now() - sonSinyal.current > 60000) gonder(true);
    const t = setInterval(() => gonder(false), 180000);
    const sub = AppState.addEventListener('change', (st) => { if (st === 'active') gonder(true); });
    return () => { clearInterval(t); sub.remove(); };
  }, [uid, tab]);
  const [detail, setDetail] = useState(null);
  const [jump, setJump] = useState(null);
  const [shareTick, setShareTick] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  // Veriler zaten canlı akıyor; aşağı çekince kısa bir yenileme hissi verir
  const pullRefresh = () => { setRefreshing(true); titret('hafif'); setTimeout(() => { setRefreshing(false); toast('Güncel ✓'); }, 700); };
  const [lock, setLock] = useState(null);
  const [sheet, setSheet] = useState(null); // 'rg' | 'store' | 'welcome'
  const [authSheet, setAuthSheet] = useState(null); // { mode, reason }
  const [admin, setAdmin] = useState(null); // null | 'list' | 'new' | { edit: maç }
  const [hizli, setHizli] = useState(null);
  const [fakeAd, setFakeAd] = useState(null); // { forId }
  const [adBusy, setAdBusy] = useState(false);
  const [gorevAc, setGorevAc] = useState(false);
  // 📲 Yeni sürüm uyarısı (admin panelinden açılır)
  const [surumKapat, setSurumKapat] = useState(false);
  const yeniSurum = !!cfg.surum?.on && !!cfg.surum?.son && surumKarsilastir(APP_SURUM, cfg.surum.son) < 0;
  // Görev ödülü: günde bir kez, kurallarla sınırlı
  const gorevOdul = () => {
    const n = Math.max(0, Number(cfg.rewards?.tasks ?? 2) || 0);
    if (!n) return Promise.resolve();
    if (me.taskDay === today() || Date.now() - (Number(me.taskAt) || 0) < BONUS_GAP) return Promise.reject(new Error('alindi'));
    return updateMe((x) => ({ keys: x.keys + n, taskDay: today(), taskAt: Date.now() }), true).then(() => konfeti());
  };
  const bonusDone = useRef(false);

  // Favori takımın maçlarını otomatik hatırlat (bildirim izni verilmişse)
  useEffect(() => {
    if (!me.favTeam || matches.loading) return;
    const soon = Date.now() + 3 * 864e5;
    const L = matches.list.filter((m) => !m.hidden && isFav(m, me.favTeam) && canPredictScore(m) && matchStart(m) < soon);
    getPrefs().then((p) => { if (p.favori !== false) autoRemind(L).catch(() => {}); }).catch(() => {});
  }, [me.favTeam, matches.list.length, matches.loading]); // eslint-disable-line

  // 🎡 Günlük şans çarkı (eski günlük bonusun yerine)
  const carkHazir = !me.guest && !me.loading && !!me.id && !me.banned && !me.admin
    && me.lastBonusDay !== today() && Date.now() - (Number(me.lastBonusAt) || 0) >= BONUS_GAP;
  const [cark, setCark] = useState(false);
  useEffect(() => {
    if (bonusDone.current || !carkHazir) return;
    bonusDone.current = true;
    setTimeout(() => setCark(true), onboarded ? 900 : 4000);
  }, [carkHazir]); // eslint-disable-line
  useEffect(() => { gorevAyarla('giris', 1); }, []);
  useEffect(() => { if (me.lastBonusDay === today()) gorevAyarla('cark', 1); }, [me.lastBonusDay]);
  const carkStreak = me.lastBonusDay === dayOff(-1) ? (Number(me.streak) || 0) + 1 : 1;
  const dP = Math.max(1, Number(cfg.rewards?.daily ?? 1) || 1);
  const mP = dP + Math.max(0, Number(cfg.rewards?.week ?? 2) || 0);
  const midP = Math.min(mP, dP + 1);
  const carkPrizes = [dP, midP, dP, mP, dP, midP, dP, mP];
  const carkSpin = (gift) => updateMe((x) => ({ keys: x.keys + gift, lastBonusDay: today(), lastBonusAt: Date.now(), streak: carkStreak, maxStreak: Math.max(Number(x.maxStreak) || 0, carkStreak) }), true)
    .then(() => gorevAyarla('cark', 1));

  // Kullanılmayan anahtarların süresi (admin ayarı, 0 = kapalı)
  const expDays = Number(cfg.keys?.expireDays) || 0;
  useEffect(() => {
    if (me.guest || me.loading || !me.id || me.admin) return;
    if (!me.keyAt) { updateMe(() => ({ keyAt: Date.now() })); return; }
    if (expDays > 0 && me.keys > 0 && Date.now() - me.keyAt > expDays * 864e5) {
      updateMe(() => ({ keys: 0 }));
      toast(`${expDays} gün kullanılmayan anahtarların sıfırlandı`);
    }
  }, [me.id, me.loading, expDays]); // eslint-disable-line

  useEffect(() => { initAds(); setupNotifications(); }, []);
  const pushId = cfg.push?.projectId;
  const uidNow = acc.user ? acc.user.uid : null;
  useEffect(() => { if (pushId) registerPush(pushId, uidNow); }, [pushId, uidNow]);

  const playUrl = `https://play.google.com/store/apps/details?id=${PLAY_PACKAGE}`;
  const rateApp = () => Linking.openURL(`market://details?id=${PLAY_PACKAGE}`).catch(() => Linking.openURL(playUrl).catch(() => {}));
  const shareApp = async () => {
    try {
      await Share.share({ message: `⚽ ${cfg.name} — günün tahminleri, banko kuponlar ve canlı tahminler tek uygulamada!\n📲 ${playUrl}\n18+` });
      const n = Number(cfg.rewards?.share) || 0;
      if (n > 0 && !me.guest && !me.shareRewarded && !me.banned) {
        updateMe((x) => ({ keys: x.keys + n, shareRewarded: true }));
        toast(`Teşekkürler! +${n} anahtar hesabına eklendi 🎁`);
      }
    } catch (e) {}
  };

  const skorCanli = useCanliSkor();
  const liveCount = Math.max(matches.list.filter((m) => m.status === 'live' && !m.hidden).length,
    (skorCanli.list || []).filter((x) => ['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE'].includes(x.s)).length);
  const hour = new Date().getHours();
  const greet = hour < 6 ? 'İyi geceler' : hour < 12 ? 'Günaydın' : hour < 18 ? 'İyi günler' : 'İyi akşamlar';

  const askAuth = (reason, mode = 'register') => setAuthSheet({ mode, reason });
  const openMatch = (m) => {
    if (isOpen(m, me)) return setDetail(m);
    if (me.guest) return askAuth('Kilitli tahminleri açmak için ücretsiz kayıt ol. Anahtarların hesabında saklanır.');
    if (me.banned) return toast('Hesabın askıya alındı');
    setLock(m);
  };

  const openCouponLock = (c) => {
    if (me.guest) return askAuth('Kilitli kuponları açmak için ücretsiz kayıt ol.');
    if (me.banned) return toast('Hesabın askıya alındı');
    setLock({ id: couponKey(c), cost: c.cost, access: c.access, label: c.title || 'Günün Kuponu', date: c.date, isCoupon: true });
  };
  const opened = (t) => {
    konfeti();
    if (t.isCoupon) toast('Kupon açıldı! 🎉');
    else { toast('Tahmin açıldı!'); setTimeout(() => setDetail(t), 350); }
  };
  const isUnlocked = (t) => (t.isCoupon ? (me.unlocked || []).includes(t.id) : isOpen(t, me));

  const dailyMax = Number(cfg.keys?.dailyUnlock) || 0;
  const limitHit = () => dailyMax > 0 && !isVip(me) && (me.unlockCount || 0) >= dailyMax;
  const unlockPatch = (x) => ({ unlockDay: today(), unlockCount: (x.unlockCount || 0) + 1 });
  const unlockWithKeys = (t) => {
    const cost = Math.max(1, Number(t.cost) || 1);
    if ((me?.keys || 0) < cost) return toast('Yeterli anahtarın yok');
    if (limitHit()) return toast(`Bugün en fazla ${dailyMax} tahmin açabilirsin. Yarın tekrar gel 🙂`);
    setLock(null);
    updateMe((x) => ({ ...unlockPatch(x), unlocked: [...x.unlocked, t.id], keys: Math.max(0, x.keys - cost) }), true)
      .then(() => opened(t))
      .catch(() => toast('Açılamadı, internetini kontrol edip tekrar dene. Anahtarın gitmedi.'));
  };

  // Reklam izlendi: anahtarı ver, bir maç için izlendiyse ve yetiyorsa maçı aç
  const reward = (t) => {
    const r = Number(cfg.ads.reward) || 1;
    const m = t || null;
    const cost = m ? Math.max(1, Number(m.cost) || 1) : 0;
    const willOpen = m && !isUnlocked(m) && (me?.keys || 0) + r >= cost && !limitHit();
    return updateMe((x) => {
      const keys = x.keys + r;
      // 24 saatlik pencere: ilk reklamla başlar
      const fresh = !x.adAt || Date.now() - x.adAt >= AD_WINDOW;
      const ad = fresh ? { adAt: Date.now(), adCount: 1 } : { adCount: x.adCount + 1 };
      return willOpen
        ? { ...ad, ...unlockPatch(x), keys: keys - cost, unlocked: [...x.unlocked, m.id] }
        : { ...ad, keys };
    }, true).then(() => {
      if (willOpen) opened(m);
      else { titret('basari'); toast(`+${r} anahtar kazandın!`); }
    }).catch(() => toast('Ödül kaydedilemedi, internetini kontrol et'));
  };

  const watchAd = async (target) => {
    const A = cfg.ads;
    if (!A.on) return;
    if (me.guest) { setLock(null); return askAuth('Reklam izleyip anahtar kazanmak için ücretsiz kayıt ol.'); }
    if (me.banned) return toast('Hesabın askıya alındı');
    if ((me?.adCount || 0) >= adLimit(cfg)) {
      const h = Math.max(1, Math.ceil((me.adAt + AD_WINDOW - Date.now()) / 3600e3));
      return toast(`Reklam hakkın bitti, ${h} saat sonra yenilenir`);
    }
    setLock(null);
    if (!adsAvailable()) return setFakeAd({ target });
    setAdBusy(true);
    toast('Reklam yükleniyor…');
    const r = await showRewarded(A.unitId);
    setAdBusy(false);
    if (r === 'earned') reward(target);
    else if (r === 'closed') toast('Reklam yarıda kaldı, anahtar verilmedi');
    else toast('Şu an reklam yok, biraz sonra tekrar dene');
  };

  if (!acc.ready) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style={C.dark ? 'light' : 'dark'} />
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={pullRefresh} colors={[accentOf(cfg).acc]} tintColor={C.mut} progressBackgroundColor={C.card} />}
        contentContainerStyle={{ paddingTop: ins.top + 16, paddingHorizontal: 18, paddingBottom: ins.bottom + 110 }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, gap: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
            <Logo cfg={cfg} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.mut, fontSize: 13 }}>{greet}</Text>
              <Text numberOfLines={1} style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{cfg.name}</Text>
            </View>
          </View>
          {me.guest ? (
            <Pressable onPress={() => askAuth(null, 'login')} accessibilityRole="button"
              style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.hero, borderRadius: 22, paddingHorizontal: 14, minHeight: 44 }}>
              <Icon name="person-outline" size={17} color="#fff" />
              <Text style={{ fontWeight: '700', fontSize: 15, color: '#fff' }}>Giriş</Text>
            </Pressable>
          ) : (
            <Pressable onPress={() => setTab('me')} accessibilityLabel={`Anahtarların: ${me.keys}`}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.key, borderRadius: 22, paddingHorizontal: 14, minHeight: 44 }}>
              <Icon name="key" size={17} color={C.onKey} />
              <Text style={{ fontWeight: '800', fontSize: 16, color: C.onKey }}>{me.admin ? '∞' : me.keys}</Text>
            </Pressable>
          )}
        </View>

        {yeniSurum && !surumKapat ? (
          <View style={{ backgroundColor: C.hero, borderRadius: 18, padding: 14, marginBottom: 14, flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1.5, borderColor: accentOf(cfg).acc }}>
            <Text style={{ fontSize: 26 }}>📲</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 15.5 }}>Yeni sürüm var: {cfg.surum.son}</Text>
              <Text style={{ color: '#C5CCD6', fontSize: 13 }}>{cfg.surum.not || 'Yeni özellikler ve düzeltmeler için güncelle.'}</Text>
              <Text style={{ color: '#8C96A3', fontSize: 11.5, marginTop: 2 }}>Senin sürümün: {APP_SURUM}</Text>
            </View>
            <View style={{ gap: 6, alignItems: 'flex-end' }}>
              <Pressable onPress={() => Linking.openURL(cfg.surum.link || 'https://github.com/cesaret0263/tahmincim/releases/latest/download/app-release.apk').catch(() => toast('Link açılamadı'))} accessibilityRole="button"
                style={{ backgroundColor: accentOf(cfg).acc, borderRadius: 12, paddingHorizontal: 14, minHeight: 40, justifyContent: 'center' }}>
                <Text style={{ color: accentOf(cfg).onAcc, fontWeight: '800' }}>İndir</Text>
              </Pressable>
              <Pressable onPress={() => setSurumKapat(true)} hitSlop={8} accessibilityLabel="Sonra">
                <Text style={{ color: '#8C96A3', fontSize: 12.5, fontWeight: '600' }}>Sonra</Text>
              </Pressable>
            </View>
          </View>
        ) : null}

        {tab === 'today' ? (
          <Bugun cfg={cfg} matches={matches} coupons={coupons} me={me} onMatch={openMatch} isAdmin={isAdmin} onAdminMenu={(m) => { titret('orta'); setHizli(m); }} onAddMatch={() => setAdmin('new')}
            onScoreLeague={() => go('coupons', 'score')} onStats={() => go('results')} onNav={go}
            onCark={carkHazir ? () => setCark(true) : null} onGorev={() => setGorevAc(true)} />
        ) : tab === 'live' ? (
          <Canli matches={matches} me={me} onMatch={openMatch} />
        ) : tab === 'coupons' ? (
          <Kuponlar coupons={coupons} matches={matches} me={me} onLocked={openCouponLock} appName={cfg.name} logo={cfg.logo} onMatch={(m) => setDetail(m)}
            tribune={tribune} isAdmin={isAdmin} jump={jump} shareTick={shareTick} onNeedAuth={() => askAuth('Katılmak için ücretsiz kayıt ol.')} onAdminCoupon={(c) => { titret('orta'); setAdmin({ coupon: c }); }} />
        ) : tab === 'results' ? (
          <Sonuclar matches={matches} me={me} onMatch={openMatch} />
        ) : (
          <Ben cfg={cfg} matches={matches} me={me} onMatch={openMatch} isAdmin={isAdmin}
            onAd={() => !adBusy && watchAd(null)} onAdmin={() => setAdmin('list')}
            onAuth={(mode) => askAuth(null, mode)} onLogout={() => logout().then(() => toast('Çıkış yapıldı'))}
            onOnb={() => setOnboarded(false)} onRG={() => setSheet('rg')} onBuy={() => setSheet('store')}
            onDelete={async () => { try { await deleteAccount(); toast('Hesabın silindi'); } catch (e) { toast(authError(e)); } }}
            onShare={shareApp} onRate={rateApp} tribune={tribune} onUpdate={updateMe} coupons={coupons} onNav={go}
            onCark={carkHazir ? () => setCark(true) : null} onGorev={() => setGorevAc(true)} />
        )}
      </ScrollView>

      {/* Alt menü */}
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8, paddingBottom: ins.bottom + 10, flexDirection: 'row' }}>
        {TABS.map(([k, label, icon], i) => (
          <React.Fragment key={k}>
            {i === 2 ? (
              <Pressable onPress={() => { titret('orta'); if (me.guest) return askAuth('Kupon paylaşmak için ücretsiz kayıt ol.'); setJump('share'); setTab('coupons'); setShareTick((x) => x + 1); setTimeout(() => setJump(null), 800); }}
                accessibilityRole="button" accessibilityLabel="Kupon paylaş" style={{ width: 64, alignItems: 'center' }}>
                <View style={{ width: 58, height: 58, borderRadius: 29, marginTop: -28, backgroundColor: accentOf(cfg).acc, alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: C.card, elevation: 6, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 8, shadowOffset: { width: 0, height: 3 } }}>
                  <Icon name="add" size={32} color={accentOf(cfg).onAcc} />
                </View>
                <Text numberOfLines={1} style={{ fontSize: 11, fontWeight: '700', color: C.ink, marginTop: 4 }}>Paylaş</Text>
              </Pressable>
            ) : null}
            <TabBtn on={tab === k} label={label} icon={icon} badge={k === 'live' ? liveCount : 0} onPress={() => { setJump(null); setTab(k); }} />
          </React.Fragment>
        ))}
      </View>

      {profil ? <ProfilPenceresi p={profil} tribune={tribune} matches={matches} onClose={() => setProfil(null)} /> : null}
      {detail ? <Detay m={detail} appName={cfg.name} logo={cfg.logo} me={me} isAdmin={isAdmin} onNeedAuth={() => { setDetail(null); askAuth('Yorum yapmak ve oy vermek için ücretsiz kayıt ol.'); }} onClose={() => setDetail(null)} /> : null}
      {cark && carkHazir ? <Cark prizes={carkPrizes} streak={carkStreak} forced={carkStreak % 7 === 0 ? 3 : null} onSpin={carkSpin} onClose={() => setCark(false)} /> : null}
      {gorevAc ? <Gorevler me={me} cfg={cfg} carkHazir={carkHazir} onCark={() => { setGorevAc(false); setTimeout(() => setCark(true), 300); }} onClaim={gorevOdul} onClose={() => setGorevAc(false)} /> : null}
      {lock ? <Kilit m={lock} me={me} cfg={cfg} onClose={() => setLock(null)} onAd={() => watchAd(lock)} onKey={() => unlockWithKeys(lock)} onBuy={() => { setLock(null); setTimeout(() => setSheet('store'), 300); }} /> : null}
      {sheet === 'rg' ? <SorumluOyun onClose={() => setSheet(null)} /> : null}
      {sheet === 'welcome' ? <Hosgeldin cfg={cfg} me={me} onClose={() => setSheet(null)} onShare={() => { setSheet(null); setTimeout(shareApp, 300); }} onRate={rateApp} /> : null}
      {sheet === 'store' ? <Magaza cfg={cfg} me={me} onClose={() => setSheet(null)} onSoon={() => toast('Satın alma, uygulama Google Play\'e çıkınca açılacak')} /> : null}
      {authSheet ? <Hesap startMode={authSheet.mode} reason={authSheet.reason} startKeys={cfg.startKeys} onClose={() => setAuthSheet(null)} onDone={(msg, kind) => { setTab('today'); if (kind === 'register') setTimeout(() => setSheet('welcome'), 400); else toast(msg); }} /> : null}
      {hizli && isAdmin ? <HizliMenu m={matchesRaw.list.find((x) => x.id === hizli.id) || hizli} all={matchesRaw.list} cfg={cfg} onEdit={(m) => setAdmin({ edit: m })} onClose={() => setHizli(null)} /> : null}
      <Admin visible={!!admin && isMod} startWith={admin} onClose={() => setAdmin(null)} matches={matchesRaw} coupons={couponsRaw} cfg={cfg} me={me} perm={{ owner: isOwner, admin: isAdmin, mod: isMod }} onGoMatch={(x) => setDetail(x)} onGoTribun={() => { setTab('coupons'); setJump('feed'); setTimeout(() => setJump(null), 800); }} />
      <SayacReklam visible={!!fakeAd} cfg={cfg} seconds={15}
        onCancel={() => { setFakeAd(null); toast('Reklam yarıda kaldı, anahtar verilmedi'); }}
        onDone={() => { const f = fakeAd; setFakeAd(null); reward(f?.target); }} />
      <Tanitim visible={!onboarded} cfg={cfg} onDone={() => setOnboarded(true)} />
    </View>
  );
}

function TabBtn({ on, label, icon, badge, onPress }) {
  const t = React.useContext(Theme);
  return (
    <Pressable onPress={onPress} accessibilityRole="tab" accessibilityState={{ selected: on }} style={{ flex: 1, alignItems: 'center', gap: 4, minHeight: 52 }}>
      <ThemedPill on={on}><Icon name={on ? icon.replace('-outline', '') : icon} size={22} color={on ? t.onAcc : C.mut} /></ThemedPill>
      <Text numberOfLines={1} style={{ fontSize: 12, fontWeight: on ? '700' : '600', color: on ? C.ink : C.mut }}>{label}</Text>
      {badge ? (
        <View style={{ position: 'absolute', top: 0, left: '58%', backgroundColor: '#E5484D', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
          <Text style={{ color: '#fff', fontSize: 10.5, fontWeight: '700' }}>{badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

function ThemedPill({ on, children }) {
  const t = React.useContext(Theme);
  return <View style={{ width: 52, height: 32, borderRadius: 16, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', backgroundColor: on ? t.acc : 'transparent' }}>{children}</View>;
}
