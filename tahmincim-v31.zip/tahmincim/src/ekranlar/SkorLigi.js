import React, { useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { C, isOwnerMe, izinVar, monthKey, canPredictScore, scorePoints, skorTam, matchStart, dayLabel, scoreOf } from '../tema';
import { Btn, Crest, Icon, s, useToast, Avatar } from '../parcalar';
import { useScores, saveScore } from '../topluluk';
import { updateUser, addKeys } from '../veri';
import { titret } from '../efekt';
import { profilAc } from '../profil';
import { gorevAyarla } from '../gorev';

const AYLAR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];

export function Sayac({ value, onChange }) {
  const B = ({ icon, d }) => (
    <Pressable onPress={() => onChange(Math.max(0, Math.min(20, value + d)))} accessibilityLabel={d > 0 ? 'Artır' : 'Azalt'}
      style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name={icon} size={18} />
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <B icon="remove" d={-1} />
      <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink, minWidth: 24, textAlign: 'center' }}>{value}</Text>
      <B icon="add" d={1} />
    </View>
  );
}

function TahminKart({ m, mine, me, isAdmin, onNeedAuth }) {
  const toast = useToast();
  const [h, setH] = useState(mine ? +mine.h : 0);
  const [a, setA] = useState(mine ? +mine.a : 0);
  const [busy, setBusy] = useState(false);
  const changed = !mine || +mine.h !== h || +mine.a !== a;
  const save = async () => {
    if (!me || me.guest || !me.id) return onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    if (me.muted) return toast('Bir süre paylaşım yapman kısıtlandı');
    if (!canPredictScore(m)) return toast('Maç başladı, tahmin kapandı');
    setBusy(true);
    try { await saveScore(m, me.id, isAdmin ? (me.adminName || me.name || 'Admin') : (me.name || 'Üye'), me.avatar, isAdmin, h, a); titret('basari'); gorevAyarla('skor', 1); toast('Skor tahminin kaydedildi ⚽'); }
    catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };
  return (
    <View style={{ backgroundColor: C.card, borderRadius: 20, padding: 14, marginBottom: 10 }}>
      <Text style={{ color: C.mut, fontSize: 12.5, fontWeight: '600', marginBottom: 10 }}>{dayLabel(m.date)} · {m.time}{m.league ? ` · ${m.league}` : ''}</Text>
      {[[m.home, m.homeLogo, h, setH], [m.away, m.awayLogo, a, setA]].map(([n, l, v, set], i) => (
        <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <Crest name={n} logo={l} size={26} />
          <Text numberOfLines={1} style={{ flex: 1, fontWeight: '700', color: C.ink, fontSize: 15 }}>{n}</Text>
          <Sayac value={v} onChange={set} />
        </View>
      ))}
      {changed ? (
        <Btn small kind="ink" title={mine ? 'Tahmini güncelle' : 'Tahmini kaydet'} onPress={save} loading={busy} style={{ marginTop: 4 }} />
      ) : (
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 40, borderRadius: 12, backgroundColor: C.okBg, marginTop: 4 }}>
          <Icon name="checkmark-circle" size={18} color={C.okTx} />
          <Text style={{ color: C.okTx, fontWeight: '700' }}>Tahminin kayıtlı: {mine.h}-{mine.a}</Text>
        </View>
      )}
    </View>
  );
}

function Sonuclarim({ mineList, byId }) {
  const rows = mineList.map((p) => ({ p, m: byId[p.matchId] })).filter((x) => x.m && x.m.status === 'finished')
    .sort((x, y) => matchStart(y.m) - matchStart(x.m)).slice(0, 10);
  if (!rows.length) return null;
  return (
    <View style={{ marginTop: 8 }}>
      <Text style={[s.h3, { marginBottom: 8 }]}>Son tahminlerim</Text>
      {rows.map(({ p, m }) => {
        const pt = scorePoints(p, m);
        return (
          <View key={p.id} style={[s.row, { minHeight: 56 }]}>
            <View style={{ flex: 1 }}>
              <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{m.home} – {m.away}</Text>
              <Text style={{ color: C.mut, fontSize: 13 }}>Sen: {p.h}-{p.a} · Maç: {scoreOf(m).join('-')}</Text>
            </View>
            <Text style={{ fontWeight: '800', fontSize: 15, color: skorTam(p, m) ? C.okTx : pt > 0 ? C.lockTx : C.mut }}>{pt == null ? '–' : `+${pt}${m.buyuk ? ' ⭐' : ''}`}</Text>
          </View>
        );
      })}
    </View>
  );
}

function Siralama({ list, byId, isAdmin, me }) {
  const toast = useToast();
  const agg = {};
  list.forEach((p) => {
    const pt = scorePoints(p, byId[p.matchId]);
    if (pt == null) return;
    const r = (agg[p.uid] = agg[p.uid] || { uid: p.uid, name: p.name, avatar: p.avatar, admin: p.admin, pts: 0, exact: 0, n: 0 });
    r.pts += pt; r.n++; if (skorTam(p, byId[p.matchId])) r.exact++;
    if (p.createdAt > (r.t || 0)) { r.t = p.createdAt; r.name = p.name; r.avatar = p.avatar; }
  });
  const rows = Object.values(agg).filter((r) => !r.admin).sort((x, y) => y.pts - x.pts || y.exact - x.exact || x.n - y.n).slice(0, 30);
  const reward = (r) => Alert.alert(`${r.name} ödüllendirilsin mi?`, 'Seçtiğin ödül hesabına eklenecek.', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: '+10 anahtar', onPress: () => addKeys(r.uid, 10).then(() => toast('+10 anahtar verildi 🎁')).catch(() => toast('Verilemedi')) },
    { text: '7 gün VIP', onPress: () => updateUser(r.uid, { vipUntil: Date.now() + 7 * 864e5 }).then(() => toast('7 gün VIP verildi 👑')).catch(() => toast('Verilemedi')) },
  ]);
  const medal = ['🥇', '🥈', '🥉'];
  const now = new Date();
  return (
    <View>
      <Text style={[s.sub, { marginBottom: 10 }]}>{AYLAR[now.getMonth()]} ayı sıralaması. Tam skor 3 puan, doğru sonuç 1 puan, ⭐ büyük maçta 2 katı. Ay sonunda şampiyon belli olur!</Text>
      {!rows.length ? <View style={s.empty}><Text style={[s.sub, { textAlign: 'center' }]}>Bu ay henüz sonuçlanan tahmin yok.</Text></View> : rows.map((r, i) => (
        <Pressable key={r.uid} onPress={() => profilAc({ uid: r.uid, name: r.name, avatar: r.avatar })} style={[s.row, { minHeight: 56 }, me && r.uid === me.id && { borderWidth: 2, borderColor: C.key }]}>
          <Text style={{ width: 28, fontSize: 18, fontWeight: '800', color: C.ink, textAlign: 'center' }}>{medal[i] || i + 1}</Text>
          <Avatar emoji={r.avatar} name={r.name} size={32} />
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{r.name}{me && r.uid === me.id ? ' (sen)' : ''}</Text>
            <Text style={{ color: C.mut, fontSize: 13 }}>{r.n} tahmin · {r.exact} tam skor</Text>
          </View>
          <Text style={{ fontWeight: '800', color: C.okTx, fontSize: 16 }}>{r.pts} p</Text>
          {isAdmin ? <Pressable onPress={() => reward(r)} accessibilityLabel="Ödül ver" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 20 }}>🎁</Text></Pressable> : null}
        </Pressable>
      ))}
    </View>
  );
}

export default function SkorLigi({ matches, me, isAdmin, onNeedAuth }) {
  const [tab, setTab] = useState('play');
  const mk = monthKey();
  const nd = new Date(); nd.setDate(1); nd.setMonth(nd.getMonth() + 1);
  const mkNext = monthKey(nd.getTime());
  const cur = useScores(mk);
  const next = useScores(mkNext);
  const byId = {};
  matches.list.forEach((m) => { byId[m.id] = m; });
  const all = [...cur.list, ...next.list];
  const mineMap = {};
  if (me && me.id) all.forEach((p) => { if (p.uid === me.id) mineMap[p.matchId] = p; });
  const open = matches.list.filter((m) => !m.hidden && canPredictScore(m)).sort((x, y) => matchStart(x) - matchStart(y)).slice(0, 30);
  return (
    <View>
      <View style={{ backgroundColor: C.hero, borderRadius: 20, padding: 16, marginBottom: 12 }}>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 17 }}>⚽ Skor Ligi</Text>
        <Text style={{ color: '#C5CCD6', marginTop: 4, lineHeight: 20 }}>Maçların skorunu tahmin et, puan topla. Tam skor 3 puan, doğru sonuç 1 puan, ⭐ büyük maçta 2 katı. Ücretsiz!</Text>
      </View>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 12 }}>
        {[['play', 'Tahmin yap'], ['rank', '🏆 Aylık sıralama']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }}
            style={{ flex: 1, minHeight: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: tab === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: tab === k ? '800' : '600', color: tab === k ? C.ink : C.mut }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {tab === 'rank' ? <Siralama list={cur.list} byId={byId} isAdmin={izinVar(me, 'anahtar')} me={me} /> : (
        <View>
          {!open.length ? (
            <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Şu an açık maç yok</Text><Text style={[s.sub, { textAlign: 'center' }]}>Yeni maçlar eklenince buradan skor tahmini yapabilirsin.</Text></View>
          ) : open.map((m) => <TahminKart key={m.id + (mineMap[m.id] ? `_${mineMap[m.id].h}_${mineMap[m.id].a}` : '')} m={m} mine={mineMap[m.id]} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} />)}
          <Sonuclarim mineList={Object.values(mineMap)} byId={byId} />
        </View>
      )}
    </View>
  );
}
