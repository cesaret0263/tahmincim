// ⭐ Büyük Maç: admin'in seçtiği maç için topluluk skor tahmini (Skor Ligi'ne 2 kat puan)
import React, { useEffect, useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { C, canPredictScore, matchStart, scoreOf, skorTam, canliDakika } from '../tema';
import { Btn, Crest, Icon, s, useToast, Avatar } from '../parcalar';
import { useMacSkorlari, saveScore } from '../topluluk';
import { profilAc } from '../profil';
import { engelliMi } from '../sosyal';
import { titret, konfeti } from '../efekt';
import { gorevAyarla } from '../gorev';
import { Sayac } from './SkorLigi';

const kalanYazi = (ms) => {
  if (ms <= 0) return 'Başlıyor';
  const dk = Math.floor(ms / 60000);
  const g = Math.floor(dk / 1440); const sa = Math.floor((dk % 1440) / 60); const d = dk % 60;
  return g ? `${g} gün ${sa} sa` : sa ? `${sa} sa ${d} dk` : `${d} dk`;
};

export default function BuyukMac({ m, me, isAdmin, onNeedAuth, onMatch }) {
  const toast = useToast();
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 30000); return () => clearInterval(t); }, []);
  const ham = useMacSkorlari(m.id).list;
  const tahminler = ham.filter((x) => !engelliMi(me, x.uid)).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  const mine = me && me.id ? tahminler.find((x) => x.uid === me.id) : null;
  const [h, setH] = useState(mine ? +mine.h : 0);
  const [a, setA] = useState(mine ? +mine.a : 0);
  useEffect(() => { if (mine) { setH(+mine.h); setA(+mine.a); } }, [mine && mine.h, mine && mine.a]); // eslint-disable-line
  const [busy, setBusy] = useState(false);
  const [hepsi, setHepsi] = useState(false);
  const acik = canPredictScore(m);
  const canli = m.status === 'live';
  const bitti = m.status === 'finished';
  const sc = scoreOf(m);
  const n = tahminler.length;
  const ev = tahminler.filter((x) => +x.h > +x.a).length;
  const ber = tahminler.filter((x) => +x.h === +x.a).length;
  const dep = n - ev - ber;
  const yuzde = (k) => (n ? Math.round((k / n) * 100) : 0);
  const sayac = {};
  tahminler.forEach((x) => { const k = `${+x.h}-${+x.a}`; sayac[k] = (sayac[k] || 0) + 1; });
  const enCok = Object.entries(sayac).sort((x, y) => y[1] - x[1])[0];
  const tutanSimdi = canli ? tahminler.filter((x) => +x.h === +sc[0] && +x.a === +sc[1]).length : 0;
  const tamBilen = bitti ? tahminler.filter((x) => skorTam(x, m)) : [];
  const sonucBilen = bitti ? tahminler.filter((x) => Math.sign(+x.h - +x.a) === Math.sign(+sc[0] - +sc[1])).length : 0;
  const degisti = !mine || +mine.h !== h || +mine.a !== a;

  const kaydet = async () => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    if (me.muted) return toast('Bir süre paylaşım yapman kısıtlandı');
    if (!canPredictScore(m)) return toast('Maç başladı, tahmin kapandı');
    setBusy(true);
    try {
      await saveScore(m, me.id, isAdmin ? (me.adminName || me.name || 'Admin') : (me.name || 'Üye'), me.avatar, isAdmin, h, a);
      titret('basari'); if (!mine) konfeti(); gorevAyarla('skor', 1);
      toast(`Tahminin kaydedildi: ${h}-${a} ⭐`);
    } catch (e) { toast('Kaydedilemedi'); }
    setBusy(false);
  };

  const sirali = mine ? [mine, ...tahminler.filter((x) => x !== mine)] : tahminler;
  const goster = hepsi ? sirali.slice(0, 300) : sirali.slice(0, 10);
  const Takim = ({ ad, logo }) => (
    <View style={{ flex: 1, alignItems: 'center', gap: 8 }}>
      <Crest name={ad} logo={logo} size={64} />
      <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '800', fontSize: 15, textAlign: 'center' }}>{ad}</Text>
    </View>
  );

  return (
    <View style={{ backgroundColor: C.hero, borderRadius: 24, padding: 16, marginBottom: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <Text style={{ color: '#FFD54A', fontWeight: '900', letterSpacing: 1, fontSize: 13 }}>⭐ BÜYÜK MAÇ</Text>
        <Text style={{ color: '#C5CCD6', fontSize: 12.5, fontWeight: '600' }}>{m.league || ''}</Text>
      </View>

      <Pressable onPress={() => onMatch && onMatch(m)} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Takim ad={m.home} logo={m.homeLogo} />
        <View style={{ alignItems: 'center', minWidth: 90 }}>
          {canli || bitti ? (
            <>
              <Text style={{ color: '#fff', fontSize: 34, fontWeight: '900' }}>{sc[0]} - {sc[1]}</Text>
              <Text style={{ color: canli ? '#FF8A8E' : '#C5CCD6', fontWeight: '800', fontSize: 12.5 }}>{canli ? `● CANLI ${canliDakika(m)}` : 'MAÇ BİTTİ'}</Text>
            </>
          ) : (
            <>
              <Text style={{ color: '#fff', fontSize: 22, fontWeight: '900' }}>{m.time}</Text>
              <Text style={{ color: '#C5CCD6', fontSize: 12, fontWeight: '700', marginTop: 2 }}>⏳ {kalanYazi(matchStart(m) - now)}</Text>
            </>
          )}
        </View>
        <Takim ad={m.away} logo={m.awayLogo} />
      </Pressable>

      {acik ? (
        <View style={{ backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 18, padding: 12, marginTop: 14 }}>
          <Text style={{ color: '#fff', fontWeight: '800', textAlign: 'center', marginBottom: 8 }}>Skor tahminin? <Text style={{ color: '#FFD54A' }}>(2 kat puan)</Text></Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
            <View style={{ backgroundColor: C.card, borderRadius: 14, padding: 4 }}><Sayac value={h} onChange={setH} /></View>
            <Text style={{ color: '#fff', fontSize: 22, fontWeight: '900' }}>-</Text>
            <View style={{ backgroundColor: C.card, borderRadius: 14, padding: 4 }}><Sayac value={a} onChange={setA} /></View>
          </View>
          {degisti ? (
            <Btn kind="acc" title={!me || me.guest ? 'Tahmin için ücretsiz kayıt ol' : mine ? 'Tahminimi güncelle' : 'Tahminimi gönder'} onPress={kaydet} loading={busy} style={{ marginTop: 10 }} />
          ) : (
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 42, borderRadius: 12, backgroundColor: C.okBg, marginTop: 10 }}>
              <Icon name="checkmark-circle" size={18} color={C.okTx} />
              <Text style={{ color: C.okTx, fontWeight: '800' }}>Tahminin: {mine.h}-{mine.a} · maç başlayana kadar değiştirebilirsin</Text>
            </View>
          )}
        </View>
      ) : null}

      {n ? (
        <View style={{ marginTop: 14 }}>
          <Text style={{ color: '#fff', fontWeight: '800', marginBottom: 6 }}>👥 Topluluk ne diyor? <Text style={{ color: '#C5CCD6', fontWeight: '600' }}>({n} tahmin)</Text></Text>
          <View style={{ flexDirection: 'row', height: 10, borderRadius: 5, overflow: 'hidden', backgroundColor: 'rgba(255,255,255,0.1)' }}>
            <View style={{ flex: Math.max(ev, 0.001), backgroundColor: '#00D26A' }} />
            <View style={{ flex: Math.max(ber, 0.001), backgroundColor: '#8C96A3' }} />
            <View style={{ flex: Math.max(dep, 0.001), backgroundColor: '#4DA3FF' }} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
            <Text style={{ color: '#7CF0B0', fontSize: 12, fontWeight: '700' }}>%{yuzde(ev)} {m.home}</Text>
            <Text style={{ color: '#C5CCD6', fontSize: 12, fontWeight: '700' }}>%{yuzde(ber)} Beraberlik</Text>
            <Text style={{ color: '#9CCBFF', fontSize: 12, fontWeight: '700' }}>%{yuzde(dep)} {m.away}</Text>
          </View>
          {enCok ? <Text style={{ color: '#C5CCD6', fontSize: 12.5, marginTop: 6 }}>En çok tahmin edilen skor: <Text style={{ color: '#fff', fontWeight: '800' }}>{enCok[0]}</Text> ({enCok[1]} kişi)</Text> : null}
          {canli ? <Text style={{ color: '#FFD54A', fontSize: 12.5, fontWeight: '700', marginTop: 4 }}>Şu anki skoru {tutanSimdi} kişi tahmin etmişti</Text> : null}
          {bitti ? (
            <View style={{ marginTop: 8, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 14, padding: 10 }}>
              <Text style={{ color: '#FFD54A', fontWeight: '800' }}>🎯 Tam bilenler ({tamBilen.length}){tamBilen.length ? ':' : ''}</Text>
              {tamBilen.length ? (
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 6 }}>
                  {tamBilen.slice(0, 20).map((x) => (
                    <Pressable key={x.id} onPress={() => profilAc({ uid: x.uid, name: x.name, avatar: x.avatar })} style={{ backgroundColor: '#FFD54A', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
                      <Text style={{ color: '#2A1F00', fontWeight: '800', fontSize: 12.5 }}>{x.name}</Text>
                    </Pressable>
                  ))}
                </View>
              ) : <Text style={{ color: '#C5CCD6', fontSize: 12.5, marginTop: 2 }}>Bu maçta kimse tam skoru bilemedi.</Text>}
              <Text style={{ color: '#C5CCD6', fontSize: 12.5, marginTop: 6 }}>{sonucBilen} kişi sonucu doğru bildi · puanlar Skor Ligi'ne 2 kat eklendi</Text>
            </View>
          ) : null}

          <View style={{ marginTop: 10 }}>
            {goster.map((x) => {
              const benimki = mine && x.id === mine.id;
              const tam = bitti && skorTam(x, m);
              return (
                <Pressable key={x.id} onPress={() => profilAc({ uid: x.uid, name: x.name, avatar: x.avatar })} accessibilityRole="button"
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 6, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)' }}>
                  <Avatar emoji={x.avatar} name={x.name} size={26} />
                  <Text numberOfLines={1} style={{ flex: 1, color: benimki ? '#FFD54A' : '#E6EAF0', fontSize: 13.5 }}>
                    <Text style={{ fontWeight: '800' }}>{benimki ? 'Sen' : x.name}</Text> {benimki ? 'tahmin ettin' : 'tahmin etti'}
                  </Text>
                  <Text style={{ color: tam ? '#FFD54A' : '#fff', fontWeight: '900', fontSize: 15 }}>{+x.h}-{+x.a}{tam ? ' 🎯' : ''}</Text>
                </Pressable>
              );
            })}
            {sirali.length > 10 ? (
              <Pressable onPress={() => setHepsi((v) => !v)} style={{ paddingVertical: 8 }}>
                <Text style={{ color: '#7CF0B0', fontWeight: '700', fontSize: 13 }}>{hepsi ? '▲ Daha az göster' : `▼ Tümünü gör (${sirali.length})`}</Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      ) : (
        <Text style={{ color: '#C5CCD6', fontSize: 13, marginTop: 12, textAlign: 'center' }}>{acik ? 'İlk tahmini sen yap! 🎯' : 'Bu maça tahmin yapılmadı.'}</Text>
      )}
    </View>
  );
}

// Gösterilecek büyük maçlar: bugün ve yarın, gizli/taslak olmayanlar (en fazla 2)
export function buyukMaclar(list, gun, yarin) {
  const gor = new Set();
  return (list || [])
    .filter((m) => m.buyuk && !m.hidden && !m.draft && (m.date === gun || m.date === yarin))
    .sort((x, y) => (x.robot ? 1 : 0) - (y.robot ? 1 : 0) || matchStart(x) - matchStart(y))
    .filter((m) => { const k = m.afId || `${m.home}|${m.away}|${m.date}`; if (gor.has(k)) return false; gor.add(k); return true; })
    .sort((x, y) => matchStart(x) - matchStart(y))
    .slice(0, 2);
}
