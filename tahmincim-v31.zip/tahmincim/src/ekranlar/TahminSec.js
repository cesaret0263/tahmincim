// 🎯 Gruplu tahmin seçici: admin (maç, kupon) ve Tribün aynı seçiciyi kullanır.
// 100+ seçenek, kesin skor ve "Kendin birleştir" (iki-üç seçeneği tek kombine yapar).
import React, { useState } from 'react';
import { View, Text, Pressable, TextInput } from 'react-native';
import { C, MARKET_GRUP, marketText, SKOR_PAZAR } from '../tema';
import { Btn, s } from '../parcalar';

const ILK_GRUP = 4; // kısa görünümde ilk 4 grup

export default function TahminSec({ value, onChange, compact, noOther, home, away }) {
  const [hepsi, setHepsi] = useState(!compact);
  const [birles, setBirles] = useState(false);
  const [parca, setParca] = useState([]);
  const sk = SKOR_PAZAR.exec(value || '');
  const [sh, setSh] = useState(sk ? sk[1] : '');
  const [sa, setSa] = useState(sk ? sk[2] : '');
  const grup = MARKET_GRUP.filter(([g]) => !(noOther && g === 'Diğer'));
  const goster = hepsi ? grup : grup.slice(0, ILK_GRUP);
  const aciklama = value && value !== 'Diğer' ? marketText(value, home, away) : '';

  const bas = (k) => {
    if (!birles) return onChange(k);
    if (k === 'Diğer') return;
    setParca((x) => (x.includes(k) ? x.filter((y) => y !== k) : x.length >= 3 ? x : [...x, k]));
  };
  const skorSec = () => {
    if (sh === '' || sa === '') return;
    const k = `Skor ${+sh}-${+sa}`;
    if (birles) setParca((x) => (x.includes(k) || x.length >= 3 ? x : [...x, k]));
    else onChange(k);
  };
  const birlesTamam = () => {
    if (parca.length < 2) return;
    onChange(parca.join(' & '));
    setBirles(false); setParca([]);
  };

  const Cip = ({ k }) => {
    const on = birles ? parca.includes(k) : value === k;
    return (
      <Pressable onPress={() => bas(k)} accessibilityRole={birles ? 'checkbox' : 'radio'} accessibilityState={{ selected: on }}
        style={{ paddingHorizontal: 10, minHeight: 36, borderRadius: 10, justifyContent: 'center', borderWidth: 1.5, borderColor: on ? C.ink : C.border, backgroundColor: on ? C.selBg : C.card }}>
        <Text style={{ fontWeight: on ? '800' : '600', color: C.ink, fontSize: 13 }}>{k}</Text>
      </Pressable>
    );
  };

  return (
    <View style={{ marginBottom: 10 }}>
      {value ? (
        <View style={{ backgroundColor: C.selBg, borderRadius: 12, padding: 10, marginBottom: 10 }}>
          <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 14 }}>Seçili: {value}</Text>
          {aciklama ? <Text style={{ color: C.mut, fontSize: 12.5 }}>{aciklama}</Text> : null}
        </View>
      ) : null}

      <Pressable onPress={() => { setBirles((x) => !x); setParca([]); }} accessibilityRole="button"
        style={{ flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 40, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1.5, borderStyle: birles ? 'solid' : 'dashed', borderColor: birles ? C.ink : C.border, backgroundColor: birles ? C.card : 'transparent', marginBottom: 10 }}>
        <Text style={{ fontSize: 15 }}>🔗</Text>
        <Text style={{ flex: 1, fontWeight: '700', color: C.ink, fontSize: 13.5 }}>{birles ? 'Birleştirmek istediğin 2-3 seçeneğe dokun' : 'Kendin birleştir (ör. İY 1 + 2.5 Üst)'}</Text>
        <Text style={{ color: C.mut, fontWeight: '700', fontSize: 12.5 }}>{birles ? 'Kapat' : 'Aç'}</Text>
      </Pressable>
      {birles ? (
        <View style={{ backgroundColor: C.card, borderRadius: 12, padding: 10, marginBottom: 10, borderWidth: 1, borderColor: C.border }}>
          <Text style={{ fontWeight: '800', color: C.ink }}>{parca.length ? parca.join(' & ') : 'Henüz seçilmedi'}</Text>
          {parca.length >= 2 ? <Text style={{ color: C.mut, fontSize: 12.5, marginTop: 2 }}>{marketText(parca.join(' & '), home, away)}</Text> : null}
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
            <Btn small kind="out" title="Temizle" onPress={() => setParca([])} style={{ flex: 1 }} />
            <Btn small kind="ink" title={parca.length >= 2 ? 'Bu kombineyi seç' : 'En az 2 seçenek'} disabled={parca.length < 2} onPress={birlesTamam} style={{ flex: 2 }} />
          </View>
        </View>
      ) : null}

      {goster.map(([g, list]) => (
        <View key={g} style={{ marginBottom: 6 }}>
          <Text style={{ color: C.mut, fontSize: 12, fontWeight: '700', marginBottom: 4 }}>{g}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {list.map((k) => <Cip key={k} k={k} />)}
          </View>
        </View>
      ))}

      {hepsi ? (
        <View style={{ marginBottom: 6 }}>
          <Text style={{ color: C.mut, fontSize: 12, fontWeight: '700', marginBottom: 4 }}>Kesin skor</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <TextInput value={sh} onChangeText={(v) => setSh(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="Ev" placeholderTextColor="#9AA2AD" accessibilityLabel="Ev sahibi golü"
              style={[s.input, { width: 64, textAlign: 'center', marginBottom: 0 }]} />
            <Text style={{ fontWeight: '800', color: C.ink, fontSize: 18 }}>-</Text>
            <TextInput value={sa} onChangeText={(v) => setSa(v.replace(/\D/g, '').slice(0, 2))} keyboardType="number-pad" placeholder="Dep" placeholderTextColor="#9AA2AD" accessibilityLabel="Deplasman golü"
              style={[s.input, { width: 64, textAlign: 'center', marginBottom: 0 }]} />
            <Btn small kind={sk && sk[1] === sh && sk[2] === sa ? 'ink' : 'out'} title={birles ? 'Ekle' : 'Seç'} disabled={sh === '' || sa === ''} onPress={skorSec} style={{ flex: 1 }} />
          </View>
        </View>
      ) : null}

      {compact ? (
        <Pressable onPress={() => setHepsi((x) => !x)} hitSlop={6} style={{ paddingVertical: 8 }}>
          <Text style={{ color: C.okTx, fontWeight: '700', fontSize: 13 }}>
            {hepsi ? '▲ Daha az seçenek' : `▼ Tüm seçenekler (handikap, ilk/ikinci yarı, İY/MS, kesin skor, kombine…)`}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}
