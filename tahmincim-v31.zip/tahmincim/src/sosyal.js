// 👥 Sosyal yardımcılar: engelleme, isim ekleri
import { Alert } from 'react-native';
import { updateUser } from './veri';
import { takibiBirak } from './topluluk';

// Bu kullanıcıyı engelledim mi?
export const engelliMi = (me, uid) => !!(me && uid && Array.isArray(me.engelli) && me.engelli.includes(uid));

// Engellenen kişinin yorumları, kuponları ve tahminleri bana görünmez; takipler iki yönde de düşer
export async function engelle(me, p) {
  if (!me || !me.id || !p || !p.uid || p.uid === me.id) return;
  const engelli = [...new Set([...(me.engelli || []), p.uid])].slice(-500);
  const engelliAd = { ...(me.engelliAd || {}), [p.uid]: String(p.name || 'Üye').slice(0, 40) };
  await updateUser(me.id, { engelli, engelliAd });
  await takibiBirak(me.id, p.uid).catch(() => {});
  await takibiBirak(p.uid, me.id).catch(() => {});
}
export async function engeliKaldir(me, uid) {
  if (!me || !me.id) return;
  const engelli = (me.engelli || []).filter((x) => x !== uid);
  const engelliAd = { ...(me.engelliAd || {}) };
  delete engelliAd[uid];
  await updateUser(me.id, { engelli, engelliAd });
}

// "Mustafa" → "Mustafa'nın", "Ali" → "Ali'nin", "Kerem" → "Kerem'in", "Burak" → "Burak'ın"
export function iyelik(ad) {
  const n = String(ad || 'Üye').trim();
  const kucuk = n.toLocaleLowerCase('tr');
  const sesli = [...kucuk].reverse().find((c) => 'aeıioöuü'.includes(c)) || 'e';
  const ek = { a: 'ın', ı: 'ın', e: 'in', i: 'in', o: 'un', u: 'un', ö: 'ün', ü: 'ün' }[sesli];
  const sonSesli = 'aeıioöuü'.includes(kucuk.slice(-1));
  return `${n}'${sonSesli ? 'n' : ''}${ek}`;
}

// Onay sorup engeller (kupon, yorum ve profil menülerinden)
export function engelleSor(me, p, toast) {
  Alert.alert(`${p.name || 'Bu kullanıcı'} engellensin mi?`, 'Yorumları, kuponları ve skor tahminleri sana görünmez. Seni takip edemez. Ben → Engellenenler\'den istediğin zaman kaldırabilirsin.', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Engelle', style: 'destructive', onPress: () => engelle(me, p).then(() => toast && toast('Engellendi')).catch(() => toast && toast('Engellenemedi')) },
  ]);
}
