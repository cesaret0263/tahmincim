import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, accentOf } from './src/tema';
import { Theme, ToastHost, useToast, Icon } from './src/parcalar';
import { useConfig, useMatches, useMe, useAdmin, adminLogin } from './src/veri';
import { initAds, adsAvailable, showRewarded } from './src/reklam';
import Bugun from './src/ekranlar/Bugun';
import Canli from './src/ekranlar/Canli';
import Ben from './src/ekranlar/Ben';
import Admin from './src/ekranlar/Admin';
import { isOpen } from './src/ekranlar/MacKart';
import { Detay, Kilit, SorumluOyun, Giris, Tanitim, Logo, SayacReklam } from './src/ekranlar/Pencereler';

export default function App() {
  const cfg = useConfig();
  const theme = useMemo(() => accentOf(cfg), [cfg]);
  return (
    <SafeAreaProvider>
      <Theme.Provider value={theme}>
        <ToastHost>
          <Main cfg={cfg} />
        </ToastHost>
      </Theme.Provider>
    </SafeAreaProvider>
  );
}

const TABS = [
  ['today', 'Bugün', 'football-outline'],
  ['live', 'Canlı', 'radio-outline'],
  ['me', 'Ben', 'person-outline'],
];

function Main({ cfg }) {
  const ins = useSafeAreaInsets();
  const toast = useToast();
  const matches = useMatches();
  const [me, updateMe] = useMe(cfg.startKeys);
  const { isAdmin } = useAdmin();
  const [tab, setTab] = useState('today');
  const [detail, setDetail] = useState(null);
  const [lock, setLock] = useState(null);
  const [sheet, setSheet] = useState(null); // 'rg' | 'login'
  const [admin, setAdmin] = useState(null); // null | 'list' | 'new'
  const [fakeAd, setFakeAd] = useState(null); // { forId }
  const [adBusy, setAdBusy] = useState(false);

  useEffect(() => { initAds(); }, []);

  const liveCount = matches.list.filter((m) => m.status === 'live').length;
  const hour = new Date().getHours();
  const greet = hour < 6 ? 'İyi geceler' : hour < 12 ? 'Günaydın' : hour < 18 ? 'İyi günler' : 'İyi akşamlar';

  const openMatch = (m) => (isOpen(m, me) ? setDetail(m) : setLock(m));

  const unlockWithKeys = (m) => {
    const cost = Math.max(1, Number(m.cost) || 1);
    if ((me?.keys || 0) < cost) return toast('Yeterli anahtarın yok');
    updateMe((x) => ({ keys: x.keys - cost, unlocked: [...x.unlocked, m.id] }));
    setLock(null);
    toast('Tahmin açıldı!');
    setTimeout(() => setDetail(m), 350);
  };

  // Reklam izlendi: anahtarı ver, bir maç için izlendiyse ve yetiyorsa maçı aç
  const reward = (forId) => {
    const r = Number(cfg.ads.reward) || 1;
    const m = forId ? matches.list.find((x) => x.id === forId) : null;
    const cost = m ? Math.max(1, Number(m.cost) || 1) : 0;
    const willOpen = m && !isOpen(m, me) && (me?.keys || 0) + r >= cost;
    updateMe((x) => {
      const keys = x.keys + r;
      return willOpen
        ? { keys: keys - cost, unlocked: [...x.unlocked, m.id], adCount: x.adCount + 1 }
        : { keys, adCount: x.adCount + 1 };
    });
    if (willOpen) {
      toast('Tahmin açıldı!');
      setTimeout(() => setDetail(m), 350);
    } else toast(`+${r} anahtar kazandın!`);
  };

  const watchAd = async (forId) => {
    const A = cfg.ads;
    if (!A.on) return;
    if ((me?.adCount || 0) >= (Number(A.limit) || 0)) return toast('Bugünkü reklam hakkın bitti, yarın tekrar gel');
    setLock(null);
    if (!adsAvailable()) return setFakeAd({ forId });
    setAdBusy(true);
    toast('Reklam yükleniyor…');
    const r = await showRewarded(A.unitId);
    setAdBusy(false);
    if (r === 'earned') reward(forId);
    else if (r === 'closed') toast('Reklam yarıda kaldı, anahtar verilmedi');
    else toast('Şu an reklam yok, biraz sonra tekrar dene');
  };

  if (!me) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={{ paddingTop: ins.top + 16, paddingHorizontal: 18, paddingBottom: ins.bottom + 110 }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, gap: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
            <Logo cfg={cfg} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.mut, fontSize: 13 }}>{greet}</Text>
              <Text numberOfLines={1} style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{cfg.name}</Text>
            </View>
          </View>
          <Pressable onPress={() => setTab('me')} accessibilityLabel={`Anahtarların: ${me.keys}`}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.key, borderRadius: 999, paddingHorizontal: 14, minHeight: 44 }}>
            <Icon name="key" size={17} color={C.onKey} />
            <Text style={{ fontWeight: '800', fontSize: 16, color: C.onKey }}>{me.keys}</Text>
          </Pressable>
        </View>

        {tab === 'today' ? (
          <Bugun cfg={cfg} matches={matches} me={me} onMatch={openMatch} isAdmin={isAdmin} onAddMatch={() => setAdmin('new')} />
        ) : tab === 'live' ? (
          <Canli matches={matches} me={me} onMatch={openMatch} />
        ) : (
          <Ben cfg={cfg} matches={matches} me={me} onMatch={openMatch} isAdmin={isAdmin}
            onAd={() => !adBusy && watchAd(null)} onAdmin={() => setAdmin('list')} onLogin={() => setSheet('login')}
            onOnb={() => updateMe(() => ({ onboarded: false }))} onRG={() => setSheet('rg')} />
        )}
      </ScrollView>

      {/* Alt menü */}
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8, paddingBottom: ins.bottom + 10, flexDirection: 'row' }}>
        {TABS.map(([k, label, icon]) => (
          <TabBtn key={k} on={tab === k} label={label} icon={icon} badge={k === 'live' ? liveCount : 0} onPress={() => setTab(k)} />
        ))}
      </View>

      {detail ? <Detay m={detail} onClose={() => setDetail(null)} /> : null}
      {lock ? <Kilit m={lock} me={me} cfg={cfg} onClose={() => setLock(null)} onAd={() => watchAd(lock.id)} onKey={() => unlockWithKeys(lock)} /> : null}
      {sheet === 'rg' ? <SorumluOyun onClose={() => setSheet(null)} /> : null}
      {sheet === 'login' ? <Giris onClose={() => setSheet(null)} onLogin={async (e, p) => { await adminLogin(e, p); toast('Giriş yapıldı'); }} /> : null}
      <Admin visible={!!admin && isAdmin} startWith={admin} onClose={() => setAdmin(null)} matches={matches} cfg={cfg} />
      <SayacReklam visible={!!fakeAd} cfg={cfg} seconds={15}
        onCancel={() => { setFakeAd(null); toast('Reklam yarıda kaldı, anahtar verilmedi'); }}
        onDone={() => { const f = fakeAd; setFakeAd(null); reward(f?.forId); }} />
      <Tanitim visible={!me.onboarded} cfg={cfg} onDone={() => updateMe(() => ({ onboarded: true }))} />
    </View>
  );
}

function TabBtn({ on, label, icon, badge, onPress }) {
  const t = React.useContext(Theme);
  return (
    <Pressable onPress={onPress} accessibilityRole="tab" accessibilityState={{ selected: on }} style={{ flex: 1, alignItems: 'center', gap: 4, minHeight: 52 }}>
      <ThemedPill on={on}><Icon name={on ? icon.replace('-outline', '') : icon} size={22} color={on ? t.onAcc : C.mut} /></ThemedPill>
      <Text style={{ fontSize: 13, fontWeight: on ? '700' : '600', color: on ? C.ink : C.mut }}>{label}</Text>
      {badge ? (
        <View style={{ position: 'absolute', top: 0, left: '58%', backgroundColor: '#E5484D', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
          <Text style={{ color: '#fff', fontSize: 10.5, fontWeight: '700' }}>{badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

function ThemedPill({ on, children }) {
  const t = React.useContext(Theme);
  return <View style={{ paddingHorizontal: 18, paddingVertical: 5, borderRadius: 999, backgroundColor: on ? t.acc : 'transparent' }}>{children}</View>;
}
