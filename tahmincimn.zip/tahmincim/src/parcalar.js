import React, { createContext, useContext, useRef, useState, useCallback } from 'react';
import { View, Text, Image, Pressable, Modal, StyleSheet, Animated, ScrollView, TextInput, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { C, CONF, hashColor, initials, isImg } from './tema';

export const Theme = createContext({ acc: '#00D26A', onAcc: '#0B2416' });
export const useTheme = () => useContext(Theme);

export function Icon({ name, size = 20, color = C.ink }) {
  return <Ionicons name={name} size={size} color={color} />;
}

export function Crest({ name, logo, size = 28 }) {
  const img = isImg(logo);
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: img ? '#fff' : hashColor(name), alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      {img ? (
        <Image source={{ uri: logo }} style={{ width: size, height: size }} resizeMode="contain" />
      ) : (
        <Text style={{ color: '#fff', fontWeight: '700', fontSize: Math.round(size * 0.32) }}>{initials(name)}</Text>
      )}
    </View>
  );
}

export function Btn({ title, onPress, kind = 'acc', icon, disabled, loading, small, style }) {
  const t = useTheme();
  const bg = { acc: t.acc, ink: C.ink, out: '#fff', red: C.red, ghost: 'transparent' }[kind];
  const fg = { acc: t.onAcc, ink: '#fff', out: C.ink, red: '#fff', ghost: C.mut }[kind];
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      style={({ pressed }) => [
        { backgroundColor: bg, minHeight: small ? 46 : 56, borderRadius: small ? 14 : 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, gap: 10, opacity: disabled ? 0.45 : pressed ? 0.85 : 1 },
        kind === 'out' && { borderWidth: 2, borderColor: C.line },
        style,
      ]}
    >
      {loading ? <ActivityIndicator color={fg} /> : icon ? <Icon name={icon} color={fg} size={20} /> : null}
      <Text style={{ color: fg, fontWeight: '700', fontSize: small ? 15 : 17 }}>{title}</Text>
    </Pressable>
  );
}

export function ConfBars({ n = 3, color }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <Text style={{ color, fontWeight: '700', fontSize: 13 }}>{CONF[n - 1]}</Text>
      <View style={{ flexDirection: 'row', gap: 3 }}>
        {[1, 2, 3].map((i) => (
          <View key={i} style={{ width: 6, height: 16, borderRadius: 3, backgroundColor: color, opacity: i <= n ? 1 : 0.25 }} />
        ))}
      </View>
    </View>
  );
}

export function Chip({ text, bg, color, icon }) {
  return (
    <View style={{ backgroundColor: bg, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 5, maxWidth: 150 }}>
      {icon ? <Icon name={icon} size={14} color={color} /> : null}
      <Text numberOfLines={1} style={{ color, fontWeight: '700', fontSize: 13.5 }}>{text}</Text>
    </View>
  );
}

export function Card({ children, style }) {
  return <View style={[{ backgroundColor: C.card, borderRadius: 22, padding: 18, marginBottom: 12 }, style]}>{children}</View>;
}

/* Alttan açılan pencere */
export function Sheet({ visible, onClose, children }) {
  const ins = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <Pressable style={{ flex: 1, backgroundColor: 'rgba(18,22,28,.55)' }} onPress={onClose} accessibilityLabel="Kapat" />
      <View style={{ backgroundColor: '#fff', borderTopLeftRadius: 30, borderTopRightRadius: 30, maxHeight: '92%', position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 12, paddingBottom: ins.bottom + 24 }} keyboardShouldPersistTaps="handled">
          <View style={{ width: 44, height: 5, borderRadius: 5, backgroundColor: '#D9DCD4', alignSelf: 'center', marginBottom: 16 }} />
          {children}
        </ScrollView>
      </View>
    </Modal>
  );
}

/* Kısa bildirim */
const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastHost({ children }) {
  const [msg, setMsg] = useState('');
  const op = useRef(new Animated.Value(0)).current;
  const timer = useRef(null);
  const ins = useSafeAreaInsets();
  const show = useCallback((m) => {
    setMsg(m);
    clearTimeout(timer.current);
    Animated.timing(op, { toValue: 1, duration: 180, useNativeDriver: true }).start();
    timer.current = setTimeout(() => Animated.timing(op, { toValue: 0, duration: 220, useNativeDriver: true }).start(), 2400);
  }, [op]);
  return (
    <ToastCtx.Provider value={show}>
      {children}
      <Animated.View pointerEvents="none" style={{ position: 'absolute', left: 20, right: 20, bottom: ins.bottom + 100, alignItems: 'center', opacity: op }}>
        <View style={{ backgroundColor: C.ink, borderRadius: 14, paddingHorizontal: 18, paddingVertical: 12 }}>
          <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>{msg}</Text>
        </View>
      </Animated.View>
    </ToastCtx.Provider>
  );
}

/* Admin form parçaları */
export function Field({ label, style, multiline, ...p }) {
  return (
    <View style={[{ marginBottom: 12 }, style]}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TextInput
        {...p}
        multiline={multiline}
        accessibilityLabel={label}
        placeholderTextColor="#9AA2AD"
        style={[s.input, multiline && { minHeight: 90, textAlignVertical: 'top' }]}
      />
    </View>
  );
}

export function Seg({ options, value, onChange, tall }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
      {options.map(([v, l, icon]) => {
        const on = String(v) === String(value);
        return (
          <Pressable
            key={String(v)}
            onPress={() => onChange(v)}
            accessibilityRole="button"
            accessibilityState={{ selected: on }}
            style={{ flexGrow: 1, flexBasis: '30%', minHeight: tall ? 64 : 46, borderRadius: 12, borderWidth: on ? 2 : 1.5, borderColor: on ? C.ink : '#D9DCD4', backgroundColor: on ? t.acc : '#fff', alignItems: 'center', justifyContent: 'center', gap: 4, paddingHorizontal: 4 }}
          >
            {icon ? <Icon name={icon} size={18} color={on ? t.onAcc : C.ink} /> : null}
            <Text style={{ fontWeight: on ? '700' : '600', color: on ? t.onAcc : C.ink, fontSize: 14 }}>{l}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Toggle({ value, onChange, label, sub }) {
  const t = useTheme();
  return (
    <Pressable onPress={() => onChange(!value)} accessibilityRole="switch" accessibilityState={{ checked: !!value }} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48, marginBottom: 8, gap: 12 }}>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>{label}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <View style={{ width: 54, height: 32, borderRadius: 16, backgroundColor: value ? t.acc : '#D0D4CB', justifyContent: 'center', paddingHorizontal: 4 }}>
        <View style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: value ? t.onAcc : '#fff', alignSelf: value ? 'flex-end' : 'flex-start' }} />
      </View>
    </Pressable>
  );
}

export const s = StyleSheet.create({
  h1: { fontSize: 26, fontWeight: '800', color: C.ink, letterSpacing: -0.5 },
  h2: { fontSize: 19, fontWeight: '800', color: C.ink },
  h3: { fontSize: 16, fontWeight: '700', color: C.ink, marginBottom: 12 },
  sub: { color: C.mut, fontSize: 15, lineHeight: 21 },
  label: { fontSize: 13, fontWeight: '600', color: C.mut, marginBottom: 6 },
  input: { borderWidth: 1.5, borderColor: '#D9DCD4', borderRadius: 12, padding: 12, fontSize: 16, fontWeight: '600', color: C.ink, backgroundColor: '#fff', minHeight: 48 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 10, minHeight: 64 },
  empty: { backgroundColor: C.card, borderRadius: 22, padding: 28, alignItems: 'center', gap: 6 },
  note: { fontSize: 12.5, color: C.mut, textAlign: 'center', marginTop: 16, lineHeight: 18 },
});
