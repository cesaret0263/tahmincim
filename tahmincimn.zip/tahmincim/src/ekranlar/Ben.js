import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { C } from '../tema';
import { Btn, Card, Icon, s } from '../parcalar';
import { MacSatiri } from './MacKart';

function Link({ icon, title, sub, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, borderTopWidth: 1, borderTopColor: C.line }}>
      <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={18} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>{title}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <Icon name="chevron-forward" size={18} color={C.mut} />
    </Pressable>
  );
}

export default function Ben({ cfg, matches, me, onAd, onMatch, isAdmin, onAdmin, onLogin, onOnb, onRG }) {
  const A = cfg.ads;
  const left = Math.max(0, (Number(A.limit) || 0) - (me?.adCount || 0));
  const F = matches.list.filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost'));
  const won = F.filter((m) => m.result === 'won').length;
  const last = [...F].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5);

  return (
    <View>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 28, fontWeight: '800', color: C.onKey }}>{me?.keys ?? 0}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 18, fontWeight: '700', color: C.ink }}>Anahtarların</Text>
            <Text style={s.sub}>Kilitli tahminleri açmak için kullanılır</Text>
          </View>
        </View>
        {A.on ? (
          <Btn style={{ marginTop: 16 }} icon="play" disabled={left <= 0} onPress={onAd}
            title={left > 0 ? `Reklam izle, +${Number(A.reward) || 1} anahtar (${left} hak)` : 'Bugünkü reklam hakkın bitti'} />
        ) : null}
      </Card>

      <Card>
        <Text style={s.h3}>Tahminlerimizin sonucu</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[[F.length ? '%' + Math.round((won / F.length) * 100) : '–', 'Başarı'], [won, 'Tuttu'], [F.length - won, 'Tutmadı']].map(([v, l]) => (
            <View key={l} style={{ flex: 1, backgroundColor: C.bg, borderRadius: 14, padding: 12, alignItems: 'center' }}>
              <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{v}</Text>
              <Text style={{ fontSize: 12.5, color: C.mut }}>{l}</Text>
            </View>
          ))}
        </View>
        <View style={{ marginTop: 12 }}>
          {last.length ? last.map((m) => <MacSatiri key={m.id} m={m} me={me} onPress={() => onMatch(m)} />) : <Text style={s.sub}>Sonuçlanan maç olunca burada görünecek.</Text>}
        </View>
      </Card>

      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          {isAdmin ? <Link icon="construct-outline" title="Admin paneli" sub="Maç ekle, logo, mesaj, reklam" onPress={onAdmin} /> : null}
          <Link icon="help-circle-outline" title="Nasıl kullanılır?" sub="Tanıtımı tekrar göster" onPress={onOnb} />
          <Link icon="shield-checkmark-outline" title="Sorumlu oyun" sub="18+ · Bilgilendirme" onPress={onRG} />
          {!isAdmin ? <Link icon="person-circle-outline" title="Yönetici girişi" onPress={onLogin} /> : null}
        </View>
      </Card>
    </View>
  );
}
