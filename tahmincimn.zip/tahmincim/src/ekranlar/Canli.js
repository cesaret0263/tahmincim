import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { C, byTime, predText, scoreOf } from '../tema';
import { Crest, Icon, s, useTheme } from '../parcalar';
import { MacSatiri, isOpen } from './MacKart';

export default function Canli({ matches, me, onMatch }) {
  const t = useTheme();
  const L = matches.list.filter((m) => m.status === 'live').sort(byTime);
  const [f, ...rest] = L;
  return (
    <View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <Text style={s.h1}>Şu an oynanıyor</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.redBg, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999 }}>
          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#E5484D' }} />
          <Text style={{ color: C.red, fontWeight: '700' }}>{L.length} maç</Text>
        </View>
      </View>
      {!f ? (
        <View style={s.empty}>
          <Text style={[s.h3, { marginBottom: 0 }]}>Şu an canlı maç yok</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>Maç başlayınca burada görünecek.</Text>
        </View>
      ) : (
        <>
          <Pressable onPress={() => onMatch(f)} accessibilityRole="button" style={{ backgroundColor: C.ink, borderRadius: 26, padding: 20, marginBottom: 12 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: '#C5CCD6' }}>{f.league}</Text>
              <Text style={{ color: '#FF8A8E', fontWeight: '700' }}>● {f.minute}. dakika</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: 16 }}>
              <View style={{ width: '32%', alignItems: 'center', gap: 8 }}>
                <Crest name={f.home} logo={f.homeLogo} size={48} />
                <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>{f.home}</Text>
              </View>
              <Text style={{ color: '#fff', fontSize: 40, fontWeight: '800' }}>{scoreOf(f).join(' – ')}</Text>
              <View style={{ width: '32%', alignItems: 'center', gap: 8 }}>
                <Crest name={f.away} logo={f.awayLogo} size={48} />
                <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>{f.away}</Text>
              </View>
            </View>
            {isOpen(f, me) ? (
              <View style={{ backgroundColor: t.acc, borderRadius: 16, padding: 14 }}>
                <Text style={{ color: t.onAcc, fontWeight: '600', fontSize: 13 }}>Şu anki tahminimiz</Text>
                <Text style={{ color: t.onAcc, fontWeight: '800', fontSize: 17 }}>{f.liveText || predText(f)}</Text>
              </View>
            ) : (
              <View style={{ backgroundColor: C.dark2, borderRadius: 16, padding: 14, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                <Icon name="lock-closed" color="#fff" size={18} />
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Canlı tahmini açmak için dokun</Text>
              </View>
            )}
          </Pressable>
          {rest.map((m) => <MacSatiri key={m.id} m={m} me={me} onPress={() => onMatch(m)} />)}
        </>
      )}
    </View>
  );
}
