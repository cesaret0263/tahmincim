import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, Modal, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, CONF, predText, scoreOf, isImg } from '../tema';
import { Btn, Crest, Field, Icon, Sheet, s, useTheme } from '../parcalar';

/* ---------------- Tahmin detayı ---------------- */
export function Detay({ m, onClose }) {
  const t = useTheme();
  if (!m) return null;
  const p = [+m.p1 || 0, +m.px || 0, +m.p2 || 0];
  const ps = p[0] + p[1] + p[2];
  const why = String(m.reasons || '').split('\n').map((x) => x.trim()).filter(Boolean);
  const live = m.status === 'live';
  const fin = m.status === 'finished';
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ flexDirection: 'row' }}>
          <Crest name={m.home} logo={m.homeLogo} size={40} />
          <View style={{ marginLeft: -8 }}><Crest name={m.away} logo={m.awayLogo} size={40} /></View>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: '700', fontSize: 17, color: C.ink }}>{m.home} – {m.away}</Text>
          <Text style={[s.sub, live && { color: C.red, fontWeight: '700' }]}>
            {live ? `Canlı ${m.minute || ''}' · ${scoreOf(m).join('-')}` : fin ? `Bitti · ${scoreOf(m).join('-')}` : m.time}
            {m.league ? ` · ${m.league}` : ''}
          </Text>
        </View>
      </View>

      <View style={{ backgroundColor: C.ink, borderRadius: 24, padding: 20, marginTop: 14 }}>
        <Text style={{ color: t.acc, fontWeight: '800', fontSize: 12, letterSpacing: 1 }}>TAHMİNİMİZ</Text>
        <Text style={{ color: '#fff', fontSize: 25, fontWeight: '800', marginTop: 10, marginBottom: 6, lineHeight: 30 }}>{predText(m)}</Text>
        {m.market && m.market !== 'Diğer' ? <Text style={{ color: '#A3ADBA' }}>Bahis dilinde: {m.market}</Text> : null}
        <View style={{ flexDirection: 'row', gap: 6, marginTop: 14 }}>
          {CONF.map((c, i) => {
            const on = (m.conf || 3) === i + 1;
            return (
              <View key={c} style={{ flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: 'center', backgroundColor: on ? t.acc : C.dark2 }}>
                <Text style={{ color: on ? t.onAcc : '#A3ADBA', fontWeight: on ? '700' : '600' }}>{c}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {live && m.liveText ? (
        <View style={{ backgroundColor: C.redBg, borderRadius: 16, padding: 14, marginTop: 12 }}>
          <Text style={{ color: C.red, fontWeight: '700' }}>● Canlı: {m.liveText}</Text>
        </View>
      ) : null}
      {fin && m.result ? (
        <View style={{ backgroundColor: m.result === 'won' ? C.okBg : C.redBg, borderRadius: 16, padding: 14, marginTop: 12 }}>
          <Text style={{ color: m.result === 'won' ? C.okTx : C.red, fontWeight: '700' }}>{m.result === 'won' ? '✓ Bu tahmin tuttu' : '✕ Bu tahmin tutmadı'}</Text>
        </View>
      ) : null}

      {ps > 0 ? (
        <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 18, marginTop: 12 }}>
          <Text style={s.h3}>Kim kazanır?</Text>
          <View style={{ flexDirection: 'row', height: 14, borderRadius: 8, overflow: 'hidden', gap: 3, marginBottom: 10 }}>
            <View style={{ flex: p[0], backgroundColor: C.ink }} />
            <View style={{ flex: p[1], backgroundColor: '#B8BDB3' }} />
            <View style={{ flex: p[2], backgroundColor: C.key }} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 6 }}>
            <Text style={{ flex: 1 }}><Text style={{ fontWeight: '800' }}>%{p[0]}</Text> {m.home}</Text>
            <Text style={{ color: C.mut }}><Text style={{ fontWeight: '800' }}>%{p[1]}</Text> Ber.</Text>
            <Text style={{ flex: 1, textAlign: 'right' }}><Text style={{ fontWeight: '800' }}>%{p[2]}</Text> {m.away}</Text>
          </View>
        </View>
      ) : null}

      {why.length ? (
        <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 18, marginTop: 12 }}>
          <Text style={[s.h3, { marginBottom: 4 }]}>Neden böyle düşünüyoruz?</Text>
          {why.map((w, i) => (
            <View key={i} style={{ flexDirection: 'row', gap: 12, marginTop: 10, alignItems: 'flex-start' }}>
              <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: C.okBg, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="checkmark" size={15} color={C.okTx} />
              </View>
              <Text style={{ flex: 1, fontSize: 15, lineHeight: 21, color: C.ink }}>{w}</Text>
            </View>
          ))}
        </View>
      ) : null}

      <Text style={s.note}>Tahminler bilgi amaçlıdır, garanti değildir · 18+</Text>
      <Btn kind="ink" title="Tamam" onPress={onClose} style={{ marginTop: 12 }} />
    </Sheet>
  );
}

/* ---------------- Kilitli maç ---------------- */
export function Kilit({ m, me, cfg, onClose, onAd, onKey }) {
  const t = useTheme();
  if (!m) return null;
  const cost = Math.max(1, Number(m.cost) || 1);
  const A = cfg.ads;
  const left = (Number(A.limit) || 0) - (me?.adCount || 0);
  const vip = m.access === 'vip';
  const enough = (me?.keys || 0) >= cost;
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ alignItems: 'center', gap: 10 }}>
        <View style={{ width: 76, height: 76, borderRadius: 38, backgroundColor: vip ? C.vipBg : C.lockBg, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={vip ? 'diamond-outline' : 'lock-closed-outline'} size={34} color={vip ? C.vipTx : '#C25400'} />
        </View>
        <Text style={[s.h1, { textAlign: 'center' }]}>{vip ? 'Bu bir VIP tahmin' : 'Bu tahmin kilitli'}</Text>
        <Text style={[s.sub, { textAlign: 'center' }]}>{m.home} – {m.away} tahminini görmek için {cost} anahtar gerekiyor.</Text>
      </View>
      {A.on && left > 0 ? (
        <Pressable onPress={onAd} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: t.acc, borderRadius: 20, padding: 16, minHeight: 72, marginTop: 16 }}>
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: t.onAcc, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="play" size={18} color={t.acc} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: t.onAcc, fontWeight: '800', fontSize: 17 }}>Kısa reklam izle</Text>
            <Text style={{ color: t.onAcc, fontSize: 14 }}>Ücretsiz · +{Number(A.reward) || 1} anahtar</Text>
          </View>
        </Pressable>
      ) : null}
      <Pressable onPress={enough ? onKey : undefined} disabled={!enough} accessibilityRole="button" accessibilityState={{ disabled: !enough }}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: '#fff', borderWidth: 2, borderColor: C.line, borderRadius: 20, padding: 14, minHeight: 72, marginTop: 12, opacity: enough ? 1 : 0.5 }}>
        <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="key-outline" size={20} color={C.onKey} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: C.ink, fontWeight: '800', fontSize: 17 }}>{cost} anahtar kullan</Text>
          <Text style={{ color: C.mut, fontSize: 14 }}>Elinde {me?.keys || 0} anahtar var</Text>
        </View>
      </Pressable>
      <Btn kind="ghost" title="Vazgeç" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}

/* ---------------- Sorumlu oyun ---------------- */
export function SorumluOyun({ onClose }) {
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>Sorumlu oyun</Text>
      <View style={{ backgroundColor: C.bg, borderRadius: 20, padding: 16, marginVertical: 14, gap: 8 }}>
        <Text style={s.sub}>• Tahminler istatistik ve yoruma dayanır, hiçbir sonuç garanti değildir.</Text>
        <Text style={s.sub}>• Kaybetmeyi göze alamayacağın parayla oynama.</Text>
        <Text style={s.sub}>• 18 yaşından küçükler bahis oynayamaz.</Text>
        <Text style={s.sub}>• Kontrolü kaybettiğini düşünüyorsan Yeşilay Danışmanlık Merkezi'nden (YEDAM) ücretsiz destek alabilirsin: 115</Text>
      </View>
      <Btn kind="ink" title="Anladım" onPress={onClose} />
    </Sheet>
  );
}

/* ---------------- Yönetici girişi ---------------- */
export function Giris({ onClose, onLogin }) {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const go = async () => {
    setBusy(true);
    setErr('');
    try {
      await onLogin(email, pass);
      onClose();
    } catch (e) {
      setErr('E-posta veya şifre hatalı.');
    }
    setBusy(false);
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>Yönetici girişi</Text>
      <Text style={[s.sub, { marginBottom: 16, marginTop: 4 }]}>Sadece uygulamanın sahibi içindir.</Text>
      <Field label="E-posta" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" />
      <Field label="Şifre" value={pass} onChangeText={setPass} secureTextEntry autoComplete="password" />
      {err ? <Text style={{ color: C.red, fontWeight: '600', marginBottom: 10 }}>{err}</Text> : null}
      <Btn kind="ink" title="Giriş yap" onPress={go} loading={busy} disabled={!email || !pass} />
    </Sheet>
  );
}

/* ---------------- Tanıtım ---------------- */
export function Tanitim({ visible, cfg, onDone }) {
  const t = useTheme();
  const ins = useSafeAreaInsets();
  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onDone} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: C.ink, paddingHorizontal: 24, paddingTop: ins.top + 40, paddingBottom: ins.bottom + 28, gap: 28 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Logo cfg={cfg} />
          <Text style={{ color: '#fff', fontSize: 22, fontWeight: '800' }}>{cfg.name}</Text>
        </View>
        <Text style={{ color: '#fff', fontSize: 40, fontWeight: '800', lineHeight: 44, letterSpacing: -1 }}>
          Maçı seç.{'\n'}Tahmini gör.{'\n'}<Text style={{ color: t.acc }}>Bu kadar.</Text>
        </Text>
        <View style={{ gap: 12 }}>
          {['Bir maça dokun', 'Tahmini sade bir dille oku', 'Kilitliyse kısa bir reklamla aç'].map((x, i) => (
            <View key={x} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: '#1E242D', alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: t.acc, fontWeight: '800' }}>{i + 1}</Text>
              </View>
              <Text style={{ color: '#fff', fontSize: 16 }}>{x}</Text>
            </View>
          ))}
        </View>
        <View style={{ marginTop: 'auto', gap: 12, alignItems: 'center' }}>
          <Btn title="Hadi başlayalım" onPress={onDone} style={{ alignSelf: 'stretch' }} />
          <Text style={{ color: '#A3ADBA', fontSize: 12.5, textAlign: 'center' }}>18 yaş ve üzeri içindir · Tahminler bilgi amaçlıdır, garanti değildir</Text>
        </View>
      </View>
    </Modal>
  );
}

export function Logo({ cfg, size = 40 }) {
  const t = useTheme();
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.32, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      {isImg(cfg.logo) ? <Image source={{ uri: cfg.logo }} style={{ width: size, height: size }} resizeMode="cover" /> : <Icon name="checkmark" size={size * 0.55} color={t.onAcc} />}
    </View>
  );
}

/* ---------------- Yedek reklam ekranı (AdMob yoksa) ---------------- */
export function SayacReklam({ visible, cfg, seconds = 15, onDone, onCancel }) {
  const t = useTheme();
  const ins = useSafeAreaInsets();
  const [left, setLeft] = useState(seconds);
  const timer = useRef(null);
  useEffect(() => {
    if (!visible) return;
    setLeft(seconds);
    timer.current = setInterval(() => setLeft((x) => (x <= 1 ? (clearInterval(timer.current), 0) : x - 1)), 1000);
    return () => clearInterval(timer.current);
  }, [visible, seconds]);
  const img = cfg.ads.bannerImg;
  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onCancel} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: '#0b0d11', paddingTop: ins.top + 10, paddingBottom: ins.bottom + 20, paddingHorizontal: 18 }}>
        <View style={{ height: 5, backgroundColor: '#222', borderRadius: 3, overflow: 'hidden' }}>
          <View style={{ height: 5, width: `${((seconds - left) / seconds) * 100}%`, backgroundColor: t.acc }} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
          <Text style={{ color: '#aaa' }}>Reklam · {left} sn</Text>
          <Pressable onPress={onCancel} accessibilityLabel="Kapat" style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: '#1d2128', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="close" color="#ccc" />
          </Pressable>
        </View>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          {isImg(img) ? (
            <Image source={{ uri: img }} style={{ width: '100%', aspectRatio: 1.2, borderRadius: 18 }} resizeMode="contain" />
          ) : (
            <View style={{ width: '100%', aspectRatio: 1, borderRadius: 24, borderWidth: 2, borderStyle: 'dashed', borderColor: '#3a404a', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
              <Text style={{ color: '#8b94a1', textAlign: 'center', lineHeight: 22 }}>Reklam alanı{'\n'}(Test sürümü: gerçek reklam APK'da görünür)</Text>
            </View>
          )}
        </View>
        <Btn title={left > 0 ? 'İzlemeye devam et…' : 'Ödülü al'} disabled={left > 0} onPress={onDone} />
      </View>
    </Modal>
  );
}
