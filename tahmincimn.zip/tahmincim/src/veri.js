import { useEffect, useRef, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, doc, onSnapshot, setDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { db, auth, configured } from './firebase';
import { ADMIN_EMAIL } from './ayarlar';
import { mergeCfg, today } from './tema';

/* ---------- herkese açık veriler (Firestore) ---------- */
export function useConfig() {
  const [cfg, setCfg] = useState(mergeCfg(null));
  useEffect(() => {
    if (!configured) return;
    return onSnapshot(doc(db, 'app', 'config'), (s) => setCfg(mergeCfg(s.exists() ? s.data() : null)), () => {});
  }, []);
  return cfg;
}

export function useMatches() {
  const [state, setState] = useState({ list: [], loading: true, error: null });
  useEffect(() => {
    if (!configured) {
      setState({ list: [], loading: false, error: 'config' });
      return;
    }
    const t = setTimeout(() => setState((s) => (s.loading ? { ...s, error: 'timeout' } : s)), 10000);
    const un = onSnapshot(
      collection(db, 'matches'),
      (snap) => {
        clearTimeout(t);
        setState({ list: snap.docs.map((d) => ({ id: d.id, ...d.data() })), loading: false, error: null });
      },
      () => {
        clearTimeout(t);
        setState((s) => ({ ...s, loading: false, error: 'read' }));
      }
    );
    return () => {
      clearTimeout(t);
      un();
    };
  }, []);
  return state;
}

export const saveMatch = (m) => {
  const { id, ...rest } = m;
  return setDoc(doc(db, 'matches', id), rest);
};
export const removeMatch = (id) => deleteDoc(doc(db, 'matches', id));
export const saveConfig = (c) => setDoc(doc(db, 'app', 'config'), c);
export async function clearBanko(list, date, exceptId) {
  const others = list.filter((x) => x.banko && x.date === date && x.id !== exceptId);
  if (!others.length) return;
  const b = writeBatch(db);
  others.forEach((x) => b.update(doc(db, 'matches', x.id), { banko: false }));
  await b.commit();
}

/* ---------- kullanıcının kendi verisi (sadece telefonda) ---------- */
const ME_KEY = 'tahmincim_me_v1';
export function useMe(startKeys) {
  const [me, setMe] = useState(null);
  const ref = useRef(null);
  useEffect(() => {
    AsyncStorage.getItem(ME_KEY)
      .then((s) => {
        let v = null;
        try { v = JSON.parse(s || 'null'); } catch (e) {}
        v = v || { keys: null, unlocked: [], adDay: '', adCount: 0, onboarded: false };
        setMe(v);
      })
      .catch(() => setMe({ keys: null, unlocked: [], adDay: '', adCount: 0, onboarded: false }));
  }, []);
  useEffect(() => {
    if (!me) return;
    let changed = false;
    const n = { ...me };
    if (n.keys == null) { n.keys = Number(startKeys) || 0; changed = true; }
    if (n.adDay !== today()) { n.adDay = today(); n.adCount = 0; changed = true; }
    if (changed) setMe(n);
  }, [me, startKeys]);
  useEffect(() => {
    if (me && ref.current !== me) {
      ref.current = me;
      AsyncStorage.setItem(ME_KEY, JSON.stringify(me)).catch(() => {});
    }
  }, [me]);
  const update = useCallback((fn) => setMe((m) => ({ ...m, ...fn(m) })), []);
  return [me, update];
}

/* ---------- admin girişi ---------- */
export function useAdmin() {
  const [user, setUser] = useState(null);
  useEffect(() => {
    if (!configured) return;
    return onAuthStateChanged(auth, setUser);
  }, []);
  const want = String(ADMIN_EMAIL || '').trim().toLowerCase();
  const isAdmin = !!user && (!want || String(user.email || '').toLowerCase() === want);
  return { user, isAdmin };
}
export const adminLogin = (email, pass) => signInWithEmailAndPassword(auth, email.trim(), pass);
export const adminLogout = () => signOut(auth);
