import { useEffect, useRef, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, doc, onSnapshot, setDoc, deleteDoc, writeBatch, getDoc, updateDoc, query, orderBy, limit } from 'firebase/firestore';
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail, updateProfile, signOut, deleteUser } from 'firebase/auth';
import { db, auth, configured } from './firebase';
import { ADMIN_EMAIL } from './ayarlar';
import { mergeCfg, today, AD_WINDOW } from './tema';

/* ---------- herkese açık veriler (Firestore) ---------- */
export function useConfig() {
  const [cfg, setCfg] = useState(mergeCfg(null));
  useEffect(() => {
    if (!configured) return;
    return onSnapshot(doc(db, 'app', 'config'), (s) => setCfg(mergeCfg(s.exists() ? s.data() : null)), () => {});
  }, []);
  return cfg;
}

export function useMatches() {
  const [state, setState] = useState({ list: [], loading: true, error: null });
  useEffect(() => {
    if (!configured) {
      setState({ list: [], loading: false, error: 'config' });
      return;
    }
    const t = setTimeout(() => setState((s) => (s.loading ? { ...s, error: 'timeout' } : s)), 10000);
    const un = onSnapshot(
      collection(db, 'matches'),
      (snap) => {
        clearTimeout(t);
        setState({ list: snap.docs.map((d) => ({ id: d.id, ...d.data() })), loading: false, error: null });
      },
      () => {
        clearTimeout(t);
        setState((s) => ({ ...s, loading: false, error: 'read' }));
      }
    );
    return () => {
      clearTimeout(t);
      un();
    };
  }, []);
  return state;
}

export const saveMatch = (m) => {
  const { id, ...rest } = m;
  return setDoc(doc(db, 'matches', id), rest);
};
export const removeMatch = (id) => deleteDoc(doc(db, 'matches', id));
export const saveConfig = (c) => setDoc(doc(db, 'app', 'config'), c);
export async function clearBanko(list, date, exceptId) {
  const others = list.filter((x) => x.banko && x.date === date && x.id !== exceptId);
  if (!others.length) return;
  const b = writeBatch(db);
  others.forEach((x) => b.update(doc(db, 'matches', x.id), { banko: false }));
  await b.commit();
}

export function useCoupons() {
  const [state, setState] = useState({ list: [], loading: true });
  useEffect(() => {
    if (!configured) { setState({ list: [], loading: false }); return; }
    return onSnapshot(collection(db, 'coupons'),
      (snap) => setState({ list: snap.docs.map((d) => ({ id: d.id, ...d.data() })), loading: false }),
      () => setState((x) => ({ ...x, loading: false })));
  }, []);
  return state;
}
export const saveCoupon = (c) => {
  const { id, ...rest } = c;
  return setDoc(doc(db, 'coupons', id), rest);
};
export const removeCoupon = (id) => deleteDoc(doc(db, 'coupons', id));

/* ---------- hesap: giriş, kayıt, kullanıcı verisi ---------- */
const ONB_KEY = 'tahmincim_onb_v1';
const GUEST = { keys: 0, unlocked: [], adCount: 0, vipUntil: 0, guest: true };

function newProfile(user, startKeys, name) {
  return {
    name: name || user.displayName || '',
    email: String(user.email || '').toLowerCase(),
    createdAt: Date.now(),
    lastSeen: Date.now(),
    keys: Number(startKeys) || 0,
    unlocked: [],
    adAt: 0,
    adCount: 0,
    keyAt: Date.now(),
    vipUntil: 0,
    banned: false,
  };
}

export function useAccount(startKeys) {
  const [user, setUser] = useState(undefined); // undefined = yükleniyor
  const [profile, setProfile] = useState(null);
  const [onboarded, setOnb] = useState(null);
  const startRef = useRef(startKeys);
  startRef.current = startKeys;

  useEffect(() => {
    AsyncStorage.getItem(ONB_KEY).then((v) => setOnb(v === '1')).catch(() => setOnb(false));
  }, []);
  const setOnboarded = useCallback((v) => {
    setOnb(v);
    AsyncStorage.setItem(ONB_KEY, v ? '1' : '0').catch(() => {});
  }, []);

  useEffect(() => {
    if (!configured) { setUser(null); return; }
    return onAuthStateChanged(auth, (u) => setUser(u || null));
  }, []);

  useEffect(() => {
    setProfile(null);
    if (!user) return;
    const ref = doc(db, 'users', user.uid);
    let timer = null;
    let first = true;
    const un = onSnapshot(ref, (snap) => {
      if (snap.exists()) {
        setProfile({ id: snap.id, ...snap.data() });
        if (first) updateDoc(ref, { lastSeen: Date.now() }).catch(() => {});
        first = false;
      } else if (!timer) {
        // Kayıt sırasında belge zaten yazılıyor olabilir; biraz bekleyip yoksa oluştur.
        timer = setTimeout(async () => {
          try {
            const again = await getDoc(ref);
            if (!again.exists()) await setDoc(ref, newProfile(user, startRef.current));
          } catch (e) {}
        }, 2500);
      }
    }, () => {});
    return () => { clearTimeout(timer); un(); };
  }, [user]);

  const want = String(ADMIN_EMAIL || '').trim().toLowerCase();
  const isAdmin = !!user && (!want || String(user.email || '').toLowerCase() === want);

  let me = user ? { ...GUEST, guest: false, loading: true, email: user.email || '', name: user.displayName || '' } : GUEST;
  if (user && profile) {
    me = {
      ...profile,
      unlocked: profile.unlocked || [],
      keys: Number(profile.keys) || 0,
      // Reklam hakkı ilk reklamdan 24 saat sonra yenilenir
      adCount: Number(profile.adAt) && Date.now() - Number(profile.adAt) < AD_WINDOW ? Number(profile.adCount) || 0 : 0,
      adAt: Number(profile.adAt) || 0,
      unlockCount: profile.unlockDay === today() ? Number(profile.unlockCount) || 0 : 0,
      vipUntil: Number(profile.vipUntil) || 0,
      guest: false,
    };
  }
  // Admin her şeye sınırsız erişir
  if (isAdmin) me = { ...me, admin: true };

  const meRef = useRef(me);
  meRef.current = me;
  const updateMe = useCallback(async (fn) => {
    if (!user) return;
    const patch = fn(meRef.current) || {};
    if ('keys' in patch) patch.keyAt = Date.now();
    try { await updateDoc(doc(db, 'users', user.uid), patch); } catch (e) {}
  }, [user]);

  return {
    ready: user !== undefined && onboarded !== null,
    user, isAdmin, me, updateMe, onboarded, setOnboarded,
  };
}

export async function register(name, email, pass, startKeys) {
  const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
  try { await updateProfile(cred.user, { displayName: name.trim() }); } catch (e) {}
  await setDoc(doc(db, 'users', cred.user.uid), newProfile(cred.user, startKeys, name.trim()));
  return cred.user;
}
export const login = (email, pass) => signInWithEmailAndPassword(auth, email.trim(), pass);
export const logout = () => signOut(auth);
export const resetPassword = (email) => sendPasswordResetEmail(auth, email.trim());
export async function deleteAccount() {
  const u = auth.currentUser;
  if (!u) return;
  try { await deleteDoc(doc(db, 'users', u.uid)); } catch (e) {}
  await deleteUser(u);
}

export function authError(e) {
  const c = String((e && e.code) || '');
  if (c.includes('email-already-in-use')) return 'Bu e-posta ile zaten bir hesap var. Giriş yapmayı dene.';
  if (c.includes('invalid-email')) return 'E-posta adresi geçersiz.';
  if (c.includes('weak-password')) return 'Şifre en az 6 karakter olmalı.';
  if (c.includes('invalid-credential') || c.includes('wrong-password') || c.includes('user-not-found')) return 'E-posta veya şifre hatalı.';
  if (c.includes('too-many-requests')) return 'Çok fazla deneme yapıldı. Biraz sonra tekrar dene.';
  if (c.includes('network')) return 'İnternet bağlantını kontrol et.';
  if (c.includes('user-disabled')) return 'Bu hesap kapatılmış.';
  if (c.includes('requires-recent-login')) return 'Güvenlik için çıkış yapıp tekrar giriş yap, sonra yeniden dene.';
  return 'Bir sorun oluştu, tekrar dene.';
}

/* ---------- admin: kullanıcı yönetimi ---------- */
export function useUsers(enabled) {
  const [state, setState] = useState({ list: [], loading: true });
  useEffect(() => {
    if (!enabled || !configured) return;
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(1000));
    return onSnapshot(q, (snap) => setState({ list: snap.docs.map((d) => ({ id: d.id, ...d.data() })), loading: false }),
      () => setState({ list: [], loading: false, error: true }));
  }, [enabled]);
  return state;
}
export const updateUser = (uid, patch) => updateDoc(doc(db, 'users', uid), patch);
export async function addKeys(uid, n) {
  const snap = await getDoc(doc(db, 'users', uid));
  const k = snap.exists() ? Number(snap.data().keys) || 0 : 0;
  await updateDoc(doc(db, 'users', uid), { keys: k + n });
}
