import React, { useState } from 'react';
import { View, Text, Pressable, Linking, Alert } from 'react-native';
import { C, badgesOf, tribuneStatus, AVATARS, adLimit, AD_WINDOW } from '../tema';
import { Btn, Card, Icon, s, useTheme, Avatar, Sheet, Field, Crest, useToast } from '../parcalar';
import { useTeams, suggestTeams, findTeam } from '../topluluk';
import { isVip } from './MacKart';

function Link({ icon, title, sub, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, borderTopWidth: 1, borderTopColor: C.line }}>
      <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={18} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '600', fontSize: 15, color: C.ink }}>{title}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 13 }}>{sub}</Text> : null}
      </View>
      <Icon name="chevron-forward" size={18} color={C.mut} />
    </Pressable>
  );
}

export default function Ben({ cfg, matches, me, onAd, onMatch, isAdmin, onAdmin, onAuth, onLogout, onOnb, onRG, onBuy, onDelete, onShare, onRate, tribune, onUpdate }) {
  const th = useTheme();
  const [edit, setEdit] = useState(false);
  const mine = (tribune?.list || []).filter((x) => me && x.uid === me.id);
  const badges = badgesOf(me, { tribune: mine.length, tribuneWon: mine.filter((x) => tribuneStatus(x, matches.list) === 'won').length });
  const L = cfg.links || {};
  const socials = [['instagram', 'logo-instagram', '#E1306C'], ['telegram', 'paper-plane', '#2AABEE'], ['whatsapp', 'logo-whatsapp', '#25D366'], ['x', 'logo-twitter', C.ink], ['youtube', 'logo-youtube', '#FF0000'], ['tiktok', 'logo-tiktok', C.ink]]
    .filter(([k]) => /^https?:\/\//i.test(L[k] || ''));
  const A = cfg.ads;
  const left = Math.max(0, adLimit(cfg) - (me?.adCount || 0));
  const resetH = me?.adAt ? Math.max(1, Math.ceil((me.adAt + AD_WINDOW - Date.now()) / 3600e3)) : 24;
  const F = matches.list.filter((m) => m.status === 'finished' && (m.result === 'won' || m.result === 'lost'));
  const won = F.filter((m) => m.result === 'won').length;
  const last = [...F].sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5);

  return (
    <View>
      {me.guest ? (
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>Ücretsiz hesap aç</Text>
          <Text style={[s.sub, { marginTop: 4 }]}>
            Anahtar kazan, kilitli tahminleri aç; telefon değiştirsen bile her şey hesabında kalsın.
            {Number(cfg.startKeys) > 0 ? ` Kayıt olana ${Number(cfg.startKeys)} anahtar hediye!` : ''}
          </Text>
          <Btn style={{ marginTop: 14 }} title="Kayıt ol" onPress={() => onAuth('register')} />
          <Btn style={{ marginTop: 8 }} kind="out" title="Giriş yap" onPress={() => onAuth('login')} />
        </Card>
      ) : (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <Pressable onPress={() => setEdit(true)} accessibilityLabel="Profili düzenle">
              <Avatar emoji={me.avatar} name={me.name || me.email} size={52} />
              <View style={{ position: 'absolute', right: -2, bottom: -2, width: 20, height: 20, borderRadius: 10, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="pencil" size={12} color={C.ink} />
              </View>
            </Pressable>
            <Pressable style={{ flex: 1 }} onPress={() => setEdit(true)}>
              <Text numberOfLines={1} style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>{me.name || 'Hesabım'}</Text>
              <Text numberOfLines={1} style={{ color: C.mut }}>{me.favTeam ? `⭐ ${me.favTeam}` : me.email}</Text>
            </Pressable>
            {isVip(me) ? (
              <View style={{ backgroundColor: C.vipBg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                <Text style={{ color: C.vipTx, fontWeight: '800', fontSize: 12 }}>{me.admin ? 'ADMIN · Sınırsız' : `VIP · ${Math.ceil((me.vipUntil - Date.now()) / 864e5)} gün`}</Text>
              </View>
            ) : null}
          </View>
          {me.banned ? (
            <View style={{ backgroundColor: C.redBg, borderRadius: 14, padding: 12, marginBottom: 12 }}>
              <Text style={{ color: C.red, fontWeight: '700' }}>Hesabın askıya alındı. Kilitli tahminleri açamazsın.</Text>
            </View>
          ) : null}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: C.key, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 26, fontWeight: '800', color: C.onKey }}>{me.admin ? '∞' : me.keys ?? 0}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>Anahtarların</Text>
              <Text style={s.sub}>{me.admin ? 'Admin olduğun için her şey sınırsız açık' : isVip(me) ? 'VIP olduğun için tüm tahminler açık' : 'Kilitli tahminleri açmak için kullanılır'}</Text>
            </View>
          </View>
          {Number(me.streak) > 0 ? (
            <Text style={{ color: C.lockTx, fontWeight: '700', marginTop: 12 }}>🔥 {me.streak} günlük seri · her gün gir, bonusu kaçırma</Text>
          ) : null}
          {badges.length ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 12 }}>
              {badges.map(([e, l]) => (
                <View key={l} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                  <Text>{e}</Text><Text style={{ fontWeight: '700', color: C.ink, fontSize: 12.5 }}>{l}</Text>
                </View>
              ))}
            </View>
          ) : null}
          {A.on && !me.banned ? (
            <Btn style={{ marginTop: 16 }} icon="play" disabled={left <= 0} onPress={onAd}
              title={left > 0 ? `Reklam izle, +${Number(A.reward) || 1} anahtar (${left} hak)` : `Reklam hakkın ${resetH} saat sonra yenilenir`} />
          ) : null}
          {cfg.store?.on && !me.banned ? (
            <Btn style={{ marginTop: 8 }} kind="out" icon="cart-outline" title="Anahtar satın al" onPress={onBuy} />
          ) : null}
          {Number(cfg.rewards?.share) > 0 && !me.shareRewarded && !me.banned ? (
            <Btn style={{ marginTop: 8 }} kind="out" icon="share-social-outline" title={`Arkadaşına öner, +${Number(cfg.rewards.share)} anahtar`} onPress={onShare} />
          ) : null}
        </Card>
      )}

      <Card>
        <Text style={s.h3}>Görünüm</Text>
        <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4 }}>
          {[['light', '☀️ Açık'], ['dark', '🌙 Koyu'], ['system', '📱 Otomatik']].map(([k, l]) => (
            <Pressable key={k} onPress={() => th.setPref && th.setPref(k)} accessibilityRole="tab" accessibilityState={{ selected: th.pref === k }}
              style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: th.pref === k ? C.card : 'transparent' }}>
              <Text style={{ fontWeight: th.pref === k ? '800' : '600', color: th.pref === k ? C.ink : C.mut, fontSize: 14 }}>{l}</Text>
            </Pressable>
          ))}
        </View>
      </Card>

      {socials.length ? (
        <Card>
          <Text style={s.h3}>Bizi takip et</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {socials.map(([k, icon, col]) => (
              <Pressable key={k} onPress={() => Linking.openURL(L[k])} accessibilityLabel={k} accessibilityRole="link"
                style={{ width: 52, height: 52, borderRadius: 16, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={icon} size={26} color={col} />
              </Pressable>
            ))}
          </View>
        </Card>
      ) : null}

      <Card style={{ paddingVertical: 4 }}>
        <View style={{ marginTop: -1 }}>
          {isAdmin ? <Link icon="construct-outline" title="Admin paneli" sub="Maç ekle, logo, mesaj, reklam" onPress={onAdmin} /> : null}
          <Link icon="help-circle-outline" title="Nasıl kullanılır?" sub="Tanıtımı tekrar göster" onPress={onOnb} />
          <Link icon="star-outline" title="Uygulamayı değerlendir" sub="Görüşün bizim için önemli" onPress={onRate} />
          <Link icon="share-social-outline" title="Arkadaşına öner" onPress={onShare} />
          <Link icon="shield-checkmark-outline" title="Sorumlu oyun" sub="18+ · Bilgilendirme" onPress={onRG} />
          {/^https?:\/\//i.test(cfg.links?.support || '') ? <Link icon="chatbubbles-outline" title="Bize ulaş" sub="Soru, öneri ve destek" onPress={() => Linking.openURL(cfg.links.support)} /> : null}
          {/^https?:\/\//i.test(cfg.links?.privacy || '') ? <Link icon="document-text-outline" title="Gizlilik politikası" onPress={() => Linking.openURL(cfg.links.privacy)} /> : null}
          {!me.guest ? <Link icon="log-out-outline" title="Çıkış yap" onPress={onLogout} /> : null}
          {!me.guest ? <Link icon="trash-outline" title="Hesabımı sil" sub="Hesabın ve anahtarların kalıcı olarak silinir"
            onPress={() => Alert.alert('Hesabın silinsin mi?', 'Bu işlem geri alınamaz. Anahtarların ve açtığın tahminler silinir.', [
              { text: 'Vazgeç', style: 'cancel' },
              { text: 'Sil', style: 'destructive', onPress: onDelete },
            ])} /> : null}
        </View>
      </Card>
      {edit ? <ProfilDuzenle me={me} onUpdate={onUpdate} onClose={() => setEdit(false)} /> : null}
    </View>
  );
}

/* ---------------- Profil düzenle: avatar, isim, favori takım ---------------- */
function ProfilDuzenle({ me, onUpdate, onClose }) {
  const toast = useToast();
  const teams = useTeams();
  const [avatar, setAvatar] = useState(me.avatar || '');
  const [name, setName] = useState(me.name || '');
  const [fav, setFav] = useState(me.favTeam || '');
  const sug = suggestTeams(teams.list, fav);
  const save = () => {
    const n = name.trim().slice(0, 30);
    if (!n) return toast('İsmini yaz');
    const tm = findTeam(teams.list, fav);
    onUpdate && onUpdate(() => ({ avatar, name: n, favTeam: tm ? tm.name : fav.trim().slice(0, 40) }));
    toast('Profil kaydedildi');
    onClose();
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>Profilim</Text>
      <Text style={[s.label, { marginTop: 14 }]}>Avatarını seç</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
        {['', ...AVATARS].map((e) => (
          <Pressable key={e || 'harf'} onPress={() => setAvatar(e)} accessibilityLabel={e || 'Baş harf'}
            style={{ padding: 3, borderRadius: 26, borderWidth: 2, borderColor: avatar === e ? C.key : 'transparent' }}>
            <Avatar emoji={e} name={name || me.email} size={42} />
          </Pressable>
        ))}
      </View>
      <Field label="Görünen adın" value={name} onChangeText={setName} maxLength={30} placeholder="Örn. Cesaret" />
      <Field label="Favori takımın" value={fav} onChangeText={setFav} placeholder="Örn. Galatasaray" />
      {sug.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: -6, marginBottom: 12 }}>
          {sug.map((tm) => (
            <Pressable key={tm.id} onPress={() => setFav(tm.name)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, minHeight: 36, borderRadius: 18, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border }}>
              <Crest name={tm.name} logo={tm.logo} size={20} />
              <Text style={{ color: C.ink, fontWeight: '600' }}>{tm.name}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      <Text style={[s.sub, { fontSize: 13.5, marginBottom: 12 }]}>Favori takımının maçları en üstte ⭐ ile görünür ve maçtan 15 dk önce otomatik hatırlatılır.</Text>
      <Btn title="Kaydet" onPress={save} />
      <Btn kind="ghost" title="Vazgeç" onPress={onClose} style={{ marginTop: 6 }} />
    </Sheet>
  );
}
