import React, { useState } from 'react';
import { View, Text, Pressable, Image, Linking } from 'react-native';
import { C, dayOff, byTime, isImg, successStats, isFav, canPredictScore } from '../tema';
import { Icon, s, useTheme, Btn } from '../parcalar';
import { MacSatiri, BankoKart } from './MacKart';

const DAYS = ['Dün', 'Bugün', 'Yarın'];

export default function Bugun({ cfg, matches, me, onMatch, isAdmin, onAddMatch, onScoreLeague, onStats }) {
  const t = useTheme();
  const [day, setDay] = useState(0);
  const d = dayOff(day);
  const fav = me && me.favTeam;
  const list = matches.list.filter((m) => m.date === d && !m.hidden).sort(byTime)
    .sort((a, b) => (isFav(b, fav) ? 1 : 0) - (isFav(a, fav) ? 1 : 0));
  const st = successStats(matches.list, 30);
  const scoreOpen = matches.list.filter((m) => !m.hidden && canPredictScore(m)).length;
  const banko = list.find((m) => m.banko);
  const rest = list.filter((m) => m !== banko);
  const M = cfg.message;
  const A = cfg.ads;
  const msgStyle = M.type === 'warn' ? { bg: C.lockBg, fg: C.lockTx } : M.type === 'camp' ? { bg: t.acc, fg: t.onAcc } : { bg: C.hero, fg: '#fff' };

  return (
    <View>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4 }}>
        {DAYS.map((label, i) => {
          const on = day === i - 1;
          return (
            <Pressable key={label} onPress={() => setDay(i - 1)} accessibilityRole="tab" accessibilityState={{ selected: on }}
              style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.card : 'transparent' }}>
              <Text style={{ fontWeight: on ? '700' : '600', color: on ? C.ink : C.mut, fontSize: 15 }}>{label}</Text>
            </Pressable>
          );
        })}
      </View>

      {M.on && M.text ? (
        <View style={{ flexDirection: 'row', gap: 10, backgroundColor: msgStyle.bg, borderRadius: 16, padding: 14, marginTop: 14, alignItems: 'flex-start' }}>
          <Icon name="information-circle-outline" color={msgStyle.fg} size={20} />
          <Text style={{ color: msgStyle.fg, fontWeight: '600', flex: 1, lineHeight: 20 }}>{M.text}</Text>
        </View>
      ) : null}

      {banko ? <BankoKart m={banko} me={me} onPress={() => onMatch(banko)} /> : null}

      {st.total >= 3 || scoreOpen ? (
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 14 }}>
          {st.total >= 3 ? (
            <Pressable onPress={onStats} accessibilityRole="button" style={{ flex: 1, backgroundColor: C.okBg, borderRadius: 18, padding: 14 }}>
              <Text style={{ color: C.okTx, fontSize: 24, fontWeight: '800' }}>%{st.pct}</Text>
              <Text style={{ color: C.okTx, fontWeight: '600', fontSize: 13 }}>Son 30 gün başarı{`\n`}{st.won}/{st.total} tahmin tuttu</Text>
            </Pressable>
          ) : null}
          {scoreOpen ? (
            <Pressable onPress={onScoreLeague} accessibilityRole="button" style={{ flex: 1, backgroundColor: C.lockBg, borderRadius: 18, padding: 14 }}>
              <Text style={{ fontSize: 24 }}>⚽</Text>
              <Text style={{ color: C.lockTx, fontWeight: '700', fontSize: 13 }}>Skor Ligi{`\n`}Skoru tahmin et, puan topla</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 22, marginBottom: 10 }}>
        <Text style={s.h2}>{['Dünün maçları', 'Bugünün maçları', 'Yarının maçları'][day + 1]}</Text>
        {list.length ? <Text style={{ color: C.mut }}>{list.length} maç</Text> : null}
      </View>

      {matches.loading && !matches.error ? (
        <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View>
      ) : matches.error === 'config' ? (
        <View style={s.empty}><Text style={s.h3}>Kurulum tamamlanmadı</Text><Text style={[s.sub, { textAlign: 'center' }]}>src/ayarlar.js dosyasına Firebase bilgilerini gir.</Text></View>
      ) : matches.error && !matches.list.length ? (
        <View style={s.empty}><Text style={s.h3}>Bağlanılamıyor</Text><Text style={[s.sub, { textAlign: 'center' }]}>İnternet bağlantını kontrol et.</Text></View>
      ) : !list.length ? (
        <View style={s.empty}>
          <Text style={[s.h3, { marginBottom: 0 }]}>Henüz maç yok</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>Bu gün için tahmin eklenmedi.</Text>
          {isAdmin ? <Btn small kind="ink" title="+ Maç ekle" onPress={onAddMatch} style={{ marginTop: 12, alignSelf: 'stretch' }} /> : null}
        </View>
      ) : (
        rest.map((m) => <MacSatiri key={m.id} m={m} me={me} onPress={() => onMatch(m)} />)
      )}

      {A.on && isImg(A.bannerImg) ? (
        <Pressable onPress={() => /^https?:\/\//i.test(A.bannerLink || '') && Linking.openURL(A.bannerLink)} accessibilityRole="link" accessibilityLabel="Reklam" style={{ marginTop: 14, borderRadius: 18, overflow: 'hidden', backgroundColor: C.card }}>
          <Image source={{ uri: A.bannerImg }} style={{ width: '100%', aspectRatio: 3 }} resizeMode="cover" />
          <Text style={{ position: 'absolute', top: 8, left: 8, backgroundColor: 'rgba(0,0,0,.6)', color: '#fff', fontSize: 11, fontWeight: '700', paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6, overflow: 'hidden' }}>Reklam</Text>
        </Pressable>
      ) : null}
    </View>
  );
}
