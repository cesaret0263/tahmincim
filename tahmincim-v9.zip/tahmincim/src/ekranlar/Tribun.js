import React, { useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { C, TRIBUNE_MARKETS, evalMarket, tribuneStatus, weekStart, today, byTime, dayLabel } from '../tema';
import { Btn, Crest, Icon, Sheet, s, useTheme, useToast, Tik, Avatar } from '../parcalar';
import { addTribune, deleteTribune, addReport, useVotes, castVote } from '../topluluk';
import { updateUser, addKeys } from '../veri';
import { onceLabel } from './Etkilesim';
import SkorLigi from './SkorLigi';

const ST = {
  pending: { t: 'Bekliyor', bg: () => C.track, fg: () => C.mut },
  won: { t: 'Tuttu ✓', bg: () => C.okBg, fg: () => C.okTx },
  lost: { t: 'Tutmadı ✕', bg: () => C.redBg, fg: () => C.red },
};

function Begeni({ target, me, onNeedAuth }) {
  const t = useTheme();
  const votes = useVotes(target);
  const n = votes.filter((v) => v.v === 1).length;
  const mine = me && me.id ? votes.find((v) => v.uid === me.id && v.v === 1) : null;
  const press = () => {
    if (!me || me.guest || !me.id) return onNeedAuth();
    castVote(target, me.id, 1, mine ? 1 : undefined).catch(() => {});
  };
  return (
    <Pressable onPress={press} accessibilityRole="button" accessibilityLabel="Beğen" style={{ flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 40, paddingHorizontal: 12, borderRadius: 12, backgroundColor: mine ? C.okBg : C.bg }}>
      <Icon name={mine ? 'heart' : 'heart-outline'} size={18} color={mine ? C.red : C.mut} />
      <Text style={{ fontWeight: '700', color: C.ink }}>{n}</Text>
    </Pressable>
  );
}

function TribunKart({ tc, matchList, me, isAdmin, onNeedAuth }) {
  const toast = useToast();
  const byId = {};
  matchList.forEach((m) => { byId[m.id] = m; });
  const st = tribuneStatus(tc, matchList);
  const S = ST[st];
  const own = me && me.id === tc.uid;
  const more = () => {
    const b = [{ text: 'Vazgeç', style: 'cancel' }];
    if (own || isAdmin) b.push({ text: 'Sil', style: 'destructive', onPress: () => deleteTribune(tc.id).then(() => toast('Kupon silindi')).catch(() => toast('Silinemedi')) });
    if (!own && me && !me.guest) b.push({ text: 'Şikayet et', onPress: () => addReport('tribune', tc.id, `${tc.name} kuponu`, me.id).then(() => toast('Teşekkürler, inceleyeceğiz')).catch(() => {}) });
    Alert.alert('Kupon', `${tc.name} · ${(tc.picks || []).length} maç`, b);
  };
  return (
    <View style={{ backgroundColor: C.card, borderRadius: 20, padding: 14, marginBottom: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 }}>
        <Avatar emoji={tc.avatar} name={tc.name} size={36} />
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink, flexShrink: 1 }}>{tc.name}{own ? ' (sen)' : ''}</Text>
            {tc.admin ? <Tik size={15} label="Admin" /> : null}
          </View>
          <Text style={{ color: C.mut, fontSize: 12 }}>{onceLabel(tc.createdAt)}</Text>
        </View>
        <View style={{ backgroundColor: S.bg(), borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
          <Text style={{ color: S.fg(), fontWeight: '800', fontSize: 12 }}>{S.t}</Text>
        </View>
      </View>
      {(tc.picks || []).map((p, i) => {
        const m = byId[p.matchId];
        const r = evalMarket(p.market, m);
        return (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6, borderTopWidth: i ? 1 : 0, borderTopColor: C.line }}>
            {m ? <Crest name={m.home} logo={m.homeLogo} size={22} /> : null}
            <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontSize: 14 }}>{m ? `${m.home} – ${m.away}` : 'Silinmiş maç'}</Text>
            <Text style={{ fontWeight: '800', color: C.ink, fontSize: 14 }}>{p.market}</Text>
            {r ? <Icon name={r === 'won' ? 'checkmark-circle' : 'close-circle'} size={20} color={r === 'won' ? C.okTx : C.red} /> : <View style={{ width: 20 }} />}
          </View>
        );
      })}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
        <Begeni target={'t_' + tc.id} me={me} onNeedAuth={onNeedAuth} />
        <Pressable onPress={more} accessibilityLabel="Seçenekler" style={{ width: 44, height: 40, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="ellipsis-horizontal" color={C.mut} />
        </Pressable>
      </View>
    </View>
  );
}

function KuponYap({ matches, me, isAdmin, mineToday, onClose }) {
  const t = useTheme();
  const toast = useToast();
  const [picks, setPicks] = useState({});
  const [open, setOpen] = useState(null);
  const [busy, setBusy] = useState(false);
  const list = matches.list.filter((m) => m.status === 'upcoming' && m.date >= today())
    .sort((a, b) => String(a.date + a.time).localeCompare(b.date + b.time)).slice(0, 40);
  const n = Object.keys(picks).length;
  const send = async () => {
    if (!n) return toast('En az bir maç seç');
    if (!isAdmin && mineToday >= 3) return toast('Günde en fazla 3 kupon paylaşabilirsin');
    setBusy(true);
    try {
      await addTribune(me.id, me.name || 'Üye', Object.entries(picks).map(([matchId, market]) => ({ matchId, market })), isAdmin, me.avatar);
      toast('Kuponun Tribün\'de! 🎉');
      onClose();
    } catch (e) { toast('Paylaşılamadı'); }
    setBusy(false);
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>Kuponunu yap</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Maça dokun, tahminini seç. En fazla 10 maç.</Text>
      {!list.length ? <Text style={s.sub}>Şu an kupona eklenecek maç yok.</Text> : list.map((m, idx) => {
        const sel = picks[m.id];
        const head = idx === 0 || list[idx - 1].date !== m.date;
        return (
          <View key={m.id}>
            {head ? <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13, marginTop: idx ? 8 : 0, marginBottom: 6 }}>📅 {dayLabel(m.date)}</Text> : null}
            <Pressable onPress={() => setOpen(open === m.id ? null : m.id)} accessibilityRole="button"
              style={{ borderWidth: sel ? 2 : 1.5, borderColor: sel ? t.acc : C.border, borderRadius: 14, padding: 12, marginBottom: 8, backgroundColor: sel ? C.selBg : C.card }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Text style={{ color: C.mut, fontWeight: '700', width: 44 }}>{m.time}</Text>
                <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{m.home} – {m.away}</Text>
                {sel ? <Text style={{ fontWeight: '800', color: C.okTx }}>{sel}</Text> : <Icon name="chevron-down" size={18} color={C.mut} />}
              </View>
              {open === m.id ? (
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 }}>
                  {TRIBUNE_MARKETS.map((k) => {
                    const on = sel === k;
                    return (
                      <Pressable key={k} onPress={() => { setPicks((x) => { const y = { ...x }; if (on) delete y[m.id]; else if (Object.keys(y).length < 10 || y[m.id]) y[m.id] = k; return y; }); setOpen(null); }}
                        style={{ paddingHorizontal: 12, minHeight: 40, justifyContent: 'center', borderRadius: 10, borderWidth: 1.5, borderColor: on ? C.ink : C.border, backgroundColor: on ? t.acc : C.card }}>
                        <Text style={{ fontWeight: '700', color: on ? t.onAcc : C.ink }}>{k}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              ) : null}
            </Pressable>
          </View>
        );
      })}
      <Btn style={{ marginTop: 8 }} title={n ? `${n} maçlık kuponu paylaş` : 'Maç seç'} disabled={!n} loading={busy} onPress={send} />
    </Sheet>
  );
}

function Siralama({ tribune, matches, isAdmin }) {
  const toast = useToast();
  const ws = weekStart();
  const agg = {};
  tribune.list.filter((x) => (x.createdAt || 0) >= ws).forEach((x) => {
    const st = tribuneStatus(x, matches.list);
    const a = (agg[x.uid] = agg[x.uid] || { uid: x.uid, name: x.name, admin: x.admin, won: 0, lost: 0, total: 0 });
    a.total++;
    if (st === 'won') a.won++;
    if (st === 'lost') a.lost++;
  });
  const rows = Object.values(agg).filter((r) => !r.admin).sort((a, b) => b.won - a.won || (b.won / Math.max(1, b.won + b.lost)) - (a.won / Math.max(1, a.won + a.lost)) || b.total - a.total).slice(0, 20);
  const reward = (r) => Alert.alert(`${r.name} ödüllendirilsin mi?`, 'Seçtiğin ödül hesabına eklenecek.', [
    { text: 'Vazgeç', style: 'cancel' },
    { text: '+10 anahtar', onPress: () => addKeys(r.uid, 10).then(() => toast('+10 anahtar verildi 🎁')).catch(() => toast('Verilemedi')) },
    { text: '7 gün VIP', onPress: () => updateUser(r.uid, { vipUntil: Date.now() + 7 * 864e5 }).then(() => toast('7 gün VIP verildi 👑')).catch(() => toast('Verilemedi')) },
  ]);
  const medal = ['🥇', '🥈', '🥉'];
  return (
    <View>
      <Text style={[s.sub, { marginBottom: 10 }]}>Bu haftanın en çok kupon tutturanları. Sıralama her pazartesi sıfırlanır.</Text>
      {!rows.length ? <View style={s.empty}><Text style={s.sub}>Bu hafta henüz sonuçlanan kupon yok.</Text></View> : rows.map((r, i) => (
        <View key={r.uid} style={[s.row, { minHeight: 56 }]}>
          <Text style={{ width: 30, fontSize: 18, fontWeight: '800', color: C.ink, textAlign: 'center' }}>{medal[i] || i + 1}</Text>
          <View style={{ flex: 1 }}>
            <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink }}>{r.name}</Text>
            <Text style={{ color: C.mut, fontSize: 13 }}>{r.total} kupon · %{Math.round((r.won / Math.max(1, r.won + r.lost)) * 100)} başarı</Text>
          </View>
          <Text style={{ fontWeight: '800', color: C.okTx, fontSize: 16 }}>{r.won} ✓</Text>
          {isAdmin ? <Pressable onPress={() => reward(r)} accessibilityLabel="Ödül ver" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 20 }}>🎁</Text></Pressable> : null}
        </View>
      ))}
    </View>
  );
}

export default function Tribun({ tribune, matches, me, isAdmin, onNeedAuth, start: startTab }) {
  const t = useTheme();
  const [tab, setTab] = useState(startTab || 'feed');
  const [make, setMake] = useState(false);
  const toast = useToast();
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const mineToday = me && me.id ? tribune.list.filter((x) => x.uid === me.id && (x.createdAt || 0) >= dayStart.getTime()).length : 0;
  const start = () => {
    if (!me || me.guest || !me.id) return onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    setMake(true);
  };
  return (
    <View>
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 12 }}>
        {[['feed', 'Kuponlar'], ['rank', '🏆 Haftalık'], ['score', '⚽ Skor Ligi']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }}
            style={{ flex: 1, minHeight: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: tab === k ? C.ink : C.border, backgroundColor: tab === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: tab === k ? '800' : '600', color: tab === k ? C.ink : C.mut, fontSize: 13.5 }} numberOfLines={1}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {tab === 'feed' ? <Btn icon="add" title="Kendi kuponunu paylaş" onPress={start} style={{ marginBottom: 12 }} /> : null}
      {tab === 'score' ? <SkorLigi matches={matches} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} /> : tab === 'rank' ? <Siralama tribune={tribune} matches={matches} isAdmin={isAdmin} /> : tribune.loading ? (
        <View style={s.empty}><Text style={s.sub}>Yükleniyor…</Text></View>
      ) : !tribune.list.length ? (
        <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Tribün boş</Text><Text style={[s.sub, { textAlign: 'center' }]}>İlk kuponu sen paylaş!</Text></View>
      ) : tribune.list.slice(0, 60).map((tc) => <TribunKart key={tc.id} tc={tc} matchList={matches.list} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} />)}
      {make ? <KuponYap matches={matches} me={me} isAdmin={isAdmin} mineToday={mineToday} onClose={() => setMake(false)} /> : null}
    </View>
  );
}
