import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Alert } from 'react-native';
import { C } from '../tema';
import { Icon, s, useTheme, useToast, Sheet, Btn, Tik, Avatar } from '../parcalar';
import { useVotes, castVote, useComments, addComment, deleteComment, addReport, useThreadVotes, pinAdmin } from '../topluluk';

let lastSentAt = 0;
const GAP_SN = 30;          // iki yorum arası en az 30 sn
const ARKA_ARKAYA_DK = 10;  // son yorum senin ise 10 dk bekle (başkası yazmadıkça)

export function onceLabel(ms) {
  const d = Math.max(0, Date.now() - (ms || 0)) / 1000;
  if (d < 60) return 'az önce';
  if (d < 3600) return `${Math.floor(d / 60)} dk önce`;
  if (d < 86400) return `${Math.floor(d / 3600)} sa önce`;
  return `${Math.floor(d / 86400)} gün önce`;
}

/* 👍 / 👎 katılıyorum çubuğu */
export function VoteBar({ target, me, onNeedAuth, compact }) {
  const t = useTheme();
  const toast = useToast();
  const votes = useVotes(target);
  const up = votes.filter((v) => v.v === 1).length;
  const down = votes.filter((v) => v.v === -1).length;
  const mine = me && !me.guest ? (votes.find((v) => v.uid === me.id) || {}).v : undefined;
  const total = up + down;
  const pct = total ? Math.round((up / total) * 100) : 0;
  const vote = async (v) => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    try { await castVote(target, me.id, v, mine); } catch (e) { toast('Oy verilemedi'); }
  };
  const B = ({ v, icon, label, n }) => {
    const on = mine === v;
    return (
      <Pressable onPress={() => vote(v)} accessibilityRole="button" accessibilityState={{ selected: on }}
        style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 44, borderRadius: 14, borderWidth: on ? 2 : 1.5, borderColor: on ? (v === 1 ? t.acc : C.red) : C.border, backgroundColor: on ? (v === 1 ? C.okBg : C.redBg) : C.card }}>
        <Icon name={icon} size={18} color={on ? (v === 1 ? C.okTx : C.red) : C.mut} />
        <Text style={{ fontWeight: '700', color: on ? (v === 1 ? C.okTx : C.red) : C.ink }}>{label}{compact ? '' : ` · ${n}`}</Text>
      </Pressable>
    );
  };
  return (
    <View style={{ marginTop: 12 }}>
      {total ? (
        <View style={{ marginBottom: 8 }}>
          <View style={{ flexDirection: 'row', height: 8, borderRadius: 6, overflow: 'hidden', backgroundColor: C.redBg }}>
            <View style={{ width: `${pct}%`, backgroundColor: t.acc }} />
          </View>
          <Text style={{ color: C.mut, fontSize: 13, marginTop: 4 }}>Kullanıcıların %{pct}'i bu tahmine katılıyor ({total} oy)</Text>
        </View>
      ) : null}
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <B v={1} icon="thumbs-up" label="Katılıyorum" n={up} />
        <B v={-1} icon="thumbs-down" label="Katılmıyorum" n={down} />
      </View>
    </View>
  );
}

/* Yorumlar */
export function Yorumlar({ target, me, isAdmin, onNeedAuth }) {
  const t = useTheme();
  const toast = useToast();
  const { list: raw } = useComments(target);
  const list = pinAdmin(raw);
  const cv = useThreadVotes(target);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    const v = text.trim();
    if (v.length < 2) return;
    if (!isAdmin) {
      const last = raw[raw.length - 1];
      const now = Date.now();
      if (last && last.uid === me.id && now - (last.createdAt || 0) < ARKA_ARKAYA_DK * 60000)
        return toast('Üst üste yorum yapamazsın. Başkası yazsın ya da biraz bekle 🙂');
      if (now - lastSentAt < GAP_SN * 1000) return toast(`Yeni yorum için ${Math.ceil((GAP_SN * 1000 - (now - lastSentAt)) / 1000)} sn bekle`);
      if (raw.some((c) => c.uid === me.id && String(c.text).trim().toLocaleLowerCase('tr') === v.toLocaleLowerCase('tr'))) return toast('Aynı yorumu zaten yazdın');
    }
    setBusy(true);
    try { await addComment(target, me.id, isAdmin ? (me.adminName || me.name || 'Admin') : (me.name || 'Üye'), v, isAdmin, me.avatar); setText(''); lastSentAt = Date.now(); } catch (e) { toast('Gönderilemedi'); }
    setBusy(false);
  };
  const more = (c) => {
    const own = me && c.uid === me.id;
    const btns = [{ text: 'Vazgeç', style: 'cancel' }];
    if (own || isAdmin) btns.push({ text: 'Sil', style: 'destructive', onPress: () => deleteComment(c.id).then(() => toast('Yorum silindi')).catch(() => toast('Silinemedi')) });
    if (!own && me && !me.guest) btns.push({ text: 'Şikayet et', onPress: () => addReport('comment', c.id, c.text, me.id).then(() => toast('Teşekkürler, inceleyeceğiz')).catch(() => toast('Gönderilemedi')) });
    Alert.alert('Yorum', c.text.slice(0, 80), btns);
  };
  return (
    <View style={{ marginTop: 16 }}>
      <Text style={[s.h3, { marginBottom: 8 }]}>💬 Yorumlar {list.length ? `(${list.length})` : ''}</Text>
      {!list.length ? <Text style={[s.sub, { marginBottom: 8 }]}>İlk yorumu sen yaz!</Text> : list.map((c) => (
        <Pressable key={c.id} onLongPress={() => more(c)} onPress={() => more(c)} style={{ backgroundColor: c.admin ? C.selBg : C.bg, borderRadius: 14, padding: 12, marginBottom: 8, borderWidth: c.admin ? 1.5 : 0, borderColor: t.acc }}>
          {c.admin ? <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 11.5, marginBottom: 4 }}>📌 SABİTLENDİ</Text> : null}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 1 }}>
              <Avatar emoji={c.avatar} name={c.name} size={24} />
              <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink, flexShrink: 1 }}>{c.name || 'Üye'}{me && c.uid === me.id ? ' (sen)' : ''}</Text>
              {c.admin ? <Tik size={15} label="Admin" /> : null}
            </View>
            <Text style={{ color: C.mut, fontSize: 12 }}>{onceLabel(c.createdAt)} ⋯</Text>
          </View>
          <Text style={{ color: C.ink, lineHeight: 20 }}>{c.text}</Text>
          <YorumOy c={c} votes={cv} me={me} thread={target} onNeedAuth={onNeedAuth} />
        </Pressable>
      ))}
      {me && !me.guest ? (
        <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', marginTop: 4 }}>
          <TextInput value={text} onChangeText={setText} placeholder="Yorumunu yaz…" placeholderTextColor={C.mut} multiline maxLength={500} accessibilityLabel="Yorum"
            style={[s.input, { flex: 1, minHeight: 46, maxHeight: 120 }]} />
          <Pressable onPress={send} disabled={busy} accessibilityLabel="Gönder" style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', opacity: busy ? 0.5 : 1 }}>
            <Icon name="send" size={20} color={t.onAcc} />
          </Pressable>
        </View>
      ) : (
        <Btn small kind="out" title="Yorum yazmak için giriş yap" onPress={onNeedAuth} />
      )}
      <Text style={[s.note, { marginTop: 8 }]}>Bir yoruma dokunarak silebilir ya da şikayet edebilirsin.</Text>
    </View>
  );
}

/* Kupon için beğeni + yorum penceresi */
export function EtkilesimPenceresi({ target, title, me, isAdmin, onNeedAuth, onClose }) {
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>{title}</Text>
      <VoteBar target={target} me={me} onNeedAuth={onNeedAuth} />
      <Yorumlar target={target} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} />
    </Sheet>
  );
}

/* Yorum altı 👍 / 👎 */
function YorumOy({ c, votes, me, thread, onNeedAuth }) {
  const toast = useToast();
  const tgt = 'cm_' + c.id;
  const mineV = votes.filter((v) => v.target === tgt);
  const up = mineV.filter((v) => v.v === 1).length;
  const down = mineV.filter((v) => v.v === -1).length;
  const my = me && !me.guest ? (mineV.find((v) => v.uid === me.id) || {}).v : undefined;
  const vote = (v) => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    castVote(tgt, me.id, v, my, thread).catch(() => toast('Oy verilemedi'));
  };
  const B = ({ v, icon, n }) => (
    <Pressable onPress={() => vote(v)} hitSlop={6} accessibilityRole="button" accessibilityLabel={v === 1 ? 'Beğen' : 'Beğenme'} accessibilityState={{ selected: my === v }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, minHeight: 32, borderRadius: 16, backgroundColor: my === v ? (v === 1 ? C.okBg : C.redBg) : C.card }}>
      <Icon name={my === v ? icon : icon + '-outline'} size={15} color={my === v ? (v === 1 ? C.okTx : C.red) : C.mut} />
      <Text style={{ fontWeight: '700', fontSize: 13, color: my === v ? (v === 1 ? C.okTx : C.red) : C.mut }}>{n}</Text>
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
      <B v={1} icon="thumbs-up" n={up} />
      <B v={-1} icon="thumbs-down" n={down} />
    </View>
  );
}
