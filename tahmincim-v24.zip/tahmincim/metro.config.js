// Firebase'in telefonda sorunsuz çalışması için gerekli küçük ayar (Expo'nun Firebase rehberinden)
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);
config.resolver.sourceExts.push('cjs');
config.resolver.unstable_enablePackageExports = false;

module.exports = config;
