# Tahmincim: Kurulum Rehberi (Windows + Android)

> **Sadece telefonla APK almak için:** Firebase bilgileri bu pakette zaten dolu. GitHub'da bir depo aç, bu zip'i (`tahmincim.zip`) olduğu gibi yükle, `.github/workflows/apk.yml` dosyasını oluşturup içine bu paketteki aynı adlı dosyanın içeriğini yapıştır. Yaklaşık 15 dakika sonra deponun **Releases** bölümünde `app-release.apk` çıkar. Aşağıdaki bilgisayarlı yol, Google Play'e yükleme için gereklidir.

Toplam süre ilk seferde yaklaşık **1–2 saat**. Her adımı sırayla yap, takıldığın yerde bana ekran görüntüsü at.

---

## Adım 1: Bilgisayara gerekli programları kur (bir kez)

1. **Node.js** indir ve kur: https://nodejs.org → "LTS" yazan yeşil buton → hep "İleri".
2. Başlat menüsüne **PowerShell** yaz ve aç. Şunu yaz, Enter'a bas:
   ```
   node -v
   ```
   `v22...` gibi bir sayı görüyorsan tamam.
3. Expo'nun derleme aracını kur:
   ```
   npm install -g eas-cli
   ```
4. Ücretsiz bir **Expo hesabı** aç: https://expo.dev/signup

---

## Adım 2: Firebase'i kur (veritabanı ve admin girişi, ücretsiz)

1. https://console.firebase.google.com → **Proje oluştur** → adı: `tahmincim` → Google Analytics'i kapatabilirsin → Oluştur.
2. Sol menü **Derleme → Firestore Database** → **Veritabanı oluştur** → konum: `eur3 (Europe)` → **Üretim modunda başlat** → Oluştur.
3. Firestore'da üstteki **Kurallar (Rules)** sekmesi → içini tamamen sil → bu klasördeki `firestore.rules` dosyasının içeriğini yapıştır → `senin@epostan.com` yazan yere **kendi e-postanı** yaz → **Yayınla**.
4. Sol menü **Derleme → Authentication** → **Başlayın** → **E-posta/Şifre** → Etkinleştir → Kaydet.
5. Authentication → **Users (Kullanıcılar)** sekmesi → **Kullanıcı ekle** → admin e-postan ve güçlü bir şifre. Bu, uygulamadaki **Yönetici girişi** bilgin olacak.
6. Sol üstte dişli ⚙️ → **Proje ayarları** → aşağıda "Uygulamalarınız" → **</>** (Web) simgesi → takma ad: `tahmincim` → Kaydet.
   Çıkan kutudaki `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` değerlerini bir yere kopyala.

---

## Adım 3: Projeyi oluştur

PowerShell'de sırayla:

```
cd Desktop
npx create-expo-app@latest tahmincim --template blank
cd tahmincim
npx expo install firebase @react-native-async-storage/async-storage react-native-safe-area-context expo-image-picker expo-image-manipulator react-native-google-mobile-ads
```

Sonra **bu zip'in içindeki her şeyi** masaüstündeki `tahmincim` klasörünün içine kopyala; "Dosyaları değiştir" sorarsa **Evet** de:
`App.js`, `app.json`, `eas.json`, `metro.config.js`, `firestore.rules`, `src` klasörü.

Şimdi `src\ayarlar.js` dosyasını Not Defteri ile aç:
- `BURAYA_YAPISTIR` yazan 6 yere Adım 2.6'da kopyaladığın değerleri yapıştır (tırnakların içine).
- `ADMIN_EMAIL` kısmına Adım 2.5'teki e-postanı yaz.
- Kaydet.

---

## Adım 4: Telefona yüklenebilir deneme sürümünü (APK) oluştur

PowerShell'de, `tahmincim` klasöründeyken:

```
eas login
eas build:configure
eas build -p android --profile deneme
```

- "Generate a new Android Keystore?" sorusuna **Y** (evet) de.
- Derleme Expo'nun sunucularında olur (10–25 dk). Bilgisayarın kapanmasın.
- Bitince bir **link ve QR kod** çıkar. Telefonundan aç → APK'yı indir → yükle (Android "bilinmeyen kaynak" izni isterse ver).

### Uygulamada ilk iş
1. Aç → **Ben** → **Yönetici girişi** → Adım 2.5'teki e-posta ve şifre.
2. **Ben → Admin paneli → Ayarlar**: logo, isim, renk, sistem mesajı.
3. **+ Yeni maç** → Galatasaray – Fenerbahçe, 2.5 Üst, Kilitli → **Yayınla**.
4. Başka bir telefonda açınca maçı görmelisin. Reklam butonu şimdilik Google'ın **test reklamını** gösterir, bu normal.

---

## Adım 5: Reklamlar (AdMob)

1. https://admob.google.com → hesap aç → **Uygulamalar → Uygulama ekle → Android** → "Henüz yayında değil".
2. Sana bir **Uygulama Kimliği** verir (`ca-app-pub-XXXX~YYYY`, içinde **~** var).
   → `app.json` dosyasında `androidAppId` değerini bununla değiştir.
3. **Reklam birimi ekle → Ödüllü (Rewarded)** → ad: `anahtar` → ödül: 1.
   Sana bir **Reklam Birimi Kimliği** verir (`ca-app-pub-XXXX/ZZZZ`, içinde **/** var).
   → Bunu **uygulamadaki Admin paneli → Ayarlar → "Ödüllü reklam birim kimliği"** alanına yaz. Kod değiştirmen gerekmez.
4. `app.json` değiştiği için yeniden derle: `eas build -p android --profile deneme`

> Not: Google, maç tahmini ("sports picks") içeriğini kumarla ilgili içerik sayıyor. Bu yüzden reklam gösterimi kısıtlanabilir ve AdMob gelirin beklediğinden düşük olabilir. Uygulamaya bahis sitesi linki veya reklamı koyma; hem Google kuralları hem Türkiye mevzuatı açısından risklidir.

---

## Adım 6: Google Play'e yükleme

1. https://play.google.com/console → geliştirici hesabı aç (**tek seferlik 25$**, kimlik doğrulaması ister).
2. Mağaza dosyasını üret:
   ```
   eas build -p android --profile production
   ```
   Bitince `.aab` dosyasını indir.
3. Play Console → **Uygulama oluştur** → ad: Tahmincim → Uygulama, Ücretsiz.
4. Doldurman gerekenler:
   - **Gizlilik politikası linki** (zorunlu). İstersen senin için yazarım.
   - **İçerik derecelendirmesi** anketi: kumarla ilgili sorulara dürüst cevap ver.
   - **Hedef kitle: 18+**
   - **Reklam içeriyor: Evet**
5. **Önemli kural:** Yeni kişisel hesaplarda önce **en az 12 test kullanıcısıyla 14 gün kesintisiz kapalı test** yapman gerekiyor. Ancak ondan sonra herkese açık yayına başvurabilirsin.
   Testing → **Closed testing** → `.aab` yükle → 12+ kişinin Gmail adresini ekle → hepsi linkten katılıp uygulamayı 14 gün telefonunda tutsun.
6. 14 gün dolunca **Production access** başvurusu → onaydan sonra herkes indirebilir.

---

## Güncelleme nasıl yapılır?

- **Maç, logo, mesaj, renk, reklam ayarları** → hepsi Admin panelinden. Yeniden derlemeye gerek yok, anında herkese yansır.
- **Kod değişikliği** (yeni özellik vb.) → `app.json` içinde `version` (örn. `1.0.1`) ve `versionCode` (örn. `2`) değerlerini bir artır → `eas build -p android --profile production` → yeni `.aab` dosyasını Play Console'a yükle.

## Sık karşılaşılan sorunlar

| Sorun | Çözüm |
|---|---|
| "Kurulum tamamlanmadı" yazıyor | `src/ayarlar.js` doldurulmamış veya kaydedilmemiş |
| Maç kaydederken "Kaydedilemedi" | `firestore.rules` ve `ayarlar.js` içindeki e-posta, giriş yaptığın e-postayla aynı olmalı |
| "Yönetici girişi" hata veriyor | Firebase → Authentication → Users'ta kullanıcı var mı, E-posta/Şifre açık mı? |
| Reklam açılmıyor | Test sürümünde normal olabilir; birkaç dakika sonra tekrar dene. Gerçek reklamlar AdMob onayından sonra gelir (1–2 gün) |
| `eas build` hata verdi | Hata mesajının son 20 satırını bana gönder |
