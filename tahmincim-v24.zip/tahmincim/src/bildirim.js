// Anlık bildirimler (Expo Push). Kurulum tamamlanmadıysa sessizce hiçbir şey yapmaz.
import { Platform } from 'react-native';
import { collection, doc, setDoc, getDocs, deleteDoc, addDoc, query, where } from 'firebase/firestore';
import { db } from './firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';

/* ---------- Bildirim tercihleri ---------- */
const PREF_KEY = 'tahmincim_bildirim';
export const PREF_LIST = [
  ['tahmin', '⚽ Yeni tahminler'],
  ['banko', '🔥 Günün bankosu'],
  ['kupon', '🎫 Yeni kuponlar'],
  ['tuttu', '✅ Tutan tahmin haberleri'],
  ['gol', '⚽ Takip ettiğim maçlarda gol'],
  ['genel', '📣 Duyurular ve kampanyalar'],
  ['favori', '⭐ Favori takım hatırlatıcısı'],
];
export const DEFAULT_PREFS = { tahmin: true, banko: true, kupon: true, tuttu: true, gol: true, genel: true, favori: true };
let lastToken = null;
let lastUid = null;
export async function getPrefs() {
  try { return { ...DEFAULT_PREFS, ...(JSON.parse((await AsyncStorage.getItem(PREF_KEY)) || '{}') || {}) }; } catch (e) { return { ...DEFAULT_PREFS }; }
}
export async function savePrefs(p) {
  const prefs = { ...DEFAULT_PREFS, ...p };
  try { await AsyncStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch (e) {}
  if (lastToken) {
    try { await setDoc(doc(db, 'tokens', tokenId(lastToken)), { token: lastToken, uid: lastUid || null, updatedAt: Date.now(), prefs }); } catch (e) {}
  }
  return prefs;
}

let N = null;
try {
  N = require('expo-notifications');
} catch (e) {
  N = null;
}

export function setupNotifications() {
  if (!N) return;
  try {
    N.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldShowBanner: true,
        shouldShowList: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      }),
    });
  } catch (e) {}
}

const tokenId = (t) => String(t).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 150);

// Telefonu bildirim listesine kaydeder. projectId admin panelinden gelir.
export async function registerPush(projectId, uid) {
  if (!N || !projectId) return null;
  try {
    if (Platform.OS === 'android') {
      await N.setNotificationChannelAsync('default', { name: 'Genel', importance: N.AndroidImportance.MAX });
    }
    let { status } = await N.getPermissionsAsync();
    if (status !== 'granted') ({ status } = await N.requestPermissionsAsync());
    if (status !== 'granted') return null;
    const t = (await N.getExpoPushTokenAsync({ projectId })).data;
    if (!t) return null;
    lastToken = t; lastUid = uid || null;
    const prefs = await getPrefs();
    await setDoc(doc(db, 'tokens', tokenId(t)), { token: t, uid: uid || null, updatedAt: Date.now(), prefs });
    return t;
  } catch (e) {
    return null;
  }
}

export async function countDevices() {
  const snap = await getDocs(collection(db, 'tokens'));
  return snap.size;
}

// Admin: kayıtlı tüm telefonlara bildirim gönderir.
// topic: kullanıcının kapattığı bildirim türlerine gönderilmez
export async function sendPushAll(title, body, topic = 'genel') {
  const snap = await getDocs(collection(db, 'tokens'));
  const toks = snap.docs.map((d) => ({ id: d.id, t: d.data().token, p: d.data().prefs || {} })).filter((x) => x.t && x.p[topic] !== false);
  let ok = 0;
  const bad = [];
  for (let i = 0; i < toks.length; i += 100) {
    const chunk = toks.slice(i, i + 100);
    const res = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(chunk.map((x) => ({ to: x.t, title, body, sound: 'default', channelId: 'default', priority: 'high' }))),
    });
    const j = await res.json().catch(() => ({}));
    (j.data || []).forEach((r, k) => {
      if (r.status === 'ok') ok++;
      else if (r.details && r.details.error === 'DeviceNotRegistered') bad.push(chunk[k].id);
    });
  }
  for (const id of bad) {
    try { await deleteDoc(doc(db, 'tokens', id)); } catch (e) {}
  }
  try { await addDoc(collection(db, 'notifications'), { title, body, sentAt: Date.now(), count: ok, total: toks.length }); } catch (e) {}
  return { ok, total: toks.length };
}

export async function notifHistory() {
  const snap = await getDocs(collection(db, 'notifications'));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => (b.sentAt || 0) - (a.sentAt || 0)).slice(0, 20);
}

// Tek bir kullanıcının telefonlarına bildirim (ör. mesajına cevap geldi)
export async function sendPushTo(uid, title, body) {
  if (!uid) return 0;
  const snap = await getDocs(query(collection(db, 'tokens'), where('uid', '==', uid)));
  const toks = snap.docs.map((d) => d.data().token).filter(Boolean);
  if (!toks.length) return 0;
  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(toks.map((t) => ({ to: t, title, body, sound: 'default', channelId: 'default', priority: 'high' }))),
  });
  return toks.length;
}

/* Maçı takip edenlere + favori takımı oynayanlara bildirim */
export async function sendPushTakip(m, title, body, topic = 'gol') {
  const uids = new Set();
  try { (await getDocs(query(collection(db, 'follows'), where('matchId', '==', m.id)))).docs.forEach((d) => uids.add(d.data().uid)); } catch (e) {}
  try {
    const names = [m.home, m.away].filter(Boolean);
    if (names.length) (await getDocs(query(collection(db, 'users'), where('favTeam', 'in', names)))).docs.forEach((d) => uids.add(d.id));
  } catch (e) {}
  const list = [...uids].filter(Boolean);
  const toks = [];
  for (let i = 0; i < list.length; i += 30) {
    try {
      const snap = await getDocs(query(collection(db, 'tokens'), where('uid', 'in', list.slice(i, i + 30))));
      snap.docs.forEach((d) => { const x = d.data(); if (x.token && (x.prefs || {})[topic] !== false) toks.push(x.token); });
    } catch (e) {}
  }
  for (let i = 0; i < toks.length; i += 100) {
    await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(toks.slice(i, i + 100).map((t) => ({ to: t, title, body, sound: 'default', channelId: 'default', priority: 'high', data: { matchId: m.id } }))),
    }).catch(() => {});
  }
  return toks.length;
}
