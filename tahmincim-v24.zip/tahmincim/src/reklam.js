// Ödüllü reklam (Google AdMob). Expo Go'da reklam modülü yoktur;
// o durumda uygulama çökmez, reklam yerine kısa bir sayaç gösterilir.
let Ads = null;
try {
  Ads = require('react-native-google-mobile-ads');
} catch (e) {
  Ads = null;
}

let started = false;
export function initAds() {
  if (!Ads || started) return;
  started = true;
  try {
    Ads.default().initialize().catch(() => {});
  } catch (e) {}
}

export const adsAvailable = () => !!Ads;

// unitId boşsa Google'ın TEST reklamı kullanılır (yayından önce admin panelinden gerçek kimliği gir).
export function showRewarded(unitId) {
  return new Promise((resolve) => {
    if (!Ads) return resolve('unavailable');
    const { RewardedAd, RewardedAdEventType, AdEventType, TestIds } = Ads;
    const id = unitId && unitId.startsWith('ca-app-pub-') && unitId.includes('/') ? unitId : TestIds.REWARDED;
    let earned = false;
    let done = false;
    const finish = (r) => {
      if (done) return;
      done = true;
      subs.forEach((u) => { try { u(); } catch (e) {} });
      resolve(r);
    };
    const ad = RewardedAd.createForAdRequest(id, { requestNonPersonalizedAdsOnly: true });
    // Reklam 15 saniyede yüklenmezse vazgeç (izlenirken süre sayılmaz)
    const loadTimer = setTimeout(() => finish('error'), 15000);
    const subs = [
      ad.addAdEventListener(RewardedAdEventType.LOADED, () => {
        clearTimeout(loadTimer);
        ad.show().catch(() => finish('error'));
      }),
      ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => { earned = true; }),
      ad.addAdEventListener(AdEventType.CLOSED, () => finish(earned ? 'earned' : 'closed')),
      ad.addAdEventListener(AdEventType.ERROR, () => { clearTimeout(loadTimer); finish('error'); }),
    ];
    ad.load();
  });
}
