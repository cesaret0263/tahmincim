// API-Football bağlantısı (anahtar sadece sahibin okuyabildiği gizli belgede durur)
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from './firebase';

const BASE = 'https://v3.football.api-sports.io';
export const SUPER_LIG = 203;

export async function getApiKey() {
  try { const s = await getDoc(doc(db, 'secret', 'api')); return s.exists() ? String(s.data().afKey || '') : ''; } catch (e) { return ''; }
}
export const saveApiKey = (k) => setDoc(doc(db, 'secret', 'api'), { afKey: String(k || '').trim(), updatedAt: Date.now() });

// Avrupa usulü sezon: Temmuz'dan itibaren yeni sezon
export function currentSeason(d = new Date()) { return d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1; }

async function apiGet(path, key) {
  const res = await fetch(BASE + path, { headers: { 'x-apisports-key': key } });
  const j = await res.json().catch(() => ({}));
  const errs = j && j.errors && (Array.isArray(j.errors) ? j.errors : Object.values(j.errors));
  return { ok: res.ok && !(errs && errs.length), status: res.status, errors: (errs || []).map(String), data: j.response, raw: j };
}

const ymdUTC = (d) => d.toISOString().slice(0, 10);

/* Bağlantı testi: hesap durumu + Süper Lig'in önümüzdeki 7 günü */
export async function testConnection(key, league = SUPER_LIG) {
  const out = { lines: [], ok: false };
  if (!key) { out.lines.push('❌ Anahtar girilmemiş.'); return out; }
  try {
    const st = await apiGet('/status', key);
    if (st.errors.length) { out.lines.push('❌ Anahtar hatalı: ' + st.errors.join(' · ')); return out; }
    const acc = st.data || {};
    const req = acc.requests || {};
    out.lines.push(`✅ Hesap bağlandı · Paket: ${acc.subscription?.plan || '?'} · Bugün kullanılan: ${req.current ?? '?'}/${req.limit_day ?? '?'}`);
    const season = currentSeason();
    const from = ymdUTC(new Date());
    const to = ymdUTC(new Date(Date.now() + 7 * 864e5));
    // Sezonsuz sorgular: bugünün maçları ve şu an canlı olanlar
    const day = await apiGet(`/fixtures?date=${from}`, key).catch(() => null);
    if (day && !day.errors.length) {
      const sl = (day.data || []).filter((f) => f.league?.id === league);
      out.lines.push(`${sl.length ? '✅' : 'ℹ️'} "Bugünün maçları" sorgusu açık · Dünyada ${(day.data || []).length} maç, Süper Lig'de ${sl.length} maç`);
      sl.slice(0, 5).forEach((f) => out.lines.push(`   ⚽ ${f.teams?.home?.name} ${f.goals?.home ?? ''}-${f.goals?.away ?? ''} ${f.teams?.away?.name} · ${f.fixture?.status?.short || ''} ${f.fixture?.status?.elapsed ? f.fixture.status.elapsed + "'" : ''}`));
      if (sl.length) out.ok = true;
    } else out.lines.push('❌ "Bugünün maçları" sorgusu kapalı: ' + ((day && day.errors.join(' · ')) || 'hata'));
    const live = await apiGet('/fixtures?live=all', key).catch(() => null);
    if (live && !live.errors.length) {
      const sl = (live.data || []).filter((f) => f.league?.id === league);
      out.lines.push(`✅ "Canlı maçlar" sorgusu açık · Şu an dünyada ${(live.data || []).length} canlı maç, Süper Lig'de ${sl.length}`);
      out.ok = true;
    } else out.lines.push('❌ "Canlı maçlar" sorgusu kapalı: ' + ((live && live.errors.join(' · ')) || 'hata'));
    const fx = await apiGet(`/fixtures?league=${league}&season=${season}&from=${from}&to=${to}`, key);
    if (fx.errors.length) {
      out.lines.push(`❌ Süper Lig ${season}-${season + 1} sezon sorgusu kapalı (ücretli pakette)`);
      return out;
    }
    const L = fx.data || [];
    out.ok = true;
    out.lines.push(`✅ Süper Lig ${season}-${season + 1} sezonu açık · Önümüzdeki 7 günde ${L.length} maç bulundu`);
    L.slice(0, 5).forEach((f) => {
      const d = new Date(f.fixture?.date);
      out.lines.push(`⚽ ${f.teams?.home?.name} – ${f.teams?.away?.name} · ${d.toLocaleDateString('tr-TR')} ${d.toTimeString().slice(0, 5)}`);
    });
    if (!L.length) out.lines.push('ℹ️ Bu hafta maç yok olabilir (milli ara). Bağlantı yine de çalışıyor.');
  } catch (e) {
    out.lines.push('❌ Bağlanılamadı: ' + (e.message || 'internet hatası'));
  }
  return out;
}
