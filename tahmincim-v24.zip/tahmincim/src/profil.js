// Kullanıcı profili penceresini her yerden açmak için
const subs = new Set();
export function profilAc(p) { if (p && p.uid) subs.forEach((f) => f(p)); }
export function profilDinle(f) { subs.add(f); return () => subs.delete(f); }
