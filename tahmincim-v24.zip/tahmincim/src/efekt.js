// Modern his: titreşim, giriş animasyonu, iskelet yükleme, canlı nabız, konfeti
import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, View, Dimensions } from 'react-native';
import { C } from './tema';

let H = null;
try { H = require('expo-haptics'); } catch (e) { H = null; }

/* Titreşim: 'hafif' | 'orta' | 'basari' | 'hata' */
export function titret(tur = 'hafif') {
  if (!H) return;
  try {
    if (tur === 'basari') H.notificationAsync(H.NotificationFeedbackType.Success);
    else if (tur === 'hata') H.notificationAsync(H.NotificationFeedbackType.Error);
    else if (tur === 'orta') H.impactAsync(H.ImpactFeedbackStyle.Medium);
    else H.selectionAsync();
  } catch (e) {}
}

/* Liste elemanları hafifçe kayarak gelir */
export function Gir({ children, i = 0, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 320, delay: Math.min(i, 8) * 45, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, []); // eslint-disable-line
  return (
    <Animated.View style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}

/* Yüklenirken parlayan gri kart taslakları */
export function Iskelet({ n = 4, h = 64 }) {
  const v = useRef(new Animated.Value(0.45)).current;
  useEffect(() => {
    const a = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration: 650, useNativeDriver: true }),
      Animated.timing(v, { toValue: 0.45, duration: 650, useNativeDriver: true }),
    ]));
    a.start();
    return () => a.stop();
  }, []); // eslint-disable-line
  return (
    <View accessibilityLabel="Yükleniyor">
      {Array.from({ length: n }).map((_, i) => (
        <Animated.View key={i} style={{ opacity: v, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: 20, padding: 14, marginBottom: 10, minHeight: h }}>
          <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: C.track }} />
          <View style={{ flex: 1, gap: 8 }}>
            <View style={{ height: 12, borderRadius: 6, backgroundColor: C.track, width: '70%' }} />
            <View style={{ height: 10, borderRadius: 5, backgroundColor: C.track, width: '45%' }} />
          </View>
          <View style={{ width: 54, height: 26, borderRadius: 13, backgroundColor: C.track }} />
        </Animated.View>
      ))}
    </View>
  );
}

/* Canlı maç: yanıp sönen kırmızı nokta */
export function Nabiz({ size = 8, color }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const a = Animated.loop(Animated.timing(v, { toValue: 1, duration: 1200, easing: Easing.out(Easing.ease), useNativeDriver: true }));
    a.start();
    return () => a.stop();
  }, []); // eslint-disable-line
  const col = color || C.red;
  return (
    <View style={{ width: size * 2.2, height: size * 2.2, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View style={{ position: 'absolute', width: size * 2.2, height: size * 2.2, borderRadius: size * 1.1, backgroundColor: col,
        opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.45, 0] }), transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }) }] }} />
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: col }} />
    </View>
  );
}

/* Değer değişince bir an parlar (canlı skor) */
export function Parla({ deger, children, style, color }) {
  const v = useRef(new Animated.Value(0)).current;
  const ilk = useRef(true);
  useEffect(() => {
    if (ilk.current) { ilk.current = false; return; }
    v.setValue(1);
    Animated.timing(v, { toValue: 0, duration: 1400, useNativeDriver: false }).start();
    titret('orta');
  }, [deger]); // eslint-disable-line
  return (
    <Animated.View style={[style, { backgroundColor: v.interpolate({ inputRange: [0, 1], outputRange: ['rgba(0,0,0,0)', color || 'rgba(255,214,0,0.35)'] }) }]}>
      {children}
    </Animated.View>
  );
}

/* Konfeti */
const dinleyen = new Set();
export function konfeti() {
  titret('basari');
  dinleyen.forEach((f) => f());
}
const RENK = ['#00D26A', '#FFB020', '#FF4D6D', '#3D8BFF', '#B46BFF', '#FFE14D'];
function Parca({ seed, onEnd }) {
  const { width, height } = Dimensions.get('window');
  const v = useRef(new Animated.Value(0)).current;
  const x0 = useRef(Math.random() * width).current;
  const dx = useRef((Math.random() - 0.5) * 160).current;
  const rot = useRef(360 + Math.random() * 720).current;
  const w = useRef(6 + Math.random() * 6).current;
  const col = RENK[seed % RENK.length];
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 1800 + Math.random() * 1200, delay: Math.random() * 300, easing: Easing.in(Easing.quad), useNativeDriver: true }).start(onEnd);
  }, []); // eslint-disable-line
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', left: x0, top: -20, width: w, height: w * 1.6, borderRadius: 2, backgroundColor: col,
      opacity: v.interpolate({ inputRange: [0, 0.85, 1], outputRange: [1, 1, 0] }),
      transform: [
        { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, height + 40] }) },
        { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, dx] }) },
        { rotate: v.interpolate({ inputRange: [0, 1], outputRange: ['0deg', `${rot}deg`] }) },
      ],
    }} />
  );
}
export function KonfetiHost() {
  const [patlama, setPatlama] = useState(0);
  const kalan = useRef(0);
  useEffect(() => {
    const f = () => { kalan.current = 42; setPatlama((x) => x + 1); };
    dinleyen.add(f);
    return () => dinleyen.delete(f);
  }, []);
  if (!patlama) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }}>
      {Array.from({ length: 42 }).map((_, i) => (
        <Parca key={patlama + '_' + i} seed={i} onEnd={() => { kalan.current -= 1; if (kalan.current <= 0) setPatlama(0); }} />
      ))}
    </View>
  );
}
