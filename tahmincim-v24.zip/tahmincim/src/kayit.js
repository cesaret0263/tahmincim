// Kaydedilenler (yer imi) – telefonda saklanır
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'tahmincim_kayit';
let cache = null;
const subs = new Set();

async function load() {
  if (cache) return cache;
  try { cache = JSON.parse((await AsyncStorage.getItem(KEY)) || '[]') || []; } catch (e) { cache = []; }
  return cache;
}
export function useSaved() {
  const [list, setList] = useState(cache || []);
  useEffect(() => {
    let on = true;
    load().then((c) => on && setList([...c]));
    subs.add(setList);
    return () => { on = false; subs.delete(setList); };
  }, []);
  return list;
}
// item: { k: 'm' | 'c', id }
export async function toggleSaved(item) {
  await load();
  const i = cache.findIndex((x) => x.k === item.k && x.id === item.id);
  if (i >= 0) cache.splice(i, 1); else cache.unshift({ ...item, at: Date.now() });
  cache = cache.slice(0, 100);
  try { await AsyncStorage.setItem(KEY, JSON.stringify(cache)); } catch (e) {}
  subs.forEach((f) => f([...cache]));
  return i < 0;
}
export const isSaved = (list, k, id) => list.some((x) => x.k === k && x.id === id);
