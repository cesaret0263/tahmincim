import { initializeApp, getApps, getApp } from 'firebase/app';
import * as FirebaseAuth from 'firebase/auth';
import { initializeFirestore, getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { firebaseConfig } from './ayarlar';

export const configured = !String(firebaseConfig.apiKey).includes('BURAYA');

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

let auth;
try {
  // Admin girişinin uygulama kapanınca da hatırlanması için
  auth = FirebaseAuth.initializeAuth(app, {
    persistence: FirebaseAuth.getReactNativePersistence(AsyncStorage),
  });
} catch (e) {
  auth = FirebaseAuth.getAuth(app);
}

let db;
try {
  db = initializeFirestore(app, { experimentalForceLongPolling: true });
} catch (e) {
  db = getFirestore(app);
}

export { app, auth, db };
