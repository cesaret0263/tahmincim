import React, { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { C, dayOff } from '../tema';
import { s, BolumSec, bizimMi } from '../parcalar';
import { MacSatiri } from './MacKart';
import { Gir } from '../efekt';

function fmtDay(d) {
  if (!d) return '';
  const [y, m, g] = d.split('-');
  const names = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const wd = names[new Date(Number(y), Number(m) - 1, Number(g)).getDay()];
  return `${g}.${m}.${y} ${wd}`;
}

export default function Sonuclar({ matches, me, onMatch }) {
  const [f, setF] = useState('all');
  const [bolum, setBolum] = useState('biz');
  const [per, setPer] = useState(30);
  const from = per ? dayOff(-per) : '';
  const F = matches.list.filter((m) => (bolum === 'robot' ? !!m.robot : bizimMi(m)) && m.status === 'finished' && (m.result === 'won' || m.result === 'lost') && (!from || String(m.date) >= from));
  const won = F.filter((m) => m.result === 'won').length;
  const lost = F.length - won;
  const shown = F.filter((m) => f === 'all' || m.result === f)
    .sort((a, b) => String(b.date + b.time).localeCompare(a.date + a.time));
  const groups = [];
  shown.forEach((m) => {
    const g = groups[groups.length - 1];
    if (g && g.date === m.date) g.items.push(m);
    else groups.push({ date: m.date, items: [m] });
  });

  return (
    <View>
      <Text style={[s.h1, { marginBottom: 10 }]}>Sonuçlar</Text>
      <BolumSec value={bolum} onChange={setBolum} />
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 12 }}>
        {[[7, 'Son 7 gün'], [30, 'Son 30 gün'], [0, 'Tümü']].map(([k, l]) => (
          <Pressable key={l} onPress={() => setPer(k)} accessibilityRole="tab" accessibilityState={{ selected: per === k }}
            style={{ paddingHorizontal: 14, minHeight: 36, borderRadius: 18, justifyContent: 'center', borderWidth: 1.5, borderColor: per === k ? C.ink : C.border, backgroundColor: per === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: per === k ? '800' : '600', color: per === k ? C.ink : C.mut, fontSize: 13.5 }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 14 }}>
        {[[F.length ? '%' + Math.round((won / F.length) * 100) : '–', 'Başarı', C.ink], [won, 'Tuttu', C.okTx], [lost, 'Tutmadı', C.red]].map(([v, l, col]) => (
          <View key={l} style={{ flex: 1, backgroundColor: C.card, borderRadius: 18, padding: 14, alignItems: 'center' }}>
            <Text style={{ fontSize: 24, fontWeight: '800', color: col }}>{v}</Text>
            <Text style={{ fontSize: 13, color: C.mut }}>{l}</Text>
          </View>
        ))}
      </View>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 6 }}>
        {[['all', 'Tümü'], ['won', 'Tuttu ✓'], ['lost', 'Tutmadı ✕']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setF(k)} accessibilityRole="tab" accessibilityState={{ selected: f === k }}
            style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: f === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: f === k ? '700' : '600', color: f === k ? C.ink : C.mut }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {!groups.length ? (
        <View style={[s.empty, { marginTop: 10 }]}>
          <Text style={[s.h3, { marginBottom: 0 }]}>Henüz sonuç yok</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>Maçlar bitip sonuçlandıkça burada görünecek.</Text>
        </View>
      ) : groups.map((g) => (
        <View key={g.date}>
          <Text style={{ color: C.mut, fontWeight: '700', fontSize: 13, marginTop: 14, marginBottom: 8 }}>{fmtDay(g.date)}</Text>
          {g.items.map((m, i) => <Gir key={m.id} i={i}><MacSatiri m={m} me={me} onPress={() => onMatch(m)} /></Gir>)}
        </View>
      ))}
    </View>
  );
}
