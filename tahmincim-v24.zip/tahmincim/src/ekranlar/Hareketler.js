// 🔔 Hareketler: admin'e özel bildirim paneli (yorum, beğeni, kupon, yeni üye, mesaj)
import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, query, orderBy, limit, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db, configured } from '../firebase';
import { C } from '../tema';
import { Avatar, Btn, Field, Icon, s, useToast } from '../parcalar';
import { addComment, deleteComment, castVote } from '../topluluk';

const KEY = 'hareket_v1';
function useSon(col, alan, n, on) {
  const [list, setList] = useState([]);
  useEffect(() => {
    if (!configured || !on) return;
    return onSnapshot(query(collection(db, col), orderBy(alan, 'desc'), limit(n)),
      (snap) => setList(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {});
  }, [on]);
  return list;
}
const adCache = {};
function useAdlar(uids) {
  const [, setT] = useState(0);
  const key = [...new Set(uids)].filter((u) => u && !(u in adCache)).slice(0, 40).join(',');
  useEffect(() => {
    if (!key) return;
    let alive = true;
    Promise.all(key.split(',').map((u) => getDoc(doc(db, 'users', u)).then((d) => { adCache[u] = d.exists() ? (d.data().name || 'Üye') : 'Üye'; }).catch(() => { adCache[u] = 'Üye'; })))
      .then(() => alive && setT((x) => x + 1));
    return () => { alive = false; };
  }, [key]);
  return adCache;
}

/* Tüm hareketleri toplayan kanca: Admin açıkken tek sefer çalışır, kart ve sayfa aynı veriyi kullanır */
export function useHareket(me, matches, on) {
  const comments = useSon('comments', 'createdAt', 60, on);
  const votes = useSon('votes', 'at', 80, on);
  const tribune = useSon('tribune', 'createdAt', 30, on);
  const users = useSon('users', 'createdAt', 30, on);
  const feedback = useSon('feedback', 'createdAt', 20, on);
  const adlar = useAdlar(votes.map((v) => v.uid));
  const [st, setSt] = useState({ readAt: 0, clearedAt: 0, gizli: [] });
  useEffect(() => { AsyncStorage.getItem(KEY).then((v) => v && setSt((x) => ({ ...x, ...JSON.parse(v) }))).catch(() => {}); }, []);
  const kaydet = (fn) => setSt((x) => { const y = fn(x); AsyncStorage.setItem(KEY, JSON.stringify(y)).catch(() => {}); return y; });

  const items = useMemo(() => {
    const mById = {}; (matches?.list || []).forEach((m) => { mById[m.id] = m; });
    const tById = {}; tribune.forEach((t) => { tById[t.id] = t; });
    const cById = {}; comments.forEach((c) => { cById[c.id] = c; });
    const yer = (target) => {
      const t = String(target || '');
      if (t.startsWith('m_')) { const m = mById[t.slice(2)]; return m ? { l: `${m.home} – ${m.away}`, m } : { l: 'bir maç' }; }
      if (t.startsWith('t_')) { const x = tById[t.slice(2)]; return { l: x ? `${x.name} adlı üyenin kuponu` : 'bir Tribün kuponu', tribun: true }; }
      return { l: '' };
    };
    const out = [];
    comments.forEach((c) => {
      if (c.uid === me?.id) return;
      const y = yer(c.target);
      out.push({ id: 'c' + c.id, t: c.createdAt || 0, k: 'yorum', e: '💬', ad: c.name, avatar: c.avatar, baslik: `${c.name || 'Üye'} yorum yaptı`, alt: `"${String(c.text || '').slice(0, 120)}"`, yer: y, c });
    });
    votes.forEach((v) => {
      if (v.uid === me?.id) return;
      const ad = adlar[v.uid] || '…';
      const t = String(v.target || '');
      let baslik = ''; let alt = ''; let y = { l: '' };
      if (t.startsWith('t_')) { y = yer(t); baslik = `${ad} ${y.l === 'bir Tribün kuponu' ? 'bir Tribün kuponunu' : y.l.replace('kuponu', 'kuponunu')} beğendi`; y = { l: '', tribun: true }; }
      else if (t.startsWith('cm_')) { const c = cById[t.slice(3)]; baslik = `${ad} bir yorumu ${v.v === 1 ? 'beğendi 👍' : 'beğenmedi 👎'}`; alt = c ? `"${String(c.text || '').slice(0, 80)}" · ${c.name}` : ''; y = c ? yer(c.target) : { l: '' }; }
      else if (t.startsWith('m_')) { y = yer(t); baslik = `${ad} tahmine ${v.v === 1 ? 'katıldı 👍' : 'katılmadı 👎'}`; }
      else return;
      out.push({ id: 'v' + v.id, t: v.at || 0, k: 'begeni', e: v.v === 1 ? '❤️' : '👎', ad, baslik, alt, yer: y });
    });
    tribune.forEach((x) => {
      if (x.uid === me?.id) return;
      out.push({ id: 't' + x.id, t: x.createdAt || 0, k: 'kupon', e: '🎟️', ad: x.name, avatar: x.avatar, baslik: `${x.name || 'Üye'} Tribün'de kupon paylaştı`, alt: `${(x.picks || []).length} maç: ` + (x.picks || []).slice(0, 3).map((p) => p.market).join(', '), yer: { l: '', tribun: true } });
    });
    users.forEach((u) => {
      if (u.id === me?.id || !u.createdAt) return;
      out.push({ id: 'u' + u.id, t: u.createdAt, k: 'uye', e: '👋', ad: u.name, avatar: u.avatar, baslik: `Yeni üye: ${u.name || 'Üye'}`, alt: '', yer: { l: '' } });
    });
    feedback.forEach((f) => {
      out.push({ id: 'f' + f.id, t: f.createdAt || 0, k: 'mesaj', e: '📩', ad: f.name, baslik: `${f.name || 'Biri'} ${f.kind === 'sikayet' ? 'şikayet' : f.kind === 'hata' ? 'hata bildirimi' : 'öneri'} gönderdi`, alt: `"${String(f.text || '').slice(0, 120)}"`, yer: { l: '' } });
    });
    return out.filter((x) => x.t > st.clearedAt && !st.gizli.includes(x.id)).sort((a, b) => b.t - a.t).slice(0, 150);
  }, [comments, votes, tribune, users, feedback, adlar, st, matches, me]);

  const yeni = items.filter((x) => x.t > st.readAt).length;
  return {
    items, yeni, readAt: st.readAt,
    hepsiOkundu: () => kaydet((x) => ({ ...x, readAt: Date.now() })),
    hepsiniSil: () => kaydet((x) => ({ ...x, clearedAt: Date.now(), readAt: Date.now(), gizli: [] })),
    tekSil: (id) => kaydet((x) => ({ ...x, gizli: [...x.gizli, id].slice(-300) })),
    oylar: votes,
  };
}

export function HareketKart({ h, onPress }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button"
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: 18, padding: 14, marginBottom: 12, borderWidth: 1.5, borderColor: h.yeni ? '#00D26A' : C.border, opacity: pressed ? 0.85 : 1 })}>
      <Text style={{ fontSize: 22 }}>🔔</Text>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '800', color: C.ink, fontSize: 16 }}>Hareketler</Text>
        <Text style={{ color: C.mut, fontSize: 13 }} numberOfLines={1}>{h.items[0] ? h.items[0].baslik : 'Yorum, beğeni, kupon ve yeni üyeler'}</Text>
      </View>
      {h.yeni ? <View style={{ backgroundColor: C.red, borderRadius: 999, minWidth: 26, height: 26, paddingHorizontal: 8, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#fff', fontWeight: '900', fontSize: 13 }}>{h.yeni > 99 ? '99+' : h.yeni}</Text></View> : null}
      <Icon name="chevron-forward" color={C.mut} size={18} />
    </Pressable>
  );
}

const once = (t) => {
  const d = Math.max(0, Math.round((Date.now() - t) / 60000));
  if (d < 1) return 'şimdi'; if (d < 60) return `${d} dk`; const s0 = Math.round(d / 60); if (s0 < 24) return `${s0} sa`; return `${Math.round(s0 / 24)} g`;
};

function Satir({ x, yeni, me, oylar, onSil, onMatch, onTribun }) {
  const toast = useToast();
  const [acik, setAcik] = useState(false);
  const [yanit, setYanit] = useState(null);
  const [busy, setBusy] = useState(false);
  const c = x.c;
  const begendim = c ? oylar.some((v) => v.target === 'cm_' + c.id && v.uid === me?.id && v.v === 1) : false;
  const [begen, setBegen] = useState(begendim);
  const begenTikla = () => {
    if (!c || !me?.id) return;
    castVote('cm_' + c.id, me.id, 1, begen ? 1 : undefined, c.target).then(() => { setBegen(!begen); toast(begen ? 'Beğeni geri alındı' : 'Yorumu beğendin ❤️'); }).catch(() => toast('Olmadı'));
  };
  const gonder = async () => {
    const v = String(yanit || '').trim();
    if (v.length < 2) return toast('Bir şeyler yaz');
    setBusy(true);
    try { await addComment(c.target, me.id, me.adminName || me.name || 'Admin', `@${c.name} ${v}`, true, me.avatar, false); setYanit(null); toast('Yanıtın gönderildi'); }
    catch (e) { toast('Gönderilemedi'); }
    setBusy(false);
  };
  const kaldir = () => Alert.alert('Yorum kaldırılsın mı?', `"${String(c.text || '').slice(0, 80)}"\nHerkesten silinir.`, [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Kaldır', style: 'destructive', onPress: () => deleteComment(c.id).then(() => { toast('Yorum kaldırıldı'); onSil(); }).catch(() => toast('Silinemedi')) },
  ]);
  const git = x.yer?.m ? () => onMatch(x.yer.m) : x.yer?.tribun ? onTribun : null;
  return (
    <View style={{ backgroundColor: yeni ? C.selBg : C.card, borderRadius: 18, padding: 12, marginBottom: 8 }}>
      <Pressable onPress={() => setAcik((a) => !a)} style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-start' }}>
        <View>
          <Avatar emoji={x.avatar} name={x.ad} size={40} />
          <Text style={{ position: 'absolute', right: -4, bottom: -4, fontSize: 15 }}>{x.e}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: C.ink, fontWeight: '700', fontSize: 14.5 }}>{x.baslik}</Text>
          {x.alt ? <Text numberOfLines={acik ? 6 : 2} style={{ color: C.ink, fontSize: 13.5, marginTop: 2 }}>{x.alt}</Text> : null}
          <Text style={{ color: C.mut, fontSize: 12.5, marginTop: 3 }}>{once(x.t)}{x.yer?.l ? ` · ${x.yer.l}` : ''}</Text>
        </View>
        {yeni ? <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: '#00D26A', marginTop: 6 }} /> : null}
        <Pressable onPress={onSil} hitSlop={10} accessibilityLabel="Listeden sil" style={{ padding: 2 }}>
          <Icon name="close" size={18} color={C.mut} />
        </Pressable>
      </Pressable>
      {acik ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10, marginLeft: 52 }}>
          {c ? <Btn small kind={begen ? 'acc' : 'out'} title={begen ? '❤️ Beğendin' : '🤍 Beğen'} onPress={begenTikla} /> : null}
          {c ? <Btn small kind="out" title="↩ Yanıt ver" onPress={() => setYanit(yanit == null ? '' : null)} /> : null}
          {git ? <Btn small kind="out" title="Git →" onPress={git} /> : null}
          {c ? <Btn small kind="out" title="🗑 Yorumu kaldır" onPress={kaldir} /> : null}
        </View>
      ) : null}
      {yanit != null ? (
        <View style={{ marginTop: 10, marginLeft: 52 }}>
          <Field value={yanit} onChangeText={setYanit} placeholder={`@${c.name} için yanıtın…`} maxLength={400} multiline autoFocus />
          <Btn small kind="ink" title="Gönder" onPress={gonder} loading={busy} />
        </View>
      ) : null}
    </View>
  );
}

const FIL = [['hepsi', 'Tümü'], ['yorum', '💬 Yorum'], ['begeni', '❤️ Beğeni'], ['kupon', '🎟️ Kupon'], ['uye', '👋 Üye'], ['mesaj', '📩 Mesaj']];

export default function Hareketler({ h, me, onBack, onMatch, onTribun, Header }) {
  const [f, setF] = useState('hepsi');
  const [ilkOkunma] = useState(h.readAt);
  const L = h.items.filter((x) => f === 'hepsi' || x.k === f);
  return (
    <View>
      <Header title="🔔 Hareketler" onBack={onBack} />
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 10 }}>
        <Btn small kind="out" icon="checkmark-done-outline" title="Tümünü okundu yap" onPress={h.hepsiOkundu} style={{ flex: 1 }} />
        <Btn small kind="out" icon="trash-outline" title="Tümünü sil" style={{ flex: 1 }}
          onPress={() => Alert.alert('Tüm hareketler temizlensin mi?', 'Sadece bu listeden kalkar. Yorumlar ve kuponlar silinmez.', [{ text: 'Vazgeç', style: 'cancel' }, { text: 'Temizle', style: 'destructive', onPress: h.hepsiniSil }])} />
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 12 }}>
        {FIL.map(([k, l]) => (
          <Pressable key={k} onPress={() => setF(k)} style={{ paddingHorizontal: 12, minHeight: 34, borderRadius: 17, justifyContent: 'center', borderWidth: 1.5, borderColor: f === k ? C.ink : C.border, backgroundColor: f === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: f === k ? '800' : '600', color: f === k ? C.ink : C.mut, fontSize: 13 }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={[s.note, { marginBottom: 10 }]}>Bir harekete dokun: beğen, yanıt ver, git ya da kaldır. ✕ sadece bu listeden siler.</Text>
      {L.length ? L.map((x) => (
        <Satir key={x.id} x={x} yeni={x.t > ilkOkunma} me={me} oylar={h.oylar} onSil={() => h.tekSil(x.id)} onMatch={onMatch} onTribun={onTribun} />
      )) : (
        <View style={s.empty}><Text style={[s.h3, { marginBottom: 0 }]}>Hareket yok</Text><Text style={s.sub}>Yeni yorum, beğeni ve kuponlar burada görünecek.</Text></View>
      )}
    </View>
  );
}
