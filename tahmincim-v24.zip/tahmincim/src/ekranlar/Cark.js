// 🎡 Şans çarkı: günlük bonusun eğlenceli hali (günde bir kez)
import React, { useEffect, useRef, useState } from 'react';
import { View, Text } from 'react-native';
import { C } from '../tema';
import { Btn, Sheet, s, useTheme, useToast } from '../parcalar';
import { titret, konfeti } from '../efekt';

const R = 112;   // halka yarıçapı
const SZ = 58;   // dilim boyutu

/* prizes: 8 anahtar değeri · forced: 7. gün garanti büyük ödül indexi */
export default function Cark({ prizes, streak, forced, onSpin, onClose }) {
  const t = useTheme();
  const toast = useToast();
  const [cur, setCur] = useState(0);
  const [state, setState] = useState('hazir'); // hazir | donuyor | bitti
  const [won, setWon] = useState(null);
  const timer = useRef(null);
  useEffect(() => () => clearTimeout(timer.current), []);

  const spin = () => {
    if (state !== 'hazir') return;
    setState('donuyor');
    titret('orta');
    const target = forced != null ? forced : Math.floor(Math.random() * prizes.length);
    const steps = prizes.length * 3 + ((target - cur + prizes.length) % prizes.length);
    let i = 0;
    let pos = cur;
    const tick = () => {
      pos = (pos + 1) % prizes.length;
      setCur(pos);
      i++;
      if (i % 2 === 0) titret('hafif');
      if (i >= steps) {
        const gift = prizes[pos];
        onSpin(gift).then(() => {
          setWon(gift); setState('bitti'); konfeti();
        }).catch(() => { setState('hazir'); toast('Ödül kaydedilemedi, internetini kontrol edip tekrar dene'); });
        return;
      }
      const left = steps - i;
      timer.current = setTimeout(tick, left > 10 ? 55 : 55 + (10 - left) * 45);
    };
    tick();
  };

  return (
    <Sheet visible onClose={state === 'donuyor' ? () => {} : onClose}>
      <Text style={[s.h2, { textAlign: 'center' }]}>🎡 Şans Çarkı</Text>
      <Text style={[s.sub, { textAlign: 'center', marginTop: 4 }]}>
        {forced != null ? `🔥 ${streak}. gün! Bugün büyük ödül garanti.` : `Günde bir kez çevir, anahtar kazan · 🔥 ${streak} günlük seri`}
      </Text>
      <View style={{ width: R * 2 + SZ, height: R * 2 + SZ, alignSelf: 'center', marginVertical: 18 }}>
        {prizes.map((p, i) => {
          const a = (i / prizes.length) * Math.PI * 2 - Math.PI / 2;
          const on = i === cur;
          const big = p === Math.max(...prizes);
          return (
            <View key={i} style={{
              position: 'absolute', left: R + Math.cos(a) * R, top: R + Math.sin(a) * R, width: SZ, height: SZ, borderRadius: SZ / 2,
              alignItems: 'center', justifyContent: 'center',
              backgroundColor: on ? t.acc : big ? C.vipBg : C.bg,
              borderWidth: on ? 3 : 1.5, borderColor: on ? C.ink : C.border,
              transform: [{ scale: on ? 1.15 : 1 }],
            }}>
              <Text style={{ fontWeight: '900', fontSize: 18, color: on ? t.onAcc : big ? C.vipTx : C.ink }}>+{p}</Text>
              <Text style={{ fontSize: 11 }}>🔑</Text>
            </View>
          );
        })}
        <View style={{ position: 'absolute', left: R - 22, top: R - 22, width: SZ + 44, height: SZ + 44, borderRadius: (SZ + 44) / 2, backgroundColor: C.hero, alignItems: 'center', justifyContent: 'center' }}>
          {won != null ? (
            <>
              <Text style={{ color: '#fff', fontSize: 30, fontWeight: '900' }}>+{won}</Text>
              <Text style={{ color: '#C5CCD6', fontSize: 12 }}>anahtar</Text>
            </>
          ) : <Text style={{ fontSize: 40 }}>🎁</Text>}
        </View>
      </View>
      {state === 'bitti' ? (
        <>
          <Text style={[s.h3, { textAlign: 'center' }]}>Tebrikler! +{won} anahtar hesabında 🎉</Text>
          <Btn title="Harika" onPress={onClose} style={{ marginTop: 8 }} />
        </>
      ) : (
        <Btn title={state === 'donuyor' ? 'Dönüyor…' : 'ÇEVİR'} icon="sync" onPress={spin} disabled={state === 'donuyor'} />
      )}
      {state === 'hazir' ? <Btn kind="ghost" title="Sonra çevir" onPress={onClose} style={{ marginTop: 4 }} /> : null}
    </Sheet>
  );
}
