import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { SKOR_LIGLER } from '../senkron';
import { View, Text, Pressable } from 'react-native';
import { C, byTime, predText, scoreOf, canliDakika } from '../tema';
import { Crest, Icon, s, useTheme, Sheet, Btn, BolumSec, bizimMi } from '../parcalar';
import { OLAY } from './Etkilesim';
import { MacSatiri, isOpen } from './MacKart';
import { Gir, Nabiz, Iskelet } from '../efekt';

function TahminCanli({ matches, me, onMatch }) {
  const t = useTheme();
  const [bolum, setBolum] = useState('biz');
  const L = matches.list.filter((m) => m.status === 'live' && !m.hidden && (bolum === 'robot' ? !!m.robot : bizimMi(m))).sort(byTime);
  const [f, ...rest] = L;
  return (
    <View>
      <BolumSec value={bolum} onChange={setBolum} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <Text style={s.h1}>Şu an oynanıyor</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.redBg, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999 }}>
          {L.length ? <Nabiz size={7} /> : <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.mut }} />}
          <Text style={{ color: C.red, fontWeight: '700' }}>{L.length} maç</Text>
        </View>
      </View>
      {!f ? (
        <View style={s.empty}>
          <Text style={[s.h3, { marginBottom: 0 }]}>Şu an canlı maç yok</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>Maç başlayınca burada görünecek.</Text>
        </View>
      ) : (
        <>
          <Pressable onPress={() => onMatch(f)} accessibilityRole="button" style={{ backgroundColor: C.hero, borderRadius: 26, padding: 20, marginBottom: 12 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: '#C5CCD6' }}>{f.league}</Text>
              <Text style={{ color: '#FF8A8E', fontWeight: '700' }}>● {canliDakika(f) === 'İY' ? 'Devre arası' : canliDakika(f)}</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: 16 }}>
              <View style={{ width: '32%', alignItems: 'center', gap: 8 }}>
                <Crest name={f.home} logo={f.homeLogo} size={48} />
                <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>{f.home}</Text>
              </View>
              <Text style={{ color: '#fff', fontSize: 40, fontWeight: '800' }}>{scoreOf(f).join(' – ')}</Text>
              <View style={{ width: '32%', alignItems: 'center', gap: 8 }}>
                <Crest name={f.away} logo={f.awayLogo} size={48} />
                <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>{f.away}</Text>
              </View>
            </View>
            {isOpen(f, me) ? (
              <View style={{ backgroundColor: t.acc, borderRadius: 16, padding: 14 }}>
                <Text style={{ color: t.onAcc, fontWeight: '600', fontSize: 13 }}>Şu anki tahminimiz</Text>
                <Text style={{ color: t.onAcc, fontWeight: '800', fontSize: 17 }}>{f.liveText || predText(f)}</Text>
              </View>
            ) : (
              <View style={{ backgroundColor: C.dark2, borderRadius: 16, padding: 14, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                <Icon name="lock-closed" color="#fff" size={18} />
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Canlı tahmini açmak için dokun</Text>
              </View>
            )}
          </Pressable>
          {rest.map((m, i) => <Gir key={m.id} i={i}><MacSatiri m={m} me={me} onPress={() => onMatch(m)} /></Gir>)}
        </>
      )}
    </View>
  );
}

/* ---------- Canlı skor (tüm büyük ligler) ---------- */
const CANLI = ['1H', '2H', 'HT', 'ET', 'BT', 'P', 'LIVE', 'INT'];
const BITTI = ['FT', 'AET', 'PEN', 'AWD', 'WO'];
export function useCanliSkor(name = 'bugun') {
  const [st, setSt] = useState({ list: [], loading: true, date: '', updatedAt: 0 });
  useEffect(() => onSnapshot(doc(db, 'canli', name), (d) => setSt(d.exists() ? { ...d.data(), loading: false } : { list: [], loading: false }), () => setSt((x) => ({ ...x, loading: false }))), [name]);
  return st;
}
function dakika(x, updatedAt) {
  if (x.s === 'HT') return 'İY';
  if (x.s === 'P') return 'Pen.';
  if (!CANLI.includes(x.s)) return '';
  const d = (x.e || 0) + Math.max(0, Math.floor((Date.now() - (updatedAt || Date.now())) / 60000));
  if (x.s === '1H' && d > 45) return "45+'";
  if (d > 90 && x.s === '2H') return "90+'";
  return `${d}'`;
}
function SkorSatir({ x, updatedAt, onPress, tahminli }) {
  const live = CANLI.includes(x.s);
  const fin = BITTI.includes(x.s);
  const iptal = ['PST', 'CANC', 'ABD', 'SUSP'].includes(x.s);
  const g = (v) => (v === null || v === undefined ? '' : String(v));
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, paddingHorizontal: 12, borderTopWidth: 1, borderTopColor: C.line }}>
      <View style={{ width: 46, alignItems: 'flex-start' }}>
        {live ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 2 }}>
            <Nabiz size={5} />
            <Text style={{ color: C.red, fontWeight: '800', fontSize: 13 }}>{dakika(x, updatedAt)}</Text>
          </View>
        ) : <Text style={{ color: fin ? C.mut : C.ink, fontWeight: '700', fontSize: 13 }}>{fin ? 'MS' : iptal ? 'Ert.' : x.t}</Text>}
      </View>
      <View style={{ flex: 1, gap: 6 }}>
        {[[x.h, x.hl, x.g?.[0]], [x.a, x.al, x.g?.[1]]].map(([n, l, sc], i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Crest name={n} logo={l} size={18} />
            <Text numberOfLines={1} style={{ flex: 1, color: C.ink, fontWeight: '600', fontSize: 14 }}>{n}</Text>
            <Text style={{ width: 22, textAlign: 'right', fontWeight: '800', fontSize: 15, color: live ? C.red : C.ink }}>{live || fin ? g(sc) : ''}</Text>
          </View>
        ))}
      </View>
      {tahminli ? <Text style={{ fontSize: 14 }}>🎯</Text> : null}
      {(x.ev || []).some((e) => e.t === 'red') ? <View style={{ width: 8, height: 11, borderRadius: 2, backgroundColor: '#E5484D' }} /> : null}
      <Icon name="chevron-forward" size={16} color={C.mut} />
    </Pressable>
  );
}
/* Canlı skordaki maça dokununca: skor, goller, kartlar, değişiklikler */
function SkorDetay({ x, updatedAt, tahmin, onMatch, onClose }) {
  const t = useTheme();
  const live = CANLI.includes(x.s);
  const fin = BITTI.includes(x.s);
  const ev = x.ev || [];
  const lig = (SKOR_LIGLER.find(([i]) => i === x.l) || [])[1] || '';
  const g = (v) => (v === null || v === undefined ? '-' : String(v));
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ backgroundColor: C.hero, borderRadius: 24, padding: 18 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: '#C5CCD6', fontWeight: '600' }}>{lig}</Text>
          <Text style={{ color: live ? '#FF8A8E' : '#C5CCD6', fontWeight: '800' }}>{live ? `● ${dakika(x, updatedAt) === 'İY' ? 'Devre arası' : dakika(x, updatedAt)}` : fin ? 'Maç sonu' : x.t}</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 14 }}>
          {[[x.h, x.hl], null, [x.a, x.al]].map((y, i) => y ? (
            <View key={i} style={{ width: '36%', alignItems: 'center', gap: 8 }}>
              <Crest name={y[0]} logo={y[1]} size={48} />
              <Text numberOfLines={2} style={{ color: '#fff', fontWeight: '700', textAlign: 'center' }}>{y[0]}</Text>
            </View>
          ) : (
            <Text key={i} style={{ color: '#fff', fontSize: 34, fontWeight: '800' }}>{live || fin ? `${g(x.g?.[0])} – ${g(x.g?.[1])}` : 'vs'}</Text>
          ))}
        </View>
      </View>
      {tahmin ? <Btn kind="acc" icon="analytics-outline" title="Bu maça tahminimizi gör" style={{ marginTop: 12 }} onPress={() => { onClose(); onMatch(tahmin); }} /> : null}
      <Text style={[s.h3, { marginTop: 16, marginBottom: 8 }]}>⏱️ Maç akışı</Text>
      {ev.length ? [...ev].reverse().map((e, i) => (
        <View key={i} style={{ flexDirection: e.s === 'h' ? 'row' : 'row-reverse', alignItems: 'center', gap: 8, paddingVertical: 6, borderTopWidth: i ? 1 : 0, borderTopColor: C.line }}>
          <Text style={{ width: 42, textAlign: e.s === 'h' ? 'left' : 'right', color: C.mut, fontWeight: '700', fontSize: 12.5 }}>{e.m}'</Text>
          <Text style={{ fontSize: 14 }}>{OLAY[e.t] || '•'}</Text>
          <Text numberOfLines={1} style={{ flex: 1, textAlign: e.s === 'h' ? 'left' : 'right', color: C.ink, fontWeight: ['goal', 'pen', 'og'].includes(e.t) ? '800' : '500' }}>
            {e.p}{e.t === 'sub' && e.a ? ` ↔ ${e.a}` : ''}
          </Text>
        </View>
      )) : (
        <Text style={[s.sub, { marginBottom: 8 }]}>{live || fin ? 'Henüz gol ya da kart yok.' : 'Maç başlayınca goller ve kartlar burada görünecek.'}</Text>
      )}
      <Text style={[s.note, { marginTop: 10, marginBottom: 8 }]}>Ev sahibi solda, deplasman sağda. Birkaç dakikada bir güncellenir.</Text>
    </Sheet>
  );
}

function CanliSkor({ matches, onMatch }) {
  const sk = useCanliSkor();
  const [acik, setAcik] = useState(null);
  const [filtre, setFiltre] = useState('hepsi');
  const [, tick] = useState(0);
  useEffect(() => { const t = setInterval(() => tick((x) => x + 1), 30000); return () => clearInterval(t); }, []);
  const tahmin = {};
  matches.list.forEach((m) => { if (m.afId) tahmin[m.afId] = m; });
  const sira = (x) => (CANLI.includes(x.s) ? 0 : BITTI.includes(x.s) ? 2 : 1);
  const L = (sk.list || []).filter((x) => filtre === 'hepsi' || CANLI.includes(x.s));
  const gruplar = SKOR_LIGLER.map(([id, ad]) => ({ id, ad, items: L.filter((x) => x.l === id).sort((a, b) => sira(a) - sira(b) || String(a.t).localeCompare(b.t)) }))
    .filter((g) => g.items.length);
  const canliSay = (sk.list || []).filter((x) => CANLI.includes(x.s)).length;
  return (
    <View>
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 12 }}>
        {[['hepsi', 'Bugünün maçları'], ['canli', `🔴 Canlı (${canliSay})`]].map(([k, l]) => (
          <Pressable key={k} onPress={() => setFiltre(k)} style={{ paddingHorizontal: 14, minHeight: 36, borderRadius: 18, justifyContent: 'center', borderWidth: 1.5, borderColor: filtre === k ? C.ink : C.border, backgroundColor: filtre === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: filtre === k ? '800' : '600', color: filtre === k ? C.ink : C.mut, fontSize: 13.5 }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {sk.loading ? <Iskelet n={4} /> : !gruplar.length ? (
        <View style={s.empty}>
          <Text style={[s.h3, { marginBottom: 0 }]}>{filtre === 'canli' ? 'Şu an canlı maç yok' : 'Bugün için maç bilgisi yok'}</Text>
          <Text style={[s.sub, { textAlign: 'center' }]}>Skorlar birkaç dakikada bir kendiliğinden güncellenir.</Text>
        </View>
      ) : gruplar.map((g) => (
        <View key={g.id} style={{ backgroundColor: C.card, borderRadius: 20, marginBottom: 12, overflow: 'hidden' }}>
          <Text style={{ fontWeight: '800', color: C.ink, paddingHorizontal: 14, paddingVertical: 10 }}>{g.ad}</Text>
          {g.items.map((x) => <SkorSatir key={x.i} x={x} updatedAt={sk.updatedAt} tahminli={!!(tahmin[x.i] && !tahmin[x.i].draft)} onPress={() => setAcik(x.i)} />)}
        </View>
      ))}
      {sk.updatedAt ? <Text style={[s.note, { textAlign: 'center', marginBottom: 8 }]}>Son güncelleme {new Date(sk.updatedAt).toTimeString().slice(0, 5)} · 🎯 işaretli maçlarda tahminimiz var</Text> : null}
      {acik && (sk.list || []).find((y) => y.i === acik) ? (
        <SkorDetay x={(sk.list || []).find((y) => y.i === acik)} updatedAt={sk.updatedAt} tahmin={tahmin[acik] && !tahmin[acik].draft ? tahmin[acik] : null} onMatch={onMatch} onClose={() => setAcik(null)} />
      ) : null}
    </View>
  );
}

export default function Canli({ matches, me, onMatch }) {
  const [tab, setTab] = useState('skor');
  return (
    <View>
      <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, gap: 4, marginBottom: 14 }}>
        {[['skor', '⚽ Canlı Skor'], ['tahmin', '🎯 Canlı Tahminler']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }}
            style={{ flex: 1, minHeight: 42, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: tab === k ? C.card : 'transparent' }}>
            <Text style={{ fontWeight: tab === k ? '800' : '600', color: tab === k ? C.ink : C.mut }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {tab === 'skor' ? <CanliSkor matches={matches} onMatch={onMatch} /> : <TahminCanli matches={matches} me={me} onMatch={onMatch} />}
    </View>
  );
}
