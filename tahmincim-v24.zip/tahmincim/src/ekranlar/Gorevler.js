// 🎯 Günlük görevler
import React, { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { C, today } from '../tema';
import { Btn, Icon, Sheet, s, useTheme, useToast } from '../parcalar';
import { GOREVLER, useGorev } from '../gorev';

export default function Gorevler({ me, cfg, carkHazir, onCark, onClaim, onClose }) {
  const t = useTheme();
  const toast = useToast();
  const { st, done, total, all } = useGorev();
  const [busy, setBusy] = useState(false);
  const odul = Math.max(0, Number(cfg.rewards?.tasks ?? 2) || 0);
  const claimed = me.taskDay === today();
  const claim = async () => {
    if (!me || me.guest) return toast('Ödül almak için ücretsiz kayıt ol');
    setBusy(true);
    try { await onClaim(); toast(`+${odul} anahtar hesabında 🎉`); }
    catch (e) { toast(e.message === 'alindi' ? 'Bugünün ödülünü zaten aldın' : 'Ödül kaydedilemedi, tekrar dene'); }
    setBusy(false);
  };
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h2}>🎯 Günlük görevler</Text>
      <Text style={[s.sub, { marginTop: 4, marginBottom: 12 }]}>Hepsini bitir, +{odul} anahtar kazan. Görevler her gece yenilenir.</Text>
      <View style={{ height: 10, borderRadius: 5, backgroundColor: C.track, overflow: 'hidden', marginBottom: 14 }}>
        <View style={{ width: `${(done / total) * 100}%`, height: 10, backgroundColor: t.acc }} />
      </View>
      {GOREVLER.map((g) => {
        const c = Math.min(g.n, st.c[g.k] || 0);
        const ok = c >= g.n;
        const go = g.k === 'cark' && !ok && carkHazir ? onCark : null;
        return (
          <Pressable key={g.k} disabled={!go} onPress={go} style={[s.row, { minHeight: 56, opacity: ok ? 0.75 : 1 }]}>
            <Text style={{ fontSize: 22 }}>{g.e}</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.ink, textDecorationLine: ok ? 'line-through' : 'none' }}>{g.t}</Text>
              {g.n > 1 ? <Text style={{ color: C.mut, fontSize: 12.5 }}>{c}/{g.n}</Text> : go ? <Text style={{ color: C.okTx, fontSize: 12.5, fontWeight: '700' }}>Dokun, çarkı çevir →</Text> : null}
            </View>
            <Icon name={ok ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={ok ? C.okTx : C.border} />
          </Pressable>
        );
      })}
      {claimed ? (
        <View style={{ backgroundColor: C.okBg, borderRadius: 14, padding: 14, marginTop: 6 }}>
          <Text style={{ color: C.okTx, fontWeight: '800', textAlign: 'center' }}>✓ Bugünün ödülünü aldın. Yarın yeni görevler!</Text>
        </View>
      ) : (
        <Btn title={all ? `🎁 Ödülü al (+${odul} anahtar)` : `${done}/${total} tamamlandı`} disabled={!all || !odul} loading={busy} onPress={claim} style={{ marginTop: 6 }} />
      )}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 4 }} />
    </Sheet>
  );
}
