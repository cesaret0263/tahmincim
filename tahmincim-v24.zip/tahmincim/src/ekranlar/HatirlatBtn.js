import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { C, canPredictScore } from '../tema';
import { Icon, useToast } from '../parcalar';
import { useReminders, addReminder, removeReminder } from '../hatirlat';
import { followMatch, useMyFollows } from '../topluluk';

// 🔔 Maçı takip et: başlamadan 15 dk önce hatırlatma + gol ve maç sonu bildirimi
export default function HatirlatBtn({ m, me, compact }) {
  const map = useReminders();
  const toast = useToast();
  const uid = me && !me.guest ? me.id : null;
  const follows = useMyFollows(uid);
  const [busy, setBusy] = useState(false);
  if (!m || m.status === 'finished') return null;
  const yakinda = canPredictScore(m);
  const rem = !!map[m.id] && !map[m.id].off;
  const fol = !!uid && follows.list.some((f) => f.matchId === m.id);
  const on = fol || rem;
  const press = async () => {
    if (busy) return;
    setBusy(true);
    try {
      if (on) {
        if (rem) await removeReminder(m.id);
        if (fol) await followMatch(m.id, uid, false);
        toast('Takip bırakıldı');
      } else {
        let r = 'ok';
        if (yakinda) r = await addReminder(m);
        if (uid) await followMatch(m.id, uid, true);
        if (r === 'perm') toast('Bildirim izni vermen gerekiyor');
        else if (!uid) toast(yakinda ? '🔔 15 dk önce hatırlatacağız · Gol bildirimi için ücretsiz kayıt ol' : 'Gol bildirimi için ücretsiz kayıt ol');
        else toast(yakinda ? '🔔 Takipte: başlamadan önce hatırlatıp gollerde haber vereceğiz' : '🔔 Takipte: gollerde ve maç sonunda haber vereceğiz');
      }
    } catch (e) { toast('Olmadı, tekrar dene'); }
    setBusy(false);
  };
  if (compact) {
    return (
      <Pressable onPress={press} accessibilityRole="button" accessibilityLabel={on ? 'Takibi bırak' : 'Maçı takip et'} hitSlop={6}
        style={{ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.lockBg : 'transparent' }}>
        <Icon name={on ? 'notifications' : 'notifications-outline'} size={20} color={on ? C.lockTx : C.mut} />
      </Pressable>
    );
  }
  return (
    <Pressable onPress={press} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 52, borderRadius: 14, marginTop: 12, paddingHorizontal: 14, backgroundColor: on ? C.lockBg : C.bg, borderWidth: 1, borderColor: on ? C.lockBg : C.border }}>
      <Icon name={on ? 'notifications' : 'notifications-outline'} size={22} color={on ? C.lockTx : C.ink} />
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '800', color: on ? C.lockTx : C.ink }}>{on ? 'Takip ediliyor · bırak' : 'Maçı takip et'}</Text>
        <Text style={{ color: on ? C.lockTx : C.mut, fontSize: 12.5 }}>{yakinda ? 'Başlamadan 15 dk önce hatırlatma + gol bildirimi' : 'Gol ve maç sonu bildirimi'}</Text>
      </View>
    </Pressable>
  );
}
