// Herkese açık kullanıcı profili: rozetler, Tribün ve Skor Ligi başarısı
import React from 'react';
import { View, Text } from 'react-native';
import { C, tribuneStatus, isVerified, scorePoints, monthKey } from '../tema';
import { Avatar, Btn, Sheet, s } from '../parcalar';
import { useUserScores } from '../topluluk';
import { onceLabel } from './Etkilesim';

export default function ProfilPenceresi({ p, tribune, matches, onClose }) {
  const scores = useUserScores(p.uid);
  const mine = (tribune?.list || []).filter((x) => x.uid === p.uid);
  const st = mine.map((x) => ({ x, st: tribuneStatus(x, matches.list) }));
  const won = st.filter((y) => y.st === 'won').length;
  const lost = st.filter((y) => y.st === 'lost').length;
  const pct = won + lost ? Math.round((won / (won + lost)) * 100) : null;
  const byId = {};
  matches.list.forEach((m) => { byId[m.id] = m; });
  const mk = monthKey();
  let pts = 0; let exact = 0; let monthPts = 0;
  scores.list.forEach((sc) => {
    const pt = scorePoints(sc, byId[sc.matchId]);
    if (pt == null) return;
    pts += pt; if (pt === 3) exact++;
    if (sc.month === mk) monthPts += pt;
  });
  const last = scores.list[0] || mine[0];
  const name = p.name || last?.name || 'Üye';
  const avatar = p.avatar || last?.avatar || '';
  const badges = [];
  if (mine.length >= 1) badges.push(['🧾', 'Kuponcu']);
  if (won >= 5) badges.push(['🏆', 'Kupon ustası']);
  if (pct != null && won + lost >= 5 && pct >= 60) badges.push(['🎯', 'Keskin nişancı']);
  if (scores.list.length >= 10) badges.push(['⚽', 'Lig oyuncusu']);
  if (exact >= 3) badges.push(['🔮', 'Skor kahini']);
  const Kutu = ({ v, l }) => (
    <View style={{ flex: 1, backgroundColor: C.bg, borderRadius: 16, padding: 12, alignItems: 'center' }}>
      <Text style={{ fontSize: 22, fontWeight: '800', color: C.ink }}>{v}</Text>
      <Text style={{ fontSize: 12, color: C.mut, textAlign: 'center' }}>{l}</Text>
    </View>
  );
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ alignItems: 'center', gap: 6 }}>
        <Avatar emoji={avatar} name={name} size={72} />
        <Text style={[s.h2, { marginTop: 4 }]}>{name}</Text>
        {badges.length ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 6, marginTop: 4 }}>
            {badges.map(([e, l]) => (
              <View key={l} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 }}>
                <Text>{e}</Text><Text style={{ fontWeight: '700', color: C.ink, fontSize: 12.5 }}>{l}</Text>
              </View>
            ))}
          </View>
        ) : null}
      </View>
      <Text style={[s.h3, { marginTop: 18 }]}>🧾 Tribün</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Kutu v={mine.length} l="Kupon" />
        <Kutu v={won} l="Tuttu" />
        <Kutu v={pct == null ? '–' : `%${pct}`} l="Başarı" />
      </View>
      <Text style={[s.h3, { marginTop: 16 }]}>⚽ Skor Ligi</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Kutu v={monthPts} l="Bu ay puan" />
        <Kutu v={pts} l="Toplam puan" />
        <Kutu v={exact} l="Tam skor" />
      </View>
      {mine.length ? (
        <View style={{ marginTop: 16 }}>
          <Text style={s.h3}>Son kuponları</Text>
          {st.slice(0, 5).map(({ x, st: k }) => (
            <View key={x.id} style={[s.row, { minHeight: 0, paddingVertical: 10, backgroundColor: C.bg }]}>
              <Text style={{ flex: 1, color: C.ink, fontWeight: '600' }}>{(x.picks || []).length} maçlık kupon{!isVerified(x) ? ' · doğrulanmamış' : ''}</Text>
              <Text style={{ color: C.mut, fontSize: 12 }}>{onceLabel(x.createdAt)}</Text>
              <Text style={{ fontWeight: '800', color: k === 'won' ? C.okTx : k === 'lost' ? C.red : C.mut }}>{k === 'won' ? '✓' : k === 'lost' ? '✕' : '…'}</Text>
            </View>
          ))}
        </View>
      ) : null}
      <Btn kind="ghost" title="Kapat" onPress={onClose} style={{ marginTop: 8 }} />
    </Sheet>
  );
}
