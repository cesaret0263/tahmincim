// Maç hatırlatıcı: maçtan 15 dk önce telefona yerel bildirim (sunucu gerekmez)
import { useEffect, useState } from 'react';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { matchStart } from './tema';

let N = null;
try { N = require('expo-notifications'); } catch (e) { N = null; }

const KEY = 'tahmincim_hatirlat';
const BEFORE = 15 * 60 * 1000;
let cache = null;
const subs = new Set();

async function load() {
  if (cache) return cache;
  try { cache = JSON.parse((await AsyncStorage.getItem(KEY)) || '{}') || {}; } catch (e) { cache = {}; }
  // Geçmiş maçları temizle
  const now = Date.now();
  Object.keys(cache).forEach((k) => { if ((cache[k]?.at || 0) < now) delete cache[k]; });
  return cache;
}
async function save() {
  try { await AsyncStorage.setItem(KEY, JSON.stringify(cache || {})); } catch (e) {}
  subs.forEach((f) => f({ ...(cache || {}) }));
}

export function useReminders() {
  const [map, setMap] = useState(cache || {});
  useEffect(() => {
    let on = true;
    load().then((c) => on && setMap({ ...c }));
    subs.add(setMap);
    return () => { on = false; subs.delete(setMap); };
  }, []);
  return map;
}

// Sonuç: 'ok' | 'perm' | 'past' | 'none'
export async function addReminder(m) {
  if (!N) return 'none';
  const at = matchStart(m) - BEFORE;
  if (!at || at < Date.now() + 30 * 1000) return 'past';
  try {
    if (Platform.OS === 'android') {
      await N.setNotificationChannelAsync('hatirlat', { name: 'Maç hatırlatıcı', importance: N.AndroidImportance.HIGH });
    }
    let { status } = await N.getPermissionsAsync();
    if (status !== 'granted') ({ status } = await N.requestPermissionsAsync());
    if (status !== 'granted') return 'perm';
    await load();
    if (cache[m.id] && cache[m.id].nid) { try { await N.cancelScheduledNotificationAsync(cache[m.id].nid); } catch (e) {} }
    const content = { title: '⏰ Maç 15 dakika sonra başlıyor', body: `${m.home} – ${m.away} · ${m.time}`, data: { matchId: m.id } };
    const date = new Date(at);
    const T = N.SchedulableTriggerInputTypes;
    const trigger = T ? { type: T.DATE, date, channelId: 'hatirlat' } : { date, channelId: 'hatirlat' };
    const nid = await N.scheduleNotificationAsync({ content, trigger });
    cache[m.id] = { nid, at };
    await save();
    return 'ok';
  } catch (e) {
    return 'none';
  }
}

export async function removeReminder(id) {
  await load();
  const r = cache[id];
  if (r && r.nid && N) { try { await N.cancelScheduledNotificationAsync(r.nid); } catch (e) {} }
  // Kullanıcı kapattıysa otomatik (favori takım) hatırlatıcı tekrar kurulmasın
  if (r) cache[id] = { off: true, at: r.at };
  else delete cache[id];
  await save();
}

// Favori takımın yaklaşan maçlarına otomatik hatırlatıcı (kullanıcı kapatmadıysa)
export async function autoRemind(list) {
  if (!N || !list.length) return;
  try {
    const { status } = await N.getPermissionsAsync();
    if (status !== 'granted') return;
  } catch (e) { return; }
  await load();
  for (const m of list) { if (!cache[m.id]) await addReminder(m); }
}
