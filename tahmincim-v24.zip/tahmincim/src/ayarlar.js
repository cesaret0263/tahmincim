// Firebase bilgileri (canlimac-b1d65 projesi)
export const firebaseConfig = {
  apiKey: 'AIzaSyDlZxMMdQaWh1rHZOEcNJYBuIZ3JuBEwVY',
  authDomain: 'canlimac-b1d65.firebaseapp.com',
  projectId: 'canlimac-b1d65',
  storageBucket: 'canlimac-b1d65.firebasestorage.app',
  messagingSenderId: '525530723511',
  appId: '1:525530723511:web:b4456b4238dda3657d0932',
};

// İstersen admin e-postanı buraya yaz. Boş bırakırsan Firebase'de eklediğin
// kullanıcıyla giriş yapan herkes admin panelini görür; veri yazma yetkisi
// zaten firestore.rules içindeki e-postayla korunuyor.
export const ADMIN_EMAIL = 'blackman0233@gmail.com';
