// Günlük görevler: yapılan işler telefonda günlük tutulur
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { today } from './tema';

const KEY = 'tahmincim_gorev';
let cache = null;
const subs = new Set();

export const GOREVLER = [
  { k: 'giris', e: '👋', t: 'Uygulamaya gir', n: 1 },
  { k: 'cark', e: '🎡', t: 'Şans çarkını çevir', n: 1 },
  { k: 'incele', e: '🔍', t: '3 tahmin incele', n: 3 },
  { k: 'skor', e: '⚽', t: 'Skor Ligi\'nde 1 tahmin yap', n: 1 },
  { k: 'yorum', e: '💬', t: '1 yorum yaz ya da oy ver', n: 1 },
  { k: 'paylas', e: '📤', t: 'Bir kupon ya da tahmin paylaş', n: 1 },
];

async function load() {
  if (cache && cache.day === today()) return cache;
  try { cache = JSON.parse((await AsyncStorage.getItem(KEY)) || 'null'); } catch (e) { cache = null; }
  if (!cache || cache.day !== today()) cache = { day: today(), c: {} };
  return cache;
}
async function save() {
  try { await AsyncStorage.setItem(KEY, JSON.stringify(cache)); } catch (e) {}
  subs.forEach((f) => f({ ...cache, c: { ...cache.c } }));
}
export async function gorevYap(k, n = 1) {
  await load();
  cache.c[k] = (cache.c[k] || 0) + n;
  await save();
}
export async function gorevAyarla(k, v) {
  await load();
  if ((cache.c[k] || 0) >= v) return;
  cache.c[k] = v;
  await save();
}
export function useGorev() {
  const [st, setSt] = useState(cache && cache.day === today() ? cache : { day: today(), c: {} });
  useEffect(() => {
    let on = true;
    load().then((c) => on && setSt({ ...c, c: { ...c.c } }));
    subs.add(setSt);
    return () => { on = false; subs.delete(setSt); };
  }, []);
  const done = GOREVLER.filter((g) => (st.c[g.k] || 0) >= g.n).length;
  return { st, done, total: GOREVLER.length, all: done === GOREVLER.length };
}
