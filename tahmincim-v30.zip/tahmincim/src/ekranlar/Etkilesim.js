import { engelliMi, engelleSor } from '../sosyal';
import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Alert } from 'react-native';
import { C, canModerate } from '../tema';
import { modLog } from '../veri';
import { profilAc } from '../profil';
import { gorevAyarla } from '../gorev';
import { Icon, s, useTheme, useToast, Sheet, Btn, Tik, Avatar } from '../parcalar';
import { useVotes, castVote, useComments, addComment, deleteComment, addReport, useThreadVotes, pinAdmin, usePollVotes, votePoll } from '../topluluk';

let lastSentAt = 0;
const GAP_SN = 30;          // iki yorum arası en az 30 sn
const ARKA_ARKAYA_DK = 10;  // son yorum senin ise 10 dk bekle (başkası yazmadıkça)

export function onceLabel(ms) {
  const d = Math.max(0, Date.now() - (ms || 0)) / 1000;
  if (d < 60) return 'az önce';
  if (d < 3600) return `${Math.floor(d / 60)} dk önce`;
  if (d < 86400) return `${Math.floor(d / 3600)} sa önce`;
  return `${Math.floor(d / 86400)} gün önce`;
}

/* 👍 / 👎 katılıyorum çubuğu */
export function VoteBar({ target, me, onNeedAuth, compact }) {
  const t = useTheme();
  const toast = useToast();
  const votes = useVotes(target);
  const up = votes.filter((v) => v.v === 1).length;
  const down = votes.filter((v) => v.v === -1).length;
  const mine = me && !me.guest ? (votes.find((v) => v.uid === me.id) || {}).v : undefined;
  const total = up + down;
  const pct = total ? Math.round((up / total) * 100) : 0;
  const vote = async (v) => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    try { await castVote(target, me.id, v, mine); gorevAyarla('yorum', 1); } catch (e) { toast('Oy verilemedi'); }
  };
  const B = ({ v, icon, label, n }) => {
    const on = mine === v;
    return (
      <Pressable onPress={() => vote(v)} accessibilityRole="button" accessibilityState={{ selected: on }}
        style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 44, borderRadius: 14, borderWidth: on ? 2 : 1.5, borderColor: on ? (v === 1 ? t.acc : C.red) : C.border, backgroundColor: on ? (v === 1 ? C.okBg : C.redBg) : C.card }}>
        <Icon name={icon} size={18} color={on ? (v === 1 ? C.okTx : C.red) : C.mut} />
        <Text style={{ fontWeight: '700', color: on ? (v === 1 ? C.okTx : C.red) : C.ink }}>{label}{compact ? '' : ` · ${n}`}</Text>
      </Pressable>
    );
  };
  return (
    <View style={{ marginTop: 12 }}>
      {total ? (
        <View style={{ marginBottom: 8 }}>
          <View style={{ flexDirection: 'row', height: 8, borderRadius: 6, overflow: 'hidden', backgroundColor: C.redBg }}>
            <View style={{ width: `${pct}%`, backgroundColor: t.acc }} />
          </View>
          <Text style={{ color: C.mut, fontSize: 13, marginTop: 4 }}>Kullanıcıların %{pct}'i bu tahmine katılıyor ({total} oy)</Text>
        </View>
      ) : null}
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <B v={1} icon="thumbs-up" label="Katılıyorum" n={up} />
        <B v={-1} icon="thumbs-down" label="Katılmıyorum" n={down} />
      </View>
    </View>
  );
}

/* Yorumlar */
export function Yorumlar({ target, me, isAdmin, onNeedAuth }) {
  const t = useTheme();
  const toast = useToast();
  const { list: raw } = useComments(target);
  const list = pinAdmin(raw.filter((c) => !engelliMi(me, c.uid)));   // engellediklerinin yorumları görünmez
  const cv = useThreadVotes(target);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    if (me.muted) return toast('Bir süre yorum yapman kısıtlandı');
    const v = text.trim();
    if (v.length < 2) return;
    if (!canModerate(me)) {
      const last = raw[raw.length - 1];
      const now = Date.now();
      if (last && last.uid === me.id && now - (last.createdAt || 0) < ARKA_ARKAYA_DK * 60000)
        return toast('Üst üste yorum yapamazsın. Başkası yazsın ya da biraz bekle 🙂');
      if (now - lastSentAt < GAP_SN * 1000) return toast(`Yeni yorum için ${Math.ceil((GAP_SN * 1000 - (now - lastSentAt)) / 1000)} sn bekle`);
      if (raw.some((c) => c.uid === me.id && String(c.text).trim().toLocaleLowerCase('tr') === v.toLocaleLowerCase('tr'))) return toast('Aynı yorumu zaten yazdın');
    }
    setBusy(true);
    try { await addComment(target, me.id, isAdmin ? (me.adminName || me.name || 'Admin') : (me.name || 'Üye'), v, isAdmin, me.avatar, me.role === 'mod'); setText(''); lastSentAt = Date.now(); gorevAyarla('yorum', 1); } catch (e) { toast('Gönderilemedi'); }
    setBusy(false);
  };
  const more = (c) => {
    const own = me && c.uid === me.id;
    const btns = [];
    if (own || canModerate(me)) btns.push({ text: 'Sil', style: 'destructive', onPress: () => deleteComment(c.id).then(() => { toast('Yorum silindi'); if (!own) modLog(me, 'Yorum sildi', `${c.name}: ${c.text}`); }).catch(() => toast('Silinemedi')) });
    if (!own && me && !me.guest && !canModerate(me)) btns.push({ text: 'Şikayet et', onPress: () => addReport('comment', c.id, c.text, me.id).then(() => toast('Teşekkürler, inceleyeceğiz')).catch(() => toast('Gönderilemedi')) });
    if (!own && me && !me.guest && !c.admin) btns.push({ text: 'Engelle', style: 'destructive', onPress: () => engelleSor(me, { uid: c.uid, name: c.name }, toast) });
    if (!btns.length) return;
    Alert.alert('Yorum', c.text.slice(0, 80), [{ text: 'Vazgeç', style: 'cancel' }, ...btns].slice(-3), { cancelable: true });
  };
  return (
    <View style={{ marginTop: 16 }}>
      <Text style={[s.h3, { marginBottom: 8 }]}>💬 Yorumlar {list.length ? `(${list.length})` : ''}</Text>
      {!list.length ? <Text style={[s.sub, { marginBottom: 8 }]}>İlk yorumu sen yaz!</Text> : list.map((c) => (
        <Pressable key={c.id} onLongPress={() => more(c)} onPress={() => more(c)} style={{ backgroundColor: c.admin ? C.selBg : C.bg, borderRadius: 14, padding: 12, marginBottom: 8, borderWidth: c.admin ? 1.5 : 0, borderColor: t.acc }}>
          {c.admin ? <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 11.5, marginBottom: 4 }}>📌 SABİTLENDİ</Text> : null}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 1 }}>
              <Pressable onPress={() => profilAc({ uid: c.uid, name: c.name, avatar: c.avatar })} hitSlop={6} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 1 }}>
                <Avatar emoji={c.avatar} name={c.name} size={24} />
                <Text numberOfLines={1} style={{ fontWeight: '700', color: C.ink, flexShrink: 1 }}>{c.name || 'Üye'}{me && c.uid === me.id ? ' (sen)' : ''}</Text>
              </Pressable>
              {c.admin ? <Tik size={15} label="Admin" /> : c.mod ? <Text style={{ color: C.okTx, fontWeight: '800', fontSize: 11.5 }}>🛡️ Moderatör</Text> : null}
            </View>
            <Text style={{ color: C.mut, fontSize: 12 }}>{onceLabel(c.createdAt)} ⋯</Text>
          </View>
          <Text style={{ color: C.ink, lineHeight: 20 }}>{c.text}</Text>
          <YorumOy c={c} votes={cv} me={me} thread={target} onNeedAuth={onNeedAuth} />
        </Pressable>
      ))}
      {me && !me.guest ? (
        <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', marginTop: 4 }}>
          <TextInput value={text} onChangeText={setText} placeholder="Yorumunu yaz…" placeholderTextColor={C.mut} multiline maxLength={500} accessibilityLabel="Yorum"
            style={[s.input, { flex: 1, minHeight: 46, maxHeight: 120 }]} />
          <Pressable onPress={send} disabled={busy} accessibilityLabel="Gönder" style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', opacity: busy ? 0.5 : 1 }}>
            <Icon name="send" size={20} color={t.onAcc} />
          </Pressable>
        </View>
      ) : (
        <Btn small kind="out" title="Yorum yazmak için giriş yap" onPress={onNeedAuth} />
      )}
      <Text style={[s.note, { marginTop: 8 }]}>Bir yoruma dokunarak silebilir ya da şikayet edebilirsin.</Text>
    </View>
  );
}

/* Kupon için beğeni + yorum penceresi */
export function EtkilesimPenceresi({ target, title, me, isAdmin, onNeedAuth, onClose }) {
  return (
    <Sheet visible onClose={onClose}>
      <Text style={s.h1}>{title}</Text>
      <VoteBar target={target} me={me} onNeedAuth={onNeedAuth} />
      <Yorumlar target={target} me={me} isAdmin={isAdmin} onNeedAuth={onNeedAuth} />
    </Sheet>
  );
}

/* Yorum altı 👍 / 👎 */
function YorumOy({ c, votes, me, thread, onNeedAuth }) {
  const toast = useToast();
  const tgt = 'cm_' + c.id;
  const mineV = votes.filter((v) => v.target === tgt);
  const up = mineV.filter((v) => v.v === 1).length;
  const down = mineV.filter((v) => v.v === -1).length;
  const my = me && !me.guest ? (mineV.find((v) => v.uid === me.id) || {}).v : undefined;
  const vote = (v) => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    castVote(tgt, me.id, v, my, thread).then(() => gorevAyarla('yorum', 1)).catch(() => toast('Oy verilemedi'));
  };
  const B = ({ v, icon, n }) => (
    <Pressable onPress={() => vote(v)} hitSlop={6} accessibilityRole="button" accessibilityLabel={v === 1 ? 'Beğen' : 'Beğenme'} accessibilityState={{ selected: my === v }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, minHeight: 32, borderRadius: 16, backgroundColor: my === v ? (v === 1 ? C.okBg : C.redBg) : C.card }}>
      <Icon name={my === v ? icon : icon + '-outline'} size={15} color={my === v ? (v === 1 ? C.okTx : C.red) : C.mut} />
      <Text style={{ fontWeight: '700', fontSize: 13, color: my === v ? (v === 1 ? C.okTx : C.red) : C.mut }}>{n}</Text>
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
      <B v={1} icon="thumbs-up" n={up} />
      <B v={-1} icon="thumbs-down" n={down} />
    </View>
  );
}

/* 📊 Maç anketi */
export function Anket({ m, me, onNeedAuth }) {
  const t = useTheme();
  const toast = useToast();
  const { list } = usePollVotes(m && m.poll ? m.id : null);
  if (!m || !m.poll || !(m.poll.opts || []).length) return null;
  const opts = m.poll.opts;
  const mine = me && !me.guest ? list.find((v) => v.uid === me.id) : null;
  const total = list.length;
  const show = !!mine || m.status === 'finished';
  const vote = (i) => {
    if (!me || me.guest || !me.id) return onNeedAuth && onNeedAuth();
    if (me.banned) return toast('Hesabın askıya alındı');
    votePoll(m.id, me.id, i).then(() => gorevAyarla('yorum', 1)).catch(() => toast('Oy verilemedi'));
  };
  return (
    <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 16, marginTop: 12 }}>
      <Text style={{ color: C.mut, fontWeight: '800', fontSize: 12, letterSpacing: 1 }}>📊 ANKET</Text>
      <Text style={[s.h3, { marginTop: 4, marginBottom: 10 }]}>{m.poll.q}</Text>
      {opts.map((o, i) => {
        const n = list.filter((v) => v.opt === i).length;
        const pct = total ? Math.round((n / total) * 100) : 0;
        const sel = mine && mine.opt === i;
        return (
          <Pressable key={i} onPress={() => vote(i)} accessibilityRole="button" accessibilityState={{ selected: !!sel }}
            style={{ minHeight: 46, borderRadius: 14, marginBottom: 8, overflow: 'hidden', borderWidth: sel ? 2 : 1.5, borderColor: sel ? t.acc : C.border, backgroundColor: C.card, justifyContent: 'center' }}>
            {show ? <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${pct}%`, backgroundColor: sel ? C.selBg : C.track }} /> : null}
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14 }}>
              <Text style={{ flex: 1, fontWeight: sel ? '800' : '600', color: C.ink }}>{o}{sel ? '  ✓' : ''}</Text>
              {show ? <Text style={{ fontWeight: '800', color: C.ink }}>%{pct}</Text> : null}
            </View>
          </Pressable>
        );
      })}
      <Text style={{ color: C.mut, fontSize: 12.5 }}>{total} oy{!show ? ' · oy verince sonuçları gör' : mine ? ' · fikrini değiştirmek için başka seçeneğe dokun' : ''}</Text>
    </View>
  );
}

/* 📈 Form kartı */
const FR = { G: '#16A34A', B: '#8A94A3', M: '#E5484D' };
export function FormKart({ m }) {
  const hf = String(m.homeForm || '');
  const af = String(m.awayForm || '');
  const h2h = String(m.h2h || '').split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 5);
  if (!hf && !af && !h2h.length) return null;
  const Satir = ({ name, f }) => (f ? (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
      <Text numberOfLines={1} style={{ flex: 1, fontWeight: '700', color: C.ink }}>{name}</Text>
      {f.split('').map((c, i) => (
        <View key={i} style={{ width: 26, height: 26, borderRadius: 7, backgroundColor: FR[c] || C.track, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{c}</Text>
        </View>
      ))}
    </View>
  ) : null);
  return (
    <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 16, marginTop: 12 }}>
      <Text style={[s.h3, { marginBottom: 10 }]}>📈 Form durumu</Text>
      <Satir name={m.home} f={hf} />
      <Satir name={m.away} f={af} />
      {(hf || af) ? <Text style={{ color: C.mut, fontSize: 12, marginBottom: h2h.length ? 10 : 0 }}>Son 5 maç · soldan sağa eskiden yeniye</Text> : null}
      {h2h.length ? (
        <View>
          <Text style={{ fontWeight: '700', color: C.ink, marginBottom: 6 }}>Aralarındaki son maçlar</Text>
          {h2h.map((x, i) => <Text key={i} style={{ color: C.ink, paddingVertical: 3 }}>⚔️  {x}</Text>)}
        </View>
      ) : null}
    </View>
  );
}

/* 📊 Canlı istatistik + olay akışı */
const IST_AD = [['pos', 'Topla oynama', '%'], ['shots', 'Şut'], ['sot', 'İsabetli şut'], ['corners', 'Korner'], ['saves', 'Kurtarış'], ['fouls', 'Faul'], ['yellow', 'Sarı kart'], ['red', 'Kırmızı kart'], ['offs', 'Ofsayt']];
export const OLAY = { goal: '⚽', pen: '⚽ (P)', og: '⚽ (KK)', mp: '❌ Kaçan penaltı', yellow: '🟨', red: '🟥', sub: '🔄', var: '📺 VAR' };
export function MacIstat({ m }) {
  const t = useTheme();
  const st = m && m.stats;
  const ev = (m && m.events) || [];
  if (!st && !ev.length) return null;
  return (
    <View style={{ backgroundColor: C.bg, borderRadius: 22, padding: 16, marginTop: 12 }}>
      {st ? (
        <View>
          <Text style={[s.h3, { marginBottom: 10 }]}>📊 Maç istatistikleri</Text>
          {IST_AD.filter(([k]) => st[k] && (st[k][0] || st[k][1])).map(([k, l, suf]) => {
            const [h, a] = st[k];
            const tot = h + a || 1;
            return (
              <View key={k} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text style={{ fontWeight: '800', color: C.ink }}>{h}{suf || ''}</Text>
                  <Text style={{ color: C.mut, fontSize: 13, fontWeight: '600' }}>{l}</Text>
                  <Text style={{ fontWeight: '800', color: C.ink }}>{a}{suf || ''}</Text>
                </View>
                <View style={{ flexDirection: 'row', gap: 4, height: 7 }}>
                  <View style={{ flex: 1, backgroundColor: C.track, borderRadius: 4, overflow: 'hidden', alignItems: 'flex-end' }}>
                    <View style={{ width: `${(h / tot) * 100}%`, height: 7, backgroundColor: h >= a ? t.acc : C.mut, borderRadius: 4 }} />
                  </View>
                  <View style={{ flex: 1, backgroundColor: C.track, borderRadius: 4, overflow: 'hidden' }}>
                    <View style={{ width: `${(a / tot) * 100}%`, height: 7, backgroundColor: a >= h ? '#3D8BFF' : C.mut, borderRadius: 4 }} />
                  </View>
                </View>
              </View>
            );
          })}
        </View>
      ) : null}
      {ev.length ? (
        <View style={{ marginTop: st ? 8 : 0 }}>
          <Text style={[s.h3, { marginBottom: 8 }]}>⏱️ Maç akışı</Text>
          {[...ev].reverse().map((e, i) => (
            <View key={i} style={{ flexDirection: e.s === 'h' ? 'row' : 'row-reverse', alignItems: 'center', gap: 8, paddingVertical: 5 }}>
              <Text style={{ width: 40, textAlign: e.s === 'h' ? 'left' : 'right', color: C.mut, fontWeight: '700', fontSize: 12.5 }}>{e.m}'</Text>
              <Text style={{ fontSize: 14 }}>{OLAY[e.t] || '•'}</Text>
              <Text numberOfLines={1} style={{ flex: 1, textAlign: e.s === 'h' ? 'left' : 'right', color: C.ink, fontWeight: ['goal', 'pen', 'og'].includes(e.t) ? '800' : '500' }}>
                {e.p}{e.t === 'sub' && e.a ? ` ↔ ${e.a}` : ['goal', 'pen'].includes(e.t) && e.a ? ` (asist: ${e.a})` : ''}
              </Text>
            </View>
          ))}
        </View>
      ) : null}
      <Text style={[s.note, { marginTop: 6 }]}>Birkaç dakikada bir kendiliğinden güncellenir.</Text>
    </View>
  );
}
