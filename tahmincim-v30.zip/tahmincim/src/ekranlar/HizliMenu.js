// ⚡ Admin hızlı menüsü: maça basılı tutunca açılır (ana sayfada ve admin listesinde)
import React, { useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { C, predText } from '../tema';
import { Crest, Icon, Sheet, s, useToast } from '../parcalar';
import { patchMatch, removeMatch, clearBanko } from '../veri';
import { sendPushAll } from '../bildirim';

export function askNotify(cfg, title, body, toast, topic = 'genel') {
  if (!cfg?.push?.projectId) return;
  setTimeout(() => {
    Alert.alert('Kullanıcılara bildirim gönderilsin mi?', `${title}\n${body}`, [
      { text: 'Hayır', style: 'cancel' },
      { text: 'Gönder 🔔', onPress: () => sendPushAll(title, body, topic).then((r) => toast(`${r.ok} telefona bildirim gitti`)).catch(() => toast('Bildirim gönderilemedi')) },
    ]);
  }, 600);
}

function Satir({ icon, e, title, sub, onPress, red, busy }) {
  return (
    <Pressable onPress={onPress} disabled={busy} accessibilityRole="button"
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 54, paddingHorizontal: 12, borderRadius: 14, backgroundColor: pressed ? C.bg : 'transparent', opacity: busy ? 0.5 : 1 })}>
      <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: red ? C.redBg : C.bg, alignItems: 'center', justifyContent: 'center' }}>
        {e ? <Text style={{ fontSize: 18 }}>{e}</Text> : <Icon name={icon} size={20} color={red ? C.red : C.ink} />}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontWeight: '700', fontSize: 15.5, color: red ? C.red : C.ink }}>{title}</Text>
        {sub ? <Text style={{ color: C.mut, fontSize: 12.5 }}>{sub}</Text> : null}
      </View>
    </Pressable>
  );
}

export default function HizliMenu({ m, all, cfg, onEdit, onClose }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!m) return null;
  const run = async (fn, msg) => {
    setBusy(true);
    try { await fn(); toast(msg); onClose(); } catch (e) { toast('Olmadı, internetini kontrol et'); }
    setBusy(false);
  };
  const sonuc = (r) => run(async () => {
    await patchMatch(m.id, { status: 'finished', result: r });
    if (r === 'won' && m.result !== 'won') askNotify(cfg, '✅ Tahminimiz tuttu!', `${m.home} – ${m.away}${m.score ? ` · ${m.score}` : ''} · ${predText(m)}`, toast, 'tuttu');
  }, r === 'won' ? 'Tuttu olarak işaretlendi ✅' : r === 'lost' ? 'Tutmadı olarak işaretlendi' : 'Sonuç temizlendi');
  const sil = () => Alert.alert('Maç silinsin mi?', `${m.home} – ${m.away} herkesten kaldırılacak.${m.afId ? ' Otomatik maç bir daha gelmez.' : ''}`, [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Sil', style: 'destructive', onPress: () => run(() => removeMatch(m.id, m.afId), 'Maç silindi') },
  ]);
  const basladi = m.status !== 'upcoming';
  return (
    <Sheet visible onClose={onClose}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 }}>
        <Crest name={m.home} logo={m.homeLogo} size={30} />
        <View style={{ flex: 1 }}>
          <Text numberOfLines={1} style={{ fontWeight: '800', fontSize: 16, color: C.ink }}>{m.home} – {m.away}</Text>
          <Text numberOfLines={1} style={{ color: C.mut, fontSize: 13 }}>{m.date} {m.time} · {m.market || 'tahmin yok'}{m.draft ? ' · 📝 Taslak' : ''}{m.banko ? ' · 🔥 Banko' : ''}</Text>
        </View>
        <Crest name={m.away} logo={m.awayLogo} size={30} />
      </View>
      {m.draft && m.market ? <Satir e="🚀" title="Yayınla" sub="Taslaktan çıkar, herkes görsün" busy={busy} onPress={() => run(() => patchMatch(m.id, { draft: false }), 'Yayınlandı')} /> : null}
      {m.robot ? (
        <>
          <View style={{ backgroundColor: C.bg, borderRadius: 12, padding: 10, marginBottom: 6 }}>
            <Text style={{ color: C.mut, fontSize: 12.5 }}>🤖 Bu robotun tahmini. Robotun tahminine dokunulmaz; istersen bu maça kendi tahminini ayrıca yaparsın.</Text>
          </View>
          <Satir e="🎯" title="Kendi tahminini yap" sub="Sıfırdan, robottan ayrı kayıt" busy={busy} onPress={() => { onClose(); onEdit && onEdit(m); }} />
        </>
      ) : <Satir icon="create-outline" title="Düzenle" sub="Tahmin, kilit, skor… hepsi" busy={busy} onPress={() => { onClose(); onEdit && onEdit(m); }} />}
      {m.robot ? null : m.banko
        ? <Satir e="🧯" title="Bankoyu kaldır" sub="Maç normal tahmin olarak kalır" busy={busy} onPress={() => run(() => patchMatch(m.id, { banko: false }), 'Banko kaldırıldı')} />
        : <Satir e="🔥" title="Günün bankosu yap" sub="O günün en üstünde büyük kart olur" busy={busy} onPress={() => run(async () => { await clearBanko(all || [], m.date, m.id); await patchMatch(m.id, { banko: true, draft: false }); }, 'Günün bankosu yapıldı')} />}
      {basladi && !m.robot ? (
        <View style={{ flexDirection: 'row', gap: 8, marginVertical: 6 }}>
          {[['won', '✅ Tuttu'], ['lost', '❌ Tutmadı'], ['', 'Belirsiz']].map(([r, l]) => (
            <Pressable key={l} onPress={() => sonuc(r)} disabled={busy}
              style={{ flex: 1, minHeight: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: m.result === r && (r || m.status === 'finished') ? C.ink : C.border, backgroundColor: C.card }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{l}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      {m.status !== 'finished' || m.buyuk ? (m.buyuk
        ? <Satir e="⭐" title="Büyük maçtan çıkar" sub="Skor tahminleri kalır, puan normale döner" busy={busy} onPress={() => run(() => patchMatch(m.id, { buyuk: false }), 'Büyük maçtan çıkarıldı')} />
        : <Satir e="⭐" title="Büyük maç yap" sub="Bugün'ün en üstünde topluluk skor tahmini · 2 kat puan" busy={busy} onPress={() => run(() => patchMatch(m.id, { buyuk: true, hidden: false }), 'Büyük maç yapıldı ⭐')} />) : null}
      <Satir icon={m.hidden ? 'eye-outline' : 'eye-off-outline'} title={m.hidden ? 'Ana sayfada göster' : 'Ana sayfadan gizle'} sub={m.hidden ? 'Şu an sadece kuponlarda görünüyor' : 'Sadece kuponlarda görünür'} busy={busy}
        onPress={() => run(() => patchMatch(m.id, { hidden: !m.hidden }), m.hidden ? 'Ana sayfada' : 'Gizlendi')} />
      <Satir icon="trash-outline" red title="Sil" sub={m.afId ? 'Otomatik maç bir daha gelmez' : 'Herkesten kaldırılır'} busy={busy} onPress={sil} />
      <Text style={[s.note, { textAlign: 'center', marginTop: 8, marginBottom: 6 }]}>Bu menüyü sadece yöneticiler görür</Text>
    </Sheet>
  );
}
